export type UploadedDocPayload = {
  title: string;
  contentHtml: string;
  fileName: string;
  fileType: "docx" | "pdf" | "doc" | "other";
  fileUrl?: string;
};

function readAsArrayBuffer(file: File): Promise<ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as ArrayBuffer);
    reader.onerror = () => reject(reader.error);
    reader.readAsArrayBuffer(file);
  });
}

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export async function processUploadedFile(file: File): Promise<UploadedDocPayload> {
  const ext = file.name.split(".").pop()?.toLowerCase();
  const title = file.name.replace(/\.[^.]+$/, "");

  if (ext === "docx") {
    const buffer = await readAsArrayBuffer(file);
    const mammoth = await import("mammoth");
    const { value } = await mammoth.convertToHtml({ arrayBuffer: buffer });
    return { title, contentHtml: value, fileName: file.name, fileType: "docx" };
  }

  if (ext === "pdf") {
    const dataUrl = await readAsDataUrl(file);
    return { title, contentHtml: "", fileName: file.name, fileType: "pdf", fileUrl: dataUrl };
  }

  if (ext === "doc") {
    return {
      title,
      contentHtml:
        "<p>Legacy .doc files aren't supported for preview. Please re-save this file as .docx and upload again.</p>",
      fileName: file.name,
      fileType: "doc",
    };
  }

  return {
    title,
    contentHtml: `<p>${file.name} was uploaded, but this file type can't be previewed here.</p>`,
    fileName: file.name,
    fileType: "other",
  };
}
