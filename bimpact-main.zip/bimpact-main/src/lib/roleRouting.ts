import { UserRole } from "@/store/sessionStore";

// Shared contract between the login flow, the AppShell route guard, and the
// post-login transition screen — all three need to agree on where each role
// lands and what path the brief "Preparing your workspace..." transition
// lives at, so it's centralized here instead of duplicated per file.

export const AUTH_TRANSITION_PATH = "/auth/loading";

// Partners land in Workplace (/projects) itself now, not a separate
// simplified page — Workplace filters its project list to the partner's own
// assignments and hides sponsor-only actions (see src/lib/permissions.ts and
// ProjectsTable.tsx). /partner-workspace still exists as a redirect for any
// stale links/bookmarks.
export function getDashboardPathForRole(role: UserRole | null): string {
  if (role === "partner") return "/projects";
  return "/dashboard";
}
