import { ComplianceDocType, PartnerOrg, PartnerType } from "@/types/settings";
import { PartnerComplianceChecklist } from "@/types/partnerForm";
import { COMPLIANCE_CATEGORIES, ComplianceCategory, ComplianceCatalogItem, findComplianceCatalogItem } from "@/data/complianceCatalog";

// The single place that resolves "what compliance documents does this
// Partner actually need to upload" — both the Partner's own /compliance page
// and the Sponsor's read-only Document Review screen must call through here
// rather than keeping their own copies of the required-document list, so the
// two are always looking at the same source of truth (the Sponsor's
// per-Partner-Type PartnerComplianceChecklist, settingsStore's
// `partnerForms`).

// Only an ACTIVE checklist counts — a Draft is still being edited by the
// Sponsor and must never drive a real Partner's requirements, same as the
// Active/Draft distinction the checklist's own builder screen already uses.
export function getActiveChecklistForPartnerType(
  checklists: PartnerComplianceChecklist[],
  partnerType: PartnerType
): PartnerComplianceChecklist | null {
  return checklists.find((c) => c.partnerType === partnerType && c.status === "Active") ?? null;
}

// [] means "nothing currently required" — either no Active checklist exists
// for this partner's type at all, or one exists with zero items selected.
// Callers that need to distinguish those two cases (e.g. to show a "not
// configured" empty state) should use getRequiredComplianceGroups instead.
export function getRequiredItemIdsForPartner(
  partner: PartnerOrg,
  checklists: PartnerComplianceChecklist[]
): string[] {
  return getActiveChecklistForPartnerType(checklists, partner.type)?.selectedItemIds ?? [];
}

export type RequiredComplianceGroup = { category: ComplianceCategory; items: ComplianceCatalogItem[] };

// `configured: false` is the distinct "Sponsor hasn't set up a compliance
// checklist for this Partner Type yet" state — never silently fall back to
// a default/arbitrary list for it (see compliance/page.tsx and
// ComplianceDocumentsSection.tsx's empty states). Categories with no
// selected items are dropped from `groups` — the Partner should never see an
// empty category heading.
export function getRequiredComplianceGroups(
  partner: PartnerOrg,
  checklists: PartnerComplianceChecklist[]
): { configured: boolean; groups: RequiredComplianceGroup[] } {
  const checklist = getActiveChecklistForPartnerType(checklists, partner.type);
  if (!checklist) return { configured: false, groups: [] };

  const selected = new Set(checklist.selectedItemIds);
  const groups: RequiredComplianceGroup[] = COMPLIANCE_CATEGORIES.map((category) => ({
    category,
    items: category.items.filter((item) => selected.has(item.id)),
  })).filter((group) => group.items.length > 0);

  return { configured: true, groups };
}

// Human-readable label for a document type — the catalog item's name, the
// fixed "Other Supporting Documents" label, or (for a legacy/orphaned id
// that no longer matches any catalog entry) the raw id itself as a
// last-resort fallback so nothing ever renders blank.
export function getComplianceDocLabel(type: ComplianceDocType): string {
  if (type === "Other") return "Other Supporting Documents";
  return findComplianceCatalogItem(type)?.item.name ?? type;
}
