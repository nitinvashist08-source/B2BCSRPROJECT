import { PartnerTeamRole } from "@/types/settings";

// Single source of truth for the Partner-side internal team roles — the
// Team Members table (role badges/select) and the Invite Member slide-over
// (role dropdown/radio-cards) both import this instead of each hardcoding
// their own copy of the role list, so the three roles and their
// descriptions can never drift out of sync between the two screens.
export const PARTNER_TEAM_ROLES: { value: PartnerTeamRole; description: string }[] = [
  {
    value: "Manager",
    description: "Senior organizational user with broader management access across the partner's assigned projects.",
  },
  {
    value: "Project Manager",
    description: "Responsible primarily for project-level management and execution on assigned projects.",
  },
  {
    value: "Field Officer",
    description: "Responsible primarily for field-level execution and data collection activities.",
  },
];
