import { Project } from "@/types/project";

// A project's assigned-partner names come from the union of two sources:
// the newer `projectPartners` side-table (multiple partners, set via
// Workplace's "Create Project") and the legacy single `project.partner`
// field older projects still carry. Mirrors the exact resolution logic
// ProjectsTable.tsx uses to render the "Assigned Partner" column, so the
// list a partner sees and the access check below never disagree about
// which projects belong to them.
export function resolveAssignedPartnerNames(
  project: Pick<Project, "id" | "partner">,
  projectPartners: Record<string, string[]>
): string[] {
  return projectPartners[project.id]?.length
    ? projectPartners[project.id]
    : project.partner
      ? [project.partner]
      : [];
}

// Whether `project` is assigned to the partner org named `partnerName`
// (case-sensitive exact match, matching this codebase's existing
// convention — e.g. the retired PartnerWorkspacePage's `proj.partner ===
// partner.name` check).
export function isProjectAssignedToPartner(
  project: Pick<Project, "id" | "partner">,
  projectPartners: Record<string, string[]>,
  partnerName: string | null | undefined
): boolean {
  if (!partnerName) return false;
  return resolveAssignedPartnerNames(project, projectPartners).includes(partnerName);
}
