import { PartnerOrg } from "@/types/settings";

export type InviteValidation = { ok: true; partner: PartnerOrg } | { ok: false };

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

// Every failure mode (not-found / already-consumed / expired) collapses to
// the same {ok:false} result and the same UI message — the spec explicitly
// calls for a used token to show the same expired/invalid state, so there's
// no need (and no UI) to distinguish reasons here.
export function validateInviteToken(partners: PartnerOrg[], token: string | null): InviteValidation {
  if (!token) return { ok: false };
  const partner = partners.find((p) => p.inviteToken === token);
  if (!partner) return { ok: false }; // not found, OR already consumed (activation nulls the token)
  if (partner.status !== "Invited") return { ok: false };
  if (!partner.invitedAt) return { ok: false };
  const age = Date.now() - new Date(partner.invitedAt).getTime();
  if (age > SEVEN_DAYS_MS) return { ok: false };
  return { ok: true, partner };
}
