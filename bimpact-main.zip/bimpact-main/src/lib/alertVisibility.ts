// Single source of truth for "can the current session see this Alert" — used
// by both the Sidebar's unread-count badge and the Alerts page itself, so
// the two can never disagree about what's visible (same convention as
// dashboardScope.ts being the one place Partner<->Project access is
// resolved). Spec section 14 ("Role-Based Alerts") — a Partner must never
// see an alert only a Sponsor can act on, and vice versa.
//
// Visibility falls through four cases, in order:
// 1. `targetPartnerOrgId` set — visible ONLY to that specific Partner org's
//    session (never the Sponsor; e.g. "Micro-Budget assigned to you").
// 2. `targetRole` set (no targetPartnerOrgId) — visible only to a session of
//    that role (e.g. "Partner onboarding pending" is Sponsor's own
//    follow-up item, never shown to any Partner).
// 3. Neither of the above, but `projectId` is set — project-scoped: the
//    Sponsor sees every project's alerts; a Partner sees it only if that
//    project is actually assigned to them (same isProjectAssignedToPartner
//    check Finance/WBS pages already gate on).
// 4. Neither role/partner targeting nor a projectId — these are this app's
//    Sponsor-only org-management surfaces (Board Management meetings,
//    Budget Planning, Settings→Users) with nothing project-specific to
//    scope by, so they default to Sponsor-only. A Partner's nav never even
//    links to those surfaces (see Sidebar.tsx's PARTNER_NAV_GROUPS), so
//    this default matches what a Partner could act on anyway.
import { Alert } from "@/types/alert";
import { Project } from "@/types/project";
import { PartnerOrg } from "@/types/settings";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";
import { DEFAULT_DEMO_WORKSPACE_ID } from "@/store/workspaceStore";

export function isAlertVisible(
  alert: Alert,
  ctx: {
    role: "sponsor" | "partner" | null;
    partnerOrgId: string | null;
    partnerName: string | null;
    workspaceId: string | null;
    projects: Project[];
    projectPartners: Record<string, string[]>;
    partners: PartnerOrg[];
  }
): boolean {
  if (!ctx.role) return false;

  // Partner org alerts (invite pending, review pending, inactive,
  // compliance upload) carry no workspaceId of their own on the Alert
  // record — the referenced PartnerOrg is the source of truth, same
  // workspace-scoping PartnerOrgsTable's old notification banner used, so a
  // Sponsor in one workspace never sees another workspace's partner
  // activity. Seed/legacy partners with no workspaceId are treated as
  // belonging to the shared demo workspace, matching that same convention.
  if (alert.entityType === "partner") {
    const partner = ctx.partners.find((p) => p.id === alert.entityId);
    const partnerWorkspaceId = partner?.workspaceId || DEFAULT_DEMO_WORKSPACE_ID;
    const sessionWorkspaceId = ctx.workspaceId || DEFAULT_DEMO_WORKSPACE_ID;
    if (partnerWorkspaceId !== sessionWorkspaceId) return false;
  }

  if (alert.targetPartnerOrgId) {
    return ctx.role === "partner" && ctx.partnerOrgId === alert.targetPartnerOrgId;
  }
  if (alert.targetRole) {
    return ctx.role === alert.targetRole;
  }
  if (alert.projectId) {
    if (ctx.role === "sponsor") return true;
    const project = ctx.projects.find((p) => p.id === alert.projectId);
    if (!project) return false;
    return isProjectAssignedToPartner(project, ctx.projectPartners, ctx.partnerName);
  }
  return ctx.role === "sponsor";
}
