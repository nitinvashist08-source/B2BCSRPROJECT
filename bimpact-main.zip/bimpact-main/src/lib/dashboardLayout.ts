import { CardLayout } from "@/types/dashboard";

// Underlying grid the free-form drag/resize dashboard snaps to. 12 columns
// is react-grid-layout's own convention and gives enough resolution that
// resizing still feels "free-form" to the user even though every card
// ultimately lands on a whole-unit grid cell.
export const GRID_COLS = 12;
export const ROW_HEIGHT = 32; // px per grid row unit
export const GRID_MARGIN: [number, number] = [16, 16];

// Sensible default footprint for a newly added card — two per row on
// desktop, tall enough that a bar/line/pie chart or a short table renders
// without clipping.
export const DEFAULT_W = 6;
export const DEFAULT_H = 9;

// Minimum size a card can be shrunk to — small enough to free up space, but
// still tall/wide enough to show a title, an axis-labelled chart or a few
// table rows without becoming meaningless.
export const MIN_W = 3;
export const MIN_H = 5;

// A card can never be resized past the full width of the grid, and height is
// capped so one card can't be dragged into an unusably tall column.
export const MAX_W = GRID_COLS;
export const MAX_H = 24;

// Deterministic default layout for a page's visualizations, in their
// `order` sequence — two cards per row, each filling half the grid, stacking
// downward. Used both as the very first layout a page ever gets and as what
// "Reset Dashboard Layout" restores.
export function defaultLayoutForVisualizations(vizIds: string[]): CardLayout[] {
  return vizIds.map((id, index) => ({
    i: id,
    x: (index % 2) * DEFAULT_W,
    y: Math.floor(index / 2) * DEFAULT_H,
    w: DEFAULT_W,
    h: DEFAULT_H,
    minW: MIN_W,
    minH: MIN_H,
    maxW: MAX_W,
    maxH: MAX_H,
  }));
}

// Merges a user's saved layout with the current set of visualizations on a
// page: a card the user has already positioned keeps its saved geometry, a
// card with no saved entry (just added, or saved before it existed) falls
// back to its slot in the default layout. Cards no longer on the page are
// dropped. This is what lets `defaultLayoutForVisualizations` change (e.g. a
// visualization added or removed) without ever crashing on a stale layout
// shaped for a different set of cards.
export function reconcileLayout(
  saved: CardLayout[] | undefined,
  vizIds: string[]
): CardLayout[] {
  const defaults = defaultLayoutForVisualizations(vizIds);
  const savedById = new Map((saved ?? []).map((item) => [item.i, item]));
  return defaults.map((fallback) => {
    const existing = savedById.get(fallback.i);
    if (!existing) return fallback;
    // Always re-apply the current min/max constraints — they're a product
    // rule, not part of what the user customized, so an older persisted
    // layout (e.g. from before MIN_W changed) can't leave a card stuck below
    // today's minimum.
    return { ...fallback, x: existing.x, y: existing.y, w: existing.w, h: existing.h };
  });
}
