import { PartnerOrg } from "@/types/settings";

// Single source of truth for the Partner status → available status-
// management actions matrix, shared by PartnerOrgsTable's row "⋮" menu
// (PartnerStatusMenuItems, DropdownItem-rendered) and the Partner Details
// header's persistently-visible CTAs (PartnerStatusActionButtons,
// Button-rendered) — both map over the exact same list, so they can never
// drift on what's shown for a given status. `variant` only picks visual
// emphasis (ghost/primary/danger) — it never changes which guarded
// settingsStore action actually runs (editPartner/reinvitePartner/
// cancelPartnerInvitation/deactivatePartner/reactivatePartner all
// re-validate the status themselves regardless of what triggered them).
export type PartnerStatusAction = {
  key: "edit" | "reinvite" | "cancelInvitation" | "deactivate" | "activate";
  label: string;
  variant: "primary" | "ghost" | "danger";
  onClick: () => void;
};

export function getPartnerStatusActions(
  partner: PartnerOrg,
  handlers: {
    onEdit: (p: PartnerOrg) => void;
    onReinvite: (p: PartnerOrg) => void;
    onCancelInvitation: (p: PartnerOrg) => void;
    onDeactivate: (p: PartnerOrg) => void;
    onActivate: (p: PartnerOrg) => void;
  }
): PartnerStatusAction[] {
  // inviteToken is cleared the moment onboarding is submitted (see
  // settingsStore's activatePartner/registerPartner), so it's the same
  // "actually still Invited, not Pending Review/Changes Requested under the
  // hood" guard the rest of this app already uses.
  if (partner.status === "Invited" && partner.inviteToken) {
    return [
      { key: "edit", label: "Edit Partner", variant: "ghost", onClick: () => handlers.onEdit(partner) },
      { key: "reinvite", label: "Re-invite", variant: "primary", onClick: () => handlers.onReinvite(partner) },
      {
        key: "cancelInvitation",
        label: "Cancel Invitation",
        variant: "danger",
        onClick: () => handlers.onCancelInvitation(partner),
      },
    ];
  }
  if (partner.status === "Active") {
    return [
      { key: "deactivate", label: "Deactivate Partner", variant: "danger", onClick: () => handlers.onDeactivate(partner) },
    ];
  }
  if (partner.status === "Inactive") {
    // Covers both a Rejected review outcome and a manual prior Deactivate —
    // both return to Active the same way.
    return [{ key: "activate", label: "Activate Partner", variant: "primary", onClick: () => handlers.onActivate(partner) }];
  }
  // Pending Review / Changes Requested (still "Invited" under the hood, no
  // inviteToken any more) — no status-management action; the Approve/
  // Request Changes/Reject decision CTAs own that workflow instead.
  return [];
}
