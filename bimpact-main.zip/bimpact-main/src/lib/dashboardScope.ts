// Data-scoping/aggregation layer for the Sponsor multi-dashboard feature
// (Consolidated / Partner / Project). This file is the single source of
// truth for Partner<->Project relationship logic — nobody else should
// reimplement it. Partners and Projects are many-to-many; never assume
// one-to-one.
//
// Partner<->Project linkage in this codebase is name-based (see
// src/lib/projectAccess.ts), while PartnerOrg is a first-class entity with a
// real `id`. Dashboard routes/URLs use ids (PartnerOrg.id / Project.id), so
// this file bridges id<->name using useSettingsStore.partners as the lookup
// table, then defers all actual assignment matching to projectAccess.ts's
// existing helpers (resolveAssignedPartnerNames/isProjectAssignedToPartner)
// rather than re-deriving it.
//
// These are plain functions (not hooks) that read stores via `.getState()`
// so they work from both React and non-React contexts (e.g. other pure
// utility modules). React callers that need reactivity should go through
// src/hooks/useDashboardData.ts instead, which wraps these with store hooks.

import { DashboardContext } from "@/types/dashboardContext";
import { resolveAssignedPartnerNames, isProjectAssignedToPartner } from "@/lib/projectAccess";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { Project } from "@/types/project";
import { PartnerOrg } from "@/types/settings";

// All projects assigned to the given partner (by PartnerOrg.id). Resolves
// the id to the partner's name (case-sensitive, matching this codebase's
// existing convention) and delegates the actual assignment check to
// projectAccess.ts. Returns [] if the partner id doesn't exist, or the
// partner has zero assigned projects.
export function getProjectsByPartner(partnerId: string): Project[] {
  const { partners, projectPartners } = useSettingsStore.getState();
  const { projects } = useProjectStore.getState();

  const partnerName = partners.find((p) => p.id === partnerId)?.name;
  if (!partnerName) return [];

  return projects.filter((project) => isProjectAssignedToPartner(project, projectPartners, partnerName));
}

// All partners assigned to the given project (by Project.id), resolved back
// to full PartnerOrg records. Returns [] if the project id doesn't exist, or
// the project has zero assigned partners, or an assigned name no longer
// matches any current PartnerOrg (e.g. a renamed/removed partner) — same
// "best effort" tolerance as the rest of the name-based linkage.
export function getPartnersByProject(projectId: string): PartnerOrg[] {
  const { partners, projectPartners } = useSettingsStore.getState();
  const { projects } = useProjectStore.getState();

  const project = projects.find((p) => p.id === projectId);
  if (!project) return [];

  const names = resolveAssignedPartnerNames(project, projectPartners);
  if (!names.length) return [];

  const nameSet = new Set(names);
  return partners.filter((p) => nameSet.has(p.name));
}

// Project ids in scope for a given dashboard context.
export function getScopedProjectIds(context: DashboardContext): string[] {
  switch (context.scope) {
    case "consolidated":
      return useProjectStore.getState().projects.map((p) => p.id);
    case "partner":
      return getProjectsByPartner(context.partnerId).map((p) => p.id);
    case "project":
      return [context.projectId];
  }
}

// Partner (PartnerOrg) ids in scope for a given dashboard context.
export function getScopedPartnerIds(context: DashboardContext): string[] {
  switch (context.scope) {
    case "consolidated":
      return useSettingsStore.getState().partners.map((p) => p.id);
    case "partner":
      return [context.partnerId];
    case "project":
      return getPartnersByProject(context.projectId).map((p) => p.id);
  }
}
