// File-handling for the Partner-side Compliance module (src/app/compliance).
// Deliberately separate from src/lib/docUpload.ts (Workplace project
// documents) — that one converts docx/pdf into rich-text editor content;
// compliance certificates are just stored/viewed as the original file, so
// this only needs a data-URL read + basic validation, no HTML conversion.

export const ACCEPTED_COMPLIANCE_EXTENSIONS = [".pdf", ".doc", ".docx", ".jpg", ".jpeg", ".png"];
export const ACCEPTED_COMPLIANCE_ACCEPT = ACCEPTED_COMPLIANCE_EXTENSIONS.join(",");
// No app-wide upload size limit exists yet anywhere in this codebase (only
// a file-type allowlist via <input accept>, e.g. DocSidebar.tsx) — this is
// a reasonable, clearly-labeled cap for scanned certificates/PDFs, not an
// attempt to reuse a limit that doesn't actually exist elsewhere.
//
// Explicit product limit: 1 MB per file, applied individually to every
// compliance document (including each file under "Other Supporting
// Documents" separately — there is no combined/category-wide total). Also
// keeps well clear of the browser's localStorage quota: this app has no
// backend, so an uploaded file's full content is stored as a base64
// data-URL inside the SAME "bimpact:settings" blob as every partner/team-
// member/form record (see settingsStore.ts's uploadComplianceDocument) —
// the store action still catches and reports a quota failure if one
// somehow happens anyway.
export const MAX_COMPLIANCE_FILE_SIZE_MB = 1;
const MAX_COMPLIANCE_FILE_SIZE_BYTES = MAX_COMPLIANCE_FILE_SIZE_MB * 1024 * 1024;

// Returns a validation error message, or null if the file is acceptable.
// Must be called (and must reject) before the file is read/uploaded at
// all — see UploadComplianceModal.tsx's handleFileChange, which runs this
// synchronously on selection and never lets an oversized file reach
// onUpload. A file exactly at the limit passes (only strictly-greater is
// rejected).
export function validateComplianceFile(file: File): string | null {
  const ext = `.${file.name.split(".").pop()?.toLowerCase() ?? ""}`;
  if (!ACCEPTED_COMPLIANCE_EXTENSIONS.includes(ext)) {
    return `Unsupported file type. Accepted formats: ${ACCEPTED_COMPLIANCE_EXTENSIONS.join(", ")}.`;
  }
  if (file.size > MAX_COMPLIANCE_FILE_SIZE_BYTES) {
    return `File size must be ${MAX_COMPLIANCE_FILE_SIZE_MB} MB or less. Please select a smaller file.`;
  }
  return null;
}

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
