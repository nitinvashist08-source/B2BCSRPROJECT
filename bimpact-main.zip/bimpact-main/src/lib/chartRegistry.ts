import { AggregationOp, ChartKind } from "@/types/dashboard";
import { AggregatedRow } from "@/lib/dashboardFields";

export type AxisModel = "series-category-measure" | "category-value" | "metric-only" | "tabular";
export type ColorMode = "series" | "slice" | "single" | "none";

export type ChartTypeDef = {
  kind: ChartKind;
  label: string;
  axisModel: AxisModel;
  colorMode: ColorMode;
  defaultAggregation: AggregationOp;
  // Add Visualization's chart-type library (see AddVisualizationSlideOver.tsx
  // step 1): a generic, business-agnostic guiding description of WHEN to use
  // this visualization type — never a specific metric/dataset. Selecting a
  // type only ever picks a shape (bar/line/pie/...); which data it shows is
  // decided afterward in the existing configuration step, never bound here.
  description: string;
  // Generic illustrative preview-only numbers (Category A/B/C/D, never real
  // CSR/project/beneficiary data) — rendered through the SAME chart card
  // components real dashboard charts use (see each card's `preview*` prop),
  // just fed these instead of live aggregated data. Never persisted, never
  // affects actual dashboard data.
  previewData?: AggregatedRow[]; // bar/line/area/pie/donut
  previewKpiValue?: string;
  previewKpiLabel?: string;
  previewTable?: { columns: string[]; rows: (string | number)[][] };
};

const GENERIC_CATEGORY_PREVIEW: AggregatedRow[] = [
  { category: "Category A", value: 32 },
  { category: "Category B", value: 54 },
  { category: "Category C", value: 21 },
  { category: "Category D", value: 43 },
];

// Single source of truth for chart kinds: the Add Visualization type
// library (step 1) and the customization panel (step 2/3) both read this
// list, so previews, axis controls, and color controls all adapt to the
// chart type without duplicating a hardcoded list anywhere else.
export const CHART_TYPES: ChartTypeDef[] = [
  {
    kind: "bar",
    label: "Bar Chart",
    axisModel: "series-category-measure",
    colorMode: "series",
    defaultAggregation: "count",
    description: "Compare values across different categories or groups.",
    previewData: GENERIC_CATEGORY_PREVIEW,
  },
  {
    kind: "line",
    label: "Line Chart",
    axisModel: "series-category-measure",
    colorMode: "series",
    defaultAggregation: "count",
    description: "Show how a value changes or trends over time.",
    previewData: GENERIC_CATEGORY_PREVIEW,
  },
  {
    kind: "area",
    label: "Area Chart",
    axisModel: "series-category-measure",
    colorMode: "series",
    defaultAggregation: "count",
    description: "Visualize trends over time while emphasizing the magnitude of values.",
    previewData: GENERIC_CATEGORY_PREVIEW,
  },
  {
    kind: "pie",
    label: "Pie Chart",
    axisModel: "category-value",
    colorMode: "slice",
    defaultAggregation: "count",
    description: "Show how different categories contribute to a total.",
    previewData: GENERIC_CATEGORY_PREVIEW,
  },
  {
    kind: "donut",
    label: "Donut Chart",
    axisModel: "category-value",
    colorMode: "slice",
    defaultAggregation: "count",
    description: "Show the proportion or composition of a total using a compact circular visualization.",
    previewData: GENERIC_CATEGORY_PREVIEW,
  },
  {
    kind: "kpi",
    label: "KPI / Metric",
    axisModel: "metric-only",
    colorMode: "single",
    defaultAggregation: "sum",
    description: "Highlight a single important number or performance indicator.",
    previewKpiValue: "128",
    previewKpiLabel: "Metric Value",
  },
  {
    kind: "table",
    label: "Table",
    axisModel: "tabular",
    colorMode: "none",
    defaultAggregation: "count",
    description: "Display detailed data in rows and columns for easy comparison and reference.",
    previewTable: {
      columns: ["Category", "Value 1", "Value 2"],
      rows: [
        ["Category A", 32, 12],
        ["Category B", 54, 27],
        ["Category C", 21, 9],
      ],
    },
  },
];

export function getChartType(kind: ChartKind): ChartTypeDef {
  const found = CHART_TYPES.find((c) => c.kind === kind);
  if (!found) throw new Error(`Unknown chart kind: ${kind}`);
  return found;
}
