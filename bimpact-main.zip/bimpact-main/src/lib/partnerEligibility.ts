import { PartnerOrg } from "@/types/settings";

// Whether `partner` may be assigned to a project (via CreateProjectSlideOver
// or any other assignment path). Only reached via the Sponsor's Approve
// decision (see settingsStore's approvePartnerReview, which sets
// reviewStatus: "Approved" and status: "Active" together) — or a partner
// that predates the review workflow entirely and has no reviewStatus field
// at all (e.g. the seeded demo partners in src/data/settingsData.ts, which
// are legitimately Active with no reviewStatus). Partners with
// reviewStatus "Pending Review", "Changes Requested", or "Rejected" are
// never eligible, regardless of their `status` field.
export function isPartnerEligibleForAssignment(partner: PartnerOrg): boolean {
  return (
    partner.status === "Active" &&
    (partner.reviewStatus === "Approved" || partner.reviewStatus === undefined)
  );
}
