// Pure calculation layer for the Reporting module's second report —
// "Project Execution Status" (src/components/reporting/ProjectExecutionReport.tsx).
// Sibling to reportingCalcs.ts (Fund Utilization): same "plain
// arrays/records in, no React, mostly no store reads" shape, with the same
// one exception reportingCalcs.ts already makes — partner<->project
// attribution goes through dashboardScope.ts's getProjectsByPartner/
// getPartnersByProject (the single source of truth for that many-to-many
// relationship) rather than being re-derived here.
//
// Data sources and simplifications:
// - WBS completion % per project = the average of every task row's own
//   Completion Percentage cell (lib/wbsColumns.ts's WBS_COL.completion),
//   not a separate rollup field — there is no other source of "how done is
//   this project" in the data model today. A project with zero WBS rows
//   reports 0% (not "N/A") so it still sorts/flags consistently.
// - "Delayed task" uses the exact same rule as alertRules.ts's
//   wbs_task_overdue candidate: a row whose Status isn't "Done" and whose
//   End Date is before today (lexicographic ISO-string compare, matching
//   that file's own convention — avoids timezone drift from Date math).
// - "Timeline slippage" = today minus the project's planned end date, in
//   days (lexicographic date subtraction via daysBetween). Positive means
//   the project has run past its planned end; negative means days
//   remaining. Always computed, regardless of status — a Planning-stage
//   project with a past end date is itself a signal worth surfacing.
// - "Spend discipline" has no dedicated field anywhere in the data model
//   (Expense has no approvedAt/reviewedAt timestamp) — it's approximated
//   from what IS tracked: the rejection rate of a partner's booked
//   expenses, plus how many are stuck pending longer than the same
//   EXPENSE_PENDING_DAYS threshold alertRules.ts already alerts on.
// - "Needs Intervention" (project) and "Underperforming" (partner) are
//   decision-support flags, not new business rules — each reason is
//   individually named on the row so a Sponsor can see exactly why a
//   project/partner was flagged, never a single opaque score.

import { Project, ProjectStatus, WbsState } from "@/types/project";
import { WBS_COL } from "@/lib/wbsColumns";
import { Expense } from "@/types/finance";
import { PartnerOrg } from "@/types/settings";
import { getProjectsByPartner } from "@/lib/dashboardScope";

// Mirrors alertRules.ts's own PROJECT_STALLED_DAYS (private to that file,
// duplicated here rather than exported/shared — same precedent as
// reportingCalcs.ts's isAtRisk keeping its own 60%/50% thresholds
// independent of alertRules.ts's separate at-risk rule).
const PROJECT_STALLED_DAYS = 30;
const EXPENSE_PENDING_DAYS = 3;
// A partner's on-time task rate below this is flagged as underperforming.
const ON_TIME_TASK_FLOOR_PCT = 70;
// A partner's expense rejection rate above this is flagged.
const REJECTION_RATE_CEILING_PCT = 20;

function daysBetween(fromIso: string, toIso: string): number {
  const from = new Date(fromIso).getTime();
  const to = new Date(toIso).getTime();
  if (Number.isNaN(from) || Number.isNaN(to)) return 0;
  return Math.round((to - from) / 86_400_000);
}

export type ProjectExecution = {
  projectId: string;
  projectName: string;
  status: ProjectStatus;
  state: string;
  districts: string[];
  partnerNames: string[];
  totalTasks: number;
  completedTasks: number;
  delayedTasks: number;
  completionPct: number; // 0-100, average of task completion cells
  slippageDays: number; // today - planned end date; positive = overdue
  daysInCurrentStage: number;
  needsIntervention: boolean;
  interventionReasons: string[];
};

export type StatusRollupRow = { status: ProjectStatus; count: number; budget: number };
export type PartnerRollupRow = { partnerId: string; partnerName: string; count: number };
export type DistrictRollupRow = { district: string; state: string; count: number };

export type PartnerExecutionScorecard = {
  partnerId: string;
  partnerName: string;
  projectCount: number;
  totalTasks: number;
  delayedTasks: number;
  onTimeTaskPct: number; // 100 when a partner has no tasks at all yet
  rejectedExpenseCount: number;
  submittedExpenseCount: number;
  rejectionRatePct: number;
  stalePendingCount: number; // expenses pending > EXPENSE_PENDING_DAYS
  complianceStatus: "Complete" | "Incomplete" | "Not Submitted";
  underperforming: boolean;
  underperformReasons: string[];
};

export type ProjectExecutionMetrics = {
  totalProjects: number;
  byStatus: StatusRollupRow[];
  byPartner: PartnerRollupRow[];
  byDistrict: DistrictRollupRow[];
  projects: ProjectExecution[]; // needs-intervention first, then lowest completion first
  partnerScorecards: PartnerExecutionScorecard[]; // underperforming first, then lowest on-time % first
  interventionCount: number;
  underperformingPartnerCount: number;
};

const STATUS_ORDER: ProjectStatus[] = ["Planning", "Execution", "Review", "Closing"];

function projectExecution(
  project: Project,
  wbsState: WbsState | undefined,
  districts: string[],
  partnerNames: string[],
  today: string
): ProjectExecution {
  const rows = wbsState?.rows ?? [];
  const totalTasks = rows.length;

  let completedTasks = 0;
  let delayedTasks = 0;
  let completionSum = 0;
  for (const row of rows) {
    const status = row.cells[WBS_COL.status];
    const end = row.cells[WBS_COL.end];
    const completion = Math.max(0, Math.min(100, Number(row.cells[WBS_COL.completion]) || 0));
    completionSum += completion;
    if (status === "Done") completedTasks += 1;
    else if (end && end < today) delayedTasks += 1;
  }
  const completionPct = totalTasks > 0 ? completionSum / totalTasks : 0;
  const slippageDays = daysBetween(project.endDate, today);
  const daysInCurrentStage = project.statusChangedAt ? daysBetween(project.statusChangedAt, today) : 0;

  const totalSpan = daysBetween(project.startDate, project.endDate);
  const timeElapsedPct = totalSpan > 0 ? Math.min(100, Math.max(0, (daysBetween(project.startDate, today) / totalSpan) * 100)) : 0;

  const reasons: string[] = [];
  if (project.statusChangedAt && daysInCurrentStage >= PROJECT_STALLED_DAYS) {
    reasons.push(`Stalled in ${project.status} for ${daysInCurrentStage} days`);
  }
  if (project.status === "Execution" && delayedTasks > 0) {
    reasons.push(`${delayedTasks} overdue WBS task${delayedTasks === 1 ? "" : "s"}`);
  }
  if (slippageDays > 0 && project.status !== "Closing") {
    reasons.push(`${slippageDays} day${slippageDays === 1 ? "" : "s"} past planned end date`);
  }
  if (totalSpan > 0 && timeElapsedPct >= 60 && completionPct < 50) {
    reasons.push(`Only ${completionPct.toFixed(0)}% of tasks complete with ${timeElapsedPct.toFixed(0)}% of timeline elapsed`);
  }

  return {
    projectId: project.id,
    projectName: project.name || "Untitled Project",
    status: project.status,
    state: project.location,
    districts,
    partnerNames,
    totalTasks,
    completedTasks,
    delayedTasks,
    completionPct,
    slippageDays,
    daysInCurrentStage,
    needsIntervention: reasons.length > 0,
    interventionReasons: reasons,
  };
}

function partnerScorecard(
  partner: PartnerOrg,
  projectExecutions: ProjectExecution[],
  expenses: Expense[],
  today: string
): PartnerExecutionScorecard {
  const partnerProjectIds = new Set(getProjectsByPartner(partner.id).map((p) => p.id));
  const relevant = projectExecutions.filter((p) => partnerProjectIds.has(p.projectId));

  const totalTasks = relevant.reduce((sum, p) => sum + p.totalTasks, 0);
  const delayedTasks = relevant.reduce((sum, p) => sum + p.delayedTasks, 0);
  const onTimeTaskPct = totalTasks > 0 ? ((totalTasks - delayedTasks) / totalTasks) * 100 : 100;

  const partnerExpenses = expenses.filter((e) => partnerProjectIds.has(e.projectId));
  const rejectedExpenseCount = partnerExpenses.filter((e) => e.status === "rejected").length;
  const submittedExpenseCount = partnerExpenses.length;
  const rejectionRatePct = submittedExpenseCount > 0 ? (rejectedExpenseCount / submittedExpenseCount) * 100 : 0;
  const stalePendingCount = partnerExpenses.filter(
    (e) => (e.status === "pending" || e.status === "pendingfc") && daysBetween(e.submittedAt, today) >= EXPENSE_PENDING_DAYS
  ).length;

  const complianceStatus: PartnerExecutionScorecard["complianceStatus"] =
    partner.complianceStatus ?? (partner.reviewStatus ? "Incomplete" : "Not Submitted");

  const reasons: string[] = [];
  if (totalTasks > 0 && onTimeTaskPct < ON_TIME_TASK_FLOOR_PCT) {
    reasons.push(`Only ${onTimeTaskPct.toFixed(0)}% of tasks on time`);
  }
  if (rejectionRatePct > REJECTION_RATE_CEILING_PCT) {
    reasons.push(`${rejectionRatePct.toFixed(0)}% of expenses rejected`);
  }
  if (stalePendingCount > 0) {
    reasons.push(`${stalePendingCount} expense${stalePendingCount === 1 ? "" : "s"} pending approval > ${EXPENSE_PENDING_DAYS} days`);
  }
  if (complianceStatus !== "Complete") {
    reasons.push(`Compliance documents ${complianceStatus.toLowerCase()}`);
  }

  return {
    partnerId: partner.id,
    partnerName: partner.name,
    projectCount: relevant.length,
    totalTasks,
    delayedTasks,
    onTimeTaskPct,
    rejectedExpenseCount,
    submittedExpenseCount,
    rejectionRatePct,
    stalePendingCount,
    complianceStatus,
    underperforming: reasons.length > 0,
    underperformReasons: reasons,
  };
}

export function computeProjectExecutionMetrics(input: {
  projects: Project[]; // already scoped to the active filter
  partners: PartnerOrg[]; // already scoped to the active filter
  wbs: Record<string, WbsState>; // ALL projects' WBS state — filtered internally
  projectDistricts: Record<string, string[]>; // ALL — filtered internally
  expenses: Expense[]; // ALL — filtered internally per partner's projects
}): ProjectExecutionMetrics {
  const { projects, partners, wbs, projectDistricts, expenses } = input;
  const today = new Date().toISOString().slice(0, 10);

  const projectExecutions = projects
    .map((p) =>
      projectExecution(p, wbs[p.id], projectDistricts[p.id] ?? [], getPartnerNamesForProject(p, partners), today)
    )
    .sort((a, b) => {
      if (a.needsIntervention !== b.needsIntervention) return a.needsIntervention ? -1 : 1;
      return a.completionPct - b.completionPct;
    });

  const byStatus: StatusRollupRow[] = STATUS_ORDER.map((status) => {
    const inStatus = projects.filter((p) => p.status === status);
    return { status, count: inStatus.length, budget: inStatus.reduce((sum, p) => sum + p.budget, 0) };
  });

  const byPartner: PartnerRollupRow[] = partners
    .map((partner) => ({
      partnerId: partner.id,
      partnerName: partner.name,
      count: getProjectsByPartner(partner.id).filter((p) => projects.some((sp) => sp.id === p.id)).length,
    }))
    .filter((r) => r.count > 0)
    .sort((a, b) => b.count - a.count);

  const districtCounts = new Map<string, { state: string; count: number }>();
  for (const p of projects) {
    const districts = projectDistricts[p.id] ?? [];
    for (const d of districts) {
      const existing = districtCounts.get(d);
      if (existing) existing.count += 1;
      else districtCounts.set(d, { state: p.location, count: 1 });
    }
  }
  const byDistrict: DistrictRollupRow[] = [...districtCounts.entries()]
    .map(([district, v]) => ({ district, state: v.state, count: v.count }))
    .sort((a, b) => b.count - a.count);

  const partnerScorecards = partners
    .map((partner) => partnerScorecard(partner, projectExecutions, expenses, today))
    .filter((s) => s.projectCount > 0)
    .sort((a, b) => {
      if (a.underperforming !== b.underperforming) return a.underperforming ? -1 : 1;
      return a.onTimeTaskPct - b.onTimeTaskPct;
    });

  return {
    totalProjects: projects.length,
    byStatus,
    byPartner,
    byDistrict,
    projects: projectExecutions,
    partnerScorecards,
    interventionCount: projectExecutions.filter((p) => p.needsIntervention).length,
    underperformingPartnerCount: partnerScorecards.filter((p) => p.underperforming).length,
  };
}

// Assigned partner names for one project, resolved the same many-to-many
// way as the rest of the report (getProjectsByPartner run per-partner and
// inverted) rather than reading the legacy Project.partner display string.
function getPartnerNamesForProject(project: Project, partners: PartnerOrg[]): string[] {
  return partners.filter((partner) => getProjectsByPartner(partner.id).some((p) => p.id === project.id)).map((p) => p.name);
}
