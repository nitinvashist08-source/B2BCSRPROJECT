import { PartnerType } from "@/types/settings";

// Demo-convenience cache: the Sponsor's most recent successful Partner
// invite (create or re-invite), so the self-serve onboarding entry
// (PartnerOnboardingForm.tsx, entry.type === "self_served") can prefill its
// fields instead of starting fully blank every time — handy for testing
// the self-serve flow right after inviting someone in this same browser,
// without retyping the same sample org details.
//
// Deliberately NOT wired into DataBootstrap's cross-tab live-sync (see
// localPersist.ts's subscribeToStorageChanges) — this is a one-shot "seed
// the form when it mounts" read, not a value any UI stays bound to, so it
// doesn't need to be reactive.
//
// Intentional, explicit product decision (confirmed with the user): this
// is a single-user local demo/testing convenience only. A self-serve
// visitor is anonymous until they type their own email, so this data is
// shown to WHOEVER next opens the self-serve entry in this browser, not
// specifically the invited partner — acceptable here because there is no
// real multi-user privacy boundary in this no-backend demo app, but this
// is exactly the "global latest invitation" pattern the actual Sponsor→
// Partner invite-token flow (validateInviteToken) deliberately avoids for
// its own, real, per-partner data.
export type LastPartnerInvite = {
  name: string;
  contactName: string;
  contactEmail: string;
  type: PartnerType;
  invitedAt: string;
  // The inviting Sponsor's workspace id (same PartnerOrg.workspaceId set by
  // invitePartner) — lets the self-serve simulated invite email
  // (src/app/partner-onboarding/invite) resolve the Inviter Company Name via
  // useWorkspaceStore's existing getWorkspace, instead of a second
  // company-name field/mapping.
  workspaceId: string;
};

const STORAGE_KEY = "bimpact:lastPartnerInvite";

export function saveLastPartnerInvite(invite: LastPartnerInvite): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(invite));
  } catch (err) {
    console.error("Failed to save last partner invite", err);
  }
}

export function getLastPartnerInvite(): LastPartnerInvite | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as LastPartnerInvite;
  } catch (err) {
    console.error("Failed to read last partner invite", err);
    return null;
  }
}
