import { UserRole } from "@/store/sessionStore";
import { OwnershipMode } from "@/types/project";

// Role-based route + nav config for the protected app shell.
//
// This app only has two session roles ("sponsor" and "partner" — see
// UserRole in sessionStore.ts). Per the product spec, every external
// collaborator type (Partner / NGO / Implementing Partner / Co-Sponsor)
// collapses to the single "partner" role, so there is no finer-grained role
// to slice on here.
//
// /projects (Workplace), /dashboard, /finance, /settings, and /alerts are
// SHARED, not sponsor-only: a partner gets the same route/page as a
// sponsor. /alerts stays fully unscoped (static demo content today, no
// project/org data to scope). /dashboard is the same shared page/layout
// too, but is now scoped to the logged-in partner's own projects — via a
// Project filter in its header (see src/app/dashboard/page.tsx), reusing
// the Sponsor-side Project filter component and the combined-filter/
// empty-state logic in src/lib/dashboardFilterScope.ts with the partner's
// id locked in from the session — never a Partner selector — the exception
// is the multi-dashboard sub-routes (/dashboard/consolidated,
// /dashboard/partner/*, /dashboard/project/*), which are Sponsor-only — a
// partner still lands on plain /dashboard (unchanged) and is bounced away
// from these sub-routes by the same guard as anything else in
// SPONSOR_ONLY_PREFIXES —
// Workplace itself filtered to their assigned project(s) with no
// project-creation entry point and restricted WBS/form-ownership controls
// (see ProjectsTable.tsx, WbsTable.tsx, IndicatorsView.tsx), Finance
// filtered per-module to financial data on their assigned projects, largely
// read-only (see FinanceTopBar.tsx, HighLevelBudgetTable.tsx,
// MicroBudgetView.tsx, ExpenseProjectList.tsx/ExpenseTable.tsx,
// DisbProjectList.tsx/TranchePipeline.tsx, and each finance module's
// [projectId] detail page for the actual project-assignment guard), and
// Settings scoped down to just Users — the Partner org's own internal team
// (a separate list, `partnerTeamMembers`, from the Sponsor's `teamMembers`
// — see src/app/settings/user/page.tsx's role branch and
// src/types/settings.ts's PartnerTeamMember). Everything else
// org-management-shaped stays sponsor-only.
//
// Path prefixes below are matched the same way AppShell.tsx already matches
// PUBLIC_PREFIXES: exact match, or pathname + "/" as a prefix.

export const SPONSOR_ONLY_PREFIXES = [
  "/meetings",
  "/partners",
  "/reporting",
  "/dashboard/consolidated",
  "/dashboard/partner",
  "/dashboard/project",
];

// /partner-workspace is legacy — it now just redirects into /projects (see
// its page.tsx) — kept partner-only so a sponsor bounced onto it by a stale
// link lands back in their own Workplace instead of a redirect loop.
// /compliance is the Partner-side document-management module (see
// src/app/compliance/page.tsx) — Partner-only by explicit product spec; the
// Sponsor's own read-only compliance view lives inside Partner Onboarding
// review instead and is untouched by this route.
export const PARTNER_ONLY_PREFIXES = ["/partner-workspace", "/compliance"];

function matchesPrefix(pathname: string, prefixes: string[]): boolean {
  return prefixes.some((p) => pathname === p || pathname.startsWith(p + "/"));
}

export function isSponsorOnlyPath(pathname: string): boolean {
  return matchesPrefix(pathname, SPONSOR_ONLY_PREFIXES);
}

export function isPartnerOnlyPath(pathname: string): boolean {
  return matchesPrefix(pathname, PARTNER_ONLY_PREFIXES);
}

// Single source of truth for "can this role be on this path" — used by
// AppShell's guard (to hard-redirect away) and can also be used to sanity
// check nav config (see filterNavGroupsForRole below).
export function isPathAllowedForRole(pathname: string, role: UserRole | null): boolean {
  if (role === "partner" && isSponsorOnlyPath(pathname)) return false;
  if (role === "sponsor" && isPartnerOnlyPath(pathname)) return false;
  return true;
}

// Generic enough to filter Sidebar's NAV_GROUPS-shaped arrays (whatever the
// icon/badge/sub fields end up being) down to entries the given role is
// actually allowed to navigate to. Groups left with no items are dropped.
type NavItemLike = { href: string };
type NavGroupLike<T extends NavItemLike> = { label: string; items: T[] };

export function filterNavGroupsForRole<T extends NavItemLike>(
  groups: NavGroupLike<T>[],
  role: UserRole | null
): NavGroupLike<T>[] {
  return groups
    .map((group) => ({ ...group, items: group.items.filter((item) => isPathAllowedForRole(item.href, role)) }))
    .filter((group) => group.items.length > 0);
}

// Single source of truth for Project-level "who owns this resource"
// permission matrices — shared by the Work Breakdown Structure
// (Workplace → Project → WBS) AND the Beneficiary Indicator Form
// (Workplace → Project → Beneficiary Indicators → Indicator Form). Both
// resources use the exact same ownership model: the Sponsor picks one of
// three modes per project ("self" = Sponsor owns it, "partner" = the
// Partner owns it, "both" = collaborative), which decides who may
// create/edit/delete/reorder that project's single shared resource versus
// who only gets read-only view/preview access. Used both by the resource's
// own UI (hide/disable the mutating controls) and by projectStore's actions
// themselves (refuse the mutation even if called directly, bypassing the
// UI) — permissions must hold at the data/action layer too, not just by
// hiding buttons. Deliberately resource-agnostic (same mode/role inputs
// regardless of whether the resource is the WBS or the Indicator Form) so
// neither feature has to duplicate this logic.
export function canEditProjectResource(mode: OwnershipMode | null, role: UserRole | null): boolean {
  if (!mode) return false; // no ownership configured yet — nobody can mutate
  if (mode === "both") return true;
  if (mode === "self") return role !== "partner"; // Sponsor edits, Partner views
  return role === "partner"; // mode === "partner": Partner edits, Sponsor views
}
