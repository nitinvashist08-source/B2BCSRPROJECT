// Shared display-name fallback for accounts that logged in via the unified
// LoginForm with only an email (no captured display name) — sponsor.name
// stays null in that case (see sessionStore.ts's login()). Previously a
// private helper duplicated wherever the current user's name needed
// showing (Header.tsx); pulled out here so OfficerSignoffSection.tsx (Add
// Record's Officer Sign-off) can use the exact same resolution instead of a
// second, possibly-diverging implementation.
export function deriveNameFromEmail(email: string): string {
  const local = email.split("@")[0] ?? "";
  return local
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => part[0].toUpperCase() + part.slice(1))
    .join(" ");
}

// The single place that decides what name to show/record for "the current
// user" when session.name may be null — name wins if present, otherwise
// derive something readable from the email, otherwise a plain fallback.
export function resolveDisplayName(name: string | null | undefined, email: string | null | undefined): string {
  if (name && name.trim()) return name.trim();
  if (email && email.trim()) return deriveNameFromEmail(email);
  return "Unknown User";
}
