// One-time background migration for compliance documents/history saved
// under the old fixed 6-type scheme (before ComplianceDocType became an open
// catalog-id string — see types/settings.ts's own comment). Rewrites the
// literal old codes to their equivalent new catalog item id, in place, on
// both PartnerOrg.complianceDocuments and settingsStore's partnerHistory —
// so an existing upload, its review status, and its history trail are never
// silently orphaned just because the Sponsor's checklist now speaks catalog
// ids instead of "12A"/"80G"/etc. "Other" is untouched (still the fixed
// free-form bucket, never had a catalog id).
//
// Called once from DataBootstrap after the initial hydrate, fire-and-forget,
// same pattern as complianceFileStore.ts's migrateInlineComplianceFiles — a
// partner/history with nothing to migrate is a no-op.
export const LEGACY_COMPLIANCE_TYPE_MAP: Record<string, string> = {
  "12A": "tax_12a_12ab_certificate",
  "80G": "tax_80g_certificate",
  "CSR-1": "tax_csr1_registration",
  GST: "org_gst_certificate",
  PAN: "org_pan_card",
};

export async function migrateLegacyComplianceDocumentTypes(): Promise<void> {
  // Dynamic, not top-level — same reasoning as complianceFileStore.ts's own
  // migration: keeps this module's import light for anything that doesn't
  // otherwise need settingsStore.
  const { useSettingsStore } = await import("@/store/settingsStore");
  const { partners, partnerHistory, updatePartner } = useSettingsStore.getState();

  for (const partner of partners) {
    const docs = partner.complianceDocuments;
    if (!docs || docs.length === 0) continue;
    if (!docs.some((d) => LEGACY_COMPLIANCE_TYPE_MAP[d.type])) continue;
    const migrated = docs.map((d) => (LEGACY_COMPLIANCE_TYPE_MAP[d.type] ? { ...d, type: LEGACY_COMPLIANCE_TYPE_MAP[d.type] } : d));
    updatePartner(partner.id, { complianceDocuments: migrated });
  }

  if (partnerHistory.some((h) => h.documentType && LEGACY_COMPLIANCE_TYPE_MAP[h.documentType])) {
    const migratedHistory = partnerHistory.map((h) =>
      h.documentType && LEGACY_COMPLIANCE_TYPE_MAP[h.documentType]
        ? { ...h, documentType: LEGACY_COMPLIANCE_TYPE_MAP[h.documentType] }
        : h
    );
    useSettingsStore.setState({ partnerHistory: migratedHistory });
  }
}
