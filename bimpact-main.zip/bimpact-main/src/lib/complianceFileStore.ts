// Actual file BYTES for compliance documents live here (IndexedDB), not in
// localStorage. Why: this app has no backend (see localPersist.ts) — every
// other store's data is small JSON, so keeping it all in one localStorage
// blob is fine, but compliance files are base64 data-URLs, each up to ~1MB
// raw (~1.33MB after base64 inflation) across up to 5 required documents
// plus an unbounded "Other Supporting Documents" list. That easily exceeds
// a browser's ~5-10MB per-origin localStorage quota on its own, even with
// every individual file honoring the 1MB cap (see complianceUpload.ts) —
// it's the SUM across documents, not any one file, that was blowing the
// quota. IndexedDB's quota is dramatically larger (typically hundreds of
// MB+), so it's the right place for the bytes; PartnerOrg.complianceDocuments
// (settingsStore.ts, still localStorage-backed) now only stores a small
// `fileId` reference plus metadata (type/fileName/uploadedAt).
//
// Deliberately NOT a Zustand store — this data has no reactive UI binding
// of its own; components fetch a file's bytes on demand (e.g. opening the
// View modal), keyed by the fileId already sitting in a ComplianceDocument.

const DB_NAME = "bimpact-compliance-files";
const DB_VERSION = 1;
const STORE_NAME = "files";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB is not available in this browser."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE_NAME)) {
        req.result.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveComplianceFile(fileId: string, dataUrl: string): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(dataUrl, fileId);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getComplianceFile(fileId: string): Promise<string | undefined> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const req = tx.objectStore(STORE_NAME).get(fileId);
    req.onsuccess = () => resolve(req.result as string | undefined);
    req.onerror = () => reject(req.error);
  });
}

// Best-effort — called after a successful replace/upload to clean up the
// now-unreferenced old file. Never blocks/fails the upload flow itself.
export async function deleteComplianceFile(fileId: string): Promise<void> {
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).delete(fileId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Non-fatal — an orphaned blob just wastes a little IndexedDB space.
  }
}

export function newComplianceFileId(): string {
  return `cf-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

// One-time background migration for data saved before fileId existed:
// finds any ComplianceDocument still carrying an inline fileUrl, moves its
// bytes into IndexedDB, and rewrites the record to a small {fileId}
// reference instead — shrinking the localStorage "bimpact:settings" blob
// back down without the Partner having to re-upload anything. Called once
// from DataBootstrap after the initial hydrate (see its own comment) —
// fire-and-forget, never blocks first paint; a partner with nothing to
// migrate is a no-op. Lives here (not settingsStore.ts) since it's really
// about complianceFileStore's own concern (getting bytes out of
// localStorage), just reaching into settingsStore's partners to do it.
export async function migrateInlineComplianceFiles(): Promise<void> {
  // Dynamic, not top-level: this module is also imported by components that
  // don't otherwise need settingsStore at all (e.g. the View modal), so this
  // keeps that import light.
  const { useSettingsStore } = await import("@/store/settingsStore");
  const { partners, updatePartner } = useSettingsStore.getState();

  for (const partner of partners) {
    const docs = partner.complianceDocuments;
    if (!docs || docs.length === 0) continue;
    if (!docs.some((d) => d.fileUrl && !d.fileId)) continue;

    const migrated = await Promise.all(
      docs.map(async (d) => {
        if (!d.fileUrl || d.fileId) return d;
        try {
          const fileId = newComplianceFileId();
          await saveComplianceFile(fileId, d.fileUrl);
          const { fileUrl: _fileUrl, ...rest } = d;
          return { ...rest, fileId };
        } catch {
          return d; // leave this one as-is if the IndexedDB write fails
        }
      })
    );
    updatePartner(partner.id, { complianceDocuments: migrated });
  }
}
