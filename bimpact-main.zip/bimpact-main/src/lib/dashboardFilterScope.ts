// Combined-filter-behaviour logic for the Consolidated Sponsor Dashboard's
// independent Partner + Project filters (see src/types/dashboardFilters.ts
// for the DashboardFilters contract this file consumes). This is the ONE
// place that resolves a { partnerId, projectId } pair down to concrete
// scoped Project/Partner ids and a row-level predicate — nobody else should
// re-derive this combination logic.
//
// This is a different, independent concept from dashboardScope.ts's
// getScopedProjectIds/getScopedPartnerIds, which back the older "switch to a
// whole separate dashboard" DashboardContext feature (one-of-three: overall
// / a single partner / a single project). Here, Partner and Project are two
// independent narrowing filters on ONE dashboard — either, neither, or both
// may be active at once — so the combination rules differ:
//
//   Partner=All, Project=All -> everything (no narrowing at all)
//   Partner=A,   Project=All -> every project assigned to partner A
//   Partner=All, Project=X   -> just project X, regardless of who its
//                                partners are (a specific project is
//                                unambiguous on its own)
//   Partner=A,   Project=X   -> project X IF it is actually assigned to
//                                partner A, otherwise nothing — picking two
//                                filters with no real relationship between
//                                them must not silently fall back to
//                                "show A" or "show X", it must show an
//                                explicit empty state (see
//                                isFilterCombinationEmpty below).
//
// Partner<->Project linkage is many-to-many and is never re-derived here —
// every actual assignment check is delegated to dashboardScope.ts's
// getProjectsByPartner/getPartnersByProject (id-based lookups) and
// projectAccess.ts's isProjectAssignedToPartner (the underlying name-based
// assignment check), so this file can never disagree with those about who
// is assigned to whom.

import { DashboardFilters, isDashboardFiltersEmpty } from "@/types/dashboardFilters";
import { getProjectsByPartner, getPartnersByProject } from "@/lib/dashboardScope";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { DatasetScopeFilter } from "@/hooks/useDatasetRows";

// Project ids in scope for the given filter combination. See the truth
// table in this file's header comment. When both filters are set, [projectId]
// is returned only if that project is actually assigned to that partner —
// otherwise [] (a mismatched pair must never fall back to "just show the
// partner's projects" or "just show the project").
export function getScopedProjectIds(filters: DashboardFilters): string[] {
  const { partnerId, projectId } = filters;

  if (partnerId === null && projectId === null) {
    return useProjectStore.getState().projects.map((p) => p.id);
  }

  if (partnerId === null) {
    // Project=X alone is unambiguous regardless of partner.
    return [projectId as string];
  }

  if (projectId === null) {
    return getProjectsByPartner(partnerId).map((p) => p.id);
  }

  // Both set: only in scope if X is actually assigned to A.
  const { projectPartners } = useSettingsStore.getState();
  const project = useProjectStore.getState().projects.find((p) => p.id === projectId);
  const partnerName = useSettingsStore.getState().partners.find((p) => p.id === partnerId)?.name;
  if (!project || !isProjectAssignedToPartner(project, projectPartners, partnerName)) return [];
  return [projectId];
}

// Partner ids in scope for the given filter combination — mirrors
// getScopedProjectIds above with partner/project roles swapped.
export function getScopedPartnerIds(filters: DashboardFilters): string[] {
  const { partnerId, projectId } = filters;

  if (partnerId === null && projectId === null) {
    return useSettingsStore.getState().partners.map((p) => p.id);
  }

  if (projectId === null) {
    // Partner=A alone is unambiguous regardless of project.
    return [partnerId as string];
  }

  if (partnerId === null) {
    return getPartnersByProject(projectId).map((p) => p.id);
  }

  // Both set: only in scope if X is actually assigned to A.
  const { projectPartners } = useSettingsStore.getState();
  const project = useProjectStore.getState().projects.find((p) => p.id === projectId);
  const partnerName = useSettingsStore.getState().partners.find((p) => p.id === partnerId)?.name;
  if (!project || !isProjectAssignedToPartner(project, projectPartners, partnerName)) return [];
  return [partnerId];
}

// True exactly when both filters are set AND they have no association —
// i.e. the "genuinely no relationship" case that should render an explicit
// empty state, as opposed to a partner/project that legitimately has zero
// data of some other kind. Only meaningful when both filters are set: with
// zero or one filter active there is no mismatch to detect, so this is
// always false in that case (even if, say, a lone selected partner happens
// to have zero projects — that's "no data", not "no relationship").
export function isFilterCombinationEmpty(filters: DashboardFilters): boolean {
  if (filters.partnerId === null || filters.projectId === null) return false;
  return getScopedProjectIds(filters).length === 0;
}

// Builds a DatasetScopeFilter (same shape/convention as VisualizationCanvas's
// buildDatasetScopeFilter) from a DashboardFilters value, for the integrator
// to feed into DatasetScopeProvider. Returns null when the filters are empty
// (Partner=All, Project=All) since there is nothing to narrow — matching
// buildDatasetScopeFilter's own "null = no scope" convention.
export function buildDashboardFilterScopeFilter(filters: DashboardFilters): DatasetScopeFilter | null {
  if (isDashboardFiltersEmpty(filters)) return null;

  const projectIds = new Set(getScopedProjectIds(filters));
  const partnerIds = new Set(getScopedPartnerIds(filters));

  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- row shape depends on datasetId, same as DatasetScopeFilter's own signature
  return (datasetId: string, row: any) => {
    switch (datasetId) {
      case "projects":
        return projectIds.has(row?.id);
      case "expenses":
      case "tranches":
      case "beneficiaries":
        return projectIds.has(row?.projectId);
      case "partners":
        return partnerIds.has(row?.id);
      default:
        return true;
    }
  };
}
