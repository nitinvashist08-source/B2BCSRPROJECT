// The Alerts module's rule engine — pure functions only (no store reads),
// mirroring reportingCalcs.ts's own style. alertStore.ts's evaluate() is the
// only caller: it runs this against a fresh snapshot of every relevant
// store, diffs the result against currently-active alerts (by `key`), and
// creates/resolves accordingly. Nothing here mutates anything or persists
// anything itself.
//
// Two different generation paths exist in this app (see the Alerts &
// Notifications refinement discussion this was built from):
// - EVENT-STAMPED alerts (tranche released, expense rejected, micro-budget
//   ownership assigned, partner marked inactive, compliance doc uploaded)
//   are pushed directly by the store action that causes them — see
//   financeStore.ts's rejectExpense/releaseTranche/setMicroBudgetOwnership
//   and settingsStore.ts's uploadComplianceDocument/rejectPartnerReview/
//   updatePartner. They are NOT computed here.
// - DERIVED/COMPUTED alerts (everything threshold- or state-based: overdue,
//   pending too long, approaching a deadline, stalled) have no "moment" a
//   store action can hook — nothing in this no-backend app runs on a timer
//   when the tab is closed, so they're recomputed fresh every time
//   evaluate() runs (on app load, and periodically while the tab stays
//   open — see DataBootstrap.tsx). That's every rule in this file.
//
// Configurable thresholds live as named constants right here — spec 17.14
// ("Alert thresholds should be configurable where the requirement uses
// `X days`") is satisfied by them being one clearly-named edit away, not by
// a runtime settings UI (out of scope for this pass).

import { Project, WbsState, IndicatorFormState, IndicatorFormResponse, IndicatorFormShareLink } from "@/types/project";
import { Expense, Tranche, PeriodBudget } from "@/types/finance";
import { Meeting } from "@/types/meeting";
import { PartnerOrg, TeamMember } from "@/types/settings";
import { Alert, AlertCategory, AlertSeverity, AlertEntityType, AlertAction } from "@/types/alert";
import { computeFundUtilizationMetrics } from "@/lib/reportingCalcs";
import { WBS_COL } from "@/lib/wbsColumns";

// ── Configurable thresholds ──────────────────────────────────────────────
const EXPENSE_PENDING_DAYS = 3;
const TRANCHE_UPCOMING_WINDOW_DAYS = 7; // "7d" bucket catches anything up to 7 days out
const TRANCHE_DUE_SOON_DAYS = 3; // "3d" bucket
const PROJECT_STALLED_DAYS = 30;
const PROJECT_END_WINDOW_DAYS = [30, 15, 7] as const;
const INDICATOR_FORM_NO_RECORDS_DAYS = 14;
const SHARE_LINK_NO_RESPONSE_DAYS = 7;
const PARTNER_INVITE_PENDING_DAYS = 7;
const PARTNER_REVIEW_PENDING_DAYS = 7;
const TEAM_INVITE_PENDING_DAYS = 3;
const BUDGET_PERIOD_APPROACHING_DAYS = 30;
const MEETING_SOON_HOURS = 24;

export type AlertCandidate = Omit<Alert, "id" | "isRead" | "createdAt" | "resolvedAt">;

// Every `type` id evaluateAlerts() can ever produce — alertStore.evaluate()
// uses this to know which currently-active alerts it's even allowed to
// resolve. An event-only type (currently just "compliance_document_uploaded",
// pushed by settingsStore's uploadComplianceDocument via pushIfNoUnread) is
// NOT derivable from a state snapshot at all, so it must never appear here —
// otherwise evaluate() would see it "missing" from every candidates list and
// incorrectly resolve it the very next time it runs.
export const DERIVED_ALERT_TYPES = new Set([
  "tranche_released",
  "tranche_overdue",
  "tranche_due_today",
  "tranche_due_soon",
  "tranche_upcoming",
  "expense_rejected",
  "expense_pending",
  "project_low_utilization",
  "project_over_budget",
  "budget_period_unallocated",
  "meeting_soon",
  "meeting_signoff_pending",
  "meeting_action_overdue",
  "wbs_task_overdue",
  "project_stalled",
  "project_end_approaching",
  "indicator_form_no_records",
  "share_link_no_response",
  "partner_invite_pending",
  "partner_review_pending",
  "partner_inactive",
  "partner_first_login_compliance",
  "partner_changes_requested",
  "partner_approved",
  "team_invite_pending",
  "missing_officer_signoff",
]);

function daysBetween(fromIso: string, toIso: string): number {
  const from = new Date(fromIso).getTime();
  const to = new Date(toIso).getTime();
  if (Number.isNaN(from) || Number.isNaN(to)) return 0;
  return Math.floor((to - from) / 86_400_000);
}
function hoursBetween(fromIso: string, toIso: string): number {
  const from = new Date(fromIso).getTime();
  const to = new Date(toIso).getTime();
  if (Number.isNaN(from) || Number.isNaN(to)) return 0;
  return (to - from) / 3_600_000;
}
function fmtInr(n: number): string {
  return "₹" + Math.round(Math.abs(n)).toLocaleString("en-IN");
}

function candidate(
  type: string,
  entityType: AlertEntityType,
  entityId: string,
  category: AlertCategory,
  severity: AlertSeverity,
  title: string,
  message: string,
  opts: { milestone?: string; projectId?: string; targetRole?: "sponsor" | "partner"; targetPartnerOrgId?: string; action?: AlertAction } = {}
): AlertCandidate {
  const key = `${type}:${entityType}:${entityId}${opts.milestone ? `:${opts.milestone}` : ""}`;
  return {
    key,
    type,
    category,
    severity,
    title,
    message,
    entityType,
    entityId,
    projectId: opts.projectId,
    targetRole: opts.targetRole,
    targetPartnerOrgId: opts.targetPartnerOrgId,
    action: opts.action,
  };
}

// ── 4. Finance ────────────────────────────────────────────────────────────
function financeAlerts(input: {
  projects: Project[];
  expenses: Expense[];
  disbursements: Record<string, Tranche[]>;
  periodBudgets: PeriodBudget[];
  now: string;
}): AlertCandidate[] {
  const { projects, expenses, disbursements, periodBudgets, now } = input;
  const out: AlertCandidate[] = [];
  const projectById = new Map(projects.map((p) => [p.id, p]));
  // Date-only "today" (matches projectExecutionAlerts' same convention) —
  // `t.date`/`b.endDate` are plain YYYY-MM-DD strings with no time component,
  // so comparing them against the full-instant `now` directly (via
  // daysBetween's Date parsing) drifted the bucket by up to a day depending
  // on the time of day this runs: a tranche due "today" could parse as
  // already in the past and be silently skipped, while one due "tomorrow"
  // could parse as 0 days away and wrongly fire "due today". Flooring both
  // sides to the same UTC-midnight granularity fixes it regardless of the
  // session's local timezone or time of day.
  const today = now.slice(0, 10);

  // 4.1 / 4.3 / 4.4 / 4.5 — tranche overdue / upcoming-7d / due-soon-3d / due-today.
  // "Released" (4.2) is event-stamped only (releaseTranche), not derived here.
  for (const [projectId, tranches] of Object.entries(disbursements)) {
    const project = projectById.get(projectId);
    if (!project) continue;
    for (const t of tranches) {
      const disbAction: AlertAction = { label: "View Tranche", route: `/finance/disbursement/${projectId}` };
      // 4.2 — tranche released. Status stays "released" permanently once
      // set, so the store's own dedup (one alert per key, never
      // re-created while unresolved) naturally gives "fire once" behavior
      // without needing a separate event-stamped hook in releaseTranche.
      if (t.status === "released") {
        out.push(
          candidate("tranche_released", "tranche", t.id, "finance", "info", "Tranche released",
            `Tranche ${t.name} for ${project.name} has been released successfully.`,
            { projectId, action: disbAction })
        );
        continue;
      }
      if (t.status === "overdue") {
        out.push(
          candidate("tranche_overdue", "tranche", t.id, "finance", "critical", "Tranche overdue",
            `Tranche ${t.name} for ${project.name} is overdue and has not been released.`,
            { projectId, action: disbAction })
        );
        continue;
      }
      // A tranche's `date` is only ever populated for a "time" trigger
      // milestone — task/expenditure/balance/custom tranches (see
      // buildConditionAndDate in ScheduleTrancheSlideOver.tsx) have no real
      // due date at all, and daysBetween's NaN-guard would otherwise treat
      // that empty string as "0 days away", falsely flagging every
      // non-time-triggered tranche as due today the moment it's created.
      if (t.status === "scheduled" || t.status === "upcoming") {
        if (!t.date) continue;
        const daysUntil = daysBetween(today, t.date);
        if (daysUntil < 0) continue;
        if (daysUntil === 0) {
          out.push(
            candidate("tranche_due_today", "tranche", t.id, "finance", "high", "Tranche due today",
              `Tranche ${t.name} for ${project.name} is due today. Review the tranche to ensure timely release.`,
              { milestone: "today", projectId, action: disbAction })
          );
        } else if (daysUntil <= TRANCHE_DUE_SOON_DAYS) {
          out.push(
            candidate("tranche_due_soon", "tranche", t.id, "finance", "high", "Tranche due in 3 days",
              `Tranche ${t.name} for ${project.name} is due on ${t.date}. Please review the release status.`,
              { milestone: "3d", projectId, action: disbAction })
          );
        } else if (daysUntil <= TRANCHE_UPCOMING_WINDOW_DAYS) {
          out.push(
            candidate("tranche_upcoming", "tranche", t.id, "finance", "medium", "Tranche due in 7 days",
              `Tranche ${t.name} for ${project.name} is due on ${t.date}.`,
              { milestone: "7d", projectId, action: disbAction })
          );
        }
      }
    }
  }

  // 4.6 — expense pending > 3 days. 4.7 — expense rejected (same "status
  // stays permanently set, dedup gives fire-once" reasoning as tranche
  // released above — no event-stamped hook needed in rejectExpense).
  for (const e of expenses) {
    const project = projectById.get(e.projectId);
    const expenseAction: AlertAction = { label: "Review Expense", route: `/finance/expense/${e.projectId}` };
    if (e.status === "rejected") {
      out.push(
        candidate("expense_rejected", "expense", e.id, "finance", "high", "Expense rejected",
          `Expense ${e.id} for ${project?.name ?? "an unknown project"} has been rejected. Review the reason and update the expense if required.`,
          { projectId: e.projectId, action: expenseAction })
      );
      continue;
    }
    if (e.status !== "pending" && e.status !== "pendingfc") continue;
    if (daysBetween(e.submittedAt, now) < EXPENSE_PENDING_DAYS) continue;
    out.push(
      candidate("expense_pending", "expense", e.id, "finance", "high", "Expense awaiting approval",
        `Expense ${e.id} for ${project?.name ?? "an unknown project"} has been awaiting approval for more than ${EXPENSE_PENDING_DAYS} days.`,
        { projectId: e.projectId, action: expenseAction })
    );
  }

  // 4.8 / 4.10 — low utilization / spend exceeds allocated. Reuse the exact
  // same calc the Reporting module already built (reportingCalcs.ts) rather
  // than re-deriving "at risk"/utilization math a second time.
  const metrics = computeFundUtilizationMetrics({ projects, partners: [], expenses, disbursements });
  for (const p of metrics.byProject) {
    if (p.atRisk) {
      out.push(
        candidate("project_low_utilization", "project", p.projectId, "finance", "high", "Project spending is behind plan",
          `${p.projectName} has low budget utilization while most of the project period has elapsed. Review the remaining budget and planned activities.`,
          { projectId: p.projectId, action: { label: "View Project", route: `/projects/${p.projectId}/details` } })
      );
    }
    if (p.utilized > p.allocated && p.allocated > 0) {
      out.push(
        candidate("project_over_budget", "project", p.projectId, "finance", "critical", "Project budget exceeded",
          `Spending for ${p.projectName} has exceeded the allocated budget by ${fmtInr(p.utilized - p.allocated)}.`,
          { projectId: p.projectId, action: { label: "View Budget", route: `/finance/hlp` } })
      );
    }
  }

  // 4.11 — budget period ending with unallocated balance.
  for (const b of periodBudgets) {
    const daysUntilEnd = daysBetween(today, b.endDate);
    if (daysUntilEnd < 0 || daysUntilEnd > BUDGET_PERIOD_APPROACHING_DAYS) continue;
    const allocated = b.allocations.reduce((sum, a) => sum + a.allocatedAmount, 0);
    const balance = b.totalSanctionedAmount - allocated;
    if (balance <= 0) continue;
    out.push(
      candidate("budget_period_unallocated", "periodBudget", b.id, "finance", "high", "Unallocated budget remaining",
        `Budget period ending ${b.endDate} has ${fmtInr(balance)} remaining unallocated.`,
        { action: { label: "View Budget", route: "/finance/hlp" } })
    );
  }

  return out;
}

// 4.9 — Micro-Budget ownership assigned/changed now lives entirely in
// src/lib/ownershipAlerts.ts (pushOwnershipAlerts), event-pushed from
// MicroBudgetOwnershipDropdown.tsx alongside the identical algorithm for
// Documents/WBS/Indicator Form — replacing the derived rule that used to
// live here. That old rule also unconditionally told the Sponsor about the
// initial assignment, which the corrected spec explicitly forbids (only the
// newly-assigned Partner is told, never the Sponsor) — the shared algorithm
// gets this right by construction, not as a special case.

// ── 5. Governance & Meetings ──────────────────────────────────────────────
function governanceAlerts(input: { meetings: Meeting[]; now: string }): AlertCandidate[] {
  const { meetings, now } = input;
  const out: AlertCandidate[] = [];

  for (const m of meetings) {
    const meetingAction: AlertAction = { label: "View Meeting", route: `/meetings/${m.id}` };

    // 5.2 — meeting within 24 hours.
    if (m.status === "Upcoming") {
      const hrs = hoursBetween(now, `${m.date}T${m.startTime || "00:00"}`);
      if (hrs >= 0 && hrs <= MEETING_SOON_HOURS) {
        out.push(
          candidate("meeting_soon", "meeting", m.id, "governance", "medium", "Meeting tomorrow",
            `${m.title || "This meeting"} is scheduled for ${m.date} ${m.startTime}. Review the meeting details and agenda before the meeting.`,
            { action: meetingAction })
        );
      }
    }

    // 5.3 — completed meeting without sign-off.
    if (m.status === "Completed" && !m.signoff.confirmed) {
      out.push(
        candidate("meeting_signoff_pending", "meeting", m.id, "governance", "high", "Meeting sign-off pending",
          `${m.title || "This meeting"} is marked completed, but the required minutes/sign-off has not been completed.`,
          { action: { label: "Complete Sign-off", route: `/meetings/${m.id}` } })
      );
    }

    // 5.4 — overdue action item.
    for (const a of m.actions) {
      if (a.status === "Done") continue;
      if (daysBetween(a.dueDate, now) <= 0) continue;
      out.push(
        candidate("meeting_action_overdue", "actionItem", a.id, "governance", "high", "Meeting action item overdue",
          `Action item "${a.task}" from ${m.title || "a meeting"} was due on ${a.dueDate} and is still incomplete.`,
          { action: meetingAction })
      );
    }
  }

  return out;
}

// ── 6. Project & Execution ────────────────────────────────────────────────
function projectExecutionAlerts(input: {
  projects: Project[];
  wbs: Record<string, WbsState>;
  indicatorForms: Record<string, IndicatorFormState>;
  indicatorFormResponses: IndicatorFormResponse[];
  indicatorFormShareLinks: Record<string, IndicatorFormShareLink>;
  now: string;
}): AlertCandidate[] {
  const { projects, wbs, indicatorForms, indicatorFormResponses, indicatorFormShareLinks, now } = input;
  const out: AlertCandidate[] = [];
  const today = now.slice(0, 10);

  for (const p of projects) {
    // 6.1 — WBS task overdue.
    const state = wbs[p.id];
    if (state) {
      for (const row of state.rows) {
        const end = row.cells[WBS_COL.end];
        const status = row.cells[WBS_COL.status];
        if (!end || status === "Done") continue;
        if (end >= today) continue;
        const title = row.cells[WBS_COL.title] || "Untitled Task";
        out.push(
          candidate("wbs_task_overdue", "wbsTask", `${p.id}:${row.id}`, "project", "high", "Task overdue",
            `Task "${title}" for ${p.name} was due on ${end} and is still incomplete.`,
            { projectId: p.id, action: { label: "View Task", route: `/projects/${p.id}/wbs` } })
        );
      }
    }

    // 6.2 — project stage stalled.
    if (p.statusChangedAt) {
      const daysInStage = daysBetween(p.statusChangedAt, now);
      if (daysInStage >= PROJECT_STALLED_DAYS) {
        out.push(
          candidate("project_stalled", "project", p.id, "project", "high", "Project progress is stalled",
            `${p.name} has remained in ${p.status} for ${daysInStage} days without significant progress. Review the project status and next steps.`,
            { projectId: p.id, action: { label: "View Project", route: `/projects/${p.id}/details` } })
        );
      }
    }

    // 6.3 — project end date approaching (30/15/7), only while Execution.
    if (p.status === "Execution") {
      const daysUntilEnd = daysBetween(today, p.endDate);
      if (daysUntilEnd >= 0) {
        for (const window of PROJECT_END_WINDOW_DAYS) {
          if (daysUntilEnd > window) continue;
          const severity: AlertSeverity = window === 7 ? "high" : "medium";
          out.push(
            candidate("project_end_approaching", "project", p.id, "project", severity, `Project ends in ${window} days`,
              window === 7
                ? `${p.name} is scheduled to end on ${p.endDate} and is still in Execution. Review outstanding activities and initiate closure if appropriate.`
                : `${p.name} is scheduled to end on ${p.endDate}. Review the remaining activities and closure plan.`,
              { milestone: `${window}d`, projectId: p.id, action: { label: "View Project", route: `/projects/${p.id}/details` } })
          );
          break; // only the tightest window that applies
        }
      }
    }

    // 6.4 — indicator form with no beneficiary records.
    const form = indicatorForms[p.id];
    if (form?.createdAt && daysBetween(form.createdAt, now) >= INDICATOR_FORM_NO_RECORDS_DAYS) {
      const hasResponses = indicatorFormResponses.some((r) => r.projectId === p.id);
      if (!hasResponses) {
        out.push(
          candidate("indicator_form_no_records", "indicatorForm", p.id, "project", "medium", "No beneficiary records received",
            `${form.title || "This project's Indicator Form"} has been active for ${daysBetween(form.createdAt, now)} days but no beneficiary records have been submitted.`,
            { projectId: p.id, action: { label: "View Indicator Form", route: `/projects/${p.id}/indicators` } })
        );
      }
    }
  }

  // 6.5 — shared form with no responses.
  for (const link of Object.values(indicatorFormShareLinks)) {
    if (daysBetween(link.createdAt, now) < SHARE_LINK_NO_RESPONSE_DAYS) continue;
    const hasResponse = indicatorFormResponses.some((r) => r.sharedLinkToken === link.token);
    if (hasResponse) continue;
    const project = projects.find((p) => p.id === link.projectId);
    out.push(
      candidate("share_link_no_response", "shareLink", link.token, "project", "medium", "No responses received",
        `The shared beneficiary form for ${project?.name ?? "this project"} has not received any responses yet. Consider following up with respondents.`,
        { projectId: link.projectId, action: { label: "View Form", route: `/projects/${link.projectId}/indicators` } })
    );
  }

  return out;
}

// ── 7. Partner & Compliance ────────────────────────────────────────────────
function partnerAlerts(input: { partners: PartnerOrg[]; now: string }): AlertCandidate[] {
  const { partners, now } = input;
  const out: AlertCandidate[] = [];
  const partnerAction: AlertAction = { label: "View Partner", route: "/partners" };

  for (const p of partners) {
    // 7.1 — partner invitation pending > 7 days (never submitted onboarding).
    if (p.status === "Invited" && !p.reviewStatus && p.invitedAt && daysBetween(p.invitedAt, now) >= PARTNER_INVITE_PENDING_DAYS) {
      out.push(
        candidate("partner_invite_pending", "partner", p.id, "partner", "high", "Partner onboarding pending",
          `${p.name} has not completed onboarding after ${PARTNER_INVITE_PENDING_DAYS} days. Follow up to complete the onboarding process.`,
          { targetRole: "sponsor", action: partnerAction })
      );
    }

    // 7.3 — partner submission awaiting Sponsor review > 7 days.
    if (p.reviewStatus === "Pending Review" && p.submittedAt && daysBetween(p.submittedAt, now) >= PARTNER_REVIEW_PENDING_DAYS) {
      out.push(
        candidate("partner_review_pending", "partner", p.id, "partner", "high", "Partner review pending",
          `${p.name} has been awaiting Sponsor review for more than ${PARTNER_REVIEW_PENDING_DAYS} days.`,
          { targetRole: "sponsor", action: { label: "Review Submission", route: "/partners" } })
      );
    }

    // 7.4 — partner becomes Inactive. Status stays permanently "Inactive"
    // once set (until a Sponsor reactivates), so dedup gives fire-once
    // behavior the same way as the finance rules above — no event-stamped
    // hook needed in rejectPartnerReview/updatePartner.
    if (p.status === "Inactive") {
      out.push(
        candidate("partner_inactive", "partner", p.id, "partner", "critical", "Partner status changed",
          `${p.name} has been marked as Inactive. Review the Partner profile and affected projects.`,
          { targetRole: "sponsor", action: partnerAction })
      );
    }

    // 7.5 — welcome nudge on first login: upload compliance documents.
    // `firstLoginAt` is stamped once by sessionStore's loginAsPartner (never
    // re-stamped on later logins); the alert itself stays derived off
    // complianceStatus rather than being a one-shot event, so it naturally
    // resolves the moment the partner finishes uploading every required
    // document — no separate "dismiss" action needed for that case, though
    // the Partner can still mark it read at any time.
    if (p.firstLoginAt && p.complianceStatus !== "Complete") {
      out.push(
        candidate("partner_first_login_compliance", "partner", p.id, "partner", "medium", "Upload your compliance documents",
          `Welcome to bImpact! Please upload ${p.name}'s required compliance documents to complete your organization's profile.`,
          { targetPartnerOrgId: p.id, action: { label: "Upload Documents", route: "/compliance" } })
      );
    }

    // 7.5b — Sponsor requests changes on a partner's submission. Includes
    // the Sponsor's own message verbatim (same field PartnerSubmissionReview
    // .tsx and ProjectsTable.tsx's own banner already surface to the
    // partner) so the partner doesn't have to go find it separately.
    // reviewStatus stays "Changes Requested" until the partner resubmits
    // (requestPartnerChanges clears it back only via a later approve/
    // reject/re-request — see settingsStore.ts), so this uses the same
    // fire-once dedup as every other permanent-state alert here.
    if (p.reviewStatus === "Changes Requested" && p.changeRequestMessage) {
      out.push(
        candidate("partner_changes_requested", "partner", p.id, "partner", "high", "Changes requested by Sponsor",
          `Your Sponsor has requested changes to ${p.name}'s submission: "${p.changeRequestMessage}". Go to Compliance to update the required documents.`,
          { targetPartnerOrgId: p.id, action: { label: "Go to Compliance", route: "/compliance" } })
      );
    }

    // 7.6 — partner approved by Sponsor (the onboarding/compliance review
    // decision — there is no separate "approve compliance" action in this
    // app, see approvePartnerReview in settingsStore.ts). reviewStatus stays
    // permanently "Approved" once set, so this uses the same fire-once
    // dedup as 7.4 above rather than an event-stamped hook.
    if (p.reviewStatus === "Approved") {
      out.push(
        candidate("partner_approved", "partner", p.id, "partner", "info", "Your organization has been approved",
          `Congratulations! ${p.name}'s onboarding and compliance submission has been approved by the Sponsor. You now have full access to your partner workspace.`,
          { targetPartnerOrgId: p.id, action: { label: "Go to Workspace", route: "/projects" } })
      );
    }
  }

  return out;
}

// ── 8. Team & Workspace ────────────────────────────────────────────────────
function teamAlerts(input: { teamMembers: TeamMember[]; now: string }): AlertCandidate[] {
  const { teamMembers, now } = input;
  const out: AlertCandidate[] = [];
  for (const m of teamMembers) {
    if (m.status !== "Invited" || !m.invitedAt) continue;
    if (daysBetween(m.invitedAt, now) < TEAM_INVITE_PENDING_DAYS) continue;
    out.push(
      candidate("team_invite_pending", "teamMember", m.id, "team", "medium", "Team invitation pending",
        `${m.name} has not accepted the team invitation sent ${daysBetween(m.invitedAt, now)} days ago.`,
        { targetRole: "sponsor", action: { label: "View Team", route: "/settings/user" } })
    );
  }
  return out;
}

// ── 9. Audit ────────────────────────────────────────────────────────────────
function auditAlerts(input: { indicatorFormResponses: IndicatorFormResponse[] }): AlertCandidate[] {
  const out: AlertCandidate[] = [];
  for (const r of input.indicatorFormResponses) {
    // 9.1 — missing Officer Sign-off. Scoped to the in-app Add Record path
    // ONLY (no sharedLinkToken) — a Share Form respondent submission never
    // has acknowledgement/submittedBy by design (anonymous respondent, no
    // logged-in acknowledger — see BeneficiaryShareRespond.tsx), so that
    // case must never be flagged here. In-app submission already blocks the
    // Save button without acknowledgement (AddRecordSlideOver.tsx), so this
    // should never actually fire in practice — it's a pure audit safety net
    // for any way that guard could someday be bypassed.
    if (r.sharedLinkToken) continue;
    if (r.acknowledgement?.accepted) continue;
    out.push(
      candidate("missing_officer_signoff", "indicatorFormResponse", r.id, "audit", "critical", "Officer sign-off missing",
        `Beneficiary record ${r.id} does not contain the required Officer Sign-off acknowledgement. Review the record immediately.`,
        { projectId: r.projectId, action: { label: "Review Record", route: `/projects/${r.projectId}/indicators` } })
    );
  }
  return out;
}

// ── Entry point ─────────────────────────────────────────────────────────────
export function evaluateAlerts(input: {
  projects: Project[];
  wbs: Record<string, WbsState>;
  indicatorForms: Record<string, IndicatorFormState>;
  indicatorFormResponses: IndicatorFormResponse[];
  indicatorFormShareLinks: Record<string, IndicatorFormShareLink>;
  expenses: Expense[];
  disbursements: Record<string, Tranche[]>;
  periodBudgets: PeriodBudget[];
  meetings: Meeting[];
  partners: PartnerOrg[];
  teamMembers: TeamMember[];
}): AlertCandidate[] {
  const now = new Date().toISOString();
  return [
    ...financeAlerts({ projects: input.projects, expenses: input.expenses, disbursements: input.disbursements, periodBudgets: input.periodBudgets, now }),
    ...governanceAlerts({ meetings: input.meetings, now }),
    ...projectExecutionAlerts({
      projects: input.projects,
      wbs: input.wbs,
      indicatorForms: input.indicatorForms,
      indicatorFormResponses: input.indicatorFormResponses,
      indicatorFormShareLinks: input.indicatorFormShareLinks,
      now,
    }),
    ...partnerAlerts({ partners: input.partners, now }),
    ...teamAlerts({ teamMembers: input.teamMembers, now }),
    ...auditAlerts({ indicatorFormResponses: input.indicatorFormResponses }),
  ];
}
