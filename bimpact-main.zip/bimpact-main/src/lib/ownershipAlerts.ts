// Single shared implementation of the responsibility-change alert algorithm —
// used identically by every ownership-governed resource (Documents, WBS,
// Indicator Form, Micro-Budget) per explicit product decision: this must
// never drift into four hand-rolled copies.
//
// Final rule (as specified): every responsibility change has TWO sides.
//   IF previousMode === newMode
//     → no alert at all (nothing actually changed)
//   ELSE
//     → OUTGOING side: whoever's access was reduced (lost it entirely, or
//       lost sole/exclusive control by moving to "both") gets a
//       "Responsibility Changed" alert naming who it moved to.
//     → INCOMING side: whoever gained sole responsibility, or gained access
//       for the first time via a move to "both", gets a "Responsibility
//       Assigned" alert. This fires every time a party becomes responsible,
//       including regaining it after previously losing it — never
//       suppressed as "already seen before".
//
// Note a party who already had access under "both" and becomes the sole
// exclusive owner (both → partner / both → self) STILL gets the "assigned"
// alert even though they technically had access already — going exclusive
// is itself a responsibility change for them.
import { OwnershipMode } from "@/types/project";
import { useAlertStore } from "@/store/alertStore";
import { getPartnersByProject } from "@/lib/dashboardScope";
import { useWorkspaceStore, DEFAULT_DEMO_WORKSPACE_ID } from "@/store/workspaceStore";

export type OwnershipResourceKind = "document" | "wbs" | "indicator_form" | "micro_budget";

type Party = "sponsor" | "partner";

const RESOURCE: Record<
  OwnershipResourceKind,
  // `titleLabel` defaults to `label` — only Micro-Budget's spec actually
  // hyphenates it in the title ("Micro-Budget Responsibility Assigned")
  // while keeping the body unhyphenated ("...managing the Micro Budget
  // for..."), so it's the one resource that needs both forms.
  { label: string; titleLabel?: string; typePrefix: string; route: (projectId: string) => string; ctaLabel: string }
> = {
  document: {
    label: "Project Details / Documents",
    typePrefix: "document_ownership",
    route: (projectId) => `/projects/${projectId}/details`,
    ctaLabel: "View Project",
  },
  wbs: {
    label: "Work Breakdown Structure",
    typePrefix: "wbs_ownership",
    route: (projectId) => `/projects/${projectId}/wbs`,
    ctaLabel: "View WBS",
  },
  indicator_form: {
    label: "Beneficiary Indicator Form",
    typePrefix: "indicator_form_ownership",
    route: (projectId) => `/projects/${projectId}/indicators`,
    ctaLabel: "View Indicator Form",
  },
  micro_budget: {
    label: "Micro Budget",
    titleLabel: "Micro-Budget",
    typePrefix: "micro_budget_ownership",
    route: () => "/finance/micro",
    ctaLabel: "View Micro-Budget",
  },
};

function accessorsFor(mode: OwnershipMode | null): Set<Party> {
  if (mode === "self") return new Set(["sponsor"]);
  if (mode === "partner") return new Set(["partner"]);
  if (mode === "both") return new Set(["sponsor", "partner"]);
  return new Set();
}

type NotificationKind = "assigned" | "assigned_collaborative" | "changed_reassigned" | "changed_collaborative";
type Notification = { target: Party; kind: NotificationKind; toParty?: Party };

// The algorithm itself, kept pure/testable and separate from the
// alertStore-pushing side effects below. Returns both the outgoing
// ("changed") and incoming ("assigned") notifications for one transition.
export function computeOwnershipNotifications(previousMode: OwnershipMode | null, newMode: OwnershipMode): Notification[] {
  if (previousMode === newMode) return [];

  const prevAccess = accessorsFor(previousMode);
  const out: Notification[] = [];

  if (newMode !== "both") {
    const newParty: Party = newMode === "self" ? "sponsor" : "partner";
    const otherParty: Party = newParty === "sponsor" ? "partner" : "sponsor";
    // Incoming — the new exclusive owner, always alerted on a real change,
    // even if they already had (shared) access under a previous "both".
    out.push({ target: newParty, kind: "assigned" });
    // Outgoing — only if the other party actually had access before.
    if (prevAccess.has(otherParty)) {
      out.push({ target: otherParty, kind: "changed_reassigned", toParty: newParty });
    }
    return out;
  }

  // newMode === "both"
  for (const party of ["sponsor", "partner"] as Party[]) {
    if (!prevAccess.has(party)) {
      // Gaining access for the first time via the move to collaborative.
      out.push({ target: party, kind: "assigned_collaborative" });
    }
  }
  if (prevAccess.size === 1) {
    // The previous sole owner keeps access but loses exclusivity.
    const soleParty = [...prevAccess][0];
    out.push({ target: soleParty, kind: "changed_collaborative" });
  }
  return out;
}

// `newResponsibleOrgName` is only used by "changed_reassigned" — the
// recipient there is losing responsibility to a NAMED organization (the
// actual Sponsor workspace name or Partner org name, never the generic
// word "Sponsor"/"Partner"). The other three kinds describe the
// recipient's own new responsibility, so no other org's name is needed —
// they already know "you" are the new responsible party.
function messageFor(
  n: Notification,
  resourceLabel: string,
  resourceTitleLabel: string,
  projectName: string,
  newResponsibleOrgName: string
): { title: string; message: string; severity: "info" | "medium" } {
  if (n.kind === "assigned") {
    return {
      title: `${resourceTitleLabel} Responsibility Assigned`,
      message: `You are now responsible for creating and managing the ${resourceLabel} for ${projectName}.`,
      severity: "info",
    };
  }
  if (n.kind === "assigned_collaborative") {
    return {
      title: `${resourceTitleLabel} Responsibility Assigned`,
      message: `You are now responsible for collaboratively managing the ${resourceLabel} for ${projectName}.`,
      severity: "info",
    };
  }
  if (n.kind === "changed_collaborative") {
    return {
      title: `${resourceTitleLabel} Responsibility Changed`,
      message: `${resourceLabel} creation and management for ${projectName} is no longer exclusively your responsibility. Responsibility is now shared collaboratively.`,
      severity: "medium",
    };
  }
  // changed_reassigned
  return {
    title: `${resourceTitleLabel} Responsibility Changed`,
    message: `${resourceLabel} creation and management for ${projectName} is no longer your responsibility. Responsibility has been assigned to ${newResponsibleOrgName}.`,
    severity: "medium",
  };
}

// The one call site every ownership picker (DocumentOwnershipStrip.tsx,
// WbsTable.tsx, IndicatorsView.tsx, MicroBudgetOwnershipDropdown.tsx) makes
// right after calling its own store setter. Resolves the assigned Partner
// org itself (via dashboardScope.ts) so callers don't each re-derive it.
export function pushOwnershipAlerts(
  kind: OwnershipResourceKind,
  projectId: string,
  projectName: string,
  previousMode: OwnershipMode | null,
  newMode: OwnershipMode
): void {
  const notifications = computeOwnershipNotifications(previousMode, newMode);
  if (notifications.length === 0) return;

  const resource = RESOURCE[kind];
  const action = { label: resource.ctaLabel, route: resource.route(projectId) };
  const alerts = useAlertStore.getState();
  const partner = getPartnersByProject(projectId)[0];
  const category: "finance" | "project" = kind === "micro_budget" ? "finance" : "project";
  const sponsorOrgName =
    useWorkspaceStore.getState().workspaces.find((w) => w.id === DEFAULT_DEMO_WORKSPACE_ID)?.name ?? "the Sponsor";
  const ORG_NAME_FOR: Record<Party, string> = { sponsor: sponsorOrgName, partner: partner?.name ?? "the Partner" };

  for (const n of notifications) {
    if (n.target === "partner" && !partner) continue; // nobody to notify

    const newResponsibleOrgName = n.toParty ? ORG_NAME_FOR[n.toParty] : "";
    const { title, message, severity } = messageFor(
      n,
      resource.label,
      resource.titleLabel ?? resource.label,
      projectName,
      newResponsibleOrgName
    );
    const isIncoming = n.kind === "assigned" || n.kind === "assigned_collaborative";

    // Discrete, repeatable historical event — every occurrence (gaining OR
    // losing responsibility) is its own distinct fact and must show up on
    // its own, never deduped against an earlier one (a party can regain
    // responsibility after losing it, and must be alerted again then).
    const base = {
      key: `${resource.typePrefix}_${isIncoming ? "assigned" : "changed"}:project:${projectId}`,
      type: `${resource.typePrefix}_${isIncoming ? "assigned" : "changed"}_${n.target}`,
      category,
      severity,
      title,
      message,
      entityType: "project" as const,
      entityId: projectId,
      projectId,
      action,
    };
    if (n.target === "sponsor") {
      alerts.pushHistoryEvent({ ...base, targetRole: "sponsor" });
    } else if (partner) {
      alerts.pushHistoryEvent({ ...base, targetPartnerOrgId: partner.id });
    }
  }
}
