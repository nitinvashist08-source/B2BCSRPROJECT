import { PartnerOrg } from "@/types/settings";

// Shared contract for the Sponsor's "View Submission" screen — three content
// sections (Organization Details / Operating Location / Compliance
// Documents) each render differently depending on which bucket a partner
// falls into. This categorization is DISPLAY-ONLY: it never reads/writes
// anything beyond the partner record already in the store, and never
// generates data that gets persisted — sample documents shown for the
// "active-demo" bucket exist only in the rendered JSX, not in
// partner.complianceDocuments.
export type PartnerSubmissionCategory = "active-demo" | "invited-pending" | "submitted";

// - "active-demo": legacy/seed partners with no review-workflow history at
//   all (status Active/Inactive, no reviewStatus — e.g. the two seeded demo
//   partners in settingsData.ts). Their org/location fields are already
//   real (seed data has them); only compliance documents need prototype
//   sample data, since there's no real upload trail for them at all.
// - "invited-pending": still mid-invite, genuinely hasn't submitted
//   onboarding yet (status "Invited", no reviewStatus) — nothing beyond the
//   invite's own org identity fields (name/contactName/contactEmail/type)
//   exists yet; state/districts/complianceDocuments are all still empty.
// - "submitted": has gone through the real onboarding wizard at least once
//   (reviewStatus is set — Pending Review/Changes Requested/Approved/
//   Rejected — regardless of the legacy `status` value, which may still say
//   "Invited" for a submitted-but-not-yet-approved partner). Every field
//   shown here is the partner's actual submitted data, never fabricated.
export function categorizePartnerSubmission(partner: PartnerOrg): PartnerSubmissionCategory {
  if (partner.reviewStatus) return "submitted";
  if (partner.status === "Invited") return "invited-pending";
  return "active-demo";
}

// Realistic sample filenames for the "active-demo" bucket's fully-completed
// compliance profile — one per catalog item id the seed "Implementer"
// compliance checklist (settingsData.ts) actually selects. Document
// labels/required-item lists are no longer fixed here at all — both the
// Partner's /compliance page and ComplianceDocumentsSection now resolve
// those dynamically per partner type via
// src/lib/partnerComplianceRequirements.ts. "Other Supporting Documents" is
// deliberately omitted here, same as before: the active-demo bucket only
// fabricates the required-certificate rows, never sample "Other" docs.
export const DEMO_COMPLIANCE_FILENAMES: Partial<Record<string, string>> = {
  org_pan_card: "PAN_Card.pdf",
  org_gst_certificate: "GST_Certificate.pdf",
  tax_12a_12ab_certificate: "12A_Certificate.pdf",
  tax_80g_certificate: "80G_Certificate.pdf",
  tax_csr1_registration: "CSR_Form_1.pdf",
};
