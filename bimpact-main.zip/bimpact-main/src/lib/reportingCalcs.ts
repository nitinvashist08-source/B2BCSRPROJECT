// Pure calculation layer for the Reporting module's "Fund Utilization &
// Financial Health" report (src/components/reporting/FundUtilizationReport.tsx).
// Every function here takes plain arrays/records as input (no store reads) so
// it stays testable and reusable — the report component is the only caller
// that wires it up to useFinanceStore/useProjectStore/useSettingsStore state.
//
// Simplifications, deliberately matching existing app conventions rather
// than inventing new ones:
// - "Allocated" per project = Project.budget, the same "latest allocation
//   wins, no cross-period summing" simplification financeStore.ts's
//   syncProjectBudget already uses (see PeriodBudget's own doc comment in
//   types/finance.ts). This report does not re-derive allocation from
//   PeriodBudget.allocations itself, it just reads the value the rest of the
//   app already keeps in sync.
// - "Disbursed" = sum of Tranche.amount with status "released" (cash actually
//   sent to a partner). "Utilized"/"Spent" = sum of Expense.amount with
//   status "approved" (fully approved spend). The gap between these two —
//   floatGap — is cash a partner is holding but hasn't yet spent; not
//   tracked anywhere else in this app today.
// - Partner attribution uses dashboardScope.ts's getProjectsByPartner (the
//   existing many-to-many Partner<->Project source of truth), not the
//   legacy Project.partner display string, so a project assigned to
//   multiple partners is correctly counted under each.

import { Expense, Tranche, TrancheStatus } from "@/types/finance";
import { Project } from "@/types/project";
import { PartnerOrg } from "@/types/settings";
import { getProjectsByPartner } from "@/lib/dashboardScope";

export type ProjectFinancials = {
  projectId: string;
  projectName: string;
  allocated: number;
  utilized: number;
  disbursed: number;
  utilizationPct: number; // 0-100, 0 when allocated is 0
  atRisk: boolean; // low spend with little of the project timeline left
};

export type PartnerFinancials = {
  partnerId: string;
  partnerName: string;
  allocated: number;
  utilized: number;
  disbursed: number;
  utilizationPct: number;
};

export type TrancheWithProject = {
  tranche: Tranche;
  projectName: string;
};

export type FundUtilizationMetrics = {
  totalAllocated: number;
  totalDisbursed: number;
  totalUtilized: number;
  floatGap: number; // disbursed - utilized, floored at 0 for display
  utilizationPct: number;
  pendingApprovalAmount: number;
  pendingApprovalCount: number;
  rejectedAmount: number;
  rejectedCount: number;
  trancheByStatus: Record<TrancheStatus, { count: number; amount: number }>;
  overdueTranches: TrancheWithProject[];
  upcomingTranches: (TrancheWithProject & { daysAway: number })[];
  byProject: ProjectFinancials[]; // sorted lowest utilization % first
  byPartner: PartnerFinancials[]; // sorted lowest utilization % first
};

function emptyTrancheByStatus(): Record<TrancheStatus, { count: number; amount: number }> {
  return {
    scheduled: { count: 0, amount: 0 },
    upcoming: { count: 0, amount: 0 },
    overdue: { count: 0, amount: 0 },
    released: { count: 0, amount: 0 },
  };
}

function daysBetween(fromIso: string, toIso: string): number {
  const from = new Date(fromIso).getTime();
  const to = new Date(toIso).getTime();
  if (Number.isNaN(from) || Number.isNaN(to)) return 0;
  return Math.round((to - from) / 86_400_000);
}

// A project is flagged "at risk" when it's well into its own timeline but
// has spent little of its allocation — the year-end-unspent-fund problem
// CSR Heads actually care about, not just a generic low-utilization flag.
function isAtRisk(project: Project, utilizationPct: number): boolean {
  const totalSpan = daysBetween(project.startDate, project.endDate);
  if (totalSpan <= 0) return false;
  const elapsed = daysBetween(project.startDate, new Date().toISOString().slice(0, 10));
  const timeElapsedPct = Math.min(100, Math.max(0, (elapsed / totalSpan) * 100));
  return timeElapsedPct >= 60 && utilizationPct < 50;
}

function projectFinancials(
  project: Project,
  expenses: Expense[],
  disbursements: Record<string, Tranche[]>
): ProjectFinancials {
  const allocated = project.budget;
  const utilized = expenses
    .filter((e) => e.projectId === project.id && e.status === "approved")
    .reduce((sum, e) => sum + e.amount, 0);
  const disbursed = (disbursements[project.id] ?? [])
    .filter((t) => t.status === "released")
    .reduce((sum, t) => sum + t.amount, 0);
  const utilizationPct = allocated > 0 ? (utilized / allocated) * 100 : 0;
  return {
    projectId: project.id,
    projectName: project.name || "Untitled Project",
    allocated,
    utilized,
    disbursed,
    utilizationPct,
    atRisk: isAtRisk(project, utilizationPct),
  };
}

export function computeFundUtilizationMetrics(input: {
  projects: Project[]; // already scoped to the active filter
  partners: PartnerOrg[]; // already scoped to the active filter
  expenses: Expense[]; // ALL expenses (unscoped) — filtered internally per project
  disbursements: Record<string, Tranche[]>; // ALL disbursements (unscoped)
}): FundUtilizationMetrics {
  const { projects, partners, expenses, disbursements } = input;
  const projectIds = new Set(projects.map((p) => p.id));

  const byProject = projects
    .map((p) => projectFinancials(p, expenses, disbursements))
    .sort((a, b) => a.utilizationPct - b.utilizationPct);

  const totalAllocated = byProject.reduce((sum, p) => sum + p.allocated, 0);
  const totalUtilized = byProject.reduce((sum, p) => sum + p.utilized, 0);
  const totalDisbursed = byProject.reduce((sum, p) => sum + p.disbursed, 0);

  const scopedExpenses = expenses.filter((e) => projectIds.has(e.projectId));
  const pendingApproval = scopedExpenses.filter((e) => e.status === "pending" || e.status === "pendingfc");
  const rejected = scopedExpenses.filter((e) => e.status === "rejected");

  const scopedTranches = projects.flatMap((p) =>
    (disbursements[p.id] ?? []).map((t) => ({ tranche: t, projectName: p.name || "Untitled Project" }))
  );

  const trancheByStatus = emptyTrancheByStatus();
  for (const { tranche } of scopedTranches) {
    trancheByStatus[tranche.status].count += 1;
    trancheByStatus[tranche.status].amount += tranche.amount;
  }

  const today = new Date().toISOString().slice(0, 10);
  const overdueTranches = scopedTranches
    .filter((t) => t.tranche.status === "overdue")
    .sort((a, b) => (a.tranche.date < b.tranche.date ? -1 : 1));
  const upcomingTranches = scopedTranches
    .filter((t) => t.tranche.status === "upcoming" || t.tranche.status === "scheduled")
    .map((t) => ({ ...t, daysAway: daysBetween(today, t.tranche.date) }))
    .filter((t) => t.daysAway >= 0 && t.daysAway <= 90)
    .sort((a, b) => a.daysAway - b.daysAway);

  const byPartner = partners
    .map((partner) => {
      const partnerProjectIds = new Set(getProjectsByPartner(partner.id).map((p) => p.id));
      const relevant = byProject.filter((p) => partnerProjectIds.has(p.projectId) && projectIds.has(p.projectId));
      const allocated = relevant.reduce((sum, p) => sum + p.allocated, 0);
      const utilized = relevant.reduce((sum, p) => sum + p.utilized, 0);
      const disbursed = relevant.reduce((sum, p) => sum + p.disbursed, 0);
      return {
        partnerId: partner.id,
        partnerName: partner.name,
        allocated,
        utilized,
        disbursed,
        utilizationPct: allocated > 0 ? (utilized / allocated) * 100 : 0,
      };
    })
    .filter((p) => p.allocated > 0 || p.utilized > 0 || p.disbursed > 0)
    .sort((a, b) => a.utilizationPct - b.utilizationPct);

  return {
    totalAllocated,
    totalDisbursed,
    totalUtilized,
    floatGap: Math.max(0, totalDisbursed - totalUtilized),
    utilizationPct: totalAllocated > 0 ? (totalUtilized / totalAllocated) * 100 : 0,
    pendingApprovalAmount: pendingApproval.reduce((sum, e) => sum + e.amount, 0),
    pendingApprovalCount: pendingApproval.length,
    rejectedAmount: rejected.reduce((sum, e) => sum + e.amount, 0),
    rejectedCount: rejected.length,
    trancheByStatus,
    overdueTranches,
    upcomingTranches,
    byProject,
    byPartner,
  };
}
