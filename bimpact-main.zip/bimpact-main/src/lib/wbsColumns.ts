import { WbsColumn, WbsRow } from "@/types/project";

// Status/Priority option sets — exact casing/values per the Add Task spec.
export const WBS_STATUS_OPTIONS = ["To-do", "In-progress", "Done"] as const;
export type WbsStatus = (typeof WBS_STATUS_OPTIONS)[number];

export const WBS_PRIORITY_OPTIONS = ["Urgent", "High", "Medium", "Low"] as const;
export type WbsPriority = (typeof WBS_PRIORITY_OPTIONS)[number];

// Fixed column ids — kept stable (not regenerated) so persisted cell data
// survives the fixed-schema migration (see projectStore.ts's
// normalizeWbsColumns) and so other files can key off a specific field
// (this file's own syncStatusAndCompletion, WbsTable's per-column special
// rendering) without string-literal drift.
export const WBS_COL = {
  title: "col-task",
  description: "col-desc",
  assignee: "col-assigned",
  start: "col-start",
  end: "col-end",
  status: "col-status",
  completion: "col-completion",
  priority: "col-priority",
  dependency: "col-dependency",
  remarks: "col-remarks",
} as const;

// The WBS's fixed, non-configurable Task schema — replaces the old
// freeform Add Column/Add Row model (see the Add Task redesign spec).
// Every project's WBS uses exactly this column set now; nothing adds,
// removes, renames, or retypes a column through the UI anymore.
//
// IMPORTANT: columns[0] must stay the task-title/name field at this same
// id — TranchePipeline.tsx and ScheduleTrancheSlideOver.tsx both read
// `wbs.columns[0]` as "the task display-name column" when linking a
// Disbursement tranche to a WBS task, so its position/id is load-bearing
// outside this file too.
export function taskColumns(): WbsColumn[] {
  return [
    { id: WBS_COL.title, label: "Task Title", inputType: "text" },
    { id: WBS_COL.description, label: "Task Description", inputType: "text" },
    { id: WBS_COL.assignee, label: "Assigned To", inputType: "assignee" },
    { id: WBS_COL.start, label: "Start Date", inputType: "date" },
    { id: WBS_COL.end, label: "End Date", inputType: "date" },
    { id: WBS_COL.status, label: "Status", inputType: "select", options: [...WBS_STATUS_OPTIONS] },
    { id: WBS_COL.completion, label: "Completion Percentage", inputType: "number" },
    { id: WBS_COL.priority, label: "Priority", inputType: "select", options: [...WBS_PRIORITY_OPTIONS] },
    { id: WBS_COL.dependency, label: "Dependency", inputType: "dependency" },
    { id: WBS_COL.remarks, label: "Remarks", inputType: "remarks" },
  ];
}

// Completion % <-> Status auto-sync (spec section 10.1, rules 1-5) — one
// implementation shared by Task creation (addWbsTask) and Task editing
// (updateWbsTask), so the rule can never drift between the two entry points.
export function syncStatusAndCompletion(
  status: string,
  completion: number,
  changed: "status" | "completion"
): { status: string; completion: number } {
  const clamped = Math.max(0, Math.min(100, Math.round(completion || 0)));

  if (changed === "completion") {
    if (clamped === 100) return { status: "Done", completion: 100 }; // Rule 1
    if (status === "To-do" && clamped > 0) return { status: "In-progress", completion: clamped }; // Rule 2
    return { status, completion: clamped }; // Rules 3 & 4
  }

  // changed === "status"
  if (status === "Done") return { status, completion: 100 }; // Rule 5
  return { status, completion: clamped };
}

// Dependency cells store a comma-joined list of the referenced Task IDs —
// no separate dependency data source, per spec. These two helpers are the
// only place that (de)serializes that format.
export function dependencyIdsFromCell(cell: string | undefined): string[] {
  return (cell ?? "").split(",").map((s) => s.trim()).filter(Boolean);
}
export function dependencyCellFromIds(ids: string[]): string {
  return ids.join(",");
}

// "A7K2 — Task title" — the MultiSelect-friendly display token for a
// dependency choice. The leading 4-character id is always parseable back
// out (dependencyIdFromToken) since Task IDs are a fixed 4-char format.
export function dependencyToken(row: WbsRow): string {
  const title = row.cells[WBS_COL.title]?.trim();
  return `${row.id} — ${title || "Untitled Task"}`;
}
export function dependencyIdFromToken(token: string): string {
  return token.slice(0, 4);
}
