// This app has no backend/database — every Zustand store's state lives
// entirely in the browser. Replaces the old Prisma-backed persistStore.ts:
// `loadLocal` seeds a store from localStorage if a previous session already
// saved something, falling back to the bundled sample data (src/data/*.ts)
// otherwise. `persistLocal` mirrors the old persistOnChange signature/
// debounce behavior, just writing to localStorage instead of calling a
// server action. Net effect: no shared/multi-user data, and everything
// resets if the browser's site data is cleared — see src/data/*.ts for the
// sample data each store falls back to.

type Subscribable<T> = {
  subscribe: (listener: (state: T) => void) => () => void;
};

const STORAGE_PREFIX = "bimpact:";

export function loadLocal<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(STORAGE_PREFIX + key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch (err) {
    console.error(`Failed to read "${key}" from localStorage, falling back to sample data`, err);
    return fallback;
  }
}

export function persistLocal<T extends { hydrated: boolean }>(
  key: string,
  store: Subscribable<T>,
  serialize: (state: T) => unknown,
  delay = 400
) {
  if (typeof window === "undefined") return;
  let timeout: ReturnType<typeof setTimeout> | null = null;
  store.subscribe((state) => {
    if (!state.hydrated) return;
    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(() => {
      try {
        window.localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(serialize(state)));
      } catch (err) {
        console.error(`Failed to persist "${key}" to localStorage`, err);
      }
    }, delay);
  });
}

// Same-browser, cross-tab live sync (e.g. a Sponsor tab and a Partner tab
// open side by side): the browser's native `storage` event fires in every
// OTHER tab of the same origin whenever one tab writes to localStorage —
// never in the tab that made the write itself, so there's no self-trigger
// risk. Without this, a change made in one tab (e.g. Sponsor invites/edits
// a partner) only reaches an already-open other tab (e.g. that Partner's
// onboarding/Compliance page) after a manual reload — every store's
// in-memory Zustand state is otherwise per-tab, localStorage is just where
// it happens to persist to. DataBootstrap wires this up once, app-wide,
// dispatching each bimpact:<key> change to that store's own existing
// `hydrate` (the same one used on initial load), so the exact same
// normalization/migration logic runs either way — no second data path.
export function subscribeToStorageChanges(onChange: (key: string, raw: string | null) => void): () => void {
  if (typeof window === "undefined") return () => {};
  function handleStorage(e: StorageEvent) {
    if (!e.key || !e.key.startsWith(STORAGE_PREFIX)) return;
    onChange(e.key.slice(STORAGE_PREFIX.length), e.newValue);
  }
  window.addEventListener("storage", handleStorage);
  return () => window.removeEventListener("storage", handleStorage);
}
