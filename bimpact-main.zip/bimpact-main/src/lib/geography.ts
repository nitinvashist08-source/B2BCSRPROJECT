export const DIST_MAP: Record<string, string[]> = {
  "Andhra Pradesh": ["Visakhapatnam", "Krishna", "Guntur", "Chittoor", "Kurnool"],
  "Arunachal Pradesh": ["Papum Pare", "West Kameng", "East Siang", "Lohit"],
  Assam: ["Kamrup", "Dibrugarh", "Jorhat", "Cachar", "Nagaon"],
  Bihar: ["Patna", "Gaya", "Bhojpur", "Muzaffarpur", "Darbhanga"],
  Chhattisgarh: ["Raipur", "Bilaspur", "Durg", "Bastar"],
  Goa: ["North Goa", "South Goa"],
  Gujarat: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar"],
  Haryana: ["Gurugram", "Faridabad", "Hisar", "Panipat", "Karnal"],
  "Himachal Pradesh": ["Shimla", "Kangra", "Mandi", "Solan"],
  Jharkhand: ["Ranchi", "Dhanbad", "East Singhbhum", "Bokaro"],
  Karnataka: ["Bengaluru Urban", "Mysuru", "Belagavi", "Dharwad", "Dakshina Kannada"],
  Kerala: ["Thiruvananthapuram", "Ernakulam", "Kozhikode", "Thrissur"],
  "Madhya Pradesh": ["Bhopal", "Indore", "Gwalior", "Jabalpur", "Ujjain"],
  Maharashtra: ["Pune", "Mumbai City", "Mumbai Suburban", "Nagpur", "Nashik", "Thane"],
  Manipur: ["Imphal East", "Imphal West", "Thoubal"],
  Meghalaya: ["East Khasi Hills", "West Garo Hills"],
  Mizoram: ["Aizawl", "Lunglei"],
  Nagaland: ["Kohima", "Dimapur"],
  Odisha: ["Khordha", "Cuttack", "Ganjam", "Sundargarh"],
  Punjab: ["Amritsar", "Ludhiana", "Jalandhar", "Patiala"],
  Rajasthan: ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Bikaner"],
  Sikkim: ["East Sikkim", "West Sikkim"],
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Salem", "Tiruchirappalli"],
  Telangana: ["Hyderabad", "Warangal", "Nizamabad", "Karimnagar"],
  Tripura: ["West Tripura", "South Tripura"],
  "Uttar Pradesh": ["Lucknow", "Kanpur Nagar", "Varanasi", "Agra", "Ghaziabad"],
  Uttarakhand: ["Dehradun", "Haridwar", "Nainital", "Udham Singh Nagar"],
  "West Bengal": ["Kolkata", "Howrah", "North 24 Parganas", "Darjeeling", "Murshidabad"],
  "Andaman and Nicobar Islands": ["South Andaman", "North and Middle Andaman", "Nicobar"],
  Chandigarh: ["Chandigarh"],
  "Dadra and Nagar Haveli and Daman and Diu": ["Dadra and Nagar Haveli", "Daman", "Diu"],
  Delhi: ["New Delhi", "North Delhi", "South Delhi", "East Delhi"],
  "Jammu and Kashmir": ["Srinagar", "Jammu", "Anantnag", "Baramulla"],
  Ladakh: ["Leh", "Kargil"],
  Lakshadweep: ["Lakshadweep"],
  Puducherry: ["Puducherry", "Karaikal"],
};

export const ALL_STATES = Object.keys(DIST_MAP);

export function districtsFor(state: string): string[] {
  return DIST_MAP[state] ?? [];
}

// India PIN codes are 6 digits, first digit never 0.
export const PIN_CODE_REGEX = /^[1-9][0-9]{5}$/;
