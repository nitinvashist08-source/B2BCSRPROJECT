export type ProjectStatus = "Planning" | "Execution" | "Review" | "Closing";
export type OwnershipMode = "self" | "partner" | "both";

export type Project = {
  id: string;
  code: string;
  name: string;
  location: string;
  partner: string;
  status: ProjectStatus;
  // System-stamped ISO timestamp of when `status` last changed — stamped
  // once at project creation, then re-stamped only by updateProject
  // (projectStore.ts) whenever a patch actually changes `status` (not on
  // every generic field edit). Powers the "Project progress is stalled"
  // alert (days-in-current-stage), which has no other way to know how long
  // a project has sat in its current stage.
  statusChangedAt: string;
  budget: number;
  startDate: string;
  endDate: string;
  description: string;
};

export type ProjectDoc = {
  id: string;
  title: string;
  contentHtml: string;
  created: string;
  modified: string;
  kind: "created" | "uploaded";
  fileName?: string;
  fileType?: "docx" | "pdf" | "doc" | "other";
  fileUrl?: string;
};

export type WbsColumn = {
  id: string;
  label: string;
  // "assignee"/"dependency"/"remarks" are special-rendered (dynamic
  // options, multi-value, or an opens-a-slide-over control) rather than a
  // plain input — see WbsTable.tsx and lib/wbsColumns.ts.
  inputType?: "text" | "date" | "select" | "number" | "assignee" | "dependency" | "remarks";
  options?: string[];
};

export type WbsRow = {
  id: string;
  cells: Record<string, string>;
};

export type WbsState = {
  mode: OwnershipMode | null;
  columns: WbsColumn[];
  rows: WbsRow[];
};

// Input shape for projectStore's addWbsTask — one Task created through the
// Add/Edit Task slide-over (see components/projects/TaskFormSlideOver.tsx). Maps
// 1:1 onto the fixed WBS_COL fields in lib/wbsColumns.ts.
export type WbsTaskInput = {
  title: string;
  description: string;
  assignee: string;
  startDate: string;
  endDate: string;
  status: string;
  completion: number;
  priority: string;
  dependencyIds: string[];
  remarks: string;
};

// Field type keys match the original source's UNIVERSAL_FORM / gfFieldHTML type
// values exactly (text/para/radio/checkbox/... not a renamed taxonomy) so the
// data model lines up 1:1 with bImpact_MeetingSplit_v10.html.
export type FormFieldType =
  | "text"
  | "para"
  | "number"
  | "email"
  | "phone"
  | "currency"
  | "url"
  | "radio"
  | "checkbox"
  | "dropdown"
  | "yesno"
  | "date"
  | "time"
  | "rating"
  | "scale"
  | "address"
  | "signature"
  | "file";

export type FormField = {
  id: string;
  type: FormFieldType;
  label: string;
  required: boolean;
  description?: string;
  options?: string[];
  min?: number;
  max?: number;
};

export type FormSection = {
  id: string;
  title: string;
  description?: string;
  badge?: string;
  fields: FormField[];
};

// Project-scoped Indicator Form (Workplace → Project → Beneficiary
// Indicators → Indicator Form) — mirrors WbsState's per-project shape:
// absence of a projectId entry in projectStore's `indicatorForms` record
// means "not created yet" (see IndicatorsView.tsx's empty-state/"Create
// Indicator Form" flow), never an auto-populated default. `locked` is a
// separate, pre-existing "Activate & Save" axis (once true, read-only for
// everyone regardless of ownership) — independent of the ownership-based
// canEditProjectResource() permission in permissions.ts.
export type IndicatorFormState = {
  title: string;
  description: string;
  sections: FormSection[];
  locked: boolean;
  // System-stamped ISO timestamp of when createIndicatorForm (projectStore.ts)
  // created this record — powers the "No beneficiary records received"
  // alert (days-since-form-existed with zero responses). Optional only so a
  // form created before this field existed (already-persisted localStorage
  // data) still type-checks; alertRules.ts treats a missing value as "can't
  // compute age, skip this rule for that project" rather than guessing.
  createdAt?: string;
};

// Workplace → Beneficiary Indicators → Add Record, when driven by the
// project's Indicator Form (see AddRecordSlideOver.tsx): one submission's
// answers, keyed by FormField id, against whichever Indicator Form the
// project has at submission time. Deliberately separate from
// BeneficiaryRecord (the older fixed-shape record type, still used by the
// existing Records table/seed data, untouched) — an Indicator Form's
// questions are project-defined and arbitrary, so its answers can't be
// forced into BeneficiaryRecord's fixed name/gender/age/... fields.
// `indicatorFormId` is just the owning projectId (this app's Indicator Form
// has no separate id of its own — one project, one form — see
// IndicatorFormState) kept as its own field for traceability/parity with
// the spec's data model, not because it can differ from projectId today.
export type IndicatorFormResponse = {
  id: string;
  projectId: string;
  indicatorFormId: string;
  responses: Record<string, string>;
  submittedAt: string;
  // Present only for a response submitted through a Share Form link (see
  // IndicatorFormShareLink below) — absent for one entered directly via the
  // existing in-app "+ Add Record" flow. Identifies the logged-in Sponsor/
  // Partner who GENERATED the link (the "Form Owner/Sharer"), never the
  // anonymous respondent who actually filled it in — the respondent's own
  // answers live in `responses` above like any other submission.
  sharedLinkToken?: string;
  submittedBy?: {
    userId: string;
    name: string;
    email: string;
    role: "sponsor" | "partner";
  };
  // Officer Signature & Acknowledgement (Workplace → Beneficiary Indicators
  // → Add Record's system-generated closing section, OfficerSignoffSection
  // .tsx) — present only for a response entered through that in-app flow;
  // absent for a Share Form respondent's submission (that flow has no
  // logged-in acknowledger, see BeneficiaryShareRespond.tsx). Set once at
  // submission by addIndicatorFormResponse and never re-stamped — there is
  // no edit action for an existing IndicatorFormResponse today, so there is
  // nothing yet that could overwrite the original officer identity; if an
  // edit flow is ever added, it must preserve submittedBy/acknowledgement
  // instead of replacing them with the editor's own.
  acknowledgement?: {
    accepted: boolean;
    acceptedAt: string;
  };
};

// Workplace → Beneficiary Indicators → "Share Form" — a stable, shareable
// link into one project's Indicator Form, generated by a logged-in Sponsor/
// Partner (captured here at creation time) so an anonymous respondent can
// submit a beneficiary record without ever logging into the app. One entry
// per (project, sharer): re-clicking Share Form reuses the same token/link
// instead of minting a new one every time (see
// getOrCreateIndicatorFormShareLink in projectStore.ts). The public
// /beneficiary-form/[token] route resolves `token` -> this record -> the
// SAME IndicatorFormState the Sponsor/Partner configured — never a separate
// form definition.
export type IndicatorFormShareLink = {
  token: string;
  projectId: string;
  sharedByUserId: string;
  sharedByName: string;
  sharedByEmail: string;
  sharedByRole: "sponsor" | "partner";
  createdAt: string;
};

export type BeneficiaryStatus = "enrolled" | "at-risk" | "dropout" | "completed";

export type BeneficiaryRecord = {
  id: string;
  projectId: string;
  name: string;
  gender: string;
  age: string;
  village: string;
  district: string;
  state: string;
  program: string;
  date: string;
  status: BeneficiaryStatus;
  guardian: string;
  contact: string;
  officer: string;
  cat: string;
};
