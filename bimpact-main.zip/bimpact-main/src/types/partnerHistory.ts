// Permanent, append-only audit log for Partner workflow/status actions —
// separate from PartnerOrg itself (which only ever holds the CURRENT state:
// current status, current changeRequestMessage/rejectionReason/deactivation,
// each overwritten by the next decision — see settings.ts's own comments on
// those fields). This is deliberately the opposite: every entry here is
// immutable once written and NEVER overwritten or deleted by a later action,
// so "what happened, who did it, why, and when" stays answerable no matter
// how many times a partner's status has since changed. See settingsStore's
// requestPartnerChanges/deactivatePartner/reactivatePartner for where
// entries get appended, and PartnerHistorySection for where they're shown
// (Partner Details → "Change Request & Activity History").
import { ComplianceDocType } from "@/types/settings";

export type PartnerActivityType =
  // Partner onboarding approval decisions — the ONLY two types the
  // "Approval History" section (PartnerHistorySection) displays; every
  // other type below is logged here for permanence but filtered OUT of
  // that section (see its own header comment).
  | "partner_approved"
  | "partner_rejected"
  | "change_request"
  | "partner_activated"
  | "partner_deactivated"
  | "partner_reactivated"
  // Document-level Sponsor review decisions (Partner Details → Document
  // View → Reject Document/Request Changes/Accept Document) — independent
  // of the Partner-level types above (see ComplianceDocument.reviewStatus's
  // own comment: document review never changes the overall Partner
  // status). Reuses this same append-only log rather than a second history
  // model, per spec's "reuse existing status architecture".
  | "document_accepted"
  | "document_rejected"
  | "document_changes_requested";

export type PartnerHistoryEntry = {
  id: string;
  partnerId: string;
  activityType: PartnerActivityType;
  // The Sponsor-entered reason/message — partner_rejected, change_request,
  // partner_deactivated, document_rejected, and document_changes_requested
  // all carry one (every one has a mandatory reason field on its own
  // dialog); undefined for the activity types with no explanation
  // (partner_approved/partner_activated/partner_reactivated/
  // document_accepted).
  reason?: string | null;
  // Human-readable status labels (e.g. "Pending Review", "Active",
  // "Inactive"), the same vocabulary PartnerOrg.status/reviewStatus already
  // use elsewhere in the UI — not the ticket example's snake_case slugs,
  // so this renders directly without a second lookup table.
  previousStatus: string;
  newStatus: string;
  performedBy: { userId: string; name: string; role: "sponsor" };
  createdAt: string;
  // Present ONLY for the three document_* activity types above — identifies
  // which uploaded document (see ComplianceDocument in settings.ts) this
  // entry is about. Absent for the four Partner-level activity types.
  documentType?: ComplianceDocType;
  // The document's display label AT THE TIME of the action (e.g. "80G
  // Certificate", or a custom "Other" doc's documentName) — captured once
  // so a later rename/re-upload never rewrites this entry's own history.
  documentLabel?: string;
  // The specific document record's fileId — "Other" can hold several
  // documents of the same type, so type alone can't disambiguate which one
  // this entry is about; null/undefined for a doc saved before fileId
  // existed (legacy fileUrl-only records).
  documentFileId?: string | null;
};
