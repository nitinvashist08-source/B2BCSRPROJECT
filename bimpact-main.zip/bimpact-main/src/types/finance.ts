// Lowercase to match the original's data-status vocabulary verbatim
// (_expStatuses, bImpact_MeetingSplit_v10.html:13822), consistent with the
// TrancheStatus convention.
export type ExpenseStatus = "pending" | "pendingfc" | "approved" | "rejected";

// inp-exp-type, bImpact_MeetingSplit_v10.html:7250-7255 — the real
// user-facing field; the port's earlier free-text "category" (Travel/
// Materials/...) was actually only ever the seed generator's cosmetic
// flavor pool (_expCategories, :13821), never a real form field.
export type ExpenseType = "CAPEX" | "OPEX";

// inp-exp-gst-slab options, bImpact_MeetingSplit_v10.html:7266-7270
export type GstSlab = 0 | 5 | 12 | 18 | 28;

export type Expense = {
  id: string;
  projectId: string;
  date: string; // en-GB "dd Mon yyyy" display string, matches _expFmtDate (:13834-13836)
  // System-stamped ISO timestamp of when the expense was ENTERED into
  // bimpact (addExpense, financeStore.ts) — distinct from `date` above,
  // which is the expense's own transaction date and can be backdated by the
  // user. Alerts ("Expense awaiting approval > 3 days") key off this, never
  // off `date`, so a backdated expense doesn't look falsely overdue the
  // moment it's booked.
  submittedAt: string;
  type: ExpenseType;
  description: string;
  amount: number; // GST-INCLUSIVE total, matches original's stored `amt` (:13885, :14073)
  gstSlab: GstSlab;
  docFileName: string;
  status: ExpenseStatus;
  rejectReason?: string;
};

// Lowercase to match the original's _disbTranches status vocabulary
// (bImpact_MeetingSplit_v10.html:13300 etc.) verbatim.
export type TrancheStatus = "scheduled" | "upcoming" | "overdue" | "released";

// Which trigger a tranche's release condition was configured with (see
// ScheduleTrancheSlideOver.tsx's "Trigger Milestone" picker) — kept on the
// persisted record (previously discarded after building the `condition`
// display string) so a "Custom Condition" tranche can be identified later:
// it gets an always-available manual Release action, unlike task/time/
// expenditure/balance tranches, which keep the existing sequential
// upcoming-or-follows-a-released-one gating untouched (see
// canManuallyRelease in financeStore.ts).
export type TrancheMilestoneType = "task" | "time" | "expenditure" | "balance" | "custom";

export type Tranche = {
  id: string;
  projectId: string;
  name: string;
  condition: string;
  date: string;
  amount: number;
  status: TrancheStatus;
  remarks?: string;
  milestoneType?: TrancheMilestoneType;
  // Stable reference to the Project's own WBS row (WbsRow.id — see
  // types/project.ts) when this tranche's trigger is "Specific Task
  // Completion" — the WBS row is the single source of truth for that
  // task's name; this is looked up live at render time (see
  // TranchePipeline.tsx) rather than copying the name in permanently, so a
  // later WBS rename is reflected automatically. `condition` still holds a
  // cached human-readable fallback (used if the WBS row is later deleted).
  linkedWbsRowId?: string;
  // Set by releaseTranche when a tranche transitions to "released" — never
  // backdated/inferred, only ever written by that one explicit action.
  releasedAt?: string;
};

// Keys match the original's monthlyData verbatim
// (bImpact_MeetingSplit_v10.html:14302, :15085-15098, :15424-15433).
export type FundingType = "ds" | "bs" | "as";

export type MonthlyPlan = Record<FundingType, number[]>;

// unitCost/qty deliberately dropped: the original sets them (uc=total,
// qty=1) but only the abandoned/unreachable "Add Micro Line Item" flow
// (addMicroLineItem/fin-so-micro-lineitem, never called from any button —
// bImpact_MeetingSplit_v10.html:14718) ever gave them real meaning; the one
// reachable flow (saveMicroCat) always drives totals from `monthly`.
export type MicroLineItem = {
  id: string;
  name: string;
  monthly: MonthlyPlan;
  subItems: MicroLineItem[];
};

// `open`/expand-collapse is deliberately NOT part of the persisted model —
// toggleMicro() (bImpact_MeetingSplit_v10.html:14526-14537) just flips a DOM
// element's display style; every project/category section starts expanded
// on every render, nothing is remembered. The port keeps that as ephemeral
// component state instead of stored data.
export type MicroCategory = {
  id: string;
  name: string;
  items: MicroLineItem[];
};

// Budget Planning → Create Budget: a sanctioned amount for a specific
// planning period, allocated across zero or more Projects. A Project can
// appear in multiple PeriodBudgets over time; the Project's Finance-visible
// "Allocated Budget" (Project.budget, see financeStore.ts's periodBudget
// actions) is kept in sync with whichever allocation was most recently
// created/edited for that project — this is a deliberate simplification
// (no cross-period summing), matching this feature's own scope.
export type ProjectAllocation = {
  projectId: string;
  allocatedAmount: number;
};

export type PeriodBudget = {
  id: string;
  startDate: string;
  endDate: string;
  totalSanctionedAmount: number;
  allocations: ProjectAllocation[];
  createdAt: string;
  updatedAt: string;
};

export const FUNDING_TYPE_LABEL: Record<FundingType, string> = {
  ds: "Direct Support",
  bs: "Beneficiary Contribution",
  as: "Agency / Other Support",
};

export const MONTHS = [
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
  "Jan",
  "Feb",
  "Mar",
];
