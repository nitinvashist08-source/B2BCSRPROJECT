export type MeetingStatus = "Draft" | "Upcoming" | "InProgress" | "Completed";
// mtgStatusLabels, bImpact_MeetingSplit_v10.html:10663 — display copy only;
// the stored status values themselves (used for logic/branching everywhere
// else) are unchanged.
export const MEETING_STATUS_LABEL: Record<MeetingStatus, string> = {
  Draft: "Draft",
  Upcoming: "Upcoming",
  InProgress: "In Progress",
  Completed: "Completed",
};
export type ActionStatus = "Open" | "In-Progress" | "Done";
export type PolicyStatus = "Draft" | "Published";

// A committee member for one specific period. Members form an org-chart
// tree via `reportsToId` (null = root/top-level member for that period) —
// the hierarchy is always derived from this relationship, never stored
// separately.
export type CommitteeMember = {
  id: string;
  name: string;
  email: string;
  role: string;
  organization: string;
  reportsToId: string | null;
  color?: string;
};

// stcPeriods, bImpact_MeetingSplit_v10.html:12339 — CSR Committees are
// managed period-wise; each period owns its own member list/hierarchy.
export type CommitteePeriod = {
  id: string;
  startDate: string;
  endDate: string;
  members: CommitteeMember[];
};

export type Guest = {
  id: string;
  name: string;
  email: string;
  org: string;
  role: string;
  reportsTo?: string;
};

export type ActionItem = {
  id: string;
  task: string;
  owner: string;
  dueDate: string;
  status: ActionStatus;
};

// Setup-time selection just picks who's invited (added to `present` by
// default); Execute & MoM's live Attendance section is the only place that
// actually toggles present/absent — matches source's single present/absent
// model (mtgToggleAttendance, bImpact_MeetingSplit_v10.html:10917-10923).
// No "excluded" state exists in source.
export type Attendees = {
  present: string[];
  absent: string[];
  guests: Guest[];
};

export type Signoff = {
  chairIds: string[];
  minutesPreparedBy: string;
  closedAt?: string; // date the meeting was marked complete (system-set)
  closingTime?: string; // "Meeting Closed At" — user-entered time of closing
  nextMeeting?: string; // date of the next scheduled meeting
  confirmed: boolean;
  remarks?: string;
};

export type Meeting = {
  id: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  location: string;
  status: MeetingStatus;
  agendaHtml: string;
  notesHtml: string;
  attendees: Attendees;
  signoff: Signoff;
  actions: ActionItem[];
};

export type CsrPolicy = {
  id: string;
  startDate: string;
  endDate: string;
  status: PolicyStatus;
  content: string;
  createdAt: string;
  updatedAt: string;
};
