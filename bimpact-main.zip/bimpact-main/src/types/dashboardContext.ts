// Shared contract for the Sponsor multi-dashboard feature (Consolidated /
// Partner / Project). This file is the seam between three parallel work
// streams — routing/selector, data aggregation, and visualization/layout —
// so it is intentionally minimal and additive. Do not fold this into
// dashboard.ts; keep it separate so all three streams can depend on it
// without touching each other's files.
//
// scopeKey is the stable string used everywhere a dashboard's identity needs
// to become a map/localStorage key: dashboard layout persistence
// (dashboardLayoutStore), page-set partitioning (DashboardPage.scopeKey),
// and data-scope lookups. "partner"/"project" ids are the entity's real id
// (PartnerOrg.id / Project.id) — NOT a display name.
export type DashboardScope = "consolidated" | "partner" | "project";

export type DashboardContext =
  | { scope: "consolidated" }
  | { scope: "partner"; partnerId: string }
  | { scope: "project"; projectId: string };

export function dashboardScopeKey(ctx: DashboardContext): string {
  switch (ctx.scope) {
    case "consolidated":
      return "consolidated::global";
    case "partner":
      return `partner::${ctx.partnerId}`;
    case "project":
      return `project::${ctx.projectId}`;
  }
}

export function dashboardContextsEqual(a: DashboardContext, b: DashboardContext): boolean {
  return dashboardScopeKey(a) === dashboardScopeKey(b);
}
