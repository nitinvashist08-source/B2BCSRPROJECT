export type ChartKind = "bar" | "line" | "area" | "pie" | "donut" | "kpi" | "table";
export type AggregationOp = "count" | "sum" | "avg";

// Free-form drag/resize grid position+size for a dashboard card, in grid
// units (not pixels) — see src/lib/dashboardLayout.ts for the grid constants
// (columns/row height/min/max) and src/store/dashboardLayoutStore.ts for
// where a user's arrangement per dashboard page is persisted. Deliberately
// NOT a field on Visualization itself: a visualization's config/data is
// shared across whoever can see the dashboard, but its on-screen layout is a
// per-user preference (a Sponsor's drag/resize must never affect what a
// Partner — or a different Sponsor user — sees), so layout lives in its own
// store keyed by (userId, pageId) instead of mutating the shared
// visualization record.
export type CardLayout = {
  i: string; // visualization id
  x: number;
  y: number;
  w: number;
  h: number;
  minW?: number;
  minH?: number;
  maxW?: number;
  maxH?: number;
};

// Colors are keyed by the resulting category/series LABEL, never by array
// index, so a color stays attached to "Education"/"Male"/etc. even if the
// underlying data reorders or a category is added/removed.
export type ColorMap = Record<string, string>;

export const PROTECTED_PAGE_ID = "page-overview";

export type DashboardPage = {
  id: string;
  name: string;
  order: number;
  deletable: boolean;
  // Which dashboard (Consolidated/Partner/Project) this page belongs to —
  // see src/types/dashboardContext.ts's dashboardScopeKey(). Absent/undefined
  // means the page predates multi-dashboard scoping (or was created without
  // an explicit scope) and is treated as belonging to the Consolidated
  // dashboard ("consolidated::global"), so existing pages keep working
  // unchanged.
  scopeKey?: string;
};

type BaseViz = {
  id: string;
  pageId: string;
  order: number;
  title: string;
  datasetId: string;
};

export type CategoryVizConfig = {
  kind: "bar" | "line" | "area";
  dimensionField: string;
  measureField: string;
  aggregation: AggregationOp;
  seriesField?: string;
  colors: ColorMap;
};

export type SliceVizConfig = {
  kind: "pie" | "donut";
  dimensionField: string;
  measureField: string;
  aggregation: AggregationOp;
  colors: ColorMap;
};

export type KpiVizConfig = {
  kind: "kpi";
  measureField: string;
  aggregation: AggregationOp;
  valueColor: string;
  labelColor: string;
};

export type TableVizConfig = {
  kind: "table";
  dimensionField: string;
  measureFields: string[];
  aggregation: AggregationOp;
};

export type Visualization = BaseViz &
  (CategoryVizConfig | SliceVizConfig | KpiVizConfig | TableVizConfig);

// Plain `Omit<Visualization, K>` collapses to the fields common to every
// variant (Omit/keyof don't distribute over a union on their own) — this
// distributes Omit over each variant first so the result stays a proper
// discriminated union.
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- `T extends any` is the required distributive-conditional idiom; `keyof any` mirrors lib.es5.d.ts's own Record definition.
export type DistributiveOmit<T, K extends keyof any> = T extends any ? Omit<T, K> : never;
