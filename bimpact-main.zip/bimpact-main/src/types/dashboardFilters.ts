// Shared contract for the Consolidated Sponsor Dashboard's independent
// Partner + Project filter feature. This is the seam between two parallel
// work streams (Partner filter, Project filter + combined behaviour) so it
// is intentionally minimal and additive — do not fold it into
// dashboardContext.ts, which backs the separate "switch to a whole other
// dashboard" feature (Consolidated/Partner/Project routes + DashboardSelector).
// That existing feature is untouched by this one: these two filters live
// ONLY on the Consolidated dashboard page and narrow its data, they never
// navigate anywhere.
//
// null means "All" for that filter. The two fields are independent — either,
// neither, or both may be set. See src/lib/dashboardFilterScope.ts for how a
// DashboardFilters value resolves to scoped Project/Partner ids (that file
// owns all the Partner<->Project many-to-many combination logic).
export type DashboardFilters = {
  partnerId: string | null;
  projectId: string | null;
};

export const ALL_DASHBOARD_FILTERS: DashboardFilters = { partnerId: null, projectId: null };

export function isDashboardFiltersEmpty(filters: DashboardFilters): boolean {
  return filters.partnerId === null && filters.projectId === null;
}
