export type MemberStatus = "Active" | "Invited";
export type TeamRole = "Admin" | "Manager" | "Auditor";

export type TeamMember = {
  id: string;
  name: string;
  email: string;
  role: TeamRole;
  status: MemberStatus;
  // System-stamped ISO timestamp of when inviteMember (settingsStore.ts)
  // created this record — powers the "Team invitation pending" alert.
  // Optional only so a member invited before this field existed still
  // type-checks; alertRules.ts skips that rule for a member with no value
  // rather than guessing an age.
  invitedAt?: string;
};

// Partner-side internal team roles — deliberately a separate, smaller set
// from the Sponsor's TeamRole (Admin/Manager/Auditor): a Partner org has no
// Admin/Auditor concept of its own, and must never be offered Sponsor-level
// roles. Kept as its own type (not a subset of TeamRole) so the two role
// vocabularies can't accidentally cross-contaminate as either evolves.
export type PartnerTeamRole = "Manager" | "Project Manager" | "Field Officer";

// A Partner organization's own internal team member — the Partner-side
// counterpart to TeamMember, kept as a fully separate type/list
// (settingsStore's `partnerTeamMembers`, not `teamMembers`) rather than
// reusing the Sponsor's list with a role/org flag bolted on, so "Partner A
// cannot manage users belonging to Partner B" is structural (every record
// carries its own partnerOrgId and every read/write is scoped by it) rather
// than a filter someone could forget to apply. Reuses MemberStatus
// ("Active" | "Invited") — this app has no "Inactive" team-member state
// anywhere yet (Sponsor's TeamMember doesn't support it either), so none is
// introduced here; add it to MemberStatus itself if that ever changes,
// rather than inventing a parallel status enum.
export type PartnerTeamMember = {
  id: string;
  partnerOrgId: string;
  name: string;
  email: string;
  role: PartnerTeamRole;
  status: MemberStatus;
};

export type PartnerType = "Implementer" | "Co-Implementer" | "Co-Sponsor";
// Operational lifecycle — orthogonal to the review workflow below. "Invited"
// now also covers "submitted onboarding, awaiting Sponsor review" (not just
// "hasn't onboarded yet") — once reviewStatus exists on a partner, it's the
// primary status shown to the Sponsor (see PartnerOrgsTable.tsx); this field
// only flips to "Active" when reviewStatus becomes "Approved", or "Inactive"
// when "Rejected" (or via the pre-existing manual Deactivate/Activate menu
// actions, unrelated to the review workflow).
export type PartnerStatus = "Active" | "Invited" | "Inactive";

// The Sponsor-review workflow a partner's onboarding submission goes
// through. Undefined/absent means "hasn't submitted onboarding yet" (still
// mid-invite, or a seed/legacy partner that predates this workflow).
export type PartnerReviewStatus = "Pending Review" | "Changes Requested" | "Approved" | "Rejected";

// Open string, not a closed union — a compliance document's type is either a
// predefined catalog item id (see src/data/complianceCatalog.ts's
// COMPLIANCE_CATEGORIES, selected per Partner Type via
// PartnerComplianceChecklist in src/types/partnerForm.ts) or the fixed
// literal "Other" (the free-form, multi-file supporting-documents bucket,
// orthogonal to any Sponsor checklist). See
// src/lib/partnerComplianceRequirements.ts for how a Partner's required set
// is resolved, and src/lib/complianceLegacyMigration.ts for the one-time
// rewrite of documents/history saved under the old fixed 6-code scheme
// ("12A"/"80G"/"CSR-1"/"GST"/"PAN").
export type ComplianceDocType = string;
export type ComplianceStatus = "Complete" | "Incomplete";
export type ComplianceDocument = {
  type: ComplianceDocType;
  // User-defined label for an "Other Supporting Document" (e.g. "Board
  // Resolution") — set at upload time and shown as the document's primary
  // name in place of its filename (see CompliancePage's Other Supporting
  // Documents list). Optional: never asked for on the 5 primary document
  // types (12A/80G/CSR-1/GST/PAN), and absent on any "Other" doc uploaded
  // before this field existed — those just keep showing their fileName.
  documentName?: string;
  fileName: string;
  uploadedAt: string;
  // Partner-declared validity period of the certificate itself, as
  // `YYYY-MM-DD` date-only strings (what <input type="date"> produces —
  // same convention as every other date field in this app, e.g. Task
  // start/end dates). Deliberately NOT the same thing as `uploadedAt`,
  // which is when the file reached us.
  //
  // Both are optional: several document types (PAN especially) simply
  // never expire, and every document uploaded before these fields existed
  // has neither — those render as "Not specified"/"No expiry" rather than
  // being retro-flagged as invalid. When both are present,
  // UploadComplianceModal guarantees validTill >= validFrom.
  validFrom?: string;
  validTill?: string;
  // Reference into src/lib/complianceFileStore.ts's IndexedDB store, where
  // the actual file bytes live — every new upload sets this. Not the bytes
  // themselves: this record still lives inside PartnerOrg.complianceDocuments,
  // which is part of the small JSON blob settingsStore.ts persists to
  // localStorage, and a handful of ~1MB files as inline data-URLs there was
  // enough to blow that origin's localStorage quota on its own (see
  // complianceFileStore.ts's header comment).
  fileId?: string;
  // Legacy inline data-URL, from before fileId existed — kept optional so
  // any record saved that way still opens/downloads (see
  // ViewComplianceDocumentModal.tsx, which checks fileId first and falls
  // back to this). Never set on a new upload.
  fileUrl?: string;
  // Sponsor-side "has this specific document been opened since it was last
  // uploaded/replaced" — undefined/null means unseen, which is what drives
  // the "NEW" tag in ComplianceDocumentsSection.tsx. A fresh upload/replace
  // always produces a brand-new ComplianceDocument object (see
  // uploadComplianceDocument), so this is naturally unset again every time,
  // with no separate reset step needed. Set to a timestamp only by
  // settingsStore's markComplianceDocumentViewed, when the Sponsor opens it.
  viewedBySponsorAt?: string | null;
  // Sponsor's document-level review decision — INDEPENDENT of the overall
  // Partner onboarding reviewStatus above (PartnerOrg.reviewStatus is the
  // whole submission's workflow; this is per-document, see settingsStore's
  // acceptComplianceDocument/rejectComplianceDocument/
  // requestComplianceDocumentChanges). Undefined means "Pending Review" —
  // every freshly uploaded/replaced document starts there implicitly, no
  // separate flag needed. A fresh upload/replace always produces a brand-new
  // ComplianceDocument object (see uploadComplianceDocument), so this and
  // `review` below are naturally reset to "undefined = Pending Review"
  // again on re-upload — same as viewedBySponsorAt above.
  reviewStatus?: DocumentReviewStatus;
  // The latest review decision's detail — reason/who/when. Only ever the
  // LATEST decision (same "current state, not history" role
  // changeRequestMessage/rejectionReason play on PartnerOrg); the permanent,
  // append-only trail of every decision this document has ever received
  // lives in settingsStore's partnerHistory (see PartnerHistoryEntry's
  // documentType/documentFileId fields), never here.
  review?: {
    action: "accepted" | "rejected" | "changes_requested";
    // Present for rejected/changes_requested (both have a mandatory reason
    // field); absent for accepted (no explanation required).
    reason?: string | null;
    performedBy: { userId: string; name: string; role: "sponsor" };
    performedAt: string;
  } | null;
};

export type DocumentReviewStatus = "Pending Review" | "Accepted" | "Changes Requested" | "Rejected";

// Complete registered office address — separate from `state`/`districts`
// below, which capture the (possibly multi-district) region the partner
// OPERATES in, not the single address their organization is registered at.
// Optional so existing partners who only ever had state/districts stored
// keep working untouched until they add this on the Compliance page.
export type RegisteredOfficeAddress = {
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  district: string;
  pinCode: string;
};

export type PartnerOrg = {
  id: string;
  name: string;
  contactName: string;
  contactEmail: string;
  state: string;
  // Multi-district per partner — set by the partner themselves during
  // onboarding (Step 3: Organization Location), not at invite time.
  districts: string[];
  // Set by the partner on the Compliance page (Registered Office Address
  // section) — a separate structured address, not a replacement for
  // state/districts above (see that type's own comment).
  registeredOfficeAddress?: RegisteredOfficeAddress;
  type: PartnerType;
  status: PartnerStatus;
  workspaceId: string;
  inviteToken: string | null;
  invitedAt: string | null;
  // How many times an invitation email has gone out for this partner (the
  // original invite, plus every Sponsor-initiated Re-invite — see
  // settingsStore's invitePartner/reinvitePartner). `invitedAt` above is
  // already "lastInvitedAt" in all but name, so this only adds the count on
  // top of it rather than duplicating a timestamp. Optional/undefined on any
  // partner invited before this field existed.
  invitationCount?: number;
  // System-stamped ISO timestamp of this partner's very first login — set
  // once by sessionStore's loginAsPartner and never touched again (every
  // subsequent login leaves it untouched). Powers the one-time "welcome,
  // upload your compliance documents" alert (alertRules.ts) — absent means
  // "hasn't logged in yet" (or logged in before this field existed).
  firstLoginAt?: string | null;
  complianceStatus?: ComplianceStatus;
  complianceDocuments?: ComplianceDocument[];
  // Sponsor review workflow (set once the partner completes onboarding —
  // see settingsStore's activatePartner/registerPartner — and updated by the
  // Sponsor's Approve/Request Changes/Reject decision).
  reviewStatus?: PartnerReviewStatus;
  submittedAt?: string | null;
  reviewedAt?: string | null;
  // Set when reviewStatus is "Changes Requested" — the Sponsor's message
  // telling the partner what to fix. Cleared on the next submission-state
  // change (approve/reject/re-request).
  changeRequestMessage?: string | null;
  // Set when reviewStatus is "Rejected" — shared back with the partner.
  rejectionReason?: string | null;
  // Set by settingsStore's deactivatePartner when the Sponsor deactivates an
  // Active partner (status flips to "Inactive", same as the review-rejected
  // path below — this field is what tells the two apart). Kept even if the
  // partner is later reactivated (see Activate Partner), as a historical
  // record of the prior deactivation, same as rejectionReason/
  // changeRequestMessage staying around as history elsewhere on this type.
  deactivation?: PartnerDeactivation | null;
};

export type PartnerDeactivation = {
  reason: string;
  deactivatedBy: { userId: string; name: string; role: "sponsor" };
  deactivatedAt: string;
};

// A Partner uploading/replacing a compliance document now surfaces via the
// centralized Alerts module (src/types/alert.ts, type
// "compliance_document_uploaded", pushed by settingsStore's
// uploadComplianceDocument) rather than a bespoke notification type here.
