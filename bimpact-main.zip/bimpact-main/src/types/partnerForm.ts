import { PartnerType } from "@/types/settings";

// `version` exists so future partner submissions can record which version
// of a checklist they were held to, without building full version history
// now — it just increments on every save (see settingsStore.updatePartnerForm).
//
// `selectedItemIds` are ids into src/data/complianceCatalog.ts's
// COMPLIANCE_CATEGORIES — this is a predefined-catalog SELECTION, not a
// custom form: a Sponsor can only check/uncheck items, never add, rename,
// reorder, or remove predefined items. See PartnerFormBuilder.tsx.
//
// `partnerType` is intentionally the SAME `PartnerType` union PartnerOrg.type
// uses (not a separate/looser string set) — src/lib/partnerComplianceRequirements.ts
// looks up "the Active checklist for this partner's type" by exact match, so
// the two must stay in lockstep.
export type OnboardingFormStatus = "Draft" | "Active";

export type PartnerComplianceChecklist = {
  id: string;
  partnerType: PartnerType;
  name: string;
  status: OnboardingFormStatus;
  version: number;
  selectedItemIds: string[];
  createdAt: string;
  updatedAt: string;
};

// The compliance checklist's own partner-type picker — deliberately just
// `PartnerType` (types/settings.ts) itself, the same three values every real
// PartnerOrg.type/invite/onboarding flow uses, so a checklist saved here
// always matches a real partner. (An earlier version of this list used its
// own richer/mismatched string set — fixed since nothing else in the app
// ever produces those values on an actual partner record.)
export const PARTNER_TYPE_OPTIONS: readonly PartnerType[] = ["Implementer", "Co-Implementer", "Co-Sponsor"];
