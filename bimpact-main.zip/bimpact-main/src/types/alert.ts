// Centralized Alerts & Notifications data model. See src/lib/alertRules.ts
// for how these get computed/generated, and src/store/alertStore.ts for
// where they live. Deliberately a TypeScript type (this app's existing
// "schema" convention for every other data model — Tranche, Expense,
// IndicatorFormResponse, etc. — none of which use a separate JSON Schema
// file), not a new format/tooling this codebase doesn't otherwise use.
export type AlertCategory = "finance" | "governance" | "project" | "partner" | "team" | "audit";
export type AlertSeverity = "critical" | "high" | "medium" | "info";

// Every entity type an alert can point back to — kept as a closed union
// (not a bare string) so a typo in a rule can't silently produce an alert
// nothing can ever resolve/link to correctly.
export type AlertEntityType =
  | "tranche"
  | "expense"
  | "project"
  | "meeting"
  | "actionItem"
  | "partner"
  | "wbsTask"
  | "indicatorForm"
  | "shareLink"
  | "teamMember"
  | "periodBudget"
  | "indicatorFormResponse";

export type AlertAction = {
  label: string;
  route: string;
};

export type Alert = {
  id: string;
  // Dedup identity — `${type}:${entityType}:${entityId}:${milestone?}`, per
  // spec section 10. The single thing alertStore.evaluate() diffs against to
  // decide "already active, leave alone" vs "newly true, create unread" vs
  // "no longer true, resolve". Two different rules can never collide on the
  // same key since `type` is always the first segment.
  key: string;
  type: string; // rule id, e.g. "tranche_overdue" — see alertRules.ts's RULE ids
  category: AlertCategory;
  severity: AlertSeverity;
  title: string;
  message: string;
  // Role/user targeting — all optional; an alert with neither is visible to
  // anyone who otherwise has access to `projectId`/the entity (the common
  // case: tranche/expense/task alerts, visible to Sponsor + whichever
  // Partner is assigned to that project, same access rule Finance/WBS pages
  // already use). `targetRole` alone scopes to "every Sponsor" or "every
  // Partner" (not project-specific — e.g. compliance review is Sponsor-only
  // regardless of project). `targetPartnerOrgId` narrows further to one
  // specific Partner org's own users only.
  targetRole?: "sponsor" | "partner";
  targetPartnerOrgId?: string;
  entityType: AlertEntityType;
  entityId: string;
  projectId?: string;
  isRead: boolean;
  createdAt: string;
  // Set when a derived/computed rule's underlying condition stops being
  // true (see alertStore.evaluate()) — the alert is no longer "active" but
  // is kept, never hard-deleted, per spec 17.17 (preserve alert history).
  // Event-stamped alerts (rejected/released/etc., one-shot facts that never
  // "un-happen") are never resolved this way — they just age in the list.
  resolvedAt?: string | null;
  action?: AlertAction;
};
