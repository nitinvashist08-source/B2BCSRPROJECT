// React hook wrapper around src/lib/dashboardScope.ts's pure scoping
// functions — stays reactive to store changes by reading through
// useProjectStore/useSettingsStore/useFinanceStore's hooks rather than
// their .getState() snapshots.
//
// All metrics are traceable to existing store fields/computations:
// - budget: sum of Project.budget over scoped projects — the same field
//   HighLevelBudgetTable.tsx renders as "Allocated (₹)".
// - disbursed: sum of released-tranche amounts over scoped projects,
//   replicating HighLevelBudgetTable.tsx's per-row `disbursed` computation
//   (disbursements[projectId].filter(status === "released").sum(amount)).
// - expensed: sum of Expense.amount over scoped projects, replicating
//   ExpenseTable.tsx's `expensed` total (all expenses regardless of status —
//   same pattern as FinanceTopBar.tsx's global "booked" total).
// - statusBreakdown: Project.status grouped/counted over scoped projects.

import { useMemo } from "react";
import { DashboardContext } from "@/types/dashboardContext";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useFinanceStore } from "@/store/financeStore";
import { getScopedProjectIds, getScopedPartnerIds } from "@/lib/dashboardScope";

export type DashboardHealthData = {
  context: DashboardContext;
  title: string; // display name: "Overall CSR Dashboard" | partner.name | project.name
  projectIds: string[];
  partnerIds: string[]; // PartnerOrg ids
  projectCount: number;
  partnerCount: number;
  totals: {
    budget: number;
    disbursed: number;
    expensed: number;
  };
  statusBreakdown: Record<string, number>; // Project.status -> count, scoped
};

const CONSOLIDATED_TITLE = "Overall CSR Dashboard";

export function useDashboardData(context: DashboardContext): DashboardHealthData {
  const projects = useProjectStore((s) => s.projects);
  const partners = useSettingsStore((s) => s.partners);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const disbursements = useFinanceStore((s) => s.disbursements);
  const expenses = useFinanceStore((s) => s.expenses);

  return useMemo(() => {
    // Depending on projects/partners/projectPartners (already subscribed to
    // above) keeps this reactive; the actual relationship/id-resolution work
    // still routes entirely through dashboardScope.ts (which itself reads
    // .getState() — the same underlying data these subscriptions track).
    void projectPartners;

    const projectIds = getScopedProjectIds(context);
    const partnerIds = getScopedPartnerIds(context);
    const projectIdSet = new Set(projectIds);
    const scopedProjects = projects.filter((p) => projectIdSet.has(p.id));

    let title = "";
    if (context.scope === "consolidated") {
      title = CONSOLIDATED_TITLE;
    } else if (context.scope === "partner") {
      title = partners.find((p) => p.id === context.partnerId)?.name ?? "";
    } else {
      title = projects.find((p) => p.id === context.projectId)?.name ?? "";
    }

    const budget = scopedProjects.reduce((sum, p) => sum + p.budget, 0);

    const disbursed = scopedProjects.reduce((sum, p) => {
      const tranches = disbursements[p.id] ?? [];
      const released = tranches
        .filter((t) => t.status === "released")
        .reduce((s, t) => s + t.amount, 0);
      return sum + released;
    }, 0);

    const expensed = expenses
      .filter((e) => projectIdSet.has(e.projectId))
      .reduce((sum, e) => sum + e.amount, 0);

    const statusBreakdown: Record<string, number> = {};
    for (const p of scopedProjects) {
      statusBreakdown[p.status] = (statusBreakdown[p.status] ?? 0) + 1;
    }

    return {
      context,
      title,
      projectIds,
      partnerIds,
      projectCount: projectIds.length,
      partnerCount: partnerIds.length,
      totals: { budget, disbursed, expensed },
      statusBreakdown,
    };
  }, [context, projects, partners, projectPartners, disbursements, expenses]);
}
