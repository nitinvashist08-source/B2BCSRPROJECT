"use client";

import { createContext, createElement, useContext, useMemo, type ReactNode } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore } from "@/store/financeStore";
import { useMeetingStore } from "@/store/meetingStore";
import { useSettingsStore } from "@/store/settingsStore";

// Optional per-row filter for scoping a dataset's rows down to one Partner or
// Project dashboard's data. Every chart card / the Add Visualization wizard
// keeps calling useDatasetRows(datasetId) exactly as before — the filter is
// threaded in invisibly via DatasetScopeContext instead of a call-site
// parameter, so:
//  - none of src/components/dashboard/charts/*.tsx or
//    AddVisualizationSlideOver.tsx need to change at all;
//  - the existing unscoped /dashboard route, which never renders a
//    DatasetScopeProvider, is completely unaffected (context value stays
//    null, filter is a no-op).
// VisualizationCanvas (Partner/Project-aware) wraps its subtree in
// DatasetScopeProvider with a filter built from
// src/lib/dashboardScope.ts's getScopedProjectIds/getScopedPartnerIds.
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- filter runs against each dataset's own heterogeneous row shape
export type DatasetScopeFilter = (datasetId: string, row: any) => boolean;

const DatasetScopeContext = createContext<DatasetScopeFilter | null>(null);

// Plain createElement (not JSX) so this file can stay a .ts module.
export function DatasetScopeProvider({
  filter,
  children,
}: {
  filter: DatasetScopeFilter | null;
  children: ReactNode;
}) {
  return createElement(DatasetScopeContext.Provider, { value: filter }, children);
}

// Datasets live across four different stores (Projects/Finance/Meetings/
// Settings) — this hook is the one place that knows which store backs which
// dataset id, so chart components and the Add Visualization wizard just ask
// for rows by dataset id.
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- rows are handed to the matching DatasetDef, which is what knows each entity's real field shape
export function useDatasetRows(datasetId: string): any[] {
  const projects = useProjectStore((s) => s.projects);
  const beneficiaryRecords = useProjectStore((s) => s.beneficiaryRecords);
  const expenses = useFinanceStore((s) => s.expenses);
  const disbursements = useFinanceStore((s) => s.disbursements);
  const meetings = useMeetingStore((s) => s.meetings);
  const policies = useMeetingStore((s) => s.policies);
  const partners = useSettingsStore((s) => s.partners);
  const teamMembers = useSettingsStore((s) => s.teamMembers);

  const tranches = useMemo(() => Object.values(disbursements).flat(), [disbursements]);
  const scopeFilter = useContext(DatasetScopeContext);

  return useMemo(() => {
    let rows: unknown[];
    switch (datasetId) {
      case "projects":
        rows = projects;
        break;
      case "beneficiaries":
        rows = beneficiaryRecords;
        break;
      case "expenses":
        rows = expenses;
        break;
      case "tranches":
        rows = tranches;
        break;
      case "meetings":
        rows = meetings;
        break;
      case "policies":
        rows = policies;
        break;
      case "partners":
        rows = partners;
        break;
      case "teamMembers":
        rows = teamMembers;
        break;
      default:
        rows = [];
    }
    return scopeFilter ? rows.filter((row) => scopeFilter(datasetId, row)) : rows;
  }, [datasetId, projects, beneficiaryRecords, expenses, tranches, meetings, policies, partners, teamMembers, scopeFilter]);
}
