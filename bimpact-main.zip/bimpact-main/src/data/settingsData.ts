import { PartnerOrg, PartnerTeamMember, TeamMember } from "@/types/settings";
import { PartnerComplianceChecklist } from "@/types/partnerForm";
import { PartnerHistoryEntry } from "@/types/partnerHistory";
import { DEFAULT_DEMO_WORKSPACE_ID } from "@/store/workspaceStore";

// Sample data for settingsStore — this app has no backend, so this is what
// settingsStore.hydrate() falls back to when localStorage has nothing saved
// yet (see src/lib/localPersist.ts and DataBootstrap.tsx). Edit freely;
// there's no database to keep in sync with.

export const teamMembers: TeamMember[] = [
  { id: "mem-1", name: "Ritu Sharma", email: "ritu.sharma@bimpact.org", role: "Auditor", status: "Active" },
  { id: "mem-2", name: "Arjun Mehta", email: "arjun.mehta@bimpact.org", role: "Manager", status: "Active" },
  { id: "mem-3", name: "Neha Gupta", email: "neha.gupta@bimpact.org", role: "Admin", status: "Invited" },
];

export const partners: PartnerOrg[] = [
  { id: "ptn-1", name: "Bright Futures Foundation", contactName: "Kavita Rao", contactEmail: "kavita@brightfutures.org", state: "Bihar", districts: ["Bhojpur"], type: "Implementer", status: "Active", workspaceId: DEFAULT_DEMO_WORKSPACE_ID, inviteToken: null, invitedAt: null },
  { id: "ptn-2", name: "AquaLife Trust", contactName: "Sanjay Mehra", contactEmail: "sanjay@aqualife.org", state: "Rajasthan", districts: ["Jaipur"], type: "Implementer", status: "Active", workspaceId: DEFAULT_DEMO_WORKSPACE_ID, inviteToken: null, invitedAt: null },
];

export const allocationCeiling = 10000000;

// Empty on purpose — a Partner org's internal team starts empty until they
// invite their first member, which naturally exercises the Team Members
// page's empty state (no fabricated demo members for this one).
export const partnerTeamMembers: PartnerTeamMember[] = [];

// Empty on purpose — no seed history for the two demo partners above; the
// Change Request & Activity History section is populated going forward as
// Sponsor actions actually happen (see settingsStore's
// requestPartnerChanges/deactivatePartner/reactivatePartner).
export const partnerHistory: PartnerHistoryEntry[] = [];

export const projectStates: Record<string, string[]> = {
  "prj-2": ["Rajasthan"],
};
export const projectPartners: Record<string, string[]> = {
  "prj-2": ["AquaLife Trust"],
};
export const projectDistricts: Record<string, string[]> = {
  "prj-2": ["Jaipur", "Jodhpur"],
};

export const partnerForms: PartnerComplianceChecklist[] = [
  {
    id: "pform-ngo",
    partnerType: "Implementer",
    name: "Implementer Compliance Checklist",
    status: "Active",
    version: 1,
    selectedItemIds: [
      "org_registration_certificate",
      "org_pan_card",
      "org_gst_certificate",
      "tax_12a_12ab_certificate",
      "tax_80g_certificate",
      "tax_csr1_registration",
      "fin_audited_financial_statements",
      "fin_cancelled_cheque_bank_proof",
    ],
    createdAt: "2026-08-20",
    updatedAt: "2026-08-20",
  },
  {
    id: "pform-foundation",
    partnerType: "Co-Sponsor",
    name: "Co-Sponsor Compliance Checklist",
    status: "Draft",
    version: 1,
    selectedItemIds: ["org_registration_certificate", "org_pan_card"],
    createdAt: "2026-08-20",
    updatedAt: "2026-08-20",
  },
];

export const settingsSeedData = {
  teamMembers,
  partners,
  allocationCeiling,
  projectStates,
  projectPartners,
  projectDistricts,
  partnerForms,
  partnerTeamMembers,
  partnerHistory,
};
