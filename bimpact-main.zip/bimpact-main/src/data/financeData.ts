import { Expense, MicroCategory, PeriodBudget, Tranche } from "@/types/finance";
import { OwnershipMode } from "@/types/project";

// Sample data for financeStore — this app has no backend, so this is what
// financeStore.hydrate() falls back to when localStorage has nothing saved
// yet (see src/lib/localPersist.ts and DataBootstrap.tsx). Edit freely;
// there's no database to keep in sync with.
//
// Every project's expenses/disbursements/microBudgets stay empty here on
// purpose — the store's own ensureExpenses/ensureDisbursements/
// ensureMicroBudget actions lazily seed the fixed demo projects (prj-1..
// prj-5) the first time their Finance tab is visited; any other (real,
// user-created) project stays genuinely blank. periodBudgets starts empty
// too, same rule — no auto-generated Budget Periods, only what a Sponsor
// creates via Budget Planning → Create Budget.
export const expenses: Expense[] = [];
export const disbursements: Record<string, Tranche[]> = {};
export const microBudgets: Record<string, MicroCategory[]> = {};
// Project-level "who creates the Micro Budget?" decision — absent key (or
// explicit null) means "not configured yet", same as documentOwnership/
// beneficiaryOwnership in projectStore.ts. Existing projects with
// micro-budget line items but no ownership configured yet just keep that
// data fully visible/read-only until a Sponsor picks one; nothing is
// deleted or reset by this field's mere absence.
export const microBudgetOwnership: Record<string, OwnershipMode | null> = {};
export const periodBudgets: PeriodBudget[] = [];

export const financeSeedData = {
  expenses,
  disbursements,
  microBudgets,
  microBudgetOwnership,
  periodBudgets,
};
