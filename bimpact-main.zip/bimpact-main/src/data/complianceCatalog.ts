// Predefined Sponsor-side compliance document catalog — the Partner
// Compliance Form (src/components/settings/PartnerFormBuilder.tsx) lets a
// Sponsor only select/deselect items from this fixed, categorized list per
// partner type; it can never add, rename, reorder, or remove items here.
// Category and item ids are stable identifiers, never the display label —
// see PartnerComplianceChecklist.selectedItemIds in src/types/partnerForm.ts.

export type ComplianceCatalogItem = {
  id: string;
  name: string;
  description?: string;
  // Guidance only ("If applicable", "For events", ...) — never hides or
  // auto-(de)selects the item; the checkbox always stays Sponsor-controlled.
  applicability?: string;
  guidance?: string;
};

export type ComplianceCategory = {
  id: string;
  title: string;
  items: ComplianceCatalogItem[];
};

export const COMPLIANCE_CATEGORIES: ComplianceCategory[] = [
  {
    id: "organizational_registration_legal_status",
    title: "A. Organizational Registration & Legal Status",
    items: [
      {
        id: "org_registration_certificate",
        name: "Certificate of Registration / Incorporation",
        description: "Trust Deed, Society Registration Certificate, or Section 8 Company Certificate of Incorporation",
      },
      {
        id: "org_moa_aoa",
        name: "Memorandum of Association (MOA) & Articles of Association (AOA)",
        description: "Or Trust Deed / Bye-laws",
      },
      { id: "org_pan_card", name: "PAN Card of the Organization" },
      { id: "org_tan", name: "TAN", description: "Tax Deduction Account Number" },
      { id: "org_gst_certificate", name: "GST Registration Certificate", applicability: "If applicable" },
      {
        id: "org_ngo_darpan_id",
        name: "NGO Darpan ID",
        description: "NITI Aayog registration",
        guidance: "Often mandatory for government-linked or larger CSR partnerships",
      },
      {
        id: "org_trustees_board_list",
        name: "List of Trustees / Board of Directors / Governing Council Members",
        description: "Include ID proofs such as PAN / Aadhaar",
      },
      {
        id: "org_board_resolution_signatory",
        name: "Board Resolution Authorizing the Signatory",
        description: "Authorizing the signatory to sign the MOU / agreement and receive funds",
      },
      {
        id: "org_digital_signature_certificate",
        name: "Digital Signature Certificate (DSC)",
        description: "DSC of the authorized signatory",
      },
    ],
  },
  {
    id: "tax_exemption_csr_registrations",
    title: "B. Tax Exemption & CSR-Specific Registrations",
    items: [
      {
        id: "tax_12a_12ab_certificate",
        name: "12A / 12AB Registration Certificate",
        description: "Income tax exemption",
        guidance: "Post-2020 amendments made these registrations time-bound (typically 5 years); check current validity.",
      },
      { id: "tax_80g_certificate", name: "80G Registration Certificate", description: "Donor tax benefit" },
      {
        id: "tax_csr1_registration",
        name: "Form CSR-1 Registration with MCA",
        description: "Include the Unique Registration Number (URN)",
        guidance: "Mandatory since 1 April 2021 for entities receiving CSR funds.",
      },
      {
        id: "tax_three_year_track_record",
        name: "Proof of 3-Year Track Record in Similar Activities",
        description: "Required to obtain CSR-1, unless the entity was set up by the funding company itself",
      },
      {
        id: "tax_fcra_certificate",
        name: "FCRA Registration Certificate / Prior Permission Letter",
        applicability: "Only relevant if the funding is routed as, or the NGO otherwise receives, foreign contribution",
      },
    ],
  },
  {
    id: "financial_audit",
    title: "C. Financial & Audit Documents",
    items: [
      {
        id: "fin_audited_financial_statements",
        name: "Audited Financial Statements",
        description: "Balance Sheet, Income & Expenditure / P&L, Receipts & Payments",
        guidance: "Last 3 years",
      },
      { id: "fin_income_tax_returns", name: "Income Tax Returns (ITR)", guidance: "Last 3 years" },
      { id: "fin_statutory_audit_report_10b", name: "Statutory Audit Report / Form 10B", description: "Exemption audit report" },
      { id: "fin_cancelled_cheque_bank_proof", name: "Cancelled Cheque / Bank Account Proof", description: "Bank account proof of the organization" },
      { id: "fin_annual_reports", name: "Annual Report(s)", guidance: "Last 2–3 years" },
      {
        id: "fin_major_donors_list",
        name: "List of Major Donors / Funders",
        description: "Donor concentration / diversification check",
        guidance: "Last 2–3 years",
      },
    ],
  },
  {
    id: "governance_due_diligence",
    title: "D. Governance & Due Diligence Documents",
    items: [
      { id: "gov_organogram", name: "Organogram / Organizational Structure Chart" },
      { id: "gov_key_personnel_cvs", name: "CVs / Profiles of Key Management Personnel and Board Members" },
      { id: "gov_conflict_of_interest_declaration", name: "Conflict of Interest Declaration" },
      { id: "gov_anti_bribery_undertaking", name: "Anti-Bribery / Anti-Corruption Undertaking" },
      { id: "gov_whistleblower_policy", name: "Whistleblower Policy" },
      { id: "gov_data_privacy_policy", name: "Data Privacy / Protection Policy" },
      {
        id: "gov_posh_policy",
        name: "POSH Policy and Internal Committee Details",
        description: "Prevention of Sexual Harassment",
      },
      {
        id: "gov_child_protection_policy",
        name: "Child Protection / Safeguarding Policy",
        guidance: "Critical for programmes involving children, including education and nutrition programmes.",
      },
      { id: "gov_references_testimonials", name: "References / Testimonials from Past Funders or Partners" },
      {
        id: "gov_no_pending_litigation_declaration",
        name: "Declaration of No Pending Litigation / No Conviction",
        description: "For key trustees",
      },
    ],
  },
  {
    id: "project_specific",
    title: "E. Project-Specific Documents",
    items: [
      { id: "proj_detailed_proposal", name: "Detailed Project Proposal / Concept Note", description: "Objectives, theory of change" },
      { id: "proj_logframe", name: "Logical Framework (Logframe) / Results Framework" },
      { id: "proj_line_item_budget", name: "Line-Item Budget with Justification" },
      { id: "proj_geographic_beneficiary_profile", name: "Geographic Area of Implementation and Beneficiary Profile" },
      { id: "proj_implementation_timeline", name: "Implementation Timeline / Work Plan" },
      { id: "proj_me_framework", name: "Monitoring & Evaluation (M&E) Framework" },
      { id: "proj_baseline_needs_assessment", name: "Baseline / Needs-Assessment Report", applicability: "If available" },
      { id: "proj_risk_assessment_mitigation", name: "Risk Assessment & Mitigation Plan" },
      {
        id: "proj_third_party_permissions",
        name: "Required Third-Party Permissions",
        description: "For example, school / anganwadi / government department approvals",
      },
    ],
  },
  {
    id: "legal_agreements_contracts",
    title: "F. Legal Agreements & Contracts",
    items: [
      {
        id: "legal_mou_project_agreement",
        name: "MOU / Project Agreement / Grant Agreement",
        description: "Agreement between Sponsor and Implementing Partner",
      },
      {
        id: "legal_co_sponsorship_agreement",
        name: "Co-Sponsorship Agreement",
        applicability: "For events",
        description: "Branding rights, deliverables, payment schedule",
      },
      { id: "legal_nda", name: "Non-Disclosure Agreement (NDA)", applicability: "Where sensitive data is shared" },
      { id: "legal_indemnity_liability_clause", name: "Indemnity / Liability Clause" },
      { id: "legal_ip_branding_usage_agreement", name: "IP / Branding Usage Agreement", description: "Logo usage, event material rights" },
      { id: "legal_exit_termination_clause", name: "Exit / Termination Clause" },
    ],
  },
  {
    id: "ongoing_compliance_reporting",
    title: "G. Ongoing Compliance & Reporting",
    items: [
      { id: "ongoing_utilization_certificate", name: "Utilization Certificate (UC)", description: "Per tranche of funds disbursed" },
      { id: "ongoing_expense_statement", name: "Expense Statement", description: "Supporting vouchers / invoices" },
      { id: "ongoing_periodic_progress_reports", name: "Periodic Progress Reports", description: "Against milestones" },
      {
        id: "ongoing_impact_assessment_report",
        name: "Impact Assessment / Outcome Evaluation Report",
        description: "Independent third-party evaluation where applicable under CSR Rules",
      },
      { id: "ongoing_case_studies_media", name: "Case Studies, Photographs, Media Documentation" },
      { id: "ongoing_csr2_filing_data", name: "Data for Sponsor CSR-2 Filing and Annual Report on CSR" },
      {
        id: "ongoing_statutory_auditor_csr_certificate",
        name: "Statutory Auditor's Certificate on CSR Fund Utilization",
        applicability: "Where applicable",
      },
    ],
  },
  {
    id: "event_co_sponsorship",
    title: "H. Event / Co-Sponsorship Specific",
    items: [
      {
        id: "event_sponsorship_deliverables_matrix",
        name: "Sponsorship Agreement with Deliverables Matrix",
        description: "Branding, stage time, passes",
      },
      { id: "event_gst_invoice_payment_terms", name: "GST Invoice and Payment Terms" },
      { id: "event_public_liability_insurance", name: "Event / Public Liability Insurance Certificate" },
      {
        id: "event_venue_vendor_compliance_certificates",
        name: "Venue / Vendor Compliance Certificates",
        description: "Fire safety, licenses, etc., if requested",
      },
      { id: "event_brand_guideline_signoff", name: "Brand Guideline Sign-Off", description: "Logo usage approval" },
      {
        id: "event_post_event_report",
        name: "Post-Event Report",
        description: "Reach, media coverage, ROI metrics for the Sponsor",
      },
    ],
  },
  {
    id: "child_programme_specific",
    title: "I. Child-Programme-Specific",
    items: [
      { id: "child_safeguarding_code_of_conduct", name: "Child Safeguarding Policy & Staff / Volunteer Code of Conduct" },
      {
        id: "child_police_verification_background_checks",
        name: "Police Verification / Background Checks",
        description: "For staff working directly with children",
      },
      {
        id: "child_parental_guardian_consent",
        name: "Parental / Guardian Consent Documentation",
        applicability: "Where applicable",
      },
    ],
  },
];

export function findComplianceCatalogItem(itemId: string): { category: ComplianceCategory; item: ComplianceCatalogItem } | null {
  for (const category of COMPLIANCE_CATEGORIES) {
    const item = category.items.find((i) => i.id === itemId);
    if (item) return { category, item };
  }
  return null;
}
