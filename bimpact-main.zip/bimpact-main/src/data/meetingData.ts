import { CommitteeMember, CommitteePeriod, CsrPolicy, Meeting } from "@/types/meeting";

// Sample data for meetingStore — this app has no backend, so this is what
// meetingStore.hydrate() falls back to when localStorage has nothing saved
// yet (see src/lib/localPersist.ts and DataBootstrap.tsx). Edit freely;
// there's no database to keep in sync with.

// Two clean committee periods — one Active (drives Meeting attendee
// selection via activePeriodId below), one already-ended so the "Previous"
// status/read-only-edit rule has a real example out of the box.
const activePeriodMembers: CommitteeMember[] = [
  { id: "cmem-1", name: "Amit Sharma", email: "amit.sharma@bimpact.org", role: "Chairperson", organization: "bImpact Foundation", reportsToId: null, color: "#0A97D9" },
  { id: "cmem-2", name: "Priya Verma", email: "priya.verma@bimpact.org", role: "Committee Member", organization: "bImpact Foundation", reportsToId: "cmem-1", color: "#00A651" },
  { id: "cmem-3", name: "Rahul Mehta", email: "rahul.mehta@bimpact.org", role: "Committee Member", organization: "bImpact Foundation", reportsToId: "cmem-1", color: "#7C3AED" },
  { id: "cmem-4", name: "Neha Gupta", email: "neha.gupta@bimpact.org", role: "Member Secretary", organization: "bImpact Foundation", reportsToId: "cmem-1", color: "#0891B2" },
];
const previousPeriodMembers: CommitteeMember[] = [
  { id: "cmem-5", name: "Amit Sharma", email: "amit.sharma@bimpact.org", role: "Chairperson", organization: "bImpact Foundation", reportsToId: null, color: "#0A97D9" },
  { id: "cmem-6", name: "Neha Gupta", email: "neha.gupta@bimpact.org", role: "Member Secretary", organization: "bImpact Foundation", reportsToId: "cmem-5", color: "#0891B2" },
];

export const committeePeriods: CommitteePeriod[] = [
  { id: "period-2026", startDate: "2026-04-01", endDate: "2027-03-31", members: activePeriodMembers },
  { id: "period-2025", startDate: "2025-04-01", endDate: "2026-03-31", members: previousPeriodMembers },
];

export const meetings: Meeting[] = [
  {
    id: "mtg-1",
    title: "Q3 CSR Committee Review",
    date: "2026-09-10",
    startTime: "10:00",
    endTime: "11:30",
    location: "Conference Room A",
    status: "Upcoming",
    agendaHtml: "<p>Review Q3 disbursements and upcoming project pipeline.</p>",
    notesHtml: "",
    attendees: { present: [], absent: [], guests: [] },
    signoff: { chairIds: [], minutesPreparedBy: "", confirmed: false },
    actions: [],
  },
  {
    id: "mtg-2",
    title: "Annual CSR Policy Approval",
    date: "2026-08-02",
    startTime: "14:00",
    endTime: "15:00",
    location: "Board Room",
    status: "Completed",
    agendaHtml: "<p>Approve the revised CSR policy for the fiscal year.</p>",
    notesHtml: "<p>Policy approved unanimously; effective next quarter.</p>",
    attendees: { present: ["cmem-1", "cmem-2", "cmem-3", "cmem-4"], absent: [], guests: [] },
    signoff: { chairIds: ["cmem-1"], minutesPreparedBy: "Neha Gupta", closedAt: "2026-08-02", confirmed: true },
    actions: [{ id: "act-1", task: "Circulate approved policy document", owner: "Neha Gupta", dueDate: "2026-08-10", status: "Done" }],
  },
  {
    id: "mtg-3",
    title: "New Partner Onboarding Discussion",
    date: "2026-09-25",
    startTime: "16:00",
    endTime: "17:00",
    location: "Virtual — Google Meet",
    status: "Draft",
    agendaHtml: "",
    notesHtml: "",
    attendees: { present: [], absent: [], guests: [] },
    signoff: { chairIds: [], minutesPreparedBy: "", confirmed: false },
    actions: [],
  },
];

export const csrPolicies: CsrPolicy[] = [
  {
    id: "pol-2026",
    startDate: "2026-04-01",
    endDate: "2027-03-31",
    status: "Published",
    content:
      "<h2>Corporate Social Responsibility Policy</h2><p>This policy outlines our commitment to education, health, and livelihood programs across underserved communities. Governance and reporting follow the CSR Committee's oversight, with quarterly disbursement reviews.</p>",
    createdAt: "2026-03-15",
    updatedAt: "2026-03-20",
  },
  {
    id: "pol-2027-draft",
    startDate: "2027-04-01",
    endDate: "2028-03-31",
    status: "Draft",
    content: "<h2>Corporate Social Responsibility Policy (Draft)</h2><p>Under review — updated thematic focus areas for the upcoming fiscal year.</p>",
    createdAt: "2026-08-10",
    updatedAt: "2026-08-10",
  },
];

export const meetingSeedData = {
  committee: activePeriodMembers,
  periods: committeePeriods,
  activePeriodId: "period-2026",
  meetings,
  policies: csrPolicies,
};
