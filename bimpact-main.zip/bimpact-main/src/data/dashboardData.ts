import { DashboardPage, PROTECTED_PAGE_ID, Visualization } from "@/types/dashboard";
import { ScopeSeedPage, ScopeSeedVisualization } from "@/store/dashboardStore";

// Sample data for dashboardStore — this app has no backend, so this is what
// dashboardStore.hydrate() falls back to when localStorage has nothing saved
// yet (see src/lib/localPersist.ts and DataBootstrap.tsx). Edit freely;
// there's no database to keep in sync with.

export const dashboardPages: DashboardPage[] = [
  { id: PROTECTED_PAGE_ID, name: "Program Overview", order: 0, deletable: false },
];

export const dashboardVisualizations: Visualization[] = [
  {
    id: "viz-projects-by-status",
    pageId: PROTECTED_PAGE_ID,
    order: 0,
    title: "Projects by Status",
    datasetId: "projects",
    kind: "bar",
    dimensionField: "status",
    measureField: "__count__",
    aggregation: "count",
    colors: {},
  },
  {
    id: "viz-budget-by-partner",
    pageId: PROTECTED_PAGE_ID,
    order: 1,
    title: "Budget by Partner",
    datasetId: "projects",
    kind: "bar",
    dimensionField: "partner",
    measureField: "budget",
    aggregation: "sum",
    colors: {},
  },
];

export const dashboardSeedData = {
  pages: dashboardPages,
  visualizations: dashboardVisualizations,
};

// Default page/visualization composition for a brand-new Partner or Project
// dashboard, seeded once (via dashboardStore's ensureScopeSeeded) the first
// time that dashboard is opened — see src/app/dashboard/partner/[partnerId]
// and src/app/dashboard/project/[projectId] (Sub-Agent 1's routes). Every
// chart kind/dataset id here already exists in dashboardFields.ts's DATASETS
// registry and is rendered by the exact same VisualizationCard/chart-kind
// components as Consolidated — only the title/emphasis/combination differs
// per dashboard type. Row-level scoping (down to the one partner's or
// project's data) happens generically in VisualizationCanvas, not here.

const PARTNER_OVERVIEW_PAGE_KEY = "partner-overview";

export const partnerDashboardPages: ScopeSeedPage[] = [
  { key: PARTNER_OVERVIEW_PAGE_KEY, name: "Partner Overview", deletable: false },
];

export const partnerDashboardVisualizations: ScopeSeedVisualization[] = [
  // Selected partner health, at a glance.
  {
    pageKey: PARTNER_OVERVIEW_PAGE_KEY,
    title: "Total Project Budget",
    datasetId: "projects",
    kind: "kpi",
    measureField: "budget",
    aggregation: "sum",
    valueColor: "#0A97D9",
    labelColor: "#64748B",
  },
  {
    pageKey: PARTNER_OVERVIEW_PAGE_KEY,
    title: "Total Expensed",
    datasetId: "expenses",
    kind: "kpi",
    measureField: "amount",
    aggregation: "sum",
    valueColor: "#16a34a",
    labelColor: "#64748B",
  },
  // Projects managed by the partner.
  {
    pageKey: PARTNER_OVERVIEW_PAGE_KEY,
    title: "Projects by Status",
    datasetId: "projects",
    kind: "bar",
    dimensionField: "status",
    measureField: "__count__",
    aggregation: "count",
    colors: {},
  },
  // Aggregated project performance.
  {
    pageKey: PARTNER_OVERVIEW_PAGE_KEY,
    title: "Budget by Project Location",
    datasetId: "projects",
    kind: "bar",
    dimensionField: "location",
    measureField: "budget",
    aggregation: "sum",
    colors: {},
  },
  // Implementation progress, proxied by disbursement release status.
  {
    pageKey: PARTNER_OVERVIEW_PAGE_KEY,
    title: "Disbursement Progress",
    datasetId: "tranches",
    kind: "bar",
    dimensionField: "status",
    measureField: "amount",
    aggregation: "sum",
    colors: {},
  },
];

const PROJECT_OVERVIEW_PAGE_KEY = "project-overview";

export const projectDashboardPages: ScopeSeedPage[] = [
  { key: PROJECT_OVERVIEW_PAGE_KEY, name: "Project Overview", deletable: false },
];

export const projectDashboardVisualizations: ScopeSeedVisualization[] = [
  // Selected project health, at a glance.
  {
    pageKey: PROJECT_OVERVIEW_PAGE_KEY,
    title: "Total Project Budget",
    datasetId: "projects",
    kind: "kpi",
    measureField: "budget",
    aggregation: "sum",
    valueColor: "#0A97D9",
    labelColor: "#64748B",
  },
  // Financial performance.
  {
    pageKey: PROJECT_OVERVIEW_PAGE_KEY,
    title: "Expenditure by Type",
    datasetId: "expenses",
    kind: "bar",
    dimensionField: "type",
    measureField: "amount",
    aggregation: "sum",
    colors: {},
  },
  // Project/implementation progress, proxied by disbursement release status.
  {
    pageKey: PROJECT_OVERVIEW_PAGE_KEY,
    title: "Disbursement Progress",
    datasetId: "tranches",
    kind: "bar",
    dimensionField: "status",
    measureField: "amount",
    aggregation: "sum",
    colors: {},
  },
  // Activity/work progress, proxied by expense approval status.
  {
    pageKey: PROJECT_OVERVIEW_PAGE_KEY,
    title: "Expense Approval Status",
    datasetId: "expenses",
    kind: "donut",
    dimensionField: "status",
    measureField: "__count__",
    aggregation: "count",
    colors: {},
  },
  // Partner contribution — relevant when the project has multiple partners;
  // scoped down to the project's own partners by VisualizationCanvas.
  {
    pageKey: PROJECT_OVERVIEW_PAGE_KEY,
    title: "Partner Contribution Overview",
    datasetId: "partners",
    kind: "bar",
    dimensionField: "type",
    measureField: "__count__",
    aggregation: "count",
    colors: {},
  },
];
