import { BeneficiaryRecord, FormSection, IndicatorFormResponse, IndicatorFormShareLink, IndicatorFormState, OwnershipMode, Project, WbsState } from "@/types/project";
import { taskColumns } from "@/lib/wbsColumns";

// Two seed projects (prj-3, prj-5) are deliberately backdated past the
// "Project progress is stalled" alert's 30-day threshold (alertRules.ts) so
// that alert has something real to demonstrate on first load — the other
// three use "now" (no stall to report). Everything else here is genuinely
// static sample data; this one field is the sole exception, purely so the
// Alerts module isn't empty out of the box.
const daysAgo = (n: number) => new Date(Date.now() - n * 86_400_000).toISOString();

// Sample data for projectStore — this app has no backend, so this is what
// projectStore.hydrate() falls back to when localStorage has nothing saved
// yet (see src/lib/localPersist.ts and DataBootstrap.tsx). Edit freely;
// there's no database to keep in sync with.

export const emptyWbs: WbsState = {
  mode: null,
  // Fixed Task schema — see lib/wbsColumns.ts (single source of truth,
  // also used by projectStore.ts's own emptyWbs() fallback and its
  // normalizeWbsColumns migration).
  columns: taskColumns(),
  // No default WBS items — a Project's WBS starts empty until an authorized
  // user (per the configured ownership mode) creates the first row, per spec.
  rows: [],
};

export const projects: Project[] = [
  {
    id: "prj-1",
    code: "PRJ-2024-018",
    name: "Rural Girls' Education Initiative",
    location: "Bihar, Jharkhand",
    partner: "Bright Futures Foundation",
    status: "Execution",
    statusChangedAt: daysAgo(0),
    budget: 4000000,
    startDate: "2024-04-01",
    endDate: "2026-03-31",
    description: "Scholarship and remedial-education support for girls in rural districts.",
  },
  {
    id: "prj-2",
    code: "PRJ-2024-022",
    name: "Clean Water Access Program",
    location: "Rajasthan",
    partner: "AquaLife Trust",
    status: "Execution",
    statusChangedAt: daysAgo(0),
    budget: 3000000,
    startDate: "2024-06-01",
    endDate: "2025-12-31",
    description: "Borewell installation and water-quality monitoring across 40 villages.",
  },
  {
    id: "prj-3",
    code: "PRJ-2025-004",
    name: "Skill Development for Youth",
    location: "Madhya Pradesh",
    partner: "SkillBridge India",
    status: "Planning",
    statusChangedAt: daysAgo(45),
    budget: 3100000,
    startDate: "2025-09-01",
    endDate: "2026-08-31",
    description: "Vocational training and job placement for youth aged 18-25.",
  },
  {
    id: "prj-4",
    code: "PRJ-2023-011",
    name: "Maternal Health Outreach",
    location: "Odisha",
    partner: "CareWell Health Partners",
    status: "Closing",
    statusChangedAt: daysAgo(5),
    budget: 2450000,
    startDate: "2023-01-01",
    endDate: "2026-08-31",
    description: "Mobile health camps and nutrition support for expecting mothers.",
  },
  {
    id: "prj-5",
    code: "PRJ-2025-009",
    name: "Solar Micro-Grid Pilot",
    location: "Karnataka",
    partner: "GreenVolt Energy",
    status: "Review",
    statusChangedAt: daysAgo(38),
    budget: 5300000,
    startDate: "2025-02-01",
    endDate: "2026-01-31",
    description: "Off-grid solar power for 12 unelectrified hamlets.",
  },
];

export const beneficiaryOwnership: Record<string, OwnershipMode | null> = {
  "prj-1": "both",
};

export const beneficiaryRecords: BeneficiaryRecord[] = [
  { id: "ben-1", projectId: "prj-1", name: "Priya Kumari", gender: "Female", age: "12", village: "Nawada", district: "Nawada", state: "Bihar", program: "Girl Child Education", date: "15 Jan 2025", status: "enrolled", guardian: "Ramesh Kumari", contact: "9876543210", officer: "Vijay Singh", cat: "SC" },
  { id: "ben-2", projectId: "prj-1", name: "Rahul Paswan", gender: "Male", age: "9", village: "Bodh Gaya", district: "Gaya", state: "Bihar", program: "Digital Literacy", date: "20 Jan 2025", status: "enrolled", guardian: "Sunita Devi", contact: "9876543211", officer: "Vijay Singh", cat: "ST" },
  { id: "ben-3", projectId: "prj-1", name: "Sunita Devi", gender: "Female", age: "14", village: "Kanke", district: "Ranchi", state: "Jharkhand", program: "Scholarship Program", date: "5 Feb 2025", status: "at-risk", guardian: "Mohan Kumar", contact: "9876543212", officer: "Priya Rani", cat: "OBC" },
  { id: "ben-4", projectId: "prj-1", name: "Anjali Singh", gender: "Female", age: "11", village: "Jharia", district: "Dhanbad", state: "Jharkhand", program: "Girl Child Education", date: "12 Feb 2025", status: "enrolled", guardian: "Rajesh Singh", contact: "9876543213", officer: "Priya Rani", cat: "General" },
  { id: "ben-5", projectId: "prj-1", name: "Mohan Sharma", gender: "Male", age: "13", village: "Patna City", district: "Patna", state: "Bihar", program: "Vocational Training", date: "1 Mar 2025", status: "dropout", guardian: "Geeta Sharma", contact: "9876543214", officer: "Arvind Kumar", cat: "OBC" },
  { id: "ben-6", projectId: "prj-1", name: "Rekha Yadav", gender: "Female", age: "10", village: "Chas", district: "Bokaro", state: "Jharkhand", program: "Girl Child Education", date: "15 Mar 2025", status: "enrolled", guardian: "Ramesh Yadav", contact: "9876543215", officer: "Arvind Kumar", cat: "SC" },
  { id: "ben-7", projectId: "prj-1", name: "Kavita Kumari", gender: "Female", age: "13", village: "Muzaffarpur", district: "Muzaffarpur", state: "Bihar", program: "Girl Child Education", date: "2 Apr 2025", status: "enrolled", guardian: "Suresh Kumar", contact: "9845612378", officer: "Meena Gupta", cat: "SC" },
  { id: "ben-8", projectId: "prj-1", name: "Arjun Oraon", gender: "Male", age: "10", village: "Simdega", district: "Simdega", state: "Jharkhand", program: "Digital Literacy", date: "8 Apr 2025", status: "enrolled", guardian: "Birsa Oraon", contact: "9823456701", officer: "Meena Gupta", cat: "ST" },
];

// Transcribed verbatim from UNIVERSAL_FORM in bImpact_MeetingSplit_v10.html:5568-5669.
// This was originally a single global form shared by every project (a
// pre-existing architecture gap, not a deliberate per-project seed) — now
// that the Indicator Form is project-scoped (see IndicatorFormState),
// this real curated content is preserved as prj-1's pre-existing Indicator
// Form only (see `indicatorForms` below), rather than either deleting it or
// duplicating it into every project. Every other project — and any newly
// created one — starts with no indicatorForms entry at all (undecided/
// empty until an authorized user picks "Create Indicator Form"), per the
// "no automatic sample indicators" rule.
const legacyUniversalFormSections: FormSection[] = [
  {
    id: "s1",
    title: "Section A: Beneficiary Identity",
    description: "Core identification details — required for all program types",
    badge: "Required",
    fields: [
      { id: "f1", type: "text", label: "Full Name (Beneficiary)", required: true, description: "Enter name as per official ID" },
      { id: "f2", type: "radio", label: "Gender", required: true, options: ["Female", "Male", "Transgender / Other", "Prefer not to say"] },
      { id: "f3", type: "date", label: "Date of Birth", required: true },
      { id: "f4", type: "number", label: "Age (years)", required: false, description: "Auto-calculated if DOB is provided" },
      { id: "f5", type: "text", label: "Aadhaar Number (last 4 digits)", required: false, description: "Optional — only last 4 digits required" },
      { id: "f6", type: "dropdown", label: "Social Category", required: true, options: ["General", "OBC", "SC", "ST", "Minority (Muslim/Christian/Sikh/Buddhist/Parsi)", "Not Specified"] },
      { id: "f7", type: "radio", label: "Disability Status", required: false, options: ["No disability", "Visual impairment", "Hearing impairment", "Physical / Locomotor", "Intellectual / Developmental", "Multiple disabilities"] },
    ],
  },
  {
    id: "s2",
    title: "Section B: Location & Address",
    description: "Geographic data for targeting and field visit planning",
    badge: "Required",
    fields: [
      { id: "f8", type: "text", label: "Village / Ward / Locality", required: true },
      { id: "f9", type: "text", label: "Gram Panchayat / Municipality", required: false },
      { id: "f10", type: "text", label: "Block / Taluka", required: false },
      { id: "f11", type: "dropdown", label: "District", required: true, description: "Select from list", options: ["Patna", "Gaya", "Muzaffarpur", "Ranchi", "Dhanbad", "Jamshedpur", "Bhopal", "Indore", "Jabalpur", "Raipur", "Varanasi", "Lucknow", "Agra", "Jaipur", "Jodhpur", "Other (specify below)"] },
      { id: "f12", type: "dropdown", label: "State", required: true, options: ["Bihar", "Jharkhand", "Madhya Pradesh", "Chhattisgarh", "Uttar Pradesh", "Rajasthan", "Odisha", "West Bengal", "Gujarat", "Maharashtra", "Other"] },
      { id: "f13", type: "text", label: "PIN Code", required: false },
    ],
  },
  {
    id: "s3",
    title: "Section C: Program Enrollment",
    description: "Project and scheme association for tracking and reporting",
    badge: "Required",
    fields: [
      { id: "f14", type: "dropdown", label: "Program / Project Name", required: true, options: ["Girl Child Education", "Scholarship Program", "Vocational Training", "Health Camp", "Water & Sanitation", "Livelihood / SHG", "Digital Literacy", "Environmental Initiative", "Other"] },
      { id: "f15", type: "date", label: "Enrollment Date", required: true },
      { id: "f16", type: "text", label: "Beneficiary ID / Code", required: false, description: "System-generated or field-assigned unique ID" },
      { id: "f17", type: "checkbox", label: "Type of Support Received", required: false, description: "Select all that apply", options: ["Cash Transfer / DBT", "Kind Transfer (materials/kits)", "Training / Capacity Building", "Healthcare Services", "Educational Support", "Infrastructure (building/WASH)", "Technology / Device", "Livelihood Support"] },
    ],
  },
  {
    id: "s4",
    title: "Section D: Socio-Economic Background",
    description: "Economic context for need assessment and program targeting",
    badge: "Optional",
    fields: [
      { id: "f18", type: "dropdown", label: "Annual Household Income", required: false, options: ["Below ₹30,000", "₹30,000 – ₹1 Lakh", "₹1 – ₹2.5 Lakh", "₹2.5 – ₹5 Lakh", "Above ₹5 Lakh", "Not disclosed"] },
      { id: "f19", type: "radio", label: "BPL Card Holder", required: false, options: ["Yes", "No", "Applied — pending", "Not applicable"] },
      { id: "f20", type: "radio", label: "Housing Type", required: false, options: ["Pucca (concrete)", "Semi-pucca", "Kutcha (mud/thatch)", "Rental", "Government housing"] },
      { id: "f21", type: "checkbox", label: "Government Schemes Enrolled In", required: false, description: "Select all applicable", options: ["PM Jan Dhan", "PM Ujjwala", "PM Awas Yojana", "PM Kisan", "Ayushman Bharat", "MGNREGA", "NSP / Scholarship", "None"] },
    ],
  },
  {
    id: "s5",
    title: "Section E: Education Status",
    description: "Educational indicators — applicable for education-focused programs",
    badge: "Conditional",
    fields: [
      { id: "f22", type: "dropdown", label: "Current Enrollment Status", required: false, options: ["Enrolled — attending regularly", "Enrolled — irregular attendance", "Dropout", "Never enrolled", "Graduated / Completed", "Pursuing higher education", "Not applicable"] },
      { id: "f23", type: "dropdown", label: "School / Institution Name", required: false, options: ["Government school", "Government-aided school", "Private school", "Anganwadi", "Madrasa / Religious institution", "Vocational institute", "College / University", "Not applicable"] },
      { id: "f24", type: "dropdown", label: "Current Class / Grade", required: false, options: ["Pre-Primary / LKG / UKG", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", "Class 6", "Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12", "Graduate", "Post-Graduate", "Not applicable"] },
      { id: "f25", type: "number", label: "Last Exam Score (%)", required: false, description: "Enter percentage obtained in most recent exam" },
      { id: "f26", type: "number", label: "Attendance % (current term)", required: false },
      { id: "f27", type: "radio", label: "Dropout Risk Assessment", required: false, description: "Field officer assessment", options: ["Low risk", "Moderate risk", "High risk", "Already dropped out", "Not applicable"] },
    ],
  },
  {
    id: "s6",
    title: "Section F: Health & Nutrition",
    description: "Basic health indicators — for health, nutrition and ICDS programs",
    badge: "Conditional",
    fields: [
      { id: "f28", type: "number", label: "Height (cm)", required: false },
      { id: "f29", type: "number", label: "Weight (kg)", required: false },
      { id: "f30", type: "radio", label: "Nutritional Status (by field officer)", required: false, options: ["Normal / Healthy", "Mild underweight", "Moderate underweight (MAM)", "Severely underweight (SAM)", "Overweight", "Not assessed"] },
      { id: "f31", type: "radio", label: "Vaccination Status (children)", required: false, options: ["Fully vaccinated", "Partially vaccinated", "Not vaccinated", "Vaccination card not available", "Not applicable (adult)"] },
      { id: "f32", type: "checkbox", label: "Health Conditions Reported", required: false, description: "Select all applicable", options: ["Anaemia", "Stunting", "Wasting", "Vision problem", "Hearing problem", "Chronic illness", "None reported", "Not assessed"] },
    ],
  },
  {
    id: "s7",
    title: "Section G: Family & Guardian Information",
    description: "Primary contact and household composition",
    badge: "Required",
    fields: [
      { id: "f33", type: "text", label: "Guardian / Parent Name", required: true },
      { id: "f34", type: "dropdown", label: "Relationship to Beneficiary", required: true, options: ["Father", "Mother", "Grandparent", "Uncle / Aunt", "Elder sibling", "Spouse", "Self (adult beneficiary)", "Other"] },
      { id: "f35", type: "text", label: "Guardian Contact Number", required: true, description: "10-digit mobile number" },
      { id: "f36", type: "number", label: "Total Family Members", required: false },
      { id: "f37", type: "number", label: "Number of Children (below 18)", required: false },
      { id: "f38", type: "radio", label: "Primary Earning Member (Gender)", required: false, options: ["Male earner", "Female earner", "Both earn", "No earner / dependent household"] },
    ],
  },
  {
    id: "s8",
    title: "Section H: Field Officer Observations",
    description: "Qualitative notes, visit details, and progress assessment",
    badge: "Required",
    fields: [
      { id: "f39", type: "text", label: "Field Officer Name", required: true },
      { id: "f40", type: "date", label: "Date of Visit / Data Collection", required: true },
      { id: "f41", type: "radio", label: "Overall Progress Assessment", required: true, options: ["Significant improvement", "Moderate improvement", "Stable — no change", "Slight deterioration", "Not assessed"] },
      { id: "f42", type: "scale", label: "Household Engagement Level (1–5)", required: false, description: "1 = Not engaged, 5 = Highly engaged", min: 1, max: 5 },
      { id: "f43", type: "para", label: "Key Observations & Remarks", required: false, description: "Notable findings, challenges, success stories" },
      { id: "f44", type: "file", label: "Supporting Photo / Document", required: false, description: "Upload beneficiary photo or relevant document" },
    ],
  },
];

// Only prj-1 has a pre-existing Indicator Form (see legacyUniversalFormSections
// above) — every other project has no key here at all, which is exactly the
// "not created yet" state IndicatorsView.tsx renders as "No form created
// yet — Create Indicator Form" (never an auto-populated default).
const indicatorForms: Record<string, IndicatorFormState> = {
  "prj-1": {
    title: "Beneficiary Registration & Assessment Form",
    description:
      "Universal CSR beneficiary form — covers identity, location, education, health, and socio-economic data.",
    sections: legacyUniversalFormSections,
    locked: false,
  },
};

// No seeded submissions — Add Record (Indicator-Form-driven) starts empty
// per project until someone actually submits one, same "no auto-generated
// data" rule as everything else added this session.
const indicatorFormResponses: IndicatorFormResponse[] = [];

// No project starts with a Share Form link — one is only ever created the
// first time a Sponsor/Partner with edit access clicks "Share Form" (see
// getOrCreateIndicatorFormShareLink in projectStore.ts).
const indicatorFormShareLinks: Record<string, IndicatorFormShareLink> = {};

// No project starts with a configured Document owner — same "not
// arbitrarily assigned" rule as everywhere else this session; existing
// docs (seeded or user-created) stay visible/read-only regardless until the
// Sponsor picks one.
const documentOwnership: Record<string, OwnershipMode | null> = {};

export const projectSeedData = {
  projects,
  docs: {},
  wbs: Object.fromEntries(projects.map((p) => [p.id, emptyWbs])),
  beneficiaryOwnership,
  beneficiaryRecords,
  indicatorForms,
  indicatorFormResponses,
  indicatorFormShareLinks,
  documentOwnership,
};
