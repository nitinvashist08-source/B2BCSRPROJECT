import { DEFAULT_DEMO_WORKSPACE_ID, Workspace } from "@/store/workspaceStore";

// Sample data for workspaceStore — this app has no backend, so this is what
// workspaceStore.hydrate() falls back to when localStorage has nothing saved
// yet (see src/lib/localPersist.ts and DataBootstrap.tsx). Edit freely;
// there's no database to keep in sync with.

export const workspaces: Workspace[] = [
  {
    id: DEFAULT_DEMO_WORKSPACE_ID,
    name: "bImpact Demo Foundation",
    type: "corporate",
    ownerUserId: "seed-owner",
    // Matches the current seed data counts exactly (teamMembers, partners,
    // projects, etc. in the other seed files) — irrelevant for this
    // workspace (existing demo/login users never reach the getting-started
    // step), kept only because the field is required.
    checklistBaseline: { teamMembers: 3, partners: 2, committeeMembers: 4, projects: 5 },
  },
];

export const workspaceSeedData = { workspaces };
