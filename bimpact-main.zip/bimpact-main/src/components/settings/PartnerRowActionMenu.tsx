"use client";

import { Children, ReactNode, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

const MENU_WIDTH = 176;
const ITEM_HEIGHT_ESTIMATE = 33; // matches DropdownItem's px-3 py-1.5 text-sm row height
const MENU_PADDING_ESTIMATE = 8; // the menu's own py-1
const GAP = 6;

// Drop-in replacement for src/components/ui/Dropdown.tsx, scoped to this
// one table's row "⋮" menu — same fix/precedent as
// src/components/finance/BudgetPeriodActionMenu.tsx: PartnerOrgsTable's
// rounded-corner container uses overflow-hidden, which clips Dropdown's
// normal position:absolute-within-a-relative-ancestor menu (worst for rows
// near the table's bottom edge, but it also horizontally clips at the
// container's own right edge even on the very first row). A portal to
// document.body escapes any ancestor's overflow/clipping entirely and lets
// the menu flip upward when there isn't room below. Dropdown.tsx itself and
// every other consumer are untouched — this is additive, not a shared-
// component change.
export function PartnerRowActionMenu({ trigger, children }: { trigger: ReactNode; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const triggerRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  const itemCount = Children.count(children);
  const menuHeightEstimate = itemCount * ITEM_HEIGHT_ESTIMATE + MENU_PADDING_ESTIMATE;

  function openMenu() {
    const rect = triggerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const spaceBelow = window.innerHeight - rect.bottom;
    const openUpward = spaceBelow < menuHeightEstimate + GAP && rect.top > menuHeightEstimate + GAP;
    const top = openUpward ? rect.top - menuHeightEstimate - GAP : rect.bottom + GAP;
    const left = Math.max(8, Math.min(rect.right - MENU_WIDTH, window.innerWidth - MENU_WIDTH - 8));
    setPos({ top, left });
    setOpen(true);
  }

  useEffect(() => {
    if (!open) return;
    function handlePointerDown(e: MouseEvent) {
      const target = e.target as Node;
      if (triggerRef.current?.contains(target) || menuRef.current?.contains(target)) return;
      setOpen(false);
    }
    function handleDismiss() {
      setOpen(false);
    }
    document.addEventListener("mousedown", handlePointerDown);
    window.addEventListener("scroll", handleDismiss, true);
    window.addEventListener("resize", handleDismiss);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      window.removeEventListener("scroll", handleDismiss, true);
      window.removeEventListener("resize", handleDismiss);
    };
  }, [open]);

  return (
    <>
      <div ref={triggerRef} className="inline-block" onClick={() => (open ? setOpen(false) : openMenu())}>
        {trigger}
      </div>
      {open &&
        pos &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            ref={menuRef}
            style={{ position: "fixed", top: pos.top, left: pos.left, width: MENU_WIDTH }}
            className="z-[500] rounded-sm border border-border bg-surface py-1 shadow-md"
            onClick={() => setOpen(false)}
          >
            {children}
          </div>,
          document.body
        )}
    </>
  );
}
