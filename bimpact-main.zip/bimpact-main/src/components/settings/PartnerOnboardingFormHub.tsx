"use client";

import { useState } from "react";
import { useSettingsStore } from "@/store/settingsStore";
import { PartnerType } from "@/types/settings";
import { PartnerTypeFormStatusList } from "./PartnerTypeFormStatusList";
import { PartnerFormBuilder } from "./PartnerFormBuilder";

// Orchestrates the two screens reached from Partners' "Partner Onboarding
// Form" secondary CTA: pick a partner type (PartnerTypeFormStatusList),
// then build/edit that type's one onboarding form (PartnerFormBuilder).
// `onBack` returns all the way to the Partners table.
export function PartnerOnboardingFormHub({ onBack }: { onBack: () => void }) {
  const forms = useSettingsStore((s) => s.partnerForms);
  const createPartnerForm = useSettingsStore((s) => s.createPartnerForm);
  const updatePartnerForm = useSettingsStore((s) => s.updatePartnerForm);

  const [selectedType, setSelectedType] = useState<PartnerType | null>(null);

  if (selectedType) {
    const existing = forms.find((f) => f.partnerType === selectedType) ?? null;
    return (
      <PartnerFormBuilder
        partnerType={selectedType}
        existing={existing}
        onBack={() => setSelectedType(null)}
        onSave={({ name, selectedItemIds, status }) => {
          if (existing) {
            updatePartnerForm(existing.id, { name, selectedItemIds, status });
          } else {
            // One form per partner type is enforced here too (not just by
            // the DB's unique column) — if another tab/session created one
            // in the meantime, this silently no-ops rather than duplicating.
            createPartnerForm({ partnerType: selectedType, name, selectedItemIds, status });
          }
          setSelectedType(null);
        }}
      />
    );
  }

  return <PartnerTypeFormStatusList onBack={onBack} onSelect={setSelectedType} />;
}
