"use client";

import { useState } from "react";
import { useSettingsStore } from "@/store/settingsStore";
import { PartnerOrg, PartnerType } from "@/types/settings";
import { SlideOver } from "@/components/ui/SlideOver";
import { Button } from "@/components/ui/Button";

const PARTNER_TYPES: PartnerType[] = ["Co-Sponsor", "Implementer", "Co-Implementer"];

const emptyDraft = { name: "", contactName: "", contactEmail: "", type: "" as PartnerType | "" };

// so-add-partner, bImpact_MeetingSplit_v10.html:9386-9416 ("Invite Partner
// Organization") — the mockup's own version only collects email + partner
// type and its Send Invitation button doesn't persist anything; kept this
// app's fuller working form (org/contact/location) per your call, adding
// the Partner Type field the table needs. Also serves as the "Edit
// Partner" form (unwired in the source) via the `editing` prop.
export function InvitePartnerSlideOver({
  open,
  onClose,
  editing,
}: {
  open: boolean;
  onClose: () => void;
  editing?: PartnerOrg | null;
}) {
  const invitePartner = useSettingsStore((s) => s.invitePartner);
  const editPartner = useSettingsStore((s) => s.editPartner);
  const [draft, setDraft] = useState(
    editing
      ? {
          name: editing.name,
          contactName: editing.contactName,
          contactEmail: editing.contactEmail,
          type: editing.type,
        }
      : emptyDraft
  );
  const [errors, setErrors] = useState<Set<"name" | "contactEmail" | "type">>(new Set());
  const [duplicateError, setDuplicateError] = useState(false);
  // Stale-state guard: the Edit Partner menu item is only ever rendered for
  // a still-Invited (never submitted) partner, but if this slide-over was
  // already open in one tab while another tab/action moved the partner past
  // that (approved, rejected, submitted for review) before Save is clicked,
  // editPartner refuses the write — see settingsStore's editPartner.
  const [editBlockedError, setEditBlockedError] = useState(false);

  function handleSave() {
    const bad = new Set<"name" | "contactEmail" | "type">();
    if (!draft.name.trim()) bad.add("name");
    if (!draft.contactEmail.trim()) bad.add("contactEmail");
    if (!draft.type) bad.add("type");
    setErrors(bad);
    setDuplicateError(false);
    setEditBlockedError(false);
    if (bad.size > 0) return;

    const payload = { ...draft, type: draft.type as PartnerType };
    if (editing) {
      const result = editPartner(editing.id, payload);
      if (!result.ok) {
        setEditBlockedError(true);
        return;
      }
    } else {
      // invitePartner refreshes an existing still-pending invite in place
      // (same org re-invited before they've onboarded) but refuses when the
      // email already belongs to a partner who has submitted onboarding or
      // is Active/Inactive — that partner's real data must be managed via
      // Edit/the review actions, not silently overwritten by another invite.
      const result = invitePartner(payload);
      if (!result.ok) {
        bad.add("contactEmail");
        setErrors(bad);
        setDuplicateError(true);
        return;
      }
    }
    setDraft(emptyDraft);
    onClose();
  }

  return (
    <SlideOver
      open={open}
      onClose={onClose}
      title={editing ? "Edit Partner" : "Invite Partner Organization"}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>{editing ? "Save changes" : "Send invite"}</Button>
        </>
      }
    >
      <p className="mb-4 -mt-2 text-xs text-muted">
        {editing ? "Update this partner organization's details" : "Sends an invitation to their primary contact"}
      </p>
      {editBlockedError && (
        <p className="mb-4 -mt-2 text-xs text-danger">
          This partner can no longer be edited — its status has changed since this form was opened. Close and
          refresh the Partners list to see its current status.
        </p>
      )}
      <div className="flex flex-col gap-4">
        <label className="block text-sm">
          <span className="mb-1 block font-medium text-ink-2">Organization name</span>
          <input
            value={draft.name}
            onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
            className={`w-full rounded-sm border px-3 py-2 text-sm outline-none focus:border-primary ${
              errors.has("name") ? "border-danger" : "border-border"
            }`}
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1 block font-medium text-ink-2">Contact name</span>
          <input
            value={draft.contactName}
            onChange={(e) => setDraft((d) => ({ ...d, contactName: e.target.value }))}
            className="w-full rounded-sm border border-border px-3 py-2 text-sm outline-none focus:border-primary"
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1 block font-medium text-ink-2">Work email ID</span>
          <input
            type="email"
            value={draft.contactEmail}
            onChange={(e) => {
              setDraft((d) => ({ ...d, contactEmail: e.target.value }));
              setDuplicateError(false);
            }}
            placeholder="sunita@careindia.org"
            className={`w-full rounded-sm border px-3 py-2 text-sm outline-none focus:border-primary ${
              errors.has("contactEmail") ? "border-danger" : "border-border"
            }`}
          />
          {duplicateError && (
            <p className="mt-1.5 text-xs text-danger">
              This email already belongs to a partner who has been onboarded or is under review —
              use Edit on that partner instead of a new invite.
            </p>
          )}
        </label>
        <label className="block text-sm">
          <span className="mb-1 block font-medium text-ink-2">Partner type</span>
          <select
            value={draft.type}
            onChange={(e) => setDraft((d) => ({ ...d, type: e.target.value as PartnerType }))}
            className={`w-full rounded-sm border px-3 py-2 text-sm outline-none focus:border-primary ${
              errors.has("type") ? "border-danger" : "border-border"
            }`}
          >
            <option value="">Select partner type…</option>
            {PARTNER_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </label>
      </div>
    </SlideOver>
  );
}
