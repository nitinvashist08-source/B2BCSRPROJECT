"use client";

import { useState } from "react";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { PartnerTeamMember, PartnerTeamRole } from "@/types/settings";
import { PARTNER_TEAM_ROLES } from "@/lib/partnerTeamRoles";
import { SlideOver } from "@/components/ui/SlideOver";
import { Button } from "@/components/ui/Button";

// Simple, permissive email-shape check — enough to reject an obviously
// malformed address like "not-an-email" without trying to be a full RFC
// 5322 validator (this is a mock app with no real delivery).
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type FieldError = "name" | "email";

// Partner-side counterpart to InviteMemberSlideOver.tsx — same slide-over
// pattern (email+name fields, radio-card role picker, Cancel/primary-CTA
// footer, dual-purpose via `editing`) but scoped to a single partner org's
// own team (PartnerTeamMember/PartnerTeamRole, not the Sponsor's
// TeamMember/TeamRole) and driven by PARTNER_TEAM_ROLES so the three
// Partner-side roles never drift from PartnerTeamMembersTable's list.
export function InvitePartnerMemberSlideOver({
  open,
  onClose,
  editing,
}: {
  open: boolean;
  onClose: () => void;
  editing?: PartnerTeamMember | null;
}) {
  const invitePartnerTeamMember = useSettingsStore((s) => s.invitePartnerTeamMember);
  const updatePartnerTeamMember = useSettingsStore((s) => s.updatePartnerTeamMember);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);

  const [name, setName] = useState(editing?.name ?? "");
  const [email, setEmail] = useState(editing?.email ?? "");
  const [role, setRole] = useState<PartnerTeamRole>(editing?.role ?? PARTNER_TEAM_ROLES[0].value);
  const [errors, setErrors] = useState<Set<FieldError>>(new Set());
  const [emailError, setEmailError] = useState<string | null>(null);

  function reset() {
    setName(editing?.name ?? "");
    setEmail(editing?.email ?? "");
    setRole(editing?.role ?? PARTNER_TEAM_ROLES[0].value);
    setErrors(new Set());
    setEmailError(null);
  }

  function handleClose() {
    reset();
    onClose();
  }

  function handleSave() {
    const bad = new Set<FieldError>();
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    if (!trimmedName) bad.add("name");
    if (!trimmedEmail || !EMAIL_RE.test(trimmedEmail)) bad.add("email");
    setErrors(bad);
    setEmailError(null);
    if (bad.size > 0) return;

    if (editing) {
      updatePartnerTeamMember(editing.id, { name: trimmedName, email: trimmedEmail, role });
      onClose();
      return;
    }

    // This screen is only ever reachable from a Partner session, so
    // partnerOrgId should always be set — guard rather than crash in the
    // one case (stale/edge state) where it somehow isn't.
    if (!partnerOrgId) {
      setEmailError("Unable to send invitation — no partner organization is active.");
      return;
    }

    const result = invitePartnerTeamMember({ partnerOrgId, name: trimmedName, email: trimmedEmail, role });
    if (!result.ok) {
      setErrors(new Set([...bad, "email"]));
      setEmailError("This email has already been invited.");
      return;
    }
    onClose();
  }

  return (
    <SlideOver
      open={open}
      onClose={handleClose}
      title={editing ? "Edit Team Member" : "Invite Team Member"}
      footer={
        <>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>{editing ? "Save changes" : "Send Invitation"}</Button>
        </>
      }
    >
      <p className="mb-5 -mt-2 text-xs text-muted">
        {editing ? "Update this team member's details and role" : "A secure setup link will be emailed to the user"}
      </p>

      <div className="mb-5 grid grid-cols-2 gap-3.5">
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-ink-2">Full Name</span>
          <input
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              if (e.target.value.trim()) setErrors((prev) => { const next = new Set(prev); next.delete("name"); return next; });
            }}
            placeholder="e.g. Jane Smith"
            className={`h-10 w-full rounded-sm border px-3 text-sm outline-none focus:border-primary ${
              errors.has("name") ? "border-danger" : "border-border"
            }`}
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-ink-2">Email Address</span>
          <input
            type="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setEmailError(null);
              if (EMAIL_RE.test(e.target.value.trim())) {
                setErrors((prev) => { const next = new Set(prev); next.delete("email"); return next; });
              }
            }}
            placeholder="jane@partner.org"
            className={`h-10 w-full rounded-sm border px-3 text-sm outline-none focus:border-primary ${
              errors.has("email") ? "border-danger" : "border-border"
            }`}
          />
          {emailError && <span className="mt-1 block text-xs text-danger">{emailError}</span>}
        </label>
      </div>

      <span className="mb-2.5 block text-sm font-medium text-ink-2">Assign Role</span>
      <div className="flex flex-col gap-2.5">
        {PARTNER_TEAM_ROLES.map((r) => (
          <label
            key={r.value}
            className={`flex cursor-pointer items-start gap-3 rounded-md border-[1.5px] p-3.5 transition-colors ${
              role === r.value ? "border-primary bg-primary-50 shadow-[0_0_0_1px_var(--color-primary)]" : "border-border hover:border-border-strong"
            }`}
          >
            <input
              type="radio"
              name="partner_member_role"
              className="sr-only"
              checked={role === r.value}
              onChange={() => setRole(r.value)}
            />
            <span
              className={`mt-0.5 flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full border-[1.5px] ${
                role === r.value ? "border-primary" : "border-border"
              }`}
            >
              {role === r.value && <span className="h-2 w-2 rounded-full bg-primary" />}
            </span>
            <span>
              <span className={`block text-sm font-bold ${role === r.value ? "text-primary-700" : "text-ink"}`}>
                {r.value}
              </span>
              <span className={`mt-0.5 block text-[13px] leading-snug ${role === r.value ? "text-primary-600" : "text-muted"}`}>
                {r.description}
              </span>
            </span>
          </label>
        ))}
      </div>
    </SlideOver>
  );
}
