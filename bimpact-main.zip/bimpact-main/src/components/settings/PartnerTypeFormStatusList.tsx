"use client";

import { useSettingsStore } from "@/store/settingsStore";
import { PARTNER_TYPE_OPTIONS } from "@/types/partnerForm";
import { PartnerType } from "@/types/settings";

function BackIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}
function EditIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
    </svg>
  );
}
function PlusIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}

// Section 1-2 of the spec: pick a partner type, see whether it already has
// an onboarding form. A form is enforced one-per-partner-type at the store
// layer (settingsStore.createPartnerForm) and the DB layer (@unique
// partnerType column) — this list just reflects that state, it doesn't
// enforce anything itself.
export function PartnerTypeFormStatusList({ onBack, onSelect }: { onBack: () => void; onSelect: (partnerType: PartnerType) => void }) {
  const forms = useSettingsStore((s) => s.partnerForms);

  return (
    <div>
      <button
        onClick={onBack}
        className="mb-3 inline-flex h-7 items-center gap-[5px] rounded-sm border-[1.5px] border-border bg-surface px-2.5 text-xs font-semibold text-ink-2 hover:border-border-strong"
      >
        <BackIcon />
        Back to Partners
      </button>

      <div className="mb-5">
        <div className="text-[1.1rem] font-extrabold tracking-[-0.02em] text-ink">Partner Compliance Form</div>
        <p className="mt-0.5 max-w-[600px] text-[13px] text-muted">
          Select the compliance documents required from partners of each type, from a predefined checklist. Only one
          checklist can be active per partner type.
        </p>
      </div>

      <div className="overflow-hidden rounded-md border border-border bg-surface">
        <table className="w-full table-fixed border-collapse text-[13px]">
          <thead>
            <tr className="bg-surface-2">
              <th className="w-[46%] px-4 py-2.5 text-left text-[10.5px] font-bold uppercase tracking-[0.05em] text-muted">Partner Type</th>
              <th className="w-[28%] px-4 py-2.5 text-left text-[10.5px] font-bold uppercase tracking-[0.05em] text-muted">Form Status</th>
              <th className="px-4 py-2.5 text-right text-[10.5px] font-bold uppercase tracking-[0.05em] text-muted">Action</th>
            </tr>
          </thead>
          <tbody>
            {PARTNER_TYPE_OPTIONS.map((type) => {
              const form = forms.find((f) => f.partnerType === type);
              return (
                <tr key={type} className="border-t border-border">
                  <td className="px-4 py-3 font-semibold text-ink">{type}</td>
                  <td className="px-4 py-3">
                    {form ? (
                      <span
                        className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11.5px] font-semibold ${
                          form.status === "Active" ? "border-secondary-100 bg-secondary-50 text-secondary-600" : "border-amber-100 bg-amber-50 text-amber-600"
                        }`}
                      >
                        Form Created · {form.status}
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-bg px-2.5 py-1 text-[11.5px] font-semibold text-muted">
                        Not Created
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => onSelect(type)}
                      className={`inline-flex h-7 items-center gap-1.5 rounded-sm px-2.5 text-xs font-semibold ${
                        form ? "border-[1.5px] border-border bg-surface text-ink-2 hover:border-border-strong" : "bg-primary text-white hover:bg-primary-600"
                      }`}
                    >
                      {form ? <EditIcon /> : <PlusIcon />}
                      {form ? "Edit Form" : "Create Form"}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
