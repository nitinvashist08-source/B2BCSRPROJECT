"use client";

import { ReactElement, useState } from "react";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { useAlertStore } from "@/store/alertStore";
import { DEFAULT_DEMO_WORKSPACE_ID } from "@/store/workspaceStore";
import { isAlertVisible } from "@/lib/alertVisibility";
import { useProjectStore } from "@/store/projectStore";
import { PartnerOrg, PartnerReviewStatus, PartnerStatus } from "@/types/settings";
import { Button } from "@/components/ui/Button";
import { DropdownItem } from "@/components/ui/Dropdown";
import { PartnerRowActionMenu } from "./PartnerRowActionMenu";
import { InvitePartnerSlideOver } from "./InvitePartnerSlideOver";
import { PartnerOnboardingFormHub } from "./PartnerOnboardingFormHub";
import { PartnerSubmissionReview } from "@/components/partners/PartnerSubmissionReview";
import { ReinvitePartnerDialog } from "@/components/partners/ReinvitePartnerDialog";
import { DeactivatePartnerDialog } from "@/components/partners/DeactivatePartnerDialog";
import { CancelInvitationDialog } from "@/components/partners/CancelInvitationDialog";
import { PartnerStatusMenuItems } from "@/components/partners/PartnerStatusMenuItems";

function PlusIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function SearchIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="11" cy="11" r="8" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  );
}
function MoreIcon() {
  return (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
      <circle cx="5" cy="12" r="1" />
    </svg>
  );
}
function ClockIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
function AlertTriangleIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z" />
      <line x1="12" y1="9" x2="12" y2="13" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
  );
}
function CheckCircleIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}
function XCircleIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <line x1="15" y1="9" x2="9" y2="15" />
      <line x1="9" y1="9" x2="15" y2="15" />
    </svg>
  );
}

const STATUS_STYLE: Record<PartnerStatus, string> = {
  Active: "bg-secondary-50 text-secondary-600",
  Invited: "bg-amber-50 text-amber-600",
  Inactive: "bg-bg text-muted border border-border",
};

export function StatusBadge({ status }: { status: PartnerStatus }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ${STATUS_STYLE[status]}`}>
      {status === "Active" && <span className="h-1.5 w-1.5 rounded-full bg-secondary" />}
      {status === "Invited" && <ClockIcon />}
      {status === "Inactive" && <span className="h-1.5 w-1.5 rounded-full border border-muted" />}
      {status}
    </span>
  );
}

// The Sponsor-review workflow's own status, shown in place of the plain
// Active/Invited/Inactive StatusBadge once a partner has submitted
// onboarding (see PartnerOrg.reviewStatus). Amber for the two states still
// awaiting the partner/Sponsor, green for Approved, red/danger for
// Rejected — same palette StatusBadge and the amber "Compliance Incomplete"
// pill above already use. Exported so PartnerSubmissionReview can render
// the identical badge on the detail screen.
const REVIEW_STATUS_STYLE: Record<PartnerReviewStatus, string> = {
  "Pending Review": "bg-amber-50 text-amber-600",
  "Changes Requested": "bg-amber-50 text-amber-600",
  Approved: "bg-secondary-50 text-secondary-600",
  Rejected: "bg-danger-50 text-danger",
};

const REVIEW_STATUS_ICON: Record<PartnerReviewStatus, () => ReactElement> = {
  "Pending Review": ClockIcon,
  "Changes Requested": AlertTriangleIcon,
  Approved: CheckCircleIcon,
  Rejected: XCircleIcon,
};

export function ReviewStatusBadge({ status }: { status: PartnerReviewStatus }) {
  const Icon = REVIEW_STATUS_ICON[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ${REVIEW_STATUS_STYLE[status]}`}
    >
      <Icon />
      {status}
    </span>
  );
}

// spanel-partner, bImpact_MeetingSplit_v10.html:8619-8698 — header (title +
// description + Invite Partner) → searchable table (Organization / Contact
// Person / Partner Type / Status / Action). Editing happens through the
// slide-over, reached via a row's "⋮" menu, whose items are contextual per
// status (Active/Invited/Inactive) matching the mockup's three demo rows.
export function PartnerOrgsTable() {
  const partners = useSettingsStore((s) => s.partners);
  const reactivatePartner = useSettingsStore((s) => s.reactivatePartner);
  const alerts = useAlertStore((s) => s.alerts);
  const markAlertRead = useAlertStore((s) => s.markRead);
  const workspaceId = useSessionStore((s) => s.workspaceId);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const projects = useProjectStore((s) => s.projects);

  const [search, setSearch] = useState("");
  const [inviteOpen, setInviteOpen] = useState(false);
  const [editing, setEditing] = useState<PartnerOrg | null>(null);
  const [showOnboardingForm, setShowOnboardingForm] = useState(false);
  // Looked up by id (not a captured object) so the review screen stays live
  // if the parallel Approve/Request Changes/Reject dialogs update the
  // partner's reviewStatus while it's open.
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  // Re-invite confirm/success dialog target — kept separate from `open` so
  // the dialog can flip to its success step without losing the partner's
  // name mid-flow (see ReinvitePartnerDialog).
  const [reinviteTarget, setReinviteTarget] = useState<PartnerOrg | null>(null);
  const [reinviteOpen, setReinviteOpen] = useState(false);
  // Deactivate confirm/reason dialog target — same separate-target/open
  // shape as reinvite above, for the same reason (survive the confirm →
  // success step transition without losing the partner's name).
  const [deactivateTarget, setDeactivateTarget] = useState<PartnerOrg | null>(null);
  const [deactivateOpen, setDeactivateOpen] = useState(false);
  // Cancel Invitation confirm dialog target — same separate-target/open
  // shape as the two above.
  const [cancelInviteTarget, setCancelInviteTarget] = useState<PartnerOrg | null>(null);
  const [cancelInviteOpen, setCancelInviteOpen] = useState(false);

  // Scoped to the current Sponsor (workspace) — a partner invited under a
  // different Sponsor must never show up here. The seed/demo partners in
  // settingsData.ts predate workspaceId and don't carry one, so they're
  // treated as belonging to the default demo workspace.
  const scoped = partners.filter(
    (p) => p.workspaceId === workspaceId || (!p.workspaceId && workspaceId === DEFAULT_DEMO_WORKSPACE_ID)
  );

  // "{Partner Name} has uploaded a new document in compliances" — now
  // sourced from the centralized Alerts module (alertStore) instead of a
  // bespoke notification list; isAlertVisible applies the same workspace
  // scoping the old code did directly, so a compliance upload still never
  // surfaces to a Sponsor it wasn't submitted to. Unread only; newest first
  // (alertStore prepends new alerts).
  const notifications = alerts.filter(
    (a) =>
      a.type === "compliance_document_uploaded" &&
      !a.isRead &&
      isAlertVisible(a, { role, partnerOrgId, partnerName: null, workspaceId, projects, projectPartners, partners })
  );

  const filtered = scoped.filter((p) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return p.name.toLowerCase().includes(q) || p.contactName.toLowerCase().includes(q);
  });

  function openInvite() {
    setEditing(null);
    setInviteOpen(true);
  }
  function openEdit(p: PartnerOrg) {
    setEditing(p);
    setInviteOpen(true);
  }

  if (showOnboardingForm) {
    return <PartnerOnboardingFormHub onBack={() => setShowOnboardingForm(false)} />;
  }

  const reviewingPartner = reviewingId ? scoped.find((p) => p.id === reviewingId) ?? null : null;
  if (reviewingPartner) {
    return <PartnerSubmissionReview partner={reviewingPartner} onBack={() => setReviewingId(null)} />;
  }

  return (
    <div>
      {notifications.length > 0 && (
        <div className="mb-4 flex flex-col gap-2">
          {notifications.map((n) => (
            <div
              key={n.id}
              className="flex items-center justify-between gap-3 rounded-lg border border-primary-100 bg-primary-50 px-4 py-3 text-[13px] text-primary-700"
            >
              <button
                type="button"
                onClick={() => {
                  markAlertRead(n.id);
                  setReviewingId(n.entityId);
                }}
                className="flex-1 rounded-sm text-left font-medium hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500"
              >
                <span className="font-semibold">{partners.find((p) => p.id === n.entityId)?.name ?? "A partner"}</span> has uploaded a new document in compliances
              </button>
              <button
                type="button"
                onClick={() => markAlertRead(n.id)}
                className="shrink-0 rounded-sm text-xs font-semibold text-primary-700 underline underline-offset-2 hover:text-primary-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500"
              >
                Dismiss
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-ink">Partner Organizations</h2>
          <p className="mt-1 max-w-2xl text-[13px] text-muted">
            Manage external implementing partners, co-sponsors, and their access levels across projects.
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2.5">
          <Button variant="ghost" onClick={() => setShowOnboardingForm(true)}>
            Partner Compliance Form
          </Button>
          <Button onClick={openInvite}>
            <PlusIcon />
            Partner Onboarding
          </Button>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-border bg-surface">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <span className="text-sm font-semibold text-ink">All Partners</span>
          <div className="flex h-8 w-56 items-center gap-2 rounded-sm border border-border bg-bg px-2.5">
            <SearchIcon />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search partners…"
              className="w-full bg-transparent text-xs outline-none placeholder:text-muted"
            />
          </div>
        </div>

        <table className="w-full border-collapse text-left text-sm">
          <thead>
            <tr className="border-b border-border bg-surface-2 text-xs text-muted">
              <th className="w-[30%] px-4 py-2.5 font-medium">Organization</th>
              <th className="w-[20%] px-4 py-2.5 font-medium">Contact Person</th>
              <th className="w-[18%] px-4 py-2.5 font-medium">Partner Type</th>
              <th className="w-[17%] px-4 py-2.5 font-medium">Status</th>
              <th className="px-4 py-2.5 text-right font-medium">Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) => {
              const muted = p.status === "Inactive";
              return (
                <tr key={p.id} className="border-b border-border last:border-b-0">
                  <td className="px-4 py-3">
                    <div className={`font-semibold ${muted ? "text-muted" : "text-ink"}`}>{p.name}</div>
                    <div className="mt-0.5 text-xs text-muted">{p.contactEmail}</div>
                  </td>
                  <td className={`px-4 py-3 ${muted ? "text-muted" : "text-ink-2"}`}>{p.contactName}</td>
                  <td className="px-4 py-3">
                    <span className="rounded-[6px] border border-border bg-surface-2 px-2.5 py-1 text-[11.5px] font-semibold text-ink-2">
                      {p.type}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap items-center gap-1.5">
                      {p.reviewStatus && p.reviewStatus !== "Approved" ? (
                        <ReviewStatusBadge status={p.reviewStatus} />
                      ) : (
                        <StatusBadge status={p.status} />
                      )}
                      {p.status === "Active" && p.complianceStatus === "Incomplete" && (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-2.5 py-1 text-[11.5px] font-semibold text-amber-600">
                          Compliance Incomplete
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <PartnerRowActionMenu trigger={<button className="rounded-sm p-1 text-muted hover:bg-surface-2"><MoreIcon /></button>}>
                      <DropdownItem onClick={() => setReviewingId(p.id)}>View Details</DropdownItem>
                      <PartnerStatusMenuItems
                        partner={p}
                        onEdit={openEdit}
                        onReinvite={(target) => {
                          setReinviteTarget(target);
                          setReinviteOpen(true);
                        }}
                        onCancelInvitation={(target) => {
                          setCancelInviteTarget(target);
                          setCancelInviteOpen(true);
                        }}
                        onDeactivate={(target) => {
                          setDeactivateTarget(target);
                          setDeactivateOpen(true);
                        }}
                        onActivate={(target) => reactivatePartner(target.id)}
                      />
                    </PartnerRowActionMenu>
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-sm text-muted">
                  No partners found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <InvitePartnerSlideOver
        key={editing?.id ?? "new"}
        open={inviteOpen}
        onClose={() => setInviteOpen(false)}
        editing={editing}
      />

      <ReinvitePartnerDialog partner={reinviteTarget} open={reinviteOpen} onClose={() => setReinviteOpen(false)} />
      <DeactivatePartnerDialog
        partner={deactivateTarget}
        open={deactivateOpen}
        onClose={() => setDeactivateOpen(false)}
      />
      <CancelInvitationDialog
        partner={cancelInviteTarget}
        open={cancelInviteOpen}
        onClose={() => setCancelInviteOpen(false)}
      />
    </div>
  );
}
