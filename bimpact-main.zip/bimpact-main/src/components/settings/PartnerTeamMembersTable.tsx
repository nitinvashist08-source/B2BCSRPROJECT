"use client";

import { useState } from "react";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { PartnerTeamMember } from "@/types/settings";
import { PARTNER_TEAM_ROLES } from "@/lib/partnerTeamRoles";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { Dropdown, DropdownItem } from "@/components/ui/Dropdown";
import { InvitePartnerMemberSlideOver } from "./InvitePartnerMemberSlideOver";

function PlusIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function SearchIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="11" cy="11" r="8" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  );
}
function MoreIcon() {
  return (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
      <circle cx="5" cy="12" r="1" />
    </svg>
  );
}
function ClockIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
function UsersEmptyIcon() {
  return (
    <svg fill="none" height="22" width="22" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

// Presentational-only, mirroring Sponsor's own StatusBadge shape
// (TeamMembersTable.tsx) but kept as a local copy per this task's
// boundaries — it's tiny and not exported there, so not imported from it.
function StatusBadge({ status }: { status: PartnerTeamMember["status"] }) {
  const cls = status === "Active" ? "bg-secondary-50 text-secondary-600" : "bg-amber-50 text-amber-600";
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ${cls}`}>
      {status === "Active" ? <span className="h-1.5 w-1.5 rounded-full bg-secondary" /> : <ClockIcon />}
      {status}
    </span>
  );
}

// Partner-side counterpart to TeamMembersTable.tsx, adapted (not copied):
// scoped to the logged-in partner's own org (partnerOrgId) so "Partner A
// cannot manage users belonging to Partner B" is a real data-read
// constraint, not just a UI filter of convenience; uses the
// Manager/Project Manager/Field Officer role vocabulary (PARTNER_TEAM_ROLES)
// instead of Sponsor's Admin/Manager/Auditor; and role is shown as a plain
// badge rather than Sponsor's inline-editable pill-select, since this role
// model doesn't yet define per-role permissions to justify inline editing.
export function PartnerTeamMembersTable() {
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const allMembers = useSettingsStore((s) => s.partnerTeamMembers);
  const removePartnerTeamMember = useSettingsStore((s) => s.removePartnerTeamMember);

  const members = allMembers.filter((m) => m.partnerOrgId === partnerOrgId);

  const [search, setSearch] = useState("");
  const [inviteOpen, setInviteOpen] = useState(false);
  const [editing, setEditing] = useState<PartnerTeamMember | null>(null);

  const filtered = members.filter((m) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return m.name.toLowerCase().includes(q) || m.email.toLowerCase().includes(q);
  });

  function openInvite() {
    setEditing(null);
    setInviteOpen(true);
  }
  function openEdit(m: PartnerTeamMember) {
    setEditing(m);
    setInviteOpen(true);
  }

  const roleLabel = (role: PartnerTeamMember["role"]) =>
    PARTNER_TEAM_ROLES.find((r) => r.value === role)?.value ?? role;

  return (
    <div>
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-ink">Team Members</h2>
          <p className="mt-1 max-w-2xl text-[13px] text-muted">
            Manage your internal team members and their access to assigned projects and data collection activities.
          </p>
        </div>
        <Button onClick={openInvite} className="shrink-0">
          <PlusIcon />
          Invite Member
        </Button>
      </div>

      {members.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border bg-surface px-6 py-14 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full border border-dashed border-border-strong text-muted">
            <UsersEmptyIcon />
          </div>
          <h3 className="text-sm font-bold text-ink">No team members yet</h3>
          <p className="max-w-sm text-[13px] text-muted">
            Invite your first team member to start assigning projects and data collection activities to your
            organization&apos;s staff.
          </p>
          <Button onClick={openInvite} size="sm" className="mt-1">
            <PlusIcon />
            Invite Member
          </Button>
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-border bg-surface">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <span className="text-sm font-semibold text-ink">All Members</span>
            <div className="flex h-8 w-56 items-center gap-2 rounded-sm border border-border bg-bg px-2.5">
              <SearchIcon />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search members…"
                className="w-full bg-transparent text-xs outline-none placeholder:text-muted"
              />
            </div>
          </div>

          <table className="w-full border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-border bg-surface-2 text-xs text-muted">
                <th className="w-[35%] px-4 py-2.5 font-medium">Member</th>
                <th className="w-[20%] px-4 py-2.5 font-medium">Role</th>
                <th className="w-[20%] px-4 py-2.5 font-medium">Status</th>
                <th className="w-[20%] px-4 py-2.5 font-medium">Last Active</th>
                <th className="px-4 py-2.5 text-right font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((m) => (
                <tr key={m.id} className="border-b border-border last:border-b-0">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <Avatar name={m.name} size="md" />
                      <div>
                        <div className="font-semibold text-ink">{m.name}</div>
                        <div className="mt-0.5 text-xs text-muted">{m.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="inline-flex rounded-full border border-border bg-bg px-2.5 py-1 text-xs font-bold text-ink-2">
                      {roleLabel(m.role)}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={m.status} />
                  </td>
                  <td className="px-4 py-3 text-[12.5px] text-muted">
                    {m.status === "Invited" ? "Awaiting setup" : "—"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {m.status === "Invited" ? (
                      <button className="rounded-sm border border-border px-2.5 py-1 text-xs font-semibold text-ink-2 hover:border-border-strong hover:text-ink">
                        Resend
                      </button>
                    ) : (
                      <Dropdown trigger={<button className="rounded-sm p-1 text-muted hover:bg-surface-2"><MoreIcon /></button>}>
                        <DropdownItem onClick={() => openEdit(m)}>Edit Member</DropdownItem>
                        <DropdownItem danger onClick={() => removePartnerTeamMember(m.id)}>
                          Remove
                        </DropdownItem>
                      </Dropdown>
                    )}
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-sm text-muted">
                    No members found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      <InvitePartnerMemberSlideOver
        key={editing?.id ?? "new"}
        open={inviteOpen}
        onClose={() => setInviteOpen(false)}
        editing={editing}
      />
    </div>
  );
}
