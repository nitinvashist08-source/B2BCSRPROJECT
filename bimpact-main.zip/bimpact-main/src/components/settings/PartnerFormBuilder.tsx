"use client";

import { useState } from "react";
import { PartnerComplianceChecklist } from "@/types/partnerForm";
import { PartnerType } from "@/types/settings";
import { COMPLIANCE_CATEGORIES } from "@/data/complianceCatalog";

function BackIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}

// The Partner Compliance Form screen (Partners → Partner Compliance Form →
// Create/Edit Form): a predefined, categorized (A-I) checklist of compliance
// documents. This is a compliance requirement CONFIGURATION screen, not a
// form builder — the Sponsor's only action is to select/deselect which
// predefined documents are required from partners of this type. Category
// headings and document names/descriptions come straight from
// src/data/complianceCatalog.ts and are never editable here; nothing can be
// added, renamed, reordered, or removed.
// Selections live as local draft state and only reach settingsStore (and
// therefore localStorage) when the user explicitly saves — so navigating
// away without saving discards the draft, matching "Cancel" semantics
// without needing a separate confirm step.
export function PartnerFormBuilder({
  partnerType,
  existing,
  onBack,
  onSave,
}: {
  partnerType: PartnerType;
  existing: PartnerComplianceChecklist | null;
  onBack: () => void;
  onSave: (input: { name: string; selectedItemIds: string[]; status: "Draft" | "Active" }) => void;
}) {
  const [name, setName] = useState(existing?.name ?? `${partnerType} Compliance Checklist`);
  const [selected, setSelected] = useState<Set<string>>(new Set(existing?.selectedItemIds ?? []));

  function toggle(itemId: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(itemId)) next.delete(itemId);
      else next.add(itemId);
      return next;
    });
  }

  const totalSelected = selected.size;

  return (
    <div>
      <div className="mb-3 flex items-center justify-between gap-3">
        <button
          onClick={onBack}
          className="inline-flex h-7 items-center gap-[5px] rounded-sm border-[1.5px] border-border bg-surface px-2.5 text-xs font-semibold text-ink-2 hover:border-border-strong"
        >
          <BackIcon />
          Back to Partner Types
        </button>
        {existing && (
          <span
            className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-bold ${
              existing.status === "Active" ? "border-secondary-100 bg-secondary-50 text-secondary-600" : "border-amber-100 bg-amber-50 text-amber-600"
            }`}
          >
            {existing.status}
          </span>
        )}
      </div>

      <div className="mb-4">
        <div className="text-[1.1rem] font-extrabold tracking-[-0.02em] text-ink">Partner Compliance Form</div>
        <div className="mt-0.5 text-[13px] text-muted">
          Partner Type: <span className="font-semibold text-ink-2">{partnerType}</span>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-border bg-surface">
        <div className="flex flex-wrap items-center gap-2 border-b border-border bg-surface px-4 py-2.5">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="min-w-[160px] flex-1 border-0 border-b-2 border-transparent bg-transparent pb-0.5 text-[0.9rem] font-bold text-ink outline-none focus:border-primary"
          />
          <span className="text-xs text-muted">{totalSelected} document{totalSelected !== 1 ? "s" : ""} selected</span>
          <div className="ml-auto flex shrink-0 items-center gap-2">
            <button
              onClick={() => onSave({ name, selectedItemIds: Array.from(selected), status: "Draft" })}
              className="flex h-8 items-center rounded-sm border-[1.5px] border-border bg-surface px-3 text-[12.5px] font-semibold text-ink-2 hover:border-border-strong"
            >
              Save as Draft
            </button>
            <button
              onClick={() => onSave({ name, selectedItemIds: Array.from(selected), status: "Active" })}
              className="flex h-8 shrink-0 items-center gap-1.5 rounded-lg px-3.5 text-[12.5px] font-bold text-white shadow-[0_2px_8px_rgba(91,33,182,0.25)] transition-shadow hover:shadow-[0_4px_14px_rgba(91,33,182,0.4)]"
              style={{ background: "linear-gradient(135deg, #5b21b6, #1d4ed8)" }}
            >
              ✓ Activate &amp; Save
            </button>
          </div>
        </div>

        <div className="bg-[#f0f2f5] px-5 py-5">
          <p className="mx-auto mb-4 max-w-[760px] text-[13px] text-muted">
            Select the compliance documents you want partners of this type to submit. Applicability
            notes (e.g. &ldquo;If applicable&rdquo;, &ldquo;For events&rdquo;) are guidance only —
            selection stays fully under your control.
          </p>
          <div className="mx-auto flex max-w-[760px] flex-col gap-4">
            {COMPLIANCE_CATEGORIES.map((category) => (
              <div key={category.id} className="overflow-hidden rounded-xl border border-border bg-surface shadow-[0_1px_2px_rgba(0,0,0,0.05)]">
                <div className="border-b border-border bg-surface-2 px-4 py-2.5">
                  <div className="text-[13.5px] font-bold text-ink">{category.title}</div>
                </div>
                <div className="divide-y divide-border">
                  {category.items.map((item) => (
                    <label
                      key={item.id}
                      className="flex cursor-pointer items-start gap-3 px-4 py-3 hover:bg-bg"
                    >
                      <input
                        type="checkbox"
                        checked={selected.has(item.id)}
                        onChange={() => toggle(item.id)}
                        className="mt-0.5 h-4 w-4 shrink-0 accent-primary"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                          <span className="text-[13.5px] font-semibold text-ink">{item.name}</span>
                          {item.applicability && (
                            <span className="text-[11.5px] italic text-muted-2">{item.applicability}</span>
                          )}
                        </div>
                        {item.description && <p className="mt-0.5 text-[12.5px] text-muted">{item.description}</p>}
                        {item.guidance && <p className="mt-0.5 text-[11.5px] text-muted-2">{item.guidance}</p>}
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
