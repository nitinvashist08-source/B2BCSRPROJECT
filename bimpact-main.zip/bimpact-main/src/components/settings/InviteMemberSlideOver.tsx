"use client";

import { useState } from "react";
import { useSettingsStore } from "@/store/settingsStore";
import { TeamMember, TeamRole } from "@/types/settings";
import { SlideOver } from "@/components/ui/SlideOver";
import { Button } from "@/components/ui/Button";

const ROLES: { value: TeamRole; desc: string }[] = [
  { value: "Admin", desc: "Full access. Can edit, view, and delete everything across all projects and settings." },
  { value: "Manager", desc: "Standard access. Can edit, view, and delete items within assigned projects only." },
  { value: "Auditor", desc: "Read-only mode. Can view records and reports but cannot edit or delete any data." },
];

// so-add-user, bImpact_MeetingSplit_v10.html:8780-8841 ("Invite New
// Member") — the mockup's own Send Invitation button doesn't persist
// anything; made it real per the precedent already set for Partners and
// Activity. Also serves as "Edit Member" via the `editing` prop.
export function InviteMemberSlideOver({
  open,
  onClose,
  editing,
}: {
  open: boolean;
  onClose: () => void;
  editing?: TeamMember | null;
}) {
  const inviteMember = useSettingsStore((s) => s.inviteMember);
  const updateMember = useSettingsStore((s) => s.updateMember);
  const [name, setName] = useState(editing?.name ?? "");
  const [email, setEmail] = useState(editing?.email ?? "");
  const [role, setRole] = useState<TeamRole>(editing?.role ?? "Manager");
  const [errors, setErrors] = useState<Set<"name" | "email">>(new Set());

  function handleSave() {
    const bad = new Set<"name" | "email">();
    if (!name.trim()) bad.add("name");
    if (!email.trim()) bad.add("email");
    setErrors(bad);
    if (bad.size > 0) return;

    if (editing) updateMember(editing.id, { name: name.trim(), email: email.trim(), role });
    else inviteMember({ name: name.trim(), email: email.trim(), role });
    onClose();
  }

  return (
    <SlideOver
      open={open}
      onClose={onClose}
      title={editing ? "Edit Member" : "Invite New Member"}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>{editing ? "Save changes" : "Send Invitation"}</Button>
        </>
      }
    >
      <p className="mb-5 -mt-2 text-xs text-muted">
        {editing ? "Update this member's details and role" : "A secure setup link will be emailed to the user"}
      </p>

      <div className="mb-5 grid grid-cols-2 gap-3.5">
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-ink-2">Email Address</span>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="jane@company.com"
            className={`h-10 w-full rounded-sm border px-3 text-sm outline-none focus:border-primary ${
              errors.has("email") ? "border-danger" : "border-border"
            }`}
          />
        </label>
        <label className="block text-sm">
          <span className="mb-1.5 block font-medium text-ink-2">Full Name</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Jane Smith"
            className={`h-10 w-full rounded-sm border px-3 text-sm outline-none focus:border-primary ${
              errors.has("name") ? "border-danger" : "border-border"
            }`}
          />
        </label>
      </div>

      <span className="mb-2.5 block text-sm font-medium text-ink-2">Assign Role</span>
      <div className="flex flex-col gap-2.5">
        {ROLES.map((r) => (
          <label
            key={r.value}
            className={`flex cursor-pointer items-start gap-3 rounded-md border-[1.5px] p-3.5 transition-colors ${
              role === r.value ? "border-primary bg-primary-50 shadow-[0_0_0_1px_var(--color-primary)]" : "border-border hover:border-border-strong"
            }`}
          >
            <input
              type="radio"
              name="member_role"
              className="sr-only"
              checked={role === r.value}
              onChange={() => setRole(r.value)}
            />
            <span
              className={`mt-0.5 flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full border-[1.5px] ${
                role === r.value ? "border-primary" : "border-border"
              }`}
            >
              {role === r.value && <span className="h-2 w-2 rounded-full bg-primary" />}
            </span>
            <span>
              <span className={`block text-sm font-bold ${role === r.value ? "text-primary-700" : "text-ink"}`}>
                {r.value}
              </span>
              <span className={`mt-0.5 block text-[13px] leading-snug ${role === r.value ? "text-primary-600" : "text-muted"}`}>
                {r.desc}
              </span>
            </span>
          </label>
        ))}
      </div>
    </SlideOver>
  );
}
