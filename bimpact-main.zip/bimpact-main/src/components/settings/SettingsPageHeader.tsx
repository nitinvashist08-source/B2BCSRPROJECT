"use client";

import { usePathname } from "next/navigation";
import { PageHeaderBand } from "@/components/shell/PageHeaderBand";
import { useSessionStore } from "@/store/sessionStore";

// stSectionMeta, bImpact_MeetingSplit_v10.html:12007-12014 — the topbar
// title/subtitle per Settings section. Partners moved out to its own
// standalone module (src/app/partners/layout.tsx); Activity and Budget were
// removed entirely (superseded by Workplace's Create Project and Finance's
// High-Level Budgeting); CSR Committee moved to Management → CSR Committee;
// and CSR Policy — CSR Board's last remaining section — moved to
// Management → CSR Policy (src/app/meetings/policy/page.tsx), so CSR Board
// itself no longer exists as a Settings section. Users is what's left.
const SECTION_META: Record<string, { title: string; sub: string }> = {
  user: { title: "User Management", sub: "Administer team roles, control CSR access & manage permissions" },
};

// Partner sees different copy for the same "user" section — its own
// internal team, not Sponsor-style CSR access/permissions administration.
// Kept as its own map (rather than branching inline) so Sponsor's existing
// entry above stays untouched.
const PARTNER_SECTION_META: Record<string, { title: string; sub: string }> = {
  user: {
    title: "Team Members",
    sub: "Manage your internal team members and their access to assigned projects and data collection activities.",
  },
};

export function SettingsPageHeader() {
  const pathname = usePathname();
  const role = useSessionStore((s) => s.role);
  const section = pathname.split("/")[2] ?? "";
  const meta = (role === "partner" ? PARTNER_SECTION_META : SECTION_META)[section];
  if (!meta) return null;

  return <PageHeaderBand title={meta.title} sub={meta.sub} />;
}
