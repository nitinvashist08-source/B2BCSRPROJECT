"use client";

import { DropdownItem } from "@/components/ui/Dropdown";
import { PartnerOrg } from "@/types/settings";
import { getPartnerStatusActions } from "@/lib/partnerStatusActions";

// PartnerOrgsTable's row "⋮" menu items for the status-management actions —
// see getPartnerStatusActions (src/lib/partnerStatusActions.ts) for the
// actual status → actions matrix, also used by the Partner Details header's
// PartnerStatusActionButtons.
export function PartnerStatusMenuItems({
  partner,
  onEdit,
  onReinvite,
  onCancelInvitation,
  onDeactivate,
  onActivate,
}: {
  partner: PartnerOrg;
  onEdit: (p: PartnerOrg) => void;
  onReinvite: (p: PartnerOrg) => void;
  onCancelInvitation: (p: PartnerOrg) => void;
  onDeactivate: (p: PartnerOrg) => void;
  onActivate: (p: PartnerOrg) => void;
}) {
  const actions = getPartnerStatusActions(partner, { onEdit, onReinvite, onCancelInvitation, onDeactivate, onActivate });
  return (
    <>
      {actions.map((a) => (
        <DropdownItem key={a.key} danger={a.variant === "danger"} onClick={a.onClick}>
          {a.label}
        </DropdownItem>
      ))}
    </>
  );
}
