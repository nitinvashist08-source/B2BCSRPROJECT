"use client";

import { useState } from "react";
import Link from "next/link";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { Button } from "@/components/ui/Button";
import { Field, inputCls } from "@/components/marketing/AuthCard";
import { PartnerOrg, PartnerType } from "@/types/settings";
import { getLastPartnerInvite } from "@/lib/lastPartnerInvite";
import { ONBOARDING_STEPS, StepProgress, EyeIcon } from "./onboardingSteps";

// Same fixed option set/order as InvitePartnerSlideOver.tsx's own local
// PARTNER_TYPES constant.
const PARTNER_TYPES: PartnerType[] = ["Implementer", "Co-Implementer", "Co-Sponsor"];

type IdentityErrors = { name?: string; contactName?: string; contactEmail?: string; type?: string };

function LockIcon() {
  return (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
      <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  );
}

// How this wizard was reached — the ONLY thing that varies between an
// invited Partner and a self-serve one. Everything else (steps, fields,
// validation, data structure, completion flow, review screen) is the exact
// same component/JSX below; there is deliberately no
// SelfServingPartnerOnboarding.tsx / InvitedPartnerOnboarding.tsx split.
//  - "invited": a real Sponsor invite already exists (see
//    src/lib/partnerInvite.ts's validateInviteToken) — org/contact/type
//    prefill from it, and the email becomes a fixed, read-only login
//    username (never editable here).
//  - "self_served": reached via Landing → Get Started → the simulated
//    invite screen (src/app/partner-onboarding/invite) with no Sponsor
//    involved at all — every identity field is editable (there's nothing
//    to lock any of them to), seeded from src/lib/lastPartnerInvite.ts's
//    demo-convenience cache of the Sponsor's most recent invite if this
//    browser has one (explicit product decision — see that file's header
//    comment for why this is fine here but not the same thing as the real
//    invite-token flow's per-partner data).
export type PartnerOnboardingEntry = { type: "invited"; partner: PartnerOrg } | { type: "self_served" };

// The single canonical Partner Onboarding wizard — see PartnerOnboardingEntry
// above for the only axis of variation. page.tsx decides which `entry` to
// construct (a validated invite token vs. no token at all) and both land
// here. Three guided steps either way: review/refine organization details,
// set a password, then review everything before the account is created/
// activated. (Operating location used to be a fourth step here — removed
// per explicit product request; state/districts are still part of
// PartnerOrg and the store's activatePartner/registerPartner signatures,
// just always submitted empty from this wizard now instead of collected.)
export function PartnerOnboardingForm({ entry }: { entry: PartnerOnboardingEntry }) {
  const partners = useSettingsStore((s) => s.partners);
  const activatePartner = useSettingsStore((s) => s.activatePartner);
  const updatePartner = useSettingsStore((s) => s.updatePartner);
  const registerPartner = useSettingsStore((s) => s.registerPartner);
  const loginAsPartner = useSessionStore((s) => s.loginAsPartner);

  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  // Lazy initializer: read once at mount, not on every render — this is a
  // one-shot seed for the form's starting values, not a live-bound value.
  const [lastInvite] = useState(() => (entry.type === "self_served" ? getLastPartnerInvite() : null));

  const [orgName, setOrgName] = useState(entry.type === "invited" ? entry.partner.name : lastInvite?.name ?? "");
  const [contactName, setContactName] = useState(
    entry.type === "invited" ? entry.partner.contactName : lastInvite?.contactName ?? ""
  );
  // For "invited", nothing ever changes this — it just mirrors the fixed
  // invitation email so step 3's review and the header badge can read the
  // same `contactEmail` variable either way, instead of branching on
  // entry.type at every use site. For "self_served" it's just a starting
  // value — fully editable, and re-typing it to something else is exactly
  // how a tester would avoid the "already registered" duplicate-email
  // check against the very invite this was seeded from.
  const [contactEmail, setContactEmail] = useState(
    entry.type === "invited" ? entry.partner.contactEmail : lastInvite?.contactEmail ?? ""
  );
  const [partnerType, setPartnerType] = useState<PartnerType | "">(
    entry.type === "invited" ? entry.partner.type : lastInvite?.type ?? ""
  );
  const [identityErrors, setIdentityErrors] = useState<IdentityErrors>({});

  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | undefined>();

  // Only ever set on the self-served path (someone else registered the
  // typed email between step 0's check and final submit) — the store is
  // the real source of truth, so this sends them back to fix it rather
  // than silently failing.
  const [submitError, setSubmitError] = useState<string | undefined>();

  function goNext() {
    if (step === 0) {
      const errs: IdentityErrors = {};
      if (!orgName.trim()) errs.name = "Organization name is required.";
      if (!contactName.trim()) errs.contactName = "Contact person is required.";
      // Email/Partner Type only need validating when the partner is
      // actually the one setting them — an invited partner's email is
      // fixed and their type already came from a real invitation.
      if (entry.type === "self_served") {
        if (!contactEmail.trim()) errs.contactEmail = "Contact email is required.";
        else {
          const matched = partners.find((p) => p.contactEmail.toLowerCase() === contactEmail.trim().toLowerCase());
          // A still-pending Sponsor invite (never submitted) isn't a real
          // duplicate — it's exactly registerPartner's "complete this
          // invite via self-serve" case below, so let it through here too.
          // Only block on a partner who has already submitted (reviewStatus
          // set) or is Active/Inactive.
          const isPendingInvite = !!matched && matched.status === "Invited" && !matched.reviewStatus;
          if (matched && !isPendingInvite) errs.contactEmail = "This email is already registered.";
        }
        if (!partnerType) errs.type = "Select a partner type.";
      }
      if (Object.keys(errs).length > 0) {
        setIdentityErrors(errs);
        return;
      }
      setIdentityErrors({});
    }
    if (step === 1) {
      if (!password) {
        setPasswordError("Password is required.");
        return;
      }
      setPasswordError(undefined);
    }
    setStep((s) => Math.min(s + 1, ONBOARDING_STEPS.length - 1));
  }
  function goBack() {
    setStep((s) => Math.max(s - 1, 0));
  }

  function handleComplete() {
    const trimmedOrgName = orgName.trim();
    const trimmedContactName = contactName.trim();

    if (entry.type === "invited") {
      const { partner } = entry;
      activatePartner(partner.id, {
        name: trimmedOrgName,
        contactName: trimmedContactName,
        // Location step was removed from this wizard (product decision) —
        // activatePartner's signature still takes these, so submit empty
        // rather than widening/narrowing the store contract for this.
        state: "",
        districts: [],
        complianceDocuments: [],
      });
      // activatePartner's own input type doesn't carry `type` (shared with
      // the self-served path below, which sets it via registerPartner
      // instead) — patch it in with the generic updater rather than
      // widening that shared signature just for this one field.
      updatePartner(partner.id, { type: partnerType as PartnerType });
      // `partner` (from entry) predates the writes above — pass the
      // edited name/contactName/type through directly so the session
      // reflects what was just saved instead of the invitation's
      // original values.
      loginAsPartner({ ...partner, name: trimmedOrgName, contactName: trimmedContactName, type: partnerType as PartnerType });
      setSubmitted(true);
      return;
    }

    // self_served — no existing PartnerOrg to update, so this is where one
    // gets created for the first time. Same underlying PartnerOrg shape,
    // same "Invited" status + Pending Review workflow as the invited path
    // ends up in via activatePartner (see registerPartner's own comment) —
    // one Partner data model either way, not a second one.
    const result = registerPartner({
      name: trimmedOrgName,
      contactName: trimmedContactName,
      contactEmail: contactEmail.trim(),
      state: "",
      districts: [],
      type: partnerType as PartnerType,
      complianceDocuments: [],
    });
    if (!result.ok) {
      setSubmitError("This email is already registered.");
      setStep(0);
      return;
    }
    loginAsPartner(result.partner);
    setSubmitted(true);
  }

  function goToWorkspace() {
    // Hard navigation, not router.push — router.push/replace proved
    // unreliable for auth-flow-stage transitions in this Next 16/Turbopack/
    // React 19 app; every existing auth transition uses window.location.href
    // instead, and loginAsPartner()/activatePartner()/registerPartner()
    // persist synchronously so this is safe to fire on click.
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination
    window.location.href = "/projects";
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-bg px-4 py-10">
      <Link href="/" className="flex items-center gap-2.5">
        <span
          className="flex h-9 w-9 items-center justify-center rounded-[9px] text-[14px] font-extrabold tracking-tight text-white"
          style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
        >
          bI
        </span>
        <span className="text-[15px] font-semibold tracking-tight text-ink">bImpact</span>
      </Link>

      {!submitted && <StepProgress step={step} />}

      <div className="w-full rounded-xl border border-border bg-surface p-7 shadow-sm" style={{ maxWidth: "560px" }}>
        {submitted ? (
          <div className="flex flex-col items-center gap-3 py-6 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary-50 text-2xl text-secondary-600">
              ✓
            </span>
            <h2 className="text-lg font-bold text-ink">Onboarding Submitted Successfully</h2>
            <p className="max-w-sm text-[13px] text-muted">
              Thank you for completing your partner onboarding. Your organization details have
              been submitted successfully.
            </p>
            <p className="max-w-sm text-[13px] text-ink-2">
              Your submission is now under review. Your Sponsor will notify you once your
              organization has been approved.
            </p>
            <Button variant="primary" size="md" className="mt-3 w-full" onClick={goToWorkspace}>
              Go to Workplace
            </Button>
          </div>
        ) : (
          <>
            {step === 0 && (
              <div>
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-ink">Welcome to Partner Onboarding</h2>
                  {/* Deliberately role-neutral and identical for both entry types — this
                      screen is treated as invitation-based either way (Sponsor→Partner,
                      Sponsor→Co-Sponsor, Co-Sponsor→Partner, or the self-serve "Get
                      Started" entry seeded from the last invite this browser sent/saw —
                      see selfServedEmailEditable below for the one case with nothing to
                      lock the email to). */}
                  <p className="mx-auto mt-3 text-[14px] text-muted">
                    You&apos;ve been invited to join bImpact. Please review the details provided for your
                    organization and continue to complete your onboarding.
                  </p>
                </div>

                {/* Invitation/account email — contextual info the user was invited with, not
                    just another form field, so it sits in its own box in the vertical flow
                    rather than mixed in with the Organization Name/Contact/Type stack below.
                    Always read-only for "invited" (fixed to the real invite). For
                    "self_served" it's read-only too whenever this browser has a cached
                    invite to lock it to (getLastPartnerInvite/lastInvite — the common
                    case); only a completely fresh browser with nothing cached falls back
                    to a real editable input, since self-serve registration has no other
                    way to collect the email registerPartner needs. */}
                {(() => {
                  const selfServedEmailEditable = entry.type === "self_served" && !lastInvite?.contactEmail;
                  return (
                    <>
                      <div className="mt-7 w-full rounded-lg border border-border bg-surface-2 px-4 py-3">
                        <label className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-muted-2">
                          Organization Email
                          {!selfServedEmailEditable && <LockIcon />}
                        </label>
                        {selfServedEmailEditable ? (
                          <input
                            required
                            type="email"
                            placeholder="you@organization.org"
                            value={contactEmail}
                            onChange={(e) => setContactEmail(e.target.value)}
                            className="mt-1 w-full bg-transparent text-[15px] font-semibold text-ink outline-none placeholder:font-normal placeholder:text-muted-2"
                          />
                        ) : (
                          <p
                            className="mt-1 text-[15px] font-semibold text-ink"
                            title="Invited email — used as your login username, cannot be changed"
                          >
                            {contactEmail}
                          </p>
                        )}
                      </div>

                      {identityErrors.contactEmail ? (
                        <p className="mt-2 text-xs text-danger">
                          {identityErrors.contactEmail}{" "}
                          {identityErrors.contactEmail.includes("already registered") && (
                            <Link href="/login" className="font-semibold underline">
                              Log in instead
                            </Link>
                          )}
                        </p>
                      ) : selfServedEmailEditable ? (
                        <p className="mt-2 text-xs text-muted">
                          This email will be used as your username to access your partner account.
                        </p>
                      ) : (
                        <p className="mt-2 text-xs text-muted">
                          This email is linked to your invitation and will be used to access your bImpact account.
                        </p>
                      )}
                    </>
                  );
                })()}

                <div className="mt-7">
                  <Field label="Organization Name">
                    <input
                      required
                      className={inputCls}
                      value={orgName}
                      onChange={(e) => setOrgName(e.target.value)}
                    />
                    {identityErrors.name && <p className="mt-1.5 text-xs text-danger">{identityErrors.name}</p>}
                  </Field>

                  <Field label="Primary Contact Person">
                    <input
                      required
                      className={inputCls}
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                    />
                    {identityErrors.contactName && (
                      <p className="mt-1.5 text-xs text-danger">{identityErrors.contactName}</p>
                    )}
                  </Field>

                  <Field label="Partner Type">
                    <select
                      required
                      className={inputCls}
                      value={partnerType}
                      onChange={(e) => setPartnerType(e.target.value as PartnerType)}
                    >
                      <option value="">Select partner type…</option>
                      {PARTNER_TYPES.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                    {identityErrors.type ? (
                      <p className="mt-1.5 text-xs text-danger">{identityErrors.type}</p>
                    ) : (
                      <p className="mt-1.5 text-xs text-muted">
                        Your onboarding requirements may vary based on your partner type.
                      </p>
                    )}
                  </Field>
                </div>

                {submitError && <p className="mb-3 text-xs text-danger">{submitError}</p>}

                <Button variant="primary" size="md" className="mt-6 w-full" onClick={goNext}>
                  Continue
                </Button>
              </div>
            )}

            {step === 1 && (
              <div>
                <h2 className="text-lg font-bold text-ink">Secure Your Account</h2>
                <p className="mt-1 text-[13px] text-muted">
                  Create a secure password to activate access to your partner workspace.
                </p>

                <div className="mt-5">
                  <Field label="Create Password">
                    <div className="relative">
                      <input
                        required
                        type={showPassword ? "text" : "password"}
                        className={`${inputCls} pr-10`}
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword((v) => !v)}
                        aria-label={showPassword ? "Hide password" : "Show password"}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-ink-2"
                      >
                        <EyeIcon open={showPassword} />
                      </button>
                    </div>
                    {passwordError && <p className="mt-1.5 text-xs text-danger">{passwordError}</p>}
                    <p className="mt-1.5 text-xs text-muted">
                      Use a strong password with a combination of letters, numbers, and special
                      characters.
                    </p>
                  </Field>
                </div>

                <div className="mt-2 flex gap-2.5">
                  <Button variant="ghost" size="md" className="w-full" onClick={goBack}>
                    Back
                  </Button>
                  <Button variant="primary" size="md" className="w-full" onClick={goNext}>
                    Continue
                  </Button>
                </div>
              </div>
            )}

            {step === 2 && (
              <div>
                <h2 className="text-lg font-bold text-ink">Review & Complete Onboarding</h2>
                <p className="mt-1 text-[13px] text-muted">
                  Confirm everything looks right before activating your partner account.
                </p>

                <dl className="mt-5 flex flex-col gap-3 rounded-lg border border-border bg-surface-2 p-4 text-[13px]">
                  <div className="flex justify-between gap-3">
                    <dt className="text-muted">Organization Name</dt>
                    <dd className="text-right font-semibold text-ink">{orgName}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="text-muted">Primary Contact</dt>
                    <dd className="text-right font-semibold text-ink">{contactName}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="text-muted">Organization Email</dt>
                    <dd className="text-right font-semibold text-ink">{contactEmail}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="text-muted">Partner Type</dt>
                    <dd className="text-right font-semibold text-ink">{partnerType}</dd>
                  </div>
                </dl>

                <div className="mt-5 flex gap-2.5">
                  <Button variant="ghost" size="md" className="w-full" onClick={goBack}>
                    Back
                  </Button>
                  <Button variant="primary" size="md" className="w-full" onClick={handleComplete}>
                    Complete Partner Onboarding
                  </Button>
                </div>

                <p className="mt-4 text-center text-xs text-muted">
                  By continuing, you accept the{" "}
                  <Link href="/terms" className="font-semibold text-primary hover:underline">
                    Terms of Service
                  </Link>{" "}
                  and{" "}
                  <Link href="/privacy" className="font-semibold text-primary hover:underline">
                    Privacy Policy
                  </Link>
                  .
                </p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
