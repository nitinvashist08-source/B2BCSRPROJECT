"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useSettingsStore } from "@/store/settingsStore";
import { PartnerOrg } from "@/types/settings";

function CheckIcon({ size = 18 }: { size?: number }) {
  return (
    <svg fill="none" height={size} width={size} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

// Confirmation → success two-step flow. `step` resets to "confirm" whenever
// the dialog is reopened for a (possibly different) partner, via `onClose`
// clearing it below rather than key-remounting from the parent.
export function ApprovePartnerDialog({
  partner,
  open,
  onClose,
}: {
  partner: PartnerOrg;
  open: boolean;
  onClose: () => void;
}) {
  const approvePartnerReview = useSettingsStore((s) => s.approvePartnerReview);
  const [step, setStep] = useState<"confirm" | "success">("confirm");

  function handleClose() {
    onClose();
    // Deferred so the dialog doesn't visibly flip back to the confirm step
    // during its own close transition.
    setTimeout(() => setStep("confirm"), 200);
  }

  function handleApprove() {
    approvePartnerReview(partner.id);
    setStep("success");
  }

  if (step === "success") {
    return (
      <Modal
        open={open}
        onClose={handleClose}
        title="Partner Approved Successfully"
        icon={
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-secondary-50 text-secondary">
            <CheckIcon />
          </div>
        }
        footer={<Button onClick={handleClose}>Done</Button>}
      >
        The partner is now active and can be assigned to projects.
      </Modal>
    );
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="Approve Partner?"
      footer={
        <>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleApprove}>Approve Partner</Button>
        </>
      }
    >
      Are you sure you want to approve this partner? Once approved, the partner will become active
      and available for project assignment.
    </Modal>
  );
}
