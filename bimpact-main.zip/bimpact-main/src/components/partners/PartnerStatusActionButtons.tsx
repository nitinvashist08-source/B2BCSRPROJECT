"use client";

import { Button } from "@/components/ui/Button";
import { PartnerOrg } from "@/types/settings";
import { getPartnerStatusActions } from "@/lib/partnerStatusActions";

// Partner Details header's persistently-visible status-action CTAs — same
// status → actions matrix as PartnerOrgsTable's row "⋮" menu
// (PartnerStatusMenuItems), just rendered as buttons directly in the header
// instead of tucked behind a menu, per the "make the available action(s)
// immediately discoverable" requirement. Renders nothing when the current
// status has no status-management action (Pending Review/Changes
// Requested — the Approve/Request Changes/Reject CTA row owns that instead).
export function PartnerStatusActionButtons({
  partner,
  onEdit,
  onReinvite,
  onCancelInvitation,
  onDeactivate,
  onActivate,
}: {
  partner: PartnerOrg;
  onEdit: (p: PartnerOrg) => void;
  onReinvite: (p: PartnerOrg) => void;
  onCancelInvitation: (p: PartnerOrg) => void;
  onDeactivate: (p: PartnerOrg) => void;
  onActivate: (p: PartnerOrg) => void;
}) {
  const actions = getPartnerStatusActions(partner, { onEdit, onReinvite, onCancelInvitation, onDeactivate, onActivate });
  if (actions.length === 0) return null;
  return (
    <div className="flex shrink-0 flex-wrap items-center gap-2">
      {actions.map((a) => (
        <Button key={a.key} size="sm" variant={a.variant} onClick={a.onClick}>
          {a.label}
        </Button>
      ))}
    </div>
  );
}
