"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useSettingsStore } from "@/store/settingsStore";
import { PartnerOrg } from "@/types/settings";

function CheckIcon({ size = 18 }: { size?: number }) {
  return (
    <svg fill="none" height={size} width={size} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

// Confirmation → success two-step flow, same shape as ApprovePartnerDialog/
// ReinvitePartnerDialog, plus a mandatory reason field (deactivatePartner in
// settingsStore re-validates it — this form's own check is a fast-path, not
// the enforcement). `partner` is nullable (the row's target, not a captured
// snapshot); reason/error/step reset on every close (Cancel, backdrop click,
// or "Done" after success) rather than on open, so the next open — for this
// row or a different one — always starts from a clean slate.
export function DeactivatePartnerDialog({
  partner,
  open,
  onClose,
}: {
  partner: PartnerOrg | null;
  open: boolean;
  onClose: () => void;
}) {
  const deactivatePartner = useSettingsStore((s) => s.deactivatePartner);
  const [step, setStep] = useState<"confirm" | "success">("confirm");
  const [reason, setReason] = useState("");
  const [error, setError] = useState(false);

  function handleClose() {
    onClose();
    // Deferred so the dialog doesn't visibly flip back to the confirm/blank
    // step during its own close transition.
    setTimeout(() => {
      setStep("confirm");
      setReason("");
      setError(false);
    }, 200);
  }

  if (!partner) return null;

  function handleDeactivate() {
    if (!reason.trim()) {
      setError(true);
      return;
    }
    const result = deactivatePartner(partner!.id, reason);
    if (!result.ok) {
      setError(true);
      return;
    }
    setStep("success");
  }

  if (step === "success") {
    return (
      <Modal
        open={open}
        onClose={handleClose}
        title="Partner Deactivated"
        icon={
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-secondary-50 text-secondary">
            <CheckIcon />
          </div>
        }
        footer={<Button onClick={handleClose}>Done</Button>}
      >
        <strong>{partner.name}</strong> has been deactivated and is no longer available for project assignment.
      </Modal>
    );
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="Deactivate Partner?"
      footer={
        <>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeactivate}>
            Deactivate Partner
          </Button>
        </>
      }
    >
      <p>
        Are you sure you want to deactivate <strong>{partner.name}</strong>? Please provide a reason for
        deactivating this Partner.
      </p>
      <label className="mt-3 block text-sm">
        <span className="mb-1 block font-medium text-ink-2">Reason for Deactivation</span>
        <textarea
          value={reason}
          onChange={(e) => {
            setReason(e.target.value);
            if (error) setError(false);
          }}
          placeholder="Enter the reason for deactivating this partner"
          rows={3}
          className={`w-full rounded-sm border px-3 py-2 text-sm outline-none focus:border-primary ${
            error ? "border-danger" : "border-border"
          }`}
        />
        {error && (
          <p className="mt-1.5 text-xs text-danger">Please provide a reason for deactivating the partner.</p>
        )}
      </label>
    </Modal>
  );
}
