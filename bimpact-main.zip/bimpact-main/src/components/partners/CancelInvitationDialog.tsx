"use client";

import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useSettingsStore } from "@/store/settingsStore";
import { PartnerOrg } from "@/types/settings";

// Single-step destructive confirm (no success screen) — same shape as
// RemoveMemberModal: cancelling an invite removes the still-pending Partner
// row, same behavior the old ungated removePartner call had, now sitting
// behind this confirmation and settingsStore's own re-checked
// cancelPartnerInvitation (status must still be Invited/never-submitted).
export function CancelInvitationDialog({
  partner,
  open,
  onClose,
  onCancelled,
}: {
  partner: PartnerOrg | null;
  open: boolean;
  onClose: () => void;
  // Called (in addition to onClose) right after a successful cancel — lets
  // PartnerSubmissionReview navigate back to the listing, since the partner
  // it was showing no longer exists; PartnerOrgsTable's row menu has no use
  // for it and simply omits it.
  onCancelled?: () => void;
}) {
  const cancelPartnerInvitation = useSettingsStore((s) => s.cancelPartnerInvitation);

  if (!partner) return null;

  function handleConfirm() {
    cancelPartnerInvitation(partner!.id);
    onClose();
    onCancelled?.();
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Cancel Invitation?"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleConfirm}>
            Cancel Invitation
          </Button>
        </>
      }
    >
      Are you sure you want to cancel the invitation for <strong>{partner.name}</strong>?
    </Modal>
  );
}
