"use client";

// Shared building blocks for PartnerOnboardingForm.tsx — the one canonical
// Partner Onboarding wizard used by both the Sponsor-invite entry and the
// self-served entry (see that file's PartnerOnboardingEntry type). Kept in
// its own file mostly for step-progress bookkeeping shared with the wizard
// as a whole, not because there's a second wizard to keep in sync with.

export const ONBOARDING_STEPS = ["Welcome", "Password", "Review"] as const;

export function StepProgress({ step }: { step: number }) {
  return (
    <ol className="flex items-center" aria-label="Partner onboarding progress">
      {ONBOARDING_STEPS.map((label, i) => {
        const done = i < step;
        const current = i === step;
        return (
          <li key={label} className="flex items-center">
            <span className="flex items-center gap-1.5">
              <span
                aria-hidden
                className={
                  done
                    ? "h-2 w-2 rounded-full bg-primary"
                    : current
                      ? "h-2 w-2 rounded-full border-[1.5px] border-primary bg-surface"
                      : "h-2 w-2 rounded-full bg-border-strong"
                }
              />
              <span className={`text-[11px] font-medium ${current ? "text-ink" : "text-muted"}`}>{label}</span>
            </span>
            {i < ONBOARDING_STEPS.length - 1 && <span aria-hidden className="mx-2 h-px w-5 bg-border" />}
          </li>
        );
      })}
    </ol>
  );
}

export function EyeIcon({ open }: { open: boolean }) {
  return open ? (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  ) : (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a19.9 19.9 0 0 1 4.22-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a19.86 19.86 0 0 1-2.16 3.19" />
      <path d="M14.12 14.12a3 3 0 1 1-4.24-4.24" />
      <path d="M1 1l22 22" />
    </svg>
  );
}
