"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useSettingsStore } from "@/store/settingsStore";
import { PartnerOrg } from "@/types/settings";

export function RequestChangesModal({
  partner,
  open,
  onClose,
}: {
  partner: PartnerOrg;
  open: boolean;
  onClose: () => void;
}) {
  const requestPartnerChanges = useSettingsStore((s) => s.requestPartnerChanges);
  const [message, setMessage] = useState("");
  const [showError, setShowError] = useState(false);

  function handleClose() {
    setMessage("");
    setShowError(false);
    onClose();
  }

  function handleSubmit() {
    const trimmed = message.trim();
    if (!trimmed) {
      setShowError(true);
      return;
    }
    requestPartnerChanges(partner.id, trimmed);
    handleClose();
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="Request Additional Information"
      footer={
        <>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!message.trim()}>
            Send Request
          </Button>
        </>
      }
    >
      <p className="mb-3">
        Let the partner know what information or documents need to be completed or updated.
      </p>
      <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.06em] text-muted">
        Message to Partner <span className="text-danger">*</span>
      </label>
      <textarea
        value={message}
        onChange={(e) => {
          setMessage(e.target.value);
          if (showError) setShowError(false);
        }}
        rows={4}
        placeholder="Please upload the pending CSR Form 1 and provide the latest 80G certificate."
        className={`w-full resize-none rounded-sm border px-3 py-2 text-sm text-ink outline-none focus:border-primary ${
          showError ? "border-danger" : "border-border"
        }`}
      />
      {showError && (
        <div className="mt-1.5 text-[12px] text-danger">Please enter a message for the partner.</div>
      )}
    </Modal>
  );
}
