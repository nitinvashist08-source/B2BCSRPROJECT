"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useSettingsStore } from "@/store/settingsStore";
import { PartnerOrg } from "@/types/settings";

function CheckIcon({ size = 18 }: { size?: number }) {
  return (
    <svg fill="none" height={size} width={size} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

// Confirmation → success two-step flow, same shape as ApprovePartnerDialog.
// `partner` is nullable (RemoveMemberModal-style — the row's target, not a
// captured snapshot) but the caller keeps it set through the success step
// (only clearing it on the dialog's own onClose), so the success message
// still has a name to show. Resending never re-collects name/contact/type —
// reinvitePartner (settingsStore) only refreshes the invite token/timestamp
// on the existing record, so nothing already onboarded/uploaded is touched.
export function ReinvitePartnerDialog({
  partner,
  open,
  onClose,
}: {
  partner: PartnerOrg | null;
  open: boolean;
  onClose: () => void;
}) {
  const reinvitePartner = useSettingsStore((s) => s.reinvitePartner);
  const [step, setStep] = useState<"confirm" | "success">("confirm");

  function handleClose() {
    onClose();
    // Deferred so the dialog doesn't visibly flip back to the confirm step
    // during its own close transition.
    setTimeout(() => setStep("confirm"), 200);
  }

  if (!partner) return null;

  function handleReinvite() {
    reinvitePartner(partner!.id);
    setStep("success");
  }

  if (step === "success") {
    return (
      <Modal
        open={open}
        onClose={handleClose}
        title="Invitation Sent Successfully"
        icon={
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-secondary-50 text-secondary">
            <CheckIcon />
          </div>
        }
        footer={<Button onClick={handleClose}>Done</Button>}
      >
        A new invitation has been sent to <strong>{partner.name}</strong> to complete onboarding and submit the
        required compliance documents.
      </Modal>
    );
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="Re-invite Partner?"
      footer={
        <>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleReinvite}>Re-invite</Button>
        </>
      }
    >
      Are you sure you want to re-invite <strong>{partner.name}</strong> to complete their onboarding and submit
      the required compliance documents?
    </Modal>
  );
}
