import { PartnerOrg } from "@/types/settings";
import { PartnerSubmissionCategory } from "@/lib/partnerSubmissionView";
import { DetailField, SectionCard, SectionStatusPill } from "./shared";

// Registered Office Address — a separate, complete postal address the
// partner enters on the Compliance page (distinct from Operating Location's
// state/districts above, which describe where the partner operates, not
// where it's registered). Existing partners who only ever had state/
// districts stored show as Pending here until they add this.
export function RegisteredOfficeAddressSection({
  partner,
  category,
}: {
  partner: PartnerOrg;
  category: PartnerSubmissionCategory;
}) {
  const address = partner.registeredOfficeAddress;
  const isPending = category === "invited-pending" || !address;

  if (isPending) {
    return (
      <SectionCard title="Registered Office Address" status={<SectionStatusPill tone="pending">Pending</SectionStatusPill>}>
        <p className="text-sm text-ink-2">The partner has not yet provided their registered office address.</p>
      </SectionCard>
    );
  }

  return (
    <SectionCard
      title="Registered Office Address"
      status={<SectionStatusPill tone="completed">Completed</SectionStatusPill>}
    >
      <div className="grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
        <div className="col-span-2 sm:col-span-4">
          <DetailField
            label="Address"
            value={
              <>
                {address.addressLine1}
                {address.addressLine2 ? `, ${address.addressLine2}` : ""}
              </>
            }
          />
        </div>
        <DetailField label="City / Town" value={address.city} />
        <DetailField label="State" value={address.state} />
        <DetailField label="District" value={address.district} />
        <DetailField label="PIN Code" value={address.pinCode} />
      </div>
    </SectionCard>
  );
}
