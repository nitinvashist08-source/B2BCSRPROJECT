"use client";

import { useSettingsStore } from "@/store/settingsStore";
import { PartnerOrg } from "@/types/settings";
import { SectionCard, formatDateTime } from "./shared";

const ACTIVITY_LABEL = {
  partner_approved: "Partner Approved",
  partner_rejected: "Partner Rejected",
} as const;

// Permanent "Approval History" log for this Partner — reads settingsStore's
// append-only partnerHistory (never derived from PartnerOrg's current
// status/reviewStatus fields, which only ever hold the LATEST value — see
// PartnerHistoryEntry's header comment), but filtered to ONLY
// partner_approved/partner_rejected. The same partnerHistory array also
// holds change_request/partner_activated/partner_deactivated/
// partner_reactivated/document_* entries — those are real, permanent,
// unaffected by this filter, just not this section's concern; per spec,
// Approval History must show Partner-level approve/reject decisions only,
// never document review or any other Partner activity. Newest first.
// Purely additive to Partner Details: doesn't touch any existing section,
// and has no interactive elements of its own — every entry here was
// already written at the moment its action happened (approvePartnerReview/
// rejectPartnerReview), so this component only ever reads.
export function PartnerHistorySection({ partner }: { partner: PartnerOrg }) {
  const partnerHistory = useSettingsStore((s) => s.partnerHistory);
  const entries = partnerHistory
    .filter(
      (h) =>
        h.partnerId === partner.id &&
        (h.activityType === "partner_approved" || h.activityType === "partner_rejected")
    )
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <SectionCard title="Approval History">
      {entries.length === 0 ? (
        <p className="text-sm text-muted">No approval or rejection actions have been recorded for this partner yet.</p>
      ) : (
        <div className="overflow-hidden rounded-lg border border-border">
          <table className="w-full border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-border bg-surface-2 text-xs text-muted">
                <th className="w-[16%] px-4 py-2.5 font-medium">Activity</th>
                <th className="w-[34%] px-4 py-2.5 font-medium">Reason</th>
                <th className="w-[20%] px-4 py-2.5 font-medium">Status Change</th>
                <th className="w-[16%] px-4 py-2.5 font-medium">Date &amp; Time</th>
                <th className="w-[14%] px-4 py-2.5 font-medium">Action By</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((entry) => (
                <tr key={entry.id} className="border-b border-border last:border-b-0 align-top">
                  <td className="px-4 py-3 font-semibold text-ink">
                    {ACTIVITY_LABEL[entry.activityType as keyof typeof ACTIVITY_LABEL]}
                  </td>
                  {/* Full rejection reason, never truncated — long reasons
                      must stay fully readable here, per spec. Approval has
                      none, so this reads "—". */}
                  <td className="whitespace-pre-wrap break-words px-4 py-3 text-ink-2">{entry.reason || "—"}</td>
                  <td className="px-4 py-3 text-ink-2">
                    {entry.previousStatus} → {entry.newStatus}
                  </td>
                  <td className="px-4 py-3 text-ink-2">{formatDateTime(entry.createdAt)}</td>
                  <td className="px-4 py-3 text-ink-2">{entry.performedBy.name || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </SectionCard>
  );
}
