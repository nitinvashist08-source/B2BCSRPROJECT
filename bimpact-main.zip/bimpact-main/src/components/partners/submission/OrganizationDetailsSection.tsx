import { PartnerOrg } from "@/types/settings";
import { PartnerSubmissionCategory } from "@/lib/partnerSubmissionView";
import { DetailField, SectionCard, SectionStatusPill } from "./shared";

// Organization Details — the four fields captured at invite time
// (name/contactName/contactEmail/type) exist for every partner regardless
// of category, so they're always shown as real values. The status pill is
// what honestly distinguishes "this is only what the invite captured, the
// partner hasn't submitted a full onboarding yet" (invited-pending) from a
// genuinely completed record (active-demo/submitted) — never blank/fabricate
// the fields themselves to signal that difference.
export function OrganizationDetailsSection({
  partner,
  category,
}: {
  partner: PartnerOrg;
  category: PartnerSubmissionCategory;
}) {
  const status =
    category === "invited-pending" ? (
      <SectionStatusPill tone="info">Available from invitation</SectionStatusPill>
    ) : (
      <SectionStatusPill tone="completed">Completed</SectionStatusPill>
    );

  return (
    <SectionCard title="Organization Details" status={status}>
      <div className="grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
        <DetailField label="Organization Name" value={partner.name} />
        <DetailField label="Primary Contact Person" value={partner.contactName} />
        <DetailField label="Organization Email" value={partner.contactEmail} />
        <DetailField label="Partner Type" value={partner.type} />
      </div>
    </SectionCard>
  );
}
