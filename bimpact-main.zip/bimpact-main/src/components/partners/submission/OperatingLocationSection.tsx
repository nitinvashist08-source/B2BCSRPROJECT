import { PartnerOrg } from "@/types/settings";
import { PartnerSubmissionCategory } from "@/lib/partnerSubmissionView";
import { DetailField, SectionCard, SectionStatusPill } from "./shared";

// Operating Location — "invited-pending" partners genuinely haven't
// collected state/districts yet (that only happens in the partner's own
// onboarding Step 3), so we show an honest pending message instead of
// fabricating a fake location. "active-demo"/"submitted" partners have real
// submitted/seed data and should read as Completed, independent of whatever
// the Compliance Documents section renders — this section's completeness is
// never downgraded because of missing compliance docs elsewhere.
export function OperatingLocationSection({
  partner,
  category,
}: {
  partner: PartnerOrg;
  category: PartnerSubmissionCategory;
}) {
  // Defensive fallback, not just a type assumption — a partner record
  // loaded from stale localStorage (saved before `districts` existed on
  // this app's data model) can still arrive here without it. Never call
  // .map() on partner.districts directly.
  const districts = partner.districts ?? [];
  const isPending = category === "invited-pending" || !partner.state || districts.length === 0;

  if (isPending) {
    return (
      <SectionCard title="Operating Location" status={<SectionStatusPill tone="pending">Pending</SectionStatusPill>}>
        <p className="text-sm text-ink-2">The partner has not yet completed their operating location details.</p>
      </SectionCard>
    );
  }

  return (
    <SectionCard
      title="Operating Location"
      status={<SectionStatusPill tone="completed">Completed</SectionStatusPill>}
    >
      <div className="grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
        <DetailField label="State" value={partner.state} />
        <div className="col-span-2 sm:col-span-3">
          <DetailField
            label="Districts"
            value={
              <div className="flex flex-wrap gap-1.5">
                {districts.map((district) => (
                  <span
                    key={district}
                    className="rounded-[6px] border border-border bg-surface-2 px-2 py-0.5 text-xs font-medium text-ink-2"
                  >
                    {district}
                  </span>
                ))}
              </div>
            }
          />
        </div>
      </div>
    </SectionCard>
  );
}
