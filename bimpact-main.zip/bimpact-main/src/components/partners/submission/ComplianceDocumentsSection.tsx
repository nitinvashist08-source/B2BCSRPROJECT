"use client";

import { useState } from "react";
import { ComplianceDocType, ComplianceDocument, DocumentReviewStatus, PartnerOrg } from "@/types/settings";
import { useSettingsStore } from "@/store/settingsStore";
import { DEMO_COMPLIANCE_FILENAMES, PartnerSubmissionCategory } from "@/lib/partnerSubmissionView";
import { getComplianceDocLabel, getRequiredComplianceGroups } from "@/lib/partnerComplianceRequirements";
import { ComplianceCatalogItem } from "@/data/complianceCatalog";
import { SectionCard, SectionStatusPill, formatDateTime, formatValidityPeriod } from "./shared";
import { ViewComplianceDocumentModal } from "@/components/compliance/ViewComplianceDocumentModal";
import { REVIEW_STATUS_STYLE } from "@/components/compliance/ComplianceDocumentCard";

// Not-yet-uploaded is its own display state, distinct from any real
// DocumentReviewStatus — same amber treatment "Changes Requested"/"Pending
// Review" already use, since all three mean "nothing for the Sponsor to
// review as final yet".
const PENDING_STYLE = "bg-amber-50 text-amber-600";

// The single latest status to show inline in the list, below the document
// name — never the full history (Document View/history keeps that). A
// fabricated "active-demo" row (see resolveRowState) has no real
// ComplianceDocument/reviewStatus behind it at all; those legacy partners
// predate the review workflow entirely, so their fabricated documents read
// as Accepted rather than an indefinite "Pending Review" that could never
// actually be reviewed.
function resolveDisplayStatus(state: DocRowState): { label: string; style: string } {
  if (!state.uploaded) return { label: "Pending", style: PENDING_STYLE };
  const reviewStatus: DocumentReviewStatus = state.doc ? state.doc.reviewStatus ?? "Pending Review" : "Accepted";
  return { label: reviewStatus, style: REVIEW_STATUS_STYLE[reviewStatus] };
}

// Cosmetic-only fixed timestamp for the "active-demo" bucket's fabricated
// compliance profile — these documents never existed as a real upload trail
// (see partnerSubmissionView.ts), so there's no real uploadedAt to show. A
// fixed recent-looking date keeps this section stable across re-renders
// instead of drifting on every `new Date()` call.
const DEMO_UPLOADED_AT = "2026-08-18T10:30:00.000Z";

type DocRowState =
  // `doc` is only present for a real, Sponsor-viewable submitted record —
  // the fabricated active-demo/invited-pending buckets have a fileName but
  // no real file/fileId behind it, so View and the NEW tag only ever render
  // when this is set.
  | { uploaded: true; fileName: string; uploadedAt: string; doc?: ComplianceDocument }
  | { uploaded: false; helperText?: string };

function resolveRowState(
  type: ComplianceDocType,
  partner: PartnerOrg,
  category: PartnerSubmissionCategory,
): DocRowState {
  if (category === "active-demo") {
    const fileName = DEMO_COMPLIANCE_FILENAMES[type];
    if (fileName) return { uploaded: true, fileName, uploadedAt: DEMO_UPLOADED_AT };
    return { uploaded: false };
  }

  if (category === "invited-pending") {
    return { uploaded: false, helperText: "The partner has not submitted this document yet." };
  }

  // "submitted" — evaluate each category independently against the
  // partner's real complianceDocuments array. One missing document must
  // never make the others read as Pending, and must never be treated as
  // making the whole submission incomplete.
  const doc = partner.complianceDocuments?.find((d) => d.type === type);
  if (doc) return { uploaded: true, fileName: doc.fileName, uploadedAt: doc.uploadedAt, doc };
  return { uploaded: false };
}

function DocumentRow({
  item,
  state,
  onView,
}: {
  item: ComplianceCatalogItem;
  state: DocRowState;
  onView: (type: ComplianceDocType, doc: ComplianceDocument) => void;
}) {
  // Undefined/null viewedBySponsorAt means unseen since this exact document
  // object was last uploaded/replaced — see ComplianceDocument's own comment
  // in src/types/settings.ts.
  const isNew = state.uploaded && !!state.doc && !state.doc.viewedBySponsorAt;

  // Only real records carry validity — the fabricated active-demo/
  // invited-pending rows have no ComplianceDocument behind them at all.
  const validity = state.uploaded && state.doc ? formatValidityPeriod(state.doc.validFrom, state.doc.validTill) : null;
  // The one thing this whole enhancement is about: the document's CURRENT
  // status, shown directly below its name — Accept/Reject/Request Changes
  // on the same doc.reviewStatus this reads updates it immediately (no
  // separate Sponsor-side status copy), and re-upload/replace resets it to
  // "Pending Review" the same way it always has (see
  // ComplianceDocument.reviewStatus's own comment) — nothing new is being
  // tracked here, just surfaced.
  const displayStatus = resolveDisplayStatus(state);

  return (
    <div className="flex items-start justify-between gap-3 rounded-md border border-border bg-surface-2 px-3.5 py-2.5">
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          {isNew && (
            <span className="rounded-full bg-primary-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-primary-700">
              New
            </span>
          )}
          <span className="text-sm font-medium text-ink">{item.name}</span>
        </div>
        <div className="mt-1.5">
          <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${displayStatus.style}`}>
            {displayStatus.label}
          </span>
        </div>
        {validity && <div className="mt-1 text-[11.5px] text-muted">{validity}</div>}
        {!state.uploaded && state.helperText && <div className="mt-1 text-[11.5px] text-muted">{state.helperText}</div>}
      </div>
      {state.uploaded && (
        <div className="shrink-0 text-right text-[13px] text-ink-2">
          <div className="font-semibold">{state.fileName}</div>
          <div className="text-muted">{formatDateTime(state.uploadedAt)}</div>
          {state.doc && (
            <button
              type="button"
              onClick={() => onView(item.id, state.doc as ComplianceDocument)}
              className="mt-0.5 font-semibold text-primary underline underline-offset-2 hover:text-primary-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 rounded-sm"
            >
              View
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// Sponsor-panel View Submission — third of the three read-only sections.
// Renders whatever categories/items the Sponsor's PartnerComplianceChecklist
// selects for this partner's TYPE (see partnerComplianceRequirements.ts) —
// never a fixed list; each row's Uploaded/Pending state is resolved
// independently per the partner's category (see partnerSubmissionView.ts for
// the three-bucket contract) so a single missing document never taints the
// others. "Other Supporting Documents" is a list (a Partner can upload
// several), not a single slot like the checklist items above — so it gets
// its own card row per document instead of DocumentRow's single-row-per-item
// layout, and stays untouched by the Sponsor's checklist entirely.
// Reads the SAME partner.complianceDocuments the Partner's own Compliance
// page writes (see compliance/page.tsx's handleUpload) — no separate
// Sponsor-side copy, and every doc the Partner has ever uploaded here shows
// up, not just the latest.
function OtherDocumentCard({
  doc,
  onView,
}: {
  doc: ComplianceDocument;
  onView: (doc: ComplianceDocument) => void;
}) {
  const isNew = !doc.viewedBySponsorAt;
  const validity = formatValidityPeriod(doc.validFrom, doc.validTill);
  return (
    <div className="flex items-center justify-between gap-3 rounded-md border border-border bg-surface-2 px-3.5 py-2.5">
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          {isNew && (
            <span className="rounded-full bg-primary-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-primary-700">
              New
            </span>
          )}
          {/* The Partner-provided Document Name is the primary label — the
              original filename is never lost (still on doc.fileName), just
              shown as secondary info underneath. A doc uploaded before this
              field existed has no documentName, so it falls back to the
              filename as its only/primary label. */}
          <span className="truncate text-sm font-semibold text-ink">{doc.documentName || doc.fileName}</span>
        </div>
        {doc.documentName && <p className="mt-0.5 truncate text-[12.5px] text-muted">{doc.fileName}</p>}
        <p className="mt-0.5 text-[11.5px] text-secondary-600">Uploaded · {formatDateTime(doc.uploadedAt)}</p>
        {validity && <p className="mt-0.5 text-[11.5px] text-muted">{validity}</p>}
      </div>
      <button
        type="button"
        onClick={() => onView(doc)}
        className="shrink-0 text-[13px] font-semibold text-primary underline underline-offset-2 hover:text-primary-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 rounded-sm"
      >
        View
      </button>
    </div>
  );
}

export function ComplianceDocumentsSection({
  partner,
  category,
}: {
  partner: PartnerOrg;
  category: PartnerSubmissionCategory;
}) {
  const markComplianceDocumentViewed = useSettingsStore((s) => s.markComplianceDocumentViewed);
  const markOtherComplianceDocumentViewed = useSettingsStore((s) => s.markOtherComplianceDocumentViewed);
  const partnerForms = useSettingsStore((s) => s.partnerForms);
  const [viewing, setViewing] = useState<{ label: string; doc: ComplianceDocument; type: ComplianceDocType } | null>(
    null
  );

  // Same dynamic per-partner-type resolution the Partner's own /compliance
  // page uses — one source of truth, not a separate Sponsor-side copy of the
  // required-document list.
  const { configured, groups: requiredGroups } = getRequiredComplianceGroups(partner, partnerForms);
  const requiredItems = requiredGroups.flatMap((g) => g.items);
  const requiredTotal = requiredItems.length;
  const requiredUploaded = requiredItems.filter((item) => resolveRowState(item.id, partner, category).uploaded).length;
  // Every "Other" doc the partner has ever uploaded — real ones only
  // (category "submitted"); active-demo/invited-pending never fabricate
  // sample "Other" docs (see DEMO_COMPLIANCE_FILENAMES's own comment).
  const otherDocs = category === "submitted" ? (partner.complianceDocuments ?? []).filter((d) => d.type === "Other") : [];

  function handleView(type: ComplianceDocType, doc: ComplianceDocument) {
    setViewing({ label: getComplianceDocLabel(type), doc, type });
    // Clears the NEW tag the moment the Sponsor opens the document — not
    // when the notification is merely received/dismissed (see this doc
    // field's own comment: notification state and document-level "seen"
    // state are deliberately independent).
    markComplianceDocumentViewed(partner.id, type);
  }

  function handleViewOther(doc: ComplianceDocument) {
    setViewing({ label: doc.documentName || getComplianceDocLabel("Other"), doc, type: "Other" });
    if (doc.fileId) markOtherComplianceDocumentViewed(partner.id, doc.fileId);
  }

  return (
    <>
      <SectionCard
        title="Compliance Documents"
        status={
          configured ? (
            <SectionStatusPill tone={requiredTotal > 0 && requiredUploaded === requiredTotal ? "completed" : "pending"}>
              {requiredUploaded} of {requiredTotal} required documents uploaded
            </SectionStatusPill>
          ) : (
            <SectionStatusPill tone="pending">Not configured</SectionStatusPill>
          )
        }
      >
        {!configured ? (
          <p className="text-sm text-ink-2">
            No compliance checklist has been configured yet for this partner&apos;s type. Set one up under Partners →
            Partner Compliance Form.
          </p>
        ) : (
          <div className="space-y-4">
            {requiredGroups.map((group) => (
              <div key={group.category.id} className="space-y-2">
                <h4 className="text-[12.5px] font-bold text-ink-2">{group.category.title}</h4>
                <div className="space-y-2">
                  {group.items.map((item) => (
                    <DocumentRow key={item.id} item={item} state={resolveRowState(item.id, partner, category)} onView={handleView} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      <SectionCard
        title="Other Supporting Documents"
        status={
          <SectionStatusPill tone={otherDocs.length > 0 ? "completed" : "pending"}>
            {otherDocs.length} document{otherDocs.length === 1 ? "" : "s"} uploaded
          </SectionStatusPill>
        }
      >
        {otherDocs.length === 0 ? (
          <p className="text-sm text-ink-2">
            {category === "invited-pending"
              ? "The partner has not submitted any supporting documents yet."
              : "No supporting documents uploaded."}
          </p>
        ) : (
          <div className="space-y-2">
            {otherDocs.map((doc, i) => (
              <OtherDocumentCard key={doc.fileId ?? `${doc.fileName}-${i}`} doc={doc} onView={handleViewOther} />
            ))}
          </div>
        )}
      </SectionCard>

      <ViewComplianceDocumentModal
        open={viewing !== null}
        onClose={() => setViewing(null)}
        label={viewing?.label ?? ""}
        doc={viewing?.doc ?? null}
        // Only real, Sponsor-viewable submitted documents ever set
        // `viewing` with a real doc (see DocRowState's own comment) — the
        // fabricated active-demo/invited-pending rows never open this modal
        // at all, so there's never a review action to wire to a fake doc.
        review={viewing ? { partnerId: partner.id, documentType: viewing.type } : undefined}
      />
    </>
  );
}
