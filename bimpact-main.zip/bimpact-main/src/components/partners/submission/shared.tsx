import { ReactNode } from "react";

// Small shared presentational primitives for the three View Submission
// sections (Organization Details / Operating Location / Compliance
// Documents) — kept in one place so all three sections look visually
// identical instead of drifting apart.

export function formatDateTime(value?: string | null) {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
}

// Date-only companion to formatDateTime above — for the `YYYY-MM-DD`
// fields <input type="date"> produces (e.g. a compliance document's
// validFrom/validTill), which carry no meaningful time-of-day to show.
export function formatDate(value?: string | null) {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString("en-IN", { dateStyle: "medium" });
}

// One-line rendering of a compliance document's validity period. Both
// dates are optional (see ComplianceDocument.validFrom/validTill), so this
// returns null when neither was given — callers skip the line entirely
// rather than printing an empty "Valid: — to —".
export function formatValidityPeriod(validFrom?: string | null, validTill?: string | null) {
  if (!validFrom && !validTill) return null;
  if (!validTill) return `Valid from ${formatDate(validFrom)} · No expiry`;
  if (!validFrom) return `Valid till ${formatDate(validTill)}`;
  return `Valid ${formatDate(validFrom)} – ${formatDate(validTill)}`;
}

export function DetailField({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div>
      <div className="text-[10.5px] font-bold uppercase tracking-[0.05em] text-muted">{label}</div>
      <div className="mt-1 text-sm text-ink">{value}</div>
    </div>
  );
}

export function SectionCard({
  title,
  status,
  children,
}: {
  title: string;
  // Optional section-level status pill next to the heading — e.g.
  // "Completed" / "Pending" / "Available from invitation". Omit for
  // sections that don't carry one.
  status?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="rounded-lg border border-border bg-surface p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h3 className="text-sm font-bold text-ink">{title}</h3>
        {status}
      </div>
      {children}
    </div>
  );
}

const SECTION_STATUS_STYLE = {
  completed: "bg-secondary-50 text-secondary-600",
  pending: "bg-amber-50 text-amber-600",
  info: "bg-primary-50 text-primary-700",
} as const;

// A small pill for SectionCard's `status` slot / individual document rows —
// e.g. <SectionStatusPill tone="completed">Completed</SectionStatusPill>.
export function SectionStatusPill({
  tone,
  children,
}: {
  tone: keyof typeof SECTION_STATUS_STYLE;
  children: ReactNode;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ${SECTION_STATUS_STYLE[tone]}`}
    >
      {children}
    </span>
  );
}
