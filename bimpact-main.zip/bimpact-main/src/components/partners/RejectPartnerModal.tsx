"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useSettingsStore } from "@/store/settingsStore";
import { PartnerOrg } from "@/types/settings";

export function RejectPartnerModal({
  partner,
  open,
  onClose,
}: {
  partner: PartnerOrg;
  open: boolean;
  onClose: () => void;
}) {
  const rejectPartnerReview = useSettingsStore((s) => s.rejectPartnerReview);
  const [reason, setReason] = useState("");

  function handleClose() {
    setReason("");
    onClose();
  }

  function handleSubmit() {
    const trimmed = reason.trim();
    if (!trimmed) return;
    rejectPartnerReview(partner.id, trimmed);
    handleClose();
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="Reject Partner Onboarding"
      footer={
        <>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleSubmit} disabled={!reason.trim()}>
            Reject Partner
          </Button>
        </>
      }
    >
      <p className="mb-3">
        Please provide a reason for rejecting this partner. The reason will be shared with the
        partner.
      </p>
      <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.06em] text-muted">
        Reason for Rejection <span className="text-danger">*</span>
      </label>
      <textarea
        value={reason}
        onChange={(e) => setReason(e.target.value)}
        rows={4}
        placeholder="Explain why this partner's onboarding submission is being rejected…"
        className="w-full resize-none rounded-sm border border-border px-3 py-2 text-sm text-ink outline-none focus:border-primary"
      />
    </Modal>
  );
}
