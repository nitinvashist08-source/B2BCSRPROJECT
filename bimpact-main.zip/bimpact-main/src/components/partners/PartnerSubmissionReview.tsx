"use client";

import { useState } from "react";
import { PartnerOrg } from "@/types/settings";
import { Button } from "@/components/ui/Button";
import { ReviewStatusBadge, StatusBadge } from "@/components/settings/PartnerOrgsTable";
import { InvitePartnerSlideOver } from "@/components/settings/InvitePartnerSlideOver";
import { ApprovePartnerDialog } from "./ApprovePartnerDialog";
import { RejectPartnerModal } from "./RejectPartnerModal";
import { PartnerStatusActionButtons } from "./PartnerStatusActionButtons";
import { ReinvitePartnerDialog } from "./ReinvitePartnerDialog";
import { DeactivatePartnerDialog } from "./DeactivatePartnerDialog";
import { CancelInvitationDialog } from "./CancelInvitationDialog";
import { useSettingsStore } from "@/store/settingsStore";
import { categorizePartnerSubmission } from "@/lib/partnerSubmissionView";
import { OrganizationDetailsSection } from "./submission/OrganizationDetailsSection";
import { OperatingLocationSection } from "./submission/OperatingLocationSection";
import { RegisteredOfficeAddressSection } from "./submission/RegisteredOfficeAddressSection";
import { ComplianceDocumentsSection } from "./submission/ComplianceDocumentsSection";
import { PartnerHistorySection } from "./submission/PartnerHistorySection";
import { DetailField, SectionCard, formatDateTime } from "./submission/shared";

function BackIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}

type ActiveModal = "approve" | "reject" | null;

// Sponsor-side "Partner Details" screen — reached from PartnerOrgsTable's
// "View Details" action via the same local view-state swap
// PartnerOnboardingFormHub/IndicatorsView use instead of a dedicated route.
// Originally "Partner Submission Review" (title only — the underlying
// implementation/data is unchanged). None of the fields here are editable
// directly; interactive elements are the two review decision CTAs (open
// ApprovePartnerDialog/RejectPartnerModal — unchanged; the Request Changes
// CTA that used to sit alongside them was removed from this screen per
// spec — RequestChangesModal.tsx/settingsStore's requestPartnerChanges
// still exist untouched, just no longer wired to a button here) plus the
// status-dependent action buttons rendered directly in the header (Edit
// Partner/Re-invite/Cancel Invitation/Deactivate Partner/Activate Partner —
// persistently visible, not behind a menu, per spec; same dialogs and
// guarded settingsStore actions PartnerOrgsTable's row "⋮" menu uses, via
// the shared PartnerStatusActionButtons/getPartnerStatusActions).
export function PartnerSubmissionReview({ partner, onBack }: { partner: PartnerOrg; onBack: () => void }) {
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const reactivatePartner = useSettingsStore((s) => s.reactivatePartner);
  const [editOpen, setEditOpen] = useState(false);
  const [reinviteOpen, setReinviteOpen] = useState(false);
  const [deactivateOpen, setDeactivateOpen] = useState(false);
  const [cancelInviteOpen, setCancelInviteOpen] = useState(false);
  const status = partner.reviewStatus;
  const category = categorizePartnerSubmission(partner);
  // Approved/Rejected are terminal outcomes of this workflow — once there,
  // none of the three decisions is relevant any more, so the CTA row is
  // hidden rather than showing stale/no-op actions.
  const decidable = status === "Pending Review" || status === "Changes Requested";

  return (
    <div>
      {/* Two-row header: row 1 is Back+title on the left against the
          status-appropriate action CTAs on the right (never both CTA groups
          at once — decidable's three-button row and PartnerStatusActionButtons
          are mutually exclusive, see `decidable` above); row 2 is the
          supporting description, now full-width instead of squeezed next to
          the title, using the space the CTAs no longer share with it. */}
      <div className="mb-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="inline-flex h-7 shrink-0 items-center gap-[5px] rounded-sm border-[1.5px] border-border bg-surface px-2.5 text-xs font-semibold text-ink-2 hover:border-border-strong"
            >
              <BackIcon />
              Back
            </button>
            <h2 className="text-lg font-bold text-ink">Partner Details</h2>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2">
            {decidable ? (
              <>
                <Button size="sm" variant="danger" onClick={() => setActiveModal("reject")}>
                  Reject Partner
                </Button>
                <Button size="sm" onClick={() => setActiveModal("approve")}>
                  Approve Partner
                </Button>
              </>
            ) : (
              <PartnerStatusActionButtons
                partner={partner}
                onEdit={() => setEditOpen(true)}
                onReinvite={() => setReinviteOpen(true)}
                onCancelInvitation={() => setCancelInviteOpen(true)}
                onDeactivate={() => setDeactivateOpen(true)}
                onActivate={(p) => reactivatePartner(p.id)}
              />
            )}
          </div>
        </div>

        <p className="mt-2 text-[13px] text-muted">
          Review the organization details, operating location, and compliance documents this partner submitted
          during onboarding before making a decision.
        </p>
      </div>

      <div className="mb-4 rounded-lg border border-border bg-surface p-5">
        <div className="grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
          <DetailField label="Partner Name" value={partner.name} />
          <DetailField label="Partner Type" value={partner.type} />
          <DetailField label="Submission Date" value={formatDateTime(partner.submittedAt)} />
          <DetailField
            label="Current Review Status"
            value={
              status && status !== "Approved" ? (
                <ReviewStatusBadge status={status} />
              ) : status === "Approved" ? (
                <StatusBadge status={partner.status} />
              ) : (
                "—"
              )
            }
          />
        </div>
      </div>

      <div className="space-y-4">
        <OrganizationDetailsSection partner={partner} category={category} />
        <OperatingLocationSection partner={partner} category={category} />
        <RegisteredOfficeAddressSection partner={partner} category={category} />
        <ComplianceDocumentsSection partner={partner} category={category} />

        {status === "Changes Requested" && partner.changeRequestMessage && (
          <SectionCard title="Changes Requested — Message to Partner">
            <p className="text-sm text-ink-2">{partner.changeRequestMessage}</p>
          </SectionCard>
        )}
        {status === "Rejected" && partner.rejectionReason && (
          <SectionCard title="Rejection Reason">
            <p className="text-sm text-ink-2">{partner.rejectionReason}</p>
          </SectionCard>
        )}
        {partner.status === "Inactive" && partner.deactivation && (
          <SectionCard title="Deactivation Reason">
            <p className="text-sm text-ink-2">{partner.deactivation.reason}</p>
          </SectionCard>
        )}

        <PartnerHistorySection partner={partner} />
      </div>

      <ApprovePartnerDialog partner={partner} open={activeModal === "approve"} onClose={() => setActiveModal(null)} />
      <RejectPartnerModal partner={partner} open={activeModal === "reject"} onClose={() => setActiveModal(null)} />

      <InvitePartnerSlideOver key={partner.id} open={editOpen} onClose={() => setEditOpen(false)} editing={partner} />
      <ReinvitePartnerDialog partner={partner} open={reinviteOpen} onClose={() => setReinviteOpen(false)} />
      <DeactivatePartnerDialog partner={partner} open={deactivateOpen} onClose={() => setDeactivateOpen(false)} />
      <CancelInvitationDialog
        partner={partner}
        open={cancelInviteOpen}
        onClose={() => setCancelInviteOpen(false)}
        onCancelled={onBack}
      />
    </div>
  );
}
