"use client";

import { useMemo } from "react";
import { useRouter } from "next/navigation";
import { useAlertStore } from "@/store/alertStore";
import { useSessionStore } from "@/store/sessionStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useProjectStore } from "@/store/projectStore";
import { isAlertVisible } from "@/lib/alertVisibility";
import { Alert, AlertSeverity } from "@/types/alert";
import { Badge, BadgeTone } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

const SEVERITY_TONE: Record<AlertSeverity, BadgeTone> = {
  critical: "danger",
  high: "amber",
  medium: "primary",
  info: "secondary",
};
const SEVERITY_LABEL: Record<AlertSeverity, string> = {
  critical: "Critical",
  high: "High",
  medium: "Medium",
  info: "Info",
};

function timeAgo(iso: string): string {
  const ms = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(ms / 60_000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

// The Alerts module's real page — replaces the earlier static 4-item stub.
// Alerts are generated dynamically (see src/lib/alertRules.ts /
// alertStore.ts) from existing Finance/Project/Meeting/Partner/Compliance/
// Team/Beneficiary data; this component is purely a filtered, role-scoped
// view over that store, plus read-state actions. See src/lib/
// alertVisibility.ts for the single shared visibility rule also used by the
// Sidebar's unread-count badge and PartnerOrgsTable's compliance banner.
export function AlertsPageContent() {
  const router = useRouter();
  const alerts = useAlertStore((s) => s.alerts);
  const markRead = useAlertStore((s) => s.markRead);
  const markAllRead = useAlertStore((s) => s.markAllRead);

  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const workspaceId = useSessionStore((s) => s.workspaceId);
  const partners = useSettingsStore((s) => s.partners);
  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name ?? null;
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const projects = useProjectStore((s) => s.projects);

  const visible = useMemo(
    () =>
      alerts.filter((a) =>
        isAlertVisible(a, { role, partnerOrgId, partnerName, workspaceId, projects, projectPartners, partners })
      ),
    [alerts, role, partnerOrgId, partnerName, workspaceId, projects, projectPartners, partners]
  );

  // No more category filtering (Finance/Governance/...) — every visible
  // alert lives together on this one page now, per explicit product
  // request. Resolved alerts stay hidden (no toggle to show them anymore).
  const filtered = visible.filter((a) => !a.resolvedAt).sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));

  const unreadIds = visible.filter((a) => !a.isRead).length;

  function handleOpen(alert: Alert) {
    if (!alert.isRead) markRead(alert.id);
    if (alert.action) router.push(alert.action.route);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-semibold text-ink">Alerts</h1>
          <p className="text-xs text-muted">What needs attention, why it matters, and what to do about it.</p>
        </div>
        {unreadIds > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => markAllRead(visible.filter((a) => !a.isRead).map((a) => a.id))}
          >
            Mark all as read
          </Button>
        )}
      </div>

      {filtered.length === 0 ? (
        <div className="flex min-h-[240px] flex-col items-center justify-center rounded-lg border border-dashed border-border-strong bg-surface text-center">
          <h2 className="text-sm font-semibold text-ink">Nothing here</h2>
          <p className="mt-1 max-w-sm text-xs text-muted">No alerts right now — you&apos;re caught up.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-2.5">
          {filtered.map((a) => (
            <div
              key={a.id}
              className={`flex items-start gap-3 rounded-lg border p-4 shadow-sm transition-colors ${
                a.resolvedAt ? "border-border bg-bg opacity-70" : a.isRead ? "border-border bg-surface" : "border-primary-100 bg-primary-50/40"
              }`}
            >
              {!a.isRead && !a.resolvedAt && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-primary" aria-hidden />}
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={SEVERITY_TONE[a.severity]}>{SEVERITY_LABEL[a.severity]}</Badge>
                  <h3 className="text-sm font-semibold text-ink">{a.title}</h3>
                  {a.resolvedAt && <span className="text-[11px] font-medium text-secondary-600">Resolved</span>}
                  <span className="ml-auto shrink-0 text-xs text-muted">{timeAgo(a.createdAt)}</span>
                </div>
                <p className="mt-1 text-[13px] text-ink-2">{a.message}</p>
                <div className="mt-2 flex items-center gap-3">
                  {a.action && (
                    <button
                      onClick={() => handleOpen(a)}
                      className="text-xs font-semibold text-primary hover:underline"
                    >
                      {a.action.label} →
                    </button>
                  )}
                  {!a.isRead && (
                    <button onClick={() => markRead(a.id)} className="text-xs font-semibold text-muted hover:text-ink-2">
                      Mark as read
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
