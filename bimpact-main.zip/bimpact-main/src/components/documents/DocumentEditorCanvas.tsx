"use client";

import { ReactNode, RefObject, useEffect, useRef } from "react";
import { TablePicker } from "@/components/projects/TablePicker";

function ToolIcon({ path }: { path: string }) {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d={path} />
    </svg>
  );
}

function ToolbarButton({ title, onClick, children }: { title: string; onClick: () => void; children: ReactNode }) {
  return (
    <button
      title={title}
      onMouseDown={(e) => {
        e.preventDefault();
        onClick();
      }}
      className="flex h-7 w-[30px] items-center justify-center rounded-[5px] border border-transparent text-[13px] text-ink-2 transition-colors hover:border-border hover:bg-surface-2"
    >
      {children}
    </button>
  );
}

function Sep() {
  return <div className="mx-1 h-5 w-px shrink-0 bg-border" />;
}

function buildTableHtml(rows: number, cols: number): string {
  return (
    "<table><tbody>" +
    Array.from({ length: rows })
      .map(() => "<tr>" + Array.from({ length: cols }).map(() => "<td>&nbsp;</td>").join("") + "</tr>")
      .join("") +
    "</tbody></table><p><br/></p>"
  );
}

// The one document-editing surface this app has (toolbar + a white "paper"
// canvas) — originally Project Details → Documents' own DocEditor.tsx,
// extracted here so any other feature needing the same rich-text editing
// experience (e.g. CsrPolicyEditor.tsx) reuses this instead of standing up a
// second implementation. DocEditor.tsx itself now renders this too, wrapped
// in its own project-specific pane/AI overlays — this component owns only
// the toolbar and the contentEditable "paper" body, not project- or
// policy-specific chrome.
//
// `contentKey` mirrors DocEditor's original doc.id guard: the contentEditable
// body is only re-seeded with `contentHtml` when this key changes, never on
// every keystroke (which would reset the caret mid-edit).
export function DocumentEditorCanvas({
  title,
  onTitleChange,
  titlePlaceholder = "Untitled Document",
  contentHtml,
  contentKey,
  onChange,
  canEdit,
  placeholder = "Start writing…",
  readOnlyMessage = "View only — you don't have edit access here.",
  toolbarExtra,
  bodyRef: externalBodyRef,
}: {
  // Omit both title props entirely for callers with no separate title field
  // (e.g. CSR Policy, whose "title" is just its period/date range shown
  // elsewhere) — the title input only renders when onTitleChange is passed.
  title?: string;
  onTitleChange?: (value: string) => void;
  titlePlaceholder?: string;
  contentHtml: string;
  contentKey: string;
  onChange: (html: string) => void;
  canEdit: boolean;
  placeholder?: string;
  readOnlyMessage?: string;
  toolbarExtra?: ReactNode;
  bodyRef?: RefObject<HTMLDivElement | null>;
}) {
  const internalRef = useRef<HTMLDivElement>(null);
  const initialized = useRef<string | null>(null);

  useEffect(() => {
    if (initialized.current !== contentKey && internalRef.current) {
      internalRef.current.innerHTML = contentHtml;
      initialized.current = contentKey;
    }
    // contentHtml deliberately excluded — only `contentKey` changing should
    // re-seed; the body is uncontrolled between seeds (see comment above).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contentKey]);

  function persist() {
    if (internalRef.current) onChange(internalRef.current.innerHTML);
  }

  function exec(cmd: string, arg?: string) {
    internalRef.current?.focus();
    document.execCommand(cmd, false, arg);
    persist();
  }

  function insertTable(rows: number, cols: number) {
    internalRef.current?.focus();
    document.execCommand("insertHTML", false, buildTableHtml(rows, cols));
    persist();
  }

  return (
    <>
      {canEdit && (
        <div className="flex flex-shrink-0 flex-wrap items-center gap-x-0.5 gap-y-1 border-b border-border bg-surface px-4 py-1.5">
          <select
            title="Text style"
            onChange={(e) => exec("formatBlock", e.target.value)}
            defaultValue="p"
            className="h-7 min-w-[80px] rounded-[5px] border border-border bg-transparent px-1.5 text-xs font-semibold text-ink-2 outline-none hover:border-border-strong"
          >
            <option value="p">Normal</option>
            <option value="h1">Heading 1</option>
            <option value="h2">Heading 2</option>
            <option value="h3">Heading 3</option>
          </select>
          <Sep />
          <ToolbarButton title="Bold" onClick={() => exec("bold")}>
            <b className="text-[13px]">B</b>
          </ToolbarButton>
          <ToolbarButton title="Italic" onClick={() => exec("italic")}>
            <i className="text-[13px]">I</i>
          </ToolbarButton>
          <ToolbarButton title="Underline" onClick={() => exec("underline")}>
            <u className="text-[13px]">U</u>
          </ToolbarButton>
          <ToolbarButton title="Strikethrough" onClick={() => exec("strikethrough")}>
            <s className="text-[13px]">S</s>
          </ToolbarButton>
          <Sep />
          <ToolbarButton title="Bullet list" onClick={() => exec("insertUnorderedList")}>
            <ToolIcon path="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
          </ToolbarButton>
          <ToolbarButton title="Numbered list" onClick={() => exec("insertOrderedList")}>
            <ToolIcon path="M10 6h11M10 12h11M10 18h11M4 6h1v4M4 10h2M6 18H4c0-1 2-2 2-3s-1-1.5-2-1" />
          </ToolbarButton>
          <Sep />
          <ToolbarButton title="Align left" onClick={() => exec("justifyLeft")}>
            <ToolIcon path="M17 10H3M21 6H3M21 14H3M17 18H3" />
          </ToolbarButton>
          <ToolbarButton title="Align center" onClick={() => exec("justifyCenter")}>
            <ToolIcon path="M18 10H6M21 6H3M21 14H3M18 18H6" />
          </ToolbarButton>
          <ToolbarButton title="Align right" onClick={() => exec("justifyRight")}>
            <ToolIcon path="M21 10H7M21 6H3M21 14H3M21 18H7" />
          </ToolbarButton>
          <Sep />
          <ToolbarButton title="Blockquote" onClick={() => exec("formatBlock", "blockquote")}>
            <ToolIcon path="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" />
          </ToolbarButton>
          <ToolbarButton title="Divider line" onClick={() => exec("insertHorizontalRule")}>
            <ToolIcon path="M5 12h14" />
          </ToolbarButton>
          <Sep />
          <TablePicker onInsert={insertTable} />
          {toolbarExtra}
        </div>
      )}
      {!canEdit && (
        <div className="flex shrink-0 items-center gap-2 border-b border-border bg-surface px-4 py-2 text-[12.5px] font-semibold text-muted">
          {readOnlyMessage}
        </div>
      )}

      <div className="flex-1 overflow-y-auto bg-[#f0f2f5] px-6 py-8">
        <div className="relative mx-auto min-h-[1060px] max-w-[800px] rounded-[3px] bg-white px-[72px] pb-20 pt-[60px] shadow-[0_2px_16px_rgba(0,0,0,0.08),0_0_0_1px_rgba(0,0,0,0.04)]">
          {onTitleChange && (
            <input
              value={title ?? ""}
              onChange={(e) => onTitleChange(e.target.value)}
              placeholder={titlePlaceholder}
              disabled={!canEdit}
              className="mb-6 w-full border-b-2 border-transparent bg-transparent pb-1 text-[2rem] font-bold text-ink outline-none transition-colors placeholder:text-[#c8cdd6] focus:border-primary-100 disabled:text-ink-2"
            />
          )}
          <div
            ref={(node) => {
              internalRef.current = node;
              if (externalBodyRef) externalBodyRef.current = node;
            }}
            contentEditable={canEdit}
            suppressContentEditableWarning
            onInput={persist}
            onBlur={persist}
            data-placeholder={placeholder}
            className="doc-editor-body min-h-[500px] text-base leading-[1.8] text-ink outline-none empty:before:pointer-events-none empty:before:absolute empty:before:text-base empty:before:text-[#c0c5ce] empty:before:content-[attr(data-placeholder)]"
          />
        </div>
      </div>
    </>
  );
}
