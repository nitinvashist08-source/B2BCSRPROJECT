"use client";

import { useState } from "react";
import { CsrPolicy } from "@/types/meeting";
import { useMeetingStore } from "@/store/meetingStore";
import { Button } from "@/components/ui/Button";
import { Modal } from "@/components/ui/Modal";
import { fmtPolicyDate, fmtPolicyPeriod, StatusBadge } from "./CsrPolicyList";

function BackIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}
// mgmtCsrpOpenPreview's eyebrow/empty-state icon, bImpact_MeetingSplit_v10.html:11357/11371/11391/11476 — one path, reused at three sizes/opacities.
function DocIcon({ size = 18, stroke = "currentColor" }: { size?: number; stroke?: string }) {
  return (
    <svg fill="none" height={size} width={size} stroke={stroke} strokeWidth="1.8" viewBox="0 0 24 24">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
    </svg>
  );
}
// mgmtCsrpOpenPreview's "Last updated" meta icon, :11451.
function ClockIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}

// Read-only CSR Policy view — reached from CsrPolicyList's "View" action and
// from CsrPolicyEditor's "Update Policy" completion. Renders the SAME
// CsrPolicy record's `content` HTML that CsrPolicyEditor's shared
// DocumentEditorCanvas produces (no separate preview data structure), styled
// after the source mockup's "Management → CSR Policy" read-only preview —
// mgmtCsrpOpenPreview, bImpact_MeetingSplit_v10.html:11412-11493 (dark
// gradient hero + white prose card + footer strip) — rather than a plain
// bordered box, so View genuinely reads as a published web page, not an
// editor. No toolbar/contentEditable/other editing chrome here
// (dangerouslySetInnerHTML only). Edit hands off to the existing
// CsrPolicyEditor (via the parent's `onEdit`); Publish/Unpublish call the
// same store actions the old inline list buttons used, just gated behind a
// confirmation dialog for Unpublish per spec.
export function CsrPolicyPreview({
  policy,
  onBack,
  onEdit,
}: {
  policy: CsrPolicy;
  onBack: () => void;
  onEdit: () => void;
}) {
  const publishPolicy = useMeetingStore((s) => s.publishPolicy);
  const unpublishPolicy = useMeetingStore((s) => s.unpublishPolicy);
  const deletePolicy = useMeetingStore((s) => s.deletePolicy);
  const [confirmingUnpublish, setConfirmingUnpublish] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="inline-flex h-7 items-center gap-1.5 rounded-sm border border-border bg-surface px-2.5 text-xs font-semibold text-ink-2 hover:border-border-strong"
          >
            <BackIcon />
            Policies
          </button>
          <span className="text-border">/</span>
          <span className="text-[13.5px] font-semibold text-ink">{fmtPolicyPeriod(policy)}</span>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge status={policy.status} />
          <Button size="sm" variant="ghost" onClick={onEdit}>
            Edit
          </Button>
          {/* Published policies are never locked — Edit above stays
              available either way. Publish/Unpublish is the one action that
              does change depending on status, and only Unpublish (moving
              a live policy out of publication) gets a confirmation step. */}
          {policy.status === "Published" ? (
            <Button size="sm" variant="ghost" onClick={() => setConfirmingUnpublish(true)}>
              Unpublish
            </Button>
          ) : (
            <Button size="sm" variant="secondary" onClick={() => publishPolicy(policy.id)}>
              Publish
            </Button>
          )}
          {/* Delete is available for every status — Draft, Published, or
              (the same "Draft" status) Unpublished — with no requirement to
              unpublish first; deleting a Published policy just removes the
              whole record, Published state included. */}
          <Button size="sm" variant="danger" onClick={() => setConfirmingDelete(true)}>
            Delete
          </Button>
        </div>
      </div>

      <div className="mx-auto max-w-[860px]">
        {/* Hero — mgmtCsrpOpenPreview's dark gradient banner, :11436-11454. */}
        <div
          className="relative overflow-hidden rounded-t-2xl px-[52px] pb-10 pt-11"
          style={{ background: "linear-gradient(135deg,#0c1e3e 0%,#0e3460 60%,#0a5fa3 100%)" }}
        >
          <div className="pointer-events-none absolute -right-[60px] -top-[60px] h-[260px] w-[260px] rounded-full border-2 border-white/[0.06]" />
          <div className="pointer-events-none absolute -right-5 -top-5 h-[160px] w-[160px] rounded-full border-2 border-white/[0.04]" />
          <div className="relative mb-5 inline-flex items-center gap-1.5 rounded-full border border-white/[0.14] bg-white/10 px-3 py-1">
            <DocIcon size={11} stroke="rgba(255,255,255,.8)" />
            <span className="text-[11px] font-bold uppercase tracking-[0.1em] text-white/75">CSR Policy</span>
          </div>
          <h1 className="relative mb-4 max-w-[720px] text-[28px] font-extrabold leading-[1.25] tracking-tight text-white">
            {fmtPolicyPeriod(policy)}
          </h1>
          <div className="relative flex flex-wrap items-center gap-3">
            <StatusBadge status={policy.status} />
            <span className="flex items-center gap-1.5 text-[13px] text-white/60">
              <ClockIcon />
              Last updated {fmtPolicyDate(policy.updatedAt || policy.createdAt)}
            </span>
          </div>
        </div>

        {/* Content card — :11457-11480. */}
        <div className="rounded-b-2xl border border-t-0 border-border bg-surface shadow-[0_8px_32px_rgba(15,23,42,0.08)]">
          {policy.content && policy.content.replace(/<[^>]+>/g, "").trim() ? (
            <div
              className="px-[52px] py-11 text-[15.5px] leading-[1.85] text-[#1e293b] [&_h1]:first:mt-0 [&_h1]:mb-3 [&_h1]:mt-8 [&_h1]:text-[19px] [&_h1]:font-extrabold [&_h1]:leading-tight [&_h1]:tracking-tight [&_h1]:text-ink [&_h2]:first:mt-0 [&_h2]:mb-3 [&_h2]:mt-8 [&_h2]:text-[19px] [&_h2]:font-extrabold [&_h2]:leading-tight [&_h2]:tracking-tight [&_h2]:text-ink [&_h3]:mb-2 [&_h3]:mt-6 [&_h3]:text-base [&_h3]:font-bold [&_h3]:text-ink [&_p]:mb-4 [&_ul]:mb-4 [&_ul]:list-disc [&_ul]:pl-6 [&_ol]:mb-4 [&_ol]:list-decimal [&_ol]:pl-6 [&_li]:mb-1.5 [&_strong]:font-bold [&_strong]:text-ink"
              dangerouslySetInnerHTML={{ __html: policy.content }}
            />
          ) : (
            <div className="flex min-h-[220px] flex-col items-center justify-center gap-0 px-8 py-12 text-center">
              <span className="mb-3.5 text-muted opacity-30">
                <DocIcon size={32} />
              </span>
              <div className="text-[15px] font-bold text-ink-2">No content added</div>
              <div className="mt-1.5 text-[13px] text-muted">Add policy content using the Edit action above.</div>
            </div>
          )}

          {/* Footer strip — :11483-11487. */}
          <div className="flex items-center justify-between rounded-b-2xl border-t border-border bg-surface-2 px-[52px] py-3.5">
            <span className="text-xs text-muted">
              {policy.id} &middot; {fmtPolicyPeriod(policy)}
            </span>
            <button
              onClick={onBack}
              className="inline-flex h-[30px] items-center gap-1.5 rounded-sm border border-border bg-surface px-3.5 text-[12.5px] font-semibold text-ink-2 hover:border-border-strong"
            >
              <BackIcon />
              Back to Policies
            </button>
          </div>
        </div>
      </div>

      <Modal
        open={confirmingUnpublish}
        onClose={() => setConfirmingUnpublish(false)}
        title="Unpublish CSR Policy?"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmingUnpublish(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                unpublishPolicy(policy.id);
                setConfirmingUnpublish(false);
              }}
            >
              Unpublish
            </Button>
          </>
        }
      >
        This policy is currently published. Are you sure you want to unpublish it?
      </Modal>

      <Modal
        open={confirmingDelete}
        onClose={() => setConfirmingDelete(false)}
        title="Delete CSR Policy?"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmingDelete(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                deletePolicy(policy.id);
                setConfirmingDelete(false);
                // The record is gone — nothing left to preview, so this is
                // the one action that must always leave Preview Mode.
                onBack();
              }}
            >
              Delete
            </Button>
          </>
        }
      >
        Are you sure you want to delete this CSR Policy? This action cannot be undone.
      </Modal>
    </div>
  );
}
