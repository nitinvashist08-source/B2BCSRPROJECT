"use client";

import { Meeting } from "@/types/meeting";
import { Button } from "@/components/ui/Button";
import { MeetingRecapCard } from "./MeetingRecapCard";

function PlayIcon() {
  return (
    <svg fill="none" height="20" width="20" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <polygon points="10 8 16 12 10 16 10 8" />
    </svg>
  );
}
function TriangleIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <polygon points="5 3 19 12 5 21 5 3" />
    </svg>
  );
}

// mtgRenderStartBanner, bImpact_MeetingSplit_v10.html:10874-10880 —
// .mtg-start-banner (:9834) is a light pastel gradient card with dark text
// and a solid-primary icon badge/button, not a bold blue-to-dark gradient
// with white text.
export function MeetingUpcomingView({
  meeting,
  onStartMeeting,
}: {
  meeting: Meeting;
  onStartMeeting: () => void;
}) {
  return (
    <div className="flex flex-col gap-4">
      <MeetingRecapCard meeting={meeting} />
      <div
        className="flex items-center justify-between gap-5 rounded-[14px] border-[1.5px] border-primary-100 px-[22px] py-5"
        style={{ background: "linear-gradient(135deg, var(--color-primary-50) 0%, #f0f9ff 100%)" }}
      >
        <div className="flex items-center gap-5">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary text-white">
            <PlayIcon />
          </span>
          <div>
            <div className="mb-0.5 text-[14.5px] font-extrabold text-ink">Ready to start the meeting?</div>
            <div className="text-[12.5px] text-muted">
              Click &ldquo;Start Meeting&rdquo; to open the execution view and begin recording minutes of meeting.
            </div>
          </div>
        </div>
        <Button onClick={onStartMeeting} className="shrink-0">
          <TriangleIcon />
          Start Meeting
        </Button>
      </div>
    </div>
  );
}
