"use client";

import { Meeting } from "@/types/meeting";
import { useMeetingStore } from "@/store/meetingStore";
import { Button } from "@/components/ui/Button";
import { Avatar } from "@/components/ui/Avatar";
import { AgendaNotesEditor } from "./AgendaNotesEditor";

export type Step1FieldKey = "title" | "date" | "startTime" | "endTime" | "location";
export type Step1Local = { title: string; date: string; startTime: string; endTime: string; location: string };

// .mtg-setup-card-num, source :9626 — every numbered card shares this exact
// header shape (icon badge + bold title + muted subtitle on a surface-2
// strip), used by all three cards below.
function NumBadge({ n }: { n: number }) {
  return (
    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-extrabold text-white">
      {n}
    </span>
  );
}

function CardHeader({ n, title, sub }: { n: number; title: string; sub: string }) {
  return (
    <div className="flex items-center gap-3 border-b border-border bg-surface-2 px-5 py-4">
      <NumBadge n={n} />
      <div>
        <div className="text-[13.5px] font-bold text-ink">{title}</div>
        <div className="mt-px text-xs text-muted">{sub}</div>
      </div>
    </div>
  );
}

function Required() {
  return <span className="text-danger">*</span>;
}

// .mtg-meta-lbl, source :9639
function MetaLabel({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-muted">
      {icon}
      {children} <Required />
    </span>
  );
}

function fieldCls(hasError: boolean) {
  // .mtg-meta-inp, source :9640 — 38px, 1.5px border, 8px radius, bg-bg (not
  // white), 13px text.
  return `h-[38px] w-full rounded-lg border-[1.5px] bg-bg px-3 text-[13px] outline-none focus:border-primary ${
    hasError ? "border-danger" : "border-border"
  }`;
}

function CalendarIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}
function ClockIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
function PinIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}

// mtgRenderStep1Form, bImpact_MeetingSplit_v10.html:10776-10823 — three
// numbered cards: Meeting Setup, Meeting Agenda, Attendees & Invitation.
export function MeetingStep1Form({
  meeting,
  local,
  onFieldChange,
  onFieldBlur,
  fieldErrors,
  formNotice,
  onManageAttendees,
}: {
  meeting: Meeting;
  local: Step1Local;
  onFieldChange: (patch: Partial<Step1Local>) => void;
  onFieldBlur: (patch: Partial<Step1Local>) => void;
  fieldErrors: Set<Step1FieldKey>;
  formNotice: string | null;
  onManageAttendees: () => void;
}) {
  const committee = useMeetingStore((s) => s.committee);
  const saveDraft = useMeetingStore((s) => s.saveDraft);

  const invited = committee.filter(
    (m) => meeting.attendees.present.includes(m.id) || meeting.attendees.absent.includes(m.id)
  );
  const guestCount = meeting.attendees.guests.length;
  const totalAttendees = invited.length + guestCount;
  const avatarPeople = [...invited.map((m) => ({ key: m.id, name: m.name, color: m.color })), ...meeting.attendees.guests.map((g) => ({ key: g.id, name: g.name, color: undefined }))];

  return (
    <div className="flex flex-col gap-5">
      {formNotice && (
        <p className="rounded-sm border border-danger bg-danger-50 px-3 py-2 text-xs font-medium text-danger">
          {formNotice}
        </p>
      )}

      {/* .mtg-setup-card, source :9624 — 14px radius, shadow-sm shell. */}
      <div className="overflow-hidden rounded-[14px] border border-border bg-surface shadow-sm">
        <CardHeader n={1} title="Meeting Setup" sub="Title, date, time and location" />
        <div className="p-5">
          {/* .mtg-mom-title, source :9632 — a large, borderless editorial
              input (22px/800), not a boxed form field like the meta ones
              below. */}
          <label className="mb-5 block">
            <span className="mb-2 block text-[11px] font-bold uppercase tracking-wide text-muted">
              Meeting Title <Required />
            </span>
            <input
              value={local.title}
              onChange={(e) => onFieldChange({ title: e.target.value })}
              onBlur={() => onFieldBlur({ title: local.title })}
              placeholder="e.g. CSR Board Review — Q2 FY 2025"
              className={`w-full border-0 border-b-2 bg-transparent py-1 text-[22px] font-extrabold tracking-tight text-ink outline-none placeholder:text-muted-2 ${
                fieldErrors.has("title") ? "border-danger" : "border-transparent focus:border-primary"
              }`}
            />
          </label>

          {/* .mtg-meta-grid, source :9637 — 2 columns, order Date/Start
              Time/End Time/Location (not Date/Location/Start/End). */}
          <div className="mt-[18px] grid grid-cols-2 gap-3.5">
            <label className="block">
              <MetaLabel icon={<CalendarIcon />}>Date</MetaLabel>
              <input
                type="date"
                value={local.date}
                onChange={(e) => onFieldChange({ date: e.target.value })}
                onBlur={() => onFieldBlur({ date: local.date })}
                className={fieldCls(fieldErrors.has("date"))}
              />
            </label>
            <label className="block">
              <MetaLabel icon={<ClockIcon />}>Start Time</MetaLabel>
              <input
                type="time"
                value={local.startTime}
                onChange={(e) => onFieldChange({ startTime: e.target.value })}
                onBlur={() => onFieldBlur({ startTime: local.startTime })}
                className={fieldCls(fieldErrors.has("startTime"))}
              />
            </label>
            <label className="block">
              <MetaLabel icon={<ClockIcon />}>End Time</MetaLabel>
              <input
                type="time"
                value={local.endTime}
                onChange={(e) => onFieldChange({ endTime: e.target.value })}
                onBlur={() => onFieldBlur({ endTime: local.endTime })}
                className={fieldCls(fieldErrors.has("endTime"))}
              />
            </label>
            <label className="block">
              <MetaLabel icon={<PinIcon />}>Location</MetaLabel>
              <input
                value={local.location}
                onChange={(e) => onFieldChange({ location: e.target.value })}
                onBlur={() => onFieldBlur({ location: local.location })}
                placeholder="Boardroom / Google Meet link…"
                className={fieldCls(fieldErrors.has("location"))}
              />
            </label>
          </div>
        </div>
      </div>

      <div className="overflow-hidden rounded-[14px] border border-border bg-surface shadow-sm">
        <CardHeader n={2} title="Meeting Agenda" sub="Topics to be discussed at this meeting" />
        <div className="p-5">
          <AgendaNotesEditor
            label=""
            value={meeting.agendaHtml}
            onChange={(html) => saveDraft(meeting.id, { agendaHtml: html })}
            placeholder="Write your meeting agenda here…"
          />
        </div>
      </div>

      <div className="overflow-hidden rounded-[14px] border border-border bg-surface shadow-sm">
        <CardHeader n={3} title="Attendees & Invitation" sub="Select committee members and invite external guests" />
        <div className="p-4">
          {/* .mtg-att-summary, source :9923-9931 — dashed border while
              empty, solid once attendees exist. */}
          <div
            className={`flex items-center gap-3.5 rounded-lg p-4 ${
              totalAttendees === 0
                ? "border-[1.5px] border-dashed border-border bg-bg"
                : "border-[1.5px] border-border bg-surface"
            }`}
          >
            {totalAttendees === 0 ? (
              <div className="flex w-full flex-col items-center gap-1 py-2 text-center">
                <p className="text-sm font-medium text-ink">No attendees added yet</p>
                <p className="text-xs text-muted">Click to select committee members or add guests</p>
                <Button size="sm" onClick={onManageAttendees} className="mt-2">
                  Add Attendees
                </Button>
              </div>
            ) : (
              <>
                <div className="flex items-center">
                  {avatarPeople.slice(0, 6).map((p) => (
                    <span key={p.key} className="-ml-1.5 rounded-full ring-2 ring-surface first:ml-0">
                      <Avatar name={p.name} size="sm" color={p.color} />
                    </span>
                  ))}
                  {avatarPeople.length > 6 && (
                    <span className="-ml-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-surface-2 text-[10px] font-bold text-muted ring-2 ring-surface">
                      +{avatarPeople.length - 6}
                    </span>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[13.5px] font-semibold text-ink">
                    {invited.length} committee member{invited.length !== 1 ? "s" : ""} · {guestCount} guest
                    {guestCount !== 1 ? "s" : ""}
                  </div>
                  <div className="mt-0.5 text-[11.5px] text-muted">Invited to this meeting</div>
                </div>
                <Button size="sm" variant="ghost" onClick={onManageAttendees}>
                  Edit
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
