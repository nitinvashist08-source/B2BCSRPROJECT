"use client";

import { useState } from "react";
import { Meeting } from "@/types/meeting";
import { useMeetingStore } from "@/store/meetingStore";
import { Button } from "@/components/ui/Button";
import { Avatar } from "@/components/ui/Avatar";
import { AgendaNotesEditor } from "./AgendaNotesEditor";
import { ActionItemsTable } from "./ActionItemsTable";
import { SignoffSection } from "./SignoffSection";
import { MeetingRecapCard } from "./MeetingRecapCard";
import { FeedbackModal } from "./FeedbackModal";

function CheckIcon() {
  return (
    <svg fill="none" height="10" width="10" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
function XIcon() {
  return (
    <svg fill="none" height="10" width="10" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}
function PeopleIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}
function NotesIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
    </svg>
  );
}
// .mtg-att-section-hd/.mtg-notes-card-hd, source :9687-9690/:9705-9706 —
// uppercase 12px section title on a surface-2 strip, matching the setup
// cards' header treatment but without the numbered badge.
function SectionHeader({ icon, title, right }: { icon: React.ReactNode; title: string; right?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border bg-surface-2 px-[18px] py-3.5">
      <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-ink-2">
        {icon}
        {title}
      </div>
      {right}
    </div>
  );
}

// mtgRenderExecutionSection, bImpact_MeetingSplit_v10.html:10883-10954 — one
// component drives both InProgress (editable, `readOnly=false`) and
// Completed (`readOnly=true`): recap card, attendance chips (click to
// toggle present/absent pre-completion), notes, action items, sign-off.
export function MeetingExecutionSection({
  meeting,
  readOnly,
  onManageAttendees,
  onMarkComplete,
}: {
  meeting: Meeting;
  readOnly: boolean;
  onManageAttendees: () => void;
  onMarkComplete: () => void;
}) {
  const committee = useMeetingStore((s) => s.committee);
  const saveDraft = useMeetingStore((s) => s.saveDraft);
  const setPresent = useMeetingStore((s) => s.setPresent);
  const setAbsent = useMeetingStore((s) => s.setAbsent);
  const removeGuest = useMeetingStore((s) => s.removeGuest);
  const shareMoM = useMeetingStore((s) => s.shareMoM);
  const [feedbackOpen, setFeedbackOpen] = useState(false);

  const attendees = committee.filter(
    (m) => meeting.attendees.present.includes(m.id) || meeting.attendees.absent.includes(m.id)
  );
  const presentCount = meeting.attendees.present.length;
  const absentCount = meeting.attendees.absent.length;

  function toggleAttendance(memberId: string) {
    if (readOnly) return;
    if (meeting.attendees.present.includes(memberId)) setAbsent(meeting.id, memberId);
    else setPresent(meeting.id, memberId);
  }

  return (
    <div className="flex flex-col gap-4">
      <MeetingRecapCard meeting={meeting} />

      {/* .mtg-att-section, source :9686-9690 — 12px radius shell. */}
      <div className="overflow-hidden rounded-xl border border-border bg-surface">
        <SectionHeader
          icon={<PeopleIcon />}
          title="Attendance"
          right={
            <div className="flex items-center gap-3">
              {!readOnly && (attendees.length > 0 || meeting.attendees.guests.length > 0) && (
                <span className="text-[11.5px] font-normal normal-case text-muted">Click a name to toggle present / absent</span>
              )}
              <Button size="sm" variant="ghost" onClick={onManageAttendees}>
                Manage attendees
              </Button>
            </div>
          }
        />
        <div className="p-[18px]">
        {!readOnly && (
          <p className="mb-3 text-xs font-medium text-muted">
            <strong className="font-bold text-secondary">{presentCount} present</strong> &nbsp;&middot;&nbsp; {absentCount} absent
          </p>
        )}
        {attendees.length === 0 && meeting.attendees.guests.length === 0 ? (
          <p className="py-2 text-[13px] italic text-muted">No attendees were added to this meeting.</p>
        ) : (
          <div className="flex flex-wrap gap-2.5">
            {attendees.map((m) => {
              const present = meeting.attendees.present.includes(m.id);
              return (
                <button
                  key={m.id}
                  type="button"
                  disabled={readOnly}
                  onClick={() => toggleAttendance(m.id)}
                  className={`flex items-center gap-2 rounded-full border-[1.5px] py-2 pl-2 pr-3 text-left ${
                    present
                      ? "border-secondary-100 bg-secondary-50 text-secondary-700"
                      : "border-border bg-[#F1F5F9] text-muted"
                  } ${readOnly ? "cursor-default" : "cursor-pointer"}`}
                >
                  <Avatar name={m.name} size="sm" color={m.color} />
                  <span className="flex flex-col leading-tight">
                    <span className="text-[13px] font-semibold">{m.name}</span>
                    <span className={`text-[10.5px] font-medium ${present ? "text-secondary-600" : "text-muted"}`}>{m.role}</span>
                  </span>
                  {present ? <CheckIcon /> : <XIcon />}
                </button>
              );
            })}
            {meeting.attendees.guests.map((g) => {
              const present = meeting.attendees.present.includes(g.id);
              return (
                <span
                  key={g.id}
                  className={`flex items-center gap-2 rounded-full border-[1.5px] py-2 pl-2 pr-3 ${
                    present ? "border-secondary-100 bg-secondary-50 text-secondary-700" : "border-border bg-[#F1F5F9] text-muted"
                  }`}
                >
                  <Avatar name={g.name} size="sm" />
                  <span className="flex flex-col leading-tight">
                    <span className="text-[13px] font-semibold">{g.name}</span>
                    <span className="text-[10.5px] font-medium text-muted">Guest</span>
                  </span>
                  {present ? <CheckIcon /> : <XIcon />}
                  {!readOnly && (
                    <button
                      onClick={() => removeGuest(meeting.id, g.id)}
                      className="ml-0.5 rounded p-0.5 text-muted-2 hover:bg-danger-50 hover:text-danger"
                      title="Remove guest"
                    >
                      <XIcon />
                    </button>
                  )}
                </span>
              );
            })}
          </div>
        )}
        </div>
      </div>

      {/* .mtg-notes-card, source :9704-9706 — same 12px-radius shell,
          notes-specific icon/title, no numbered badge. */}
      <div className="overflow-hidden rounded-xl border border-border bg-surface shadow-sm">
        <SectionHeader
          icon={<span className="text-primary"><NotesIcon /></span>}
          title="Meeting Notes"
          right={
            readOnly && (
              <Button size="sm" variant="ghost" onClick={() => setFeedbackOpen(true)}>
                Leave feedback
              </Button>
            )
          }
        />
        {readOnly ? (
          <div
            className="min-h-[80px] px-[18px] py-4 text-[13.5px] leading-relaxed text-ink"
            dangerouslySetInnerHTML={{ __html: meeting.notesHtml || "<p class='text-muted'>No notes recorded.</p>" }}
          />
        ) : (
          <AgendaNotesEditor
            label=""
            value={meeting.notesHtml}
            onChange={(html) => saveDraft(meeting.id, { notesHtml: html })}
            placeholder="Record key discussions, decisions, observations and outcomes…"
            minHeight={280}
            bare
          />
        )}
        {readOnly && meeting.signoff.remarks && (
          <div className="mx-[18px] mb-4 rounded-sm border border-border p-3 text-sm text-ink-2">
            <span className="mb-1 block text-xs font-medium text-muted">Feedback</span>
            {meeting.signoff.remarks}
          </div>
        )}
      </div>

      <ActionItemsTable meetingId={meeting.id} actions={meeting.actions} />

      <SignoffSection
        meeting={meeting}
        readOnly={readOnly}
        onMarkComplete={onMarkComplete}
        onShareMoM={() => shareMoM(meeting.id)}
      />

      <FeedbackModal open={feedbackOpen} onClose={() => setFeedbackOpen(false)} meetingId={meeting.id} />
    </div>
  );
}
