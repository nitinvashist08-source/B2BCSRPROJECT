"use client";

import { useState } from "react";
import { CommitteeMember } from "@/types/meeting";
import { useMeetingStore } from "@/store/meetingStore";
import { useSessionStore } from "@/store/sessionStore";
import { useWorkspaceStore } from "@/store/workspaceStore";

// stc-mem-role/mtg-mem-role options, bImpact_MeetingSplit_v10.html:10174-10202
const ROLE_OPTIONS = [
  "Chairperson",
  "Vice Chairperson",
  "Managing Director",
  "Chief Executive Officer (CEO)",
  "Chief Financial Officer (CFO)",
  "Chief Operating Officer (COO)",
  "Independent Director",
  "Board Member",
  "CSR Head",
  "CSR Director",
  "CSR Manager",
  "Programme Lead",
  "Programme Officer",
  "Field Coordinator",
  "Company Secretary",
  "Compliance Officer",
  "Legal Counsel",
  "Finance Lead",
  "HR Head",
  "Monitoring & Evaluation Lead",
  "Communication Lead",
  "Audit Lead",
  "Risk Officer",
  "NGO Representative",
  "Government Liaison",
  "Technical Expert",
  "External Consultant",
  "Others",
];

// colors, bImpact_MeetingSplit_v10.html:12609 — cycled by committee size at
// save time, not stored per-member ahead of time.
const MEMBER_COLORS = ["#0A97D9", "#00A651", "#7C3AED", "#0891B2", "#D97706", "#059669", "#BE185D", "#DC2626", "#9333EA", "#0D9488"];

function CloseIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}
function UserPlusIcon() {
  return (
    <svg fill="none" height="18" width="18" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

type FieldKey = "name" | "email" | "role" | "reportsTo";

// stc-mem-so/mtg-mem-so, bImpact_MeetingSplit_v10.html:10158-10212 — Add
// Committee Member / Add Subordinate / Edit Member all share this one form.
// `defaultParentId` preselects Reports To for "Add Subordinate" (the user
// can still change it); the very first member for a period gets no Reports
// To field at all and becomes the tree's root.
export function MemberFormSlideOver({
  open,
  onClose,
  editing,
  defaultParentId,
}: {
  open: boolean;
  onClose: () => void;
  editing: CommitteeMember | null;
  defaultParentId: string | null;
}) {
  const committee = useMeetingStore((s) => s.committee);
  const addMember = useMeetingStore((s) => s.addMember);
  const editMember = useMeetingStore((s) => s.editMember);
  const isFirst = committee.length === 0 && !editing;

  // Organization field removed from this form — every CSR Committee member
  // belongs to the same organization the committee itself is managed under,
  // so a new member just inherits it automatically instead of asking. Reuses
  // the same session workspaceId → Workspace.name link ProjectsTable.tsx
  // already resolves the Sponsor's org name from, not a new lookup.
  const workspaceId = useSessionStore((s) => s.workspaceId);
  const getWorkspace = useWorkspaceStore((s) => s.getWorkspace);
  const currentOrganization = getWorkspace(workspaceId ?? "")?.name ?? "";

  // Sentinel for "no parent / top-level" — distinct from "" (the add-flow's
  // unselected placeholder) so editing a root member (or one whose only
  // valid parents would be circular) always has a selectable, valid value
  // rather than an unsolvable required-but-empty dropdown.
  const ROOT = "__root__";

  const [name, setName] = useState(editing?.name ?? "");
  const [email, setEmail] = useState(editing?.email ?? "");
  const [role, setRole] = useState(editing?.role ?? "");
  const [reportsToId, setReportsToId] = useState(
    editing ? (editing.reportsToId ?? ROOT) : (defaultParentId ?? "")
  );
  const [errors, setErrors] = useState<Set<FieldKey>>(new Set());

  // Rule 5: a member must never report to themself or one of their own
  // subordinates (would create a cycle in the tree).
  function descendantIds(id: string): Set<string> {
    const ids = new Set<string>();
    let grew = true;
    while (grew) {
      grew = false;
      for (const m of committee) {
        if (m.reportsToId && (m.reportsToId === id || ids.has(m.reportsToId)) && !ids.has(m.id)) {
          ids.add(m.id);
          grew = true;
        }
      }
    }
    return ids;
  }
  const blockedParentIds = editing ? new Set([editing.id, ...descendantIds(editing.id)]) : new Set<string>();
  const reportsToOptions = committee.filter((m) => !blockedParentIds.has(m.id));

  const showReportsTo = !isFirst;

  function handleClose() {
    onClose();
  }

  // stcSaveMem, bImpact_MeetingSplit_v10.html:12591-12619 — field-level
  // validation highlights each empty required field in red rather than a
  // single blocking alert.
  function handleSave() {
    const bad = new Set<FieldKey>();
    if (!name.trim()) bad.add("name");
    if (!email.trim()) bad.add("email");
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) bad.add("email");
    if (!role) bad.add("role");
    // Editing always has a valid reportsToId (a real id or the ROOT
    // sentinel) — only the add flow can be left unselected.
    if (showReportsTo && !editing && !reportsToId) bad.add("reportsTo");
    setErrors(bad);
    if (bad.size > 0) return;

    const payload = {
      name: name.trim(),
      email: email.trim(),
      role,
      reportsToId: showReportsTo && reportsToId && reportsToId !== ROOT ? reportsToId : null,
    };
    if (editing) {
      // No `organization` in the patch — an existing member's organization
      // (set back when this form still asked for it) is preserved as-is,
      // never overwritten by this form again.
      editMember(editing.id, payload);
    } else {
      addMember({
        ...payload,
        organization: currentOrganization,
        color: MEMBER_COLORS[committee.length % MEMBER_COLORS.length],
      });
    }
    handleClose();
  }

  const title = editing ? "Edit Committee Member" : "Add Committee Member";
  const subtitle = editing
    ? "Update the member's details and reporting relationship."
    : "Add a member and define their role and reporting relationship within the committee.";

  const inputCls = (key: FieldKey) =>
    `box-border h-10 w-full rounded-sm border-[1.5px] bg-bg px-3 text-sm text-ink outline-none transition-colors focus:border-primary ${
      errors.has(key) ? "border-danger" : "border-border"
    }`;

  return (
    <>
      <div
        className={`fixed inset-0 z-[900] bg-black/40 transition-opacity ${open ? "opacity-100" : "pointer-events-none opacity-0"}`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) handleClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[901] flex h-full w-[420px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 border-b border-border px-5 py-4">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-sm bg-primary-50 text-primary">
            <UserPlusIcon />
          </span>
          <div>
            <div className="text-[0.95rem] font-bold text-ink">{title}</div>
            <div className="mt-px text-[11.5px] text-muted">{subtitle}</div>
          </div>
          <button onClick={handleClose} className="ml-auto flex h-8 w-8 shrink-0 items-center justify-center rounded-sm text-muted hover:bg-bg hover:text-ink">
            <CloseIcon />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          <div className="mb-3.5">
            <label className="mb-1.5 block text-[12.5px] font-semibold text-ink-2">
              Full Name <span className="text-danger">*</span>
            </label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter full name" className={inputCls("name")} />
          </div>

          <div className="mb-3.5">
            <label className="mb-1.5 block text-[12.5px] font-semibold text-ink-2">
              Email ID <span className="text-danger">*</span>
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter email address"
              className={inputCls("email")}
            />
          </div>

          <div className="mb-3.5">
            <label className="mb-1.5 block text-[12.5px] font-semibold text-ink-2">
              Role <span className="text-danger">*</span>
            </label>
            <select value={role} onChange={(e) => setRole(e.target.value)} className={inputCls("role")}>
              <option value="">Select role…</option>
              {ROLE_OPTIONS.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          {showReportsTo && (
            <div className="mb-3.5">
              <label className="mb-1.5 block text-[12.5px] font-semibold text-ink-2">
                Reports To {!editing && <span className="text-danger">*</span>}
              </label>
              <select value={reportsToId} onChange={(e) => setReportsToId(e.target.value)} className={inputCls("reportsTo")}>
                {editing ? (
                  <option value={ROOT}>— Top level (no parent) —</option>
                ) : (
                  <option value="">Select committee member…</option>
                )}
                {reportsToOptions.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({m.role})
                  </option>
                ))}
              </select>
              <div className="mt-1.5 text-[11px] text-muted">Select who this member reports to in the committee.</div>
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
          <button onClick={handleClose} className="flex h-9 items-center rounded-sm border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 hover:border-border-strong">
            Cancel
          </button>
          <button onClick={handleSave} className="flex h-9 items-center rounded-sm bg-primary px-4 text-sm font-semibold text-white hover:bg-primary-600">
            {editing ? "Save Changes" : "Save Member"}
          </button>
        </div>
      </div>
    </>
  );
}
