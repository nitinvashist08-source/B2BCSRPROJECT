"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useMeetingStore } from "@/store/meetingStore";

export function FeedbackModal({
  open,
  onClose,
  meetingId,
}: {
  open: boolean;
  onClose: () => void;
  meetingId: string;
}) {
  const saveDraft = useMeetingStore((s) => s.saveDraft);
  const meeting = useMeetingStore((s) => s.meetings.find((m) => m.id === meetingId));
  const [remarks, setRemarks] = useState(meeting?.signoff.remarks ?? "");

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Leave feedback"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={() => {
              if (meeting) saveDraft(meetingId, { signoff: { ...meeting.signoff, remarks } });
              onClose();
            }}
          >
            Save feedback
          </Button>
        </>
      }
    >
      <textarea
        value={remarks}
        onChange={(e) => setRemarks(e.target.value)}
        rows={4}
        placeholder="How did this meeting go?"
        className="w-full rounded-sm border border-border px-3 py-2 text-sm outline-none focus:border-primary"
      />
    </Modal>
  );
}
