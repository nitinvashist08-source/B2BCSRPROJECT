"use client";

import { useState } from "react";
import Link from "next/link";
import { Meeting, MEETING_STATUS_LABEL } from "@/types/meeting";
import { Button } from "@/components/ui/Button";

const STATUS_PILL: Record<Meeting["status"], string> = {
  Draft: "bg-surface-2 text-muted",
  Upcoming: "bg-primary-50 text-primary-700",
  InProgress: "bg-amber-50 text-amber-600",
  Completed: "bg-secondary-50 text-secondary-600",
};

function BackIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}
function SendIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="22" y1="2" x2="11" y2="13" />
      <polygon points="22 2 15 22 11 13 2 9 22 2" />
    </svg>
  );
}
function PlayIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <polygon points="5 3 19 12 5 21 5 3" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
function MoreIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="1" />
      <circle cx="12" cy="5" r="1" />
      <circle cx="12" cy="19" r="1" />
    </svg>
  );
}

// mtg-mom-topbar, bImpact_MeetingSplit_v10.html:10046-10101 — row 1 is
// back-nav + id + status pill + status-specific CTAs + an overflow menu;
// row 2 is the live title label + a 2-step phase bar (Setup & Invite /
// Execute & MoM). CTA visibility per status: :10670-10678.
export function MeetingMOMHeader({
  meeting,
  titleOverride,
  onSaveDraft,
  onSendInvite,
  onStartMeeting,
  onMarkComplete,
  onShareMoM,
  onDelete,
}: {
  meeting: Meeting;
  titleOverride?: string;
  onSaveDraft?: () => void;
  onSendInvite?: () => void;
  onStartMeeting?: () => void;
  onMarkComplete?: () => void;
  onShareMoM?: () => void;
  onDelete: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const phase = meeting.status === "InProgress" || meeting.status === "Completed" ? 2 : 1;

  return (
    <div className="sticky top-0 z-10 mb-4 flex flex-col border-b border-border bg-surface">
      {/* Row 1, mtg-mom-topbar-row1 (source :9597 — padding:10px 24px;
          border-bottom:1px solid var(--border)): back-nav + id + status +
          ml-auto CTAs. */}
      <div className="flex items-center gap-3 border-b border-border px-6 py-2.5">
        <Link
          href="/meetings"
          className="inline-flex h-[30px] shrink-0 items-center gap-1.5 rounded-md border border-border bg-surface px-3 text-xs font-semibold text-ink-2 transition-colors hover:bg-bg"
        >
          <BackIcon />
          All Meetings
        </Link>
        <span className="shrink-0 truncate font-mono text-[11px] font-bold tracking-wide text-muted">{meeting.id}</span>
        <span className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${STATUS_PILL[meeting.status]}`}>
          {MEETING_STATUS_LABEL[meeting.status]}
        </span>

        <div className="ml-auto flex shrink-0 items-center gap-2">
          {meeting.status === "Draft" && (
            <>
              <Button size="sm" variant="ghost" onClick={onSaveDraft}>
                Save Draft
              </Button>
              <Button size="sm" onClick={onSendInvite}>
                <SendIcon />
                Send Invite
              </Button>
            </>
          )}
          {meeting.status === "Upcoming" && (
            <Button size="sm" onClick={onStartMeeting}>
              <PlayIcon />
              Start Meeting
            </Button>
          )}
          {meeting.status === "InProgress" && (
            <Button size="sm" variant="secondary" onClick={onMarkComplete}>
              <CheckIcon />
              Mark Complete
            </Button>
          )}
          {meeting.status === "Completed" && !meeting.signoff.confirmed && (
            <Button size="sm" onClick={onShareMoM}>
              <SendIcon />
              Share MoM
            </Button>
          )}

          <div className="relative">
            <button
              onClick={() => setMenuOpen((o) => !o)}
              className="flex h-7 w-7 items-center justify-center rounded-sm border border-border bg-surface text-muted hover:border-border-strong"
            >
              <MoreIcon />
            </button>
            {menuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
                <div className="absolute right-0 top-9 z-20 min-w-[160px] rounded-sm border border-border bg-surface p-1 shadow-md">
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onDelete();
                    }}
                    className="block w-full rounded-sm px-3 py-2 text-left text-sm text-danger hover:bg-danger-50"
                  >
                    Delete Meeting
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Row 2, mtg-mom-topbar-row2 (source :9598 — padding:12px 24px;
          gap:16px): title + phase bar, same row, right-aligned stepper
          (matches source's .mtg-phase-bar{margin-left:auto}). Deliberately
          NOT flex-wrap this time — the earlier collision bug came from
          wrapping without space for the title, not from sharing a row at
          all. min-w-0 + truncate lets the title give way instead of ever
          pushing the stepper down or off. */}
      <div className="flex items-center gap-4 px-6 py-3">
        <h2 className="min-w-0 flex-1 truncate text-[15px] font-bold text-ink">
          {(titleOverride ?? meeting.title) || "Untitled Meeting"}
        </h2>
        <div className="ml-auto flex shrink-0 items-center gap-2">
          <PhaseStep num={1} label="Setup & Invite" state={phase === 1 ? "active" : "done"} />
          {/* source .mtg-phase-arrow: width:32px;height:1px */}
          <span className="h-px w-8 bg-border" />
          <PhaseStep num={2} label="Execute & MoM" state={phase === 2 ? "active" : "pending"} />
        </div>
      </div>
    </div>
  );
}

function PhaseStep({ num, label, state }: { num: number; label: string; state: "active" | "done" | "pending" }) {
  // .mtg-phase-step/.mtg-phase-num, source :9606-9611 — every step is the
  // same pill shape (padding:4px 14px, radius:999px, 12px/600); only
  // "active" gets a filled background+border, "done" just recolors the
  // text secondary, "pending" stays muted. The numeral circle is the one
  // element that's actually filled for BOTH active and done (2px border,
  // solid bg + white digit) — only "pending" is a plain unfilled outline.
  const pillCls =
    state === "active" ? "bg-primary-50 border border-primary-100 text-primary" : state === "done" ? "text-secondary" : "text-muted";
  const numCls =
    state === "active"
      ? "border-primary bg-primary text-white"
      : state === "done"
        ? "border-secondary bg-secondary text-white"
        : "border-current text-muted";
  return (
    <div className={`flex items-center gap-2 rounded-full px-3.5 py-1 text-xs font-semibold ${pillCls}`}>
      <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 text-[10px] font-extrabold ${numCls}`}>
        {num}
      </span>
      <span>{label}</span>
    </div>
  );
}
