"use client";

import { useState } from "react";
import { useMeetingStore } from "@/store/meetingStore";
import { CommitteeMember } from "@/types/meeting";
import { OrgChartNode } from "./OrgChartNode";

function UsersIcon() {
  return (
    <svg fill="none" height="32" width="32" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}
function PlusIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}

// mtgRenderOrgChart/stcRenderOrgChart, bImpact_MeetingSplit_v10.html:10345+,
// :12454-12478 — the org-chart tree for the currently active committee
// period (`committee` mirrors it — see meetingStore.ts). This is now the
// single CSR Committee experience, so there's no read-only variant.
export function OrgChart({
  onAddRoot,
  onAddChild,
  onEdit,
  onRemove,
}: {
  onAddRoot: () => void;
  onAddChild: (parentId: string) => void;
  onEdit: (member: CommitteeMember) => void;
  onRemove: (member: CommitteeMember) => void;
}) {
  const committee = useMeetingStore((s) => s.committee);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const roots = committee.filter((m) => !m.reportsToId);

  if (committee.length === 0) {
    return (
      <div className="flex flex-col items-center gap-1 rounded-md bg-bg px-6 py-14 text-center">
        <span className="mb-1 flex h-[52px] w-[52px] items-center justify-center rounded-md border border-border bg-surface text-muted">
          <UsersIcon />
        </span>
        <div className="text-[14.5px] font-bold text-ink">No committee members yet</div>
        <p className="max-w-[360px] text-[12.5px] leading-snug text-muted">
          Start building the committee structure by adding the first committee member.
        </p>
        <button
          onClick={onAddRoot}
          className="mt-3 inline-flex h-10 items-center gap-2 rounded-sm bg-primary px-[22px] text-sm font-semibold text-white hover:bg-primary-600"
        >
          <PlusIcon />
          Add Member
        </button>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-md bg-bg px-6 py-8">
      <div className="flex flex-wrap justify-center gap-10">
        {roots.map((r) => (
          <OrgChartNode
            key={r.id}
            member={r}
            isRoot
            collapsedMap={collapsed}
            onToggleCollapse={(id) => setCollapsed((c) => ({ ...c, [id]: !c[id] }))}
            onAddChild={onAddChild}
            onEdit={onEdit}
            onRemove={onRemove}
          />
        ))}
      </div>
    </div>
  );
}
