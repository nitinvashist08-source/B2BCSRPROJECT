"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

function CommitteeIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}
function MeetingsIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}
function PolicyIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
    </svg>
  );
}

const TABS = [
  { href: "/meetings/committee", label: "CSR Committee", icon: CommitteeIcon },
  {
    href: "/meetings",
    label: "Meetings",
    icon: MeetingsIcon,
    match: (p: string) => p === "/meetings" || /^\/meetings\/[^/]+$/.test(p),
  },
  { href: "/meetings/policy", label: "CSR Policy", icon: PolicyIcon },
];

// mtg-tab-bar / mtg-main-tab, bImpact_MeetingSplit_v10.html:9473-9476 —
// icon + label tabs, 2.5px underline that only appears (in primary) on the
// active tab; font-weight bumps from 500 to 600 only when active.
export function MeetingsTabs() {
  const pathname = usePathname();

  return (
    <div className="flex items-center gap-0.5 border-b border-border">
      {TABS.map((tab) => {
        const active = tab.match ? tab.match(pathname) : pathname === tab.href;
        const Icon = tab.icon;
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className={`flex items-center gap-[7px] border-b-[2.5px] px-[18px] py-2.5 text-[13px] ${
              active
                ? "border-primary font-semibold text-primary"
                : "border-transparent font-medium text-muted hover:text-ink"
            }`}
          >
            <Icon />
            {tab.label}
          </Link>
        );
      })}
    </div>
  );
}
