"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useMeetingStore } from "@/store/meetingStore";
import { Meeting } from "@/types/meeting";
import { Button } from "@/components/ui/Button";
import { MeetingCard } from "./MeetingCard";
import { DeleteMeetingModal } from "./DeleteMeetingModal";

function PlusIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function CalendarIcon() {
  return (
    <svg fill="none" height="26" width="26" stroke="currentColor" strokeWidth="1.6" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}

// mtgNewMeeting, bImpact_MeetingSplit_v10.html:10548-10561 — "New Meeting"
// has no creation form: it instantly creates a blank Draft and navigates
// straight into its Setup form. No NewMeetingSlideOver-style pre-creation
// dialog exists in source.
export function MeetingList() {
  const meetings = useMeetingStore((s) => s.meetings);
  const createMeeting = useMeetingStore((s) => s.createMeeting);
  const router = useRouter();
  const [deleteTarget, setDeleteTarget] = useState<Meeting | null>(null);

  const sorted = [...meetings].sort((a, b) => (a.date < b.date ? 1 : -1));

  function handleNewMeeting() {
    const id = createMeeting();
    router.push(`/meetings/${id}`);
  }

  return (
    // ~20-25% of the workspace on common desktop widths, clamped so it never
    // gets so narrow that titles/badges become unreadable, nor so wide that
    // it eats into the detail panel on smaller laptop screens.
    <div className="flex w-[22%] min-w-[260px] max-w-[340px] shrink-0 flex-col border-r border-border">
      {/* mtg-list-col-hd, source :10018-10023 — title + compact CTA on one
          row, 14px/16px padding, border-bottom separating it from the cards. */}
      <div className="flex shrink-0 items-center justify-between gap-2 border-b border-border px-4 py-3.5">
        <span className="text-[13.5px] font-bold text-ink">Meetings</span>
        <Button size="sm" onClick={handleNewMeeting}>
          <PlusIcon />
          New Meeting
        </Button>
      </div>
      <div className="flex flex-col gap-2 overflow-y-auto p-2">
        {sorted.length === 0 ? (
          <div className="flex flex-col items-center gap-2 rounded-md bg-bg px-4 py-10 text-center">
            <span className="mb-1 flex h-11 w-11 items-center justify-center rounded-full border border-border bg-surface text-muted">
              <CalendarIcon />
            </span>
            <div className="text-sm font-bold text-ink">No meetings yet</div>
            <p className="text-xs leading-snug text-muted">Create a meeting to get started.</p>
            <Button size="sm" onClick={handleNewMeeting} className="mt-1">
              <PlusIcon />
              New Meeting
            </Button>
          </div>
        ) : (
          sorted.map((m) => <MeetingCard key={m.id} meeting={m} onDelete={() => setDeleteTarget(m)} />)
        )}
      </div>
      <DeleteMeetingModal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        meetingId={deleteTarget?.id ?? ""}
        meetingTitle={deleteTarget?.title ?? ""}
      />
    </div>
  );
}
