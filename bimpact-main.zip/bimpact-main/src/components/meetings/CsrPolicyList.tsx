"use client";

import { useState } from "react";
import { useMeetingStore } from "@/store/meetingStore";
import { CsrPolicy } from "@/types/meeting";
import { Button } from "@/components/ui/Button";
import { CsrPolicyEditor } from "./CsrPolicyEditor";
import { CsrPolicyPreview } from "./CsrPolicyPreview";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// csrpFmtDate, bImpact_MeetingSplit_v10.html:12099-12103
export function fmtPolicyDate(iso: string) {
  if (!iso) return "—";
  const [y, m, d] = iso.split("-");
  return `${d.padStart(2, "0")} ${MONTHS[parseInt(m, 10) - 1] ?? ""} ${y}`;
}
// csrpFmtPeriod, bImpact_MeetingSplit_v10.html:12261-12266
export function fmtPolicyPeriod(p: { startDate: string; endDate: string }) {
  if (!p.startDate && !p.endDate) return "—";
  const start = p.startDate ? fmtPolicyDate(p.startDate) : "?";
  const end = p.endDate ? fmtPolicyDate(p.endDate) : "?";
  return `${start} – ${end}`;
}

function PlusIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function DocIcon({ size = 28 }: { size?: number }) {
  return (
    <svg fill="none" height={size} width={size} stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
    </svg>
  );
}

export function StatusBadge({ status }: { status: CsrPolicy["status"] }) {
  const cls =
    status === "Published"
      ? "bg-secondary-50 text-secondary-600 border border-secondary-100"
      : "bg-amber-50 text-amber-600 border border-amber-100";
  return <span className={`rounded-full px-2.5 py-0.5 text-[11.5px] font-bold ${cls}`}>{status}</span>;
}

// A policy row's action is now View-only (opens the read-only
// CsrPolicyPreview) — Edit and Publish/Unpublish moved into Preview itself
// (see CsrPolicyPreview.tsx), so there's exactly one entry point into a
// policy's Editable Mode (via Preview's Edit button) instead of two
// divergent ones, and Unpublish always goes through Preview's confirmation
// dialog.
type View = { mode: "new" } | { mode: "preview"; id: string } | { mode: "edit"; id: string } | null;

// csrpRenderList, bImpact_MeetingSplit_v10.html:12118-12172 — the Settings
// (editable) register: a table, not cards (the Management mirror uses
// cards — see CsrPolicyReadOnlyList.tsx).
export function CsrPolicyList() {
  const policies = useMeetingStore((s) => s.policies);
  const [view, setView] = useState<View>(null);

  if (view?.mode === "new") {
    return <CsrPolicyEditor editing={null} onDone={() => setView(null)} />;
  }
  if (view?.mode === "edit") {
    const policy = policies.find((p) => p.id === view.id);
    if (policy) {
      // After a successful update, land back in Preview showing the
      // updated content — never back to the bare list (see this project's
      // CSR Policy Preview requirements: "Update Policy" → Preview Mode).
      return <CsrPolicyEditor editing={policy} onDone={() => setView({ mode: "preview", id: policy.id })} />;
    }
  }
  if (view?.mode === "preview") {
    const policy = policies.find((p) => p.id === view.id);
    if (policy) {
      return (
        <CsrPolicyPreview
          policy={policy}
          onBack={() => setView(null)}
          onEdit={() => setView({ mode: "edit", id: policy.id })}
        />
      );
    }
  }

  const listed = [...policies].reverse();

  return (
    <div>
      <div className="mb-7 flex items-start justify-between gap-4">
        <div>
          <div className="text-[1.25rem] font-extrabold tracking-[-0.02em] text-ink">CSR Policy</div>
          <p className="mt-[3px] text-[13px] leading-snug text-muted">
            Manage your CSR policy documents across financial years.
          </p>
        </div>
        <Button onClick={() => setView({ mode: "new" })} className="shrink-0">
          <PlusIcon />
          Create CSR Policy
        </Button>
      </div>

      {listed.length === 0 ? (
        <div className="flex flex-col items-center gap-2 rounded-md bg-bg px-6 py-14 text-center">
          <span className="mb-2 flex h-[52px] w-[52px] items-center justify-center rounded-md border border-border bg-surface text-muted">
            <DocIcon />
          </span>
          <div className="text-[18px] font-extrabold text-ink">No CSR Policies yet</div>
          <p className="max-w-[420px] text-[13.5px] leading-relaxed text-muted">
            Create your first CSR Policy document to record your organisation&rsquo;s commitment, governance
            framework and annual spend plan.
          </p>
          <Button onClick={() => setView({ mode: "new" })} className="mt-2">
            <PlusIcon />
            Create CSR Policy
          </Button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-muted">
                <th className="py-2 font-medium">Policy Period</th>
                <th className="py-2 font-medium">Status</th>
                <th className="py-2 font-medium">Last Updated</th>
                <th className="w-[100px] py-2 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {listed.map((p) => (
                <tr key={p.id} className="border-b border-border">
                  <td className="py-3 pr-2 font-semibold text-ink">{fmtPolicyPeriod(p)}</td>
                  <td className="py-3 pr-2">
                    <StatusBadge status={p.status} />
                  </td>
                  <td className="py-3 pr-2 text-muted">{fmtPolicyDate(p.updatedAt || p.createdAt)}</td>
                  <td className="py-3 text-right">
                    <Button size="sm" variant="ghost" onClick={() => setView({ mode: "preview", id: p.id })}>
                      View
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
