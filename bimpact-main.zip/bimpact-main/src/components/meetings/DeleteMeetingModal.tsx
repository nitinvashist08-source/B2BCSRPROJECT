"use client";

import { useRouter } from "next/navigation";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useMeetingStore } from "@/store/meetingStore";

export function DeleteMeetingModal({
  open,
  onClose,
  meetingId,
  meetingTitle,
}: {
  open: boolean;
  onClose: () => void;
  meetingId: string;
  meetingTitle: string;
}) {
  const deleteMeeting = useMeetingStore((s) => s.deleteMeeting);
  const router = useRouter();

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Delete meeting?"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              deleteMeeting(meetingId);
              onClose();
              router.push("/meetings");
            }}
          >
            Delete
          </Button>
        </>
      }
    >
      This will permanently delete <strong>{meetingTitle}</strong>, including its agenda, notes,
      and action items. This can&apos;t be undone.
    </Modal>
  );
}
