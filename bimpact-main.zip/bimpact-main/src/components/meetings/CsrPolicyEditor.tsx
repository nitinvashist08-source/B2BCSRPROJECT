"use client";

import { useState } from "react";
import { CsrPolicy } from "@/types/meeting";
import { latestPolicy, useMeetingStore } from "@/store/meetingStore";
import { Button } from "@/components/ui/Button";
import { DocumentEditorCanvas } from "@/components/documents/DocumentEditorCanvas";
import { fmtPolicyPeriod } from "./CsrPolicyList";

const emptyDraft = { startDate: "", endDate: "", content: "" };

function BackIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

// csrpRenderEditor, bImpact_MeetingSplit_v10.html:12192-12258 — breadcrumb +
// status badge + Save as Draft / Publish (Publish hidden once already
// Published — unpublishing only happens from the list row); Policy Start/End
// Date fields; Policy Content uses the same document editor as Project
// Details → Documents (see DocumentEditorCanvas) rather than a CSR-specific
// rich-text editor.
export function CsrPolicyEditor({
  editing,
  onDone,
}: {
  editing: CsrPolicy | null;
  onDone: () => void;
}) {
  const policies = useMeetingStore((s) => s.policies);
  const savePolicy = useMeetingStore((s) => s.savePolicy);
  const updatePolicy = useMeetingStore((s) => s.updatePolicy);
  const publishPolicy = useMeetingStore((s) => s.publishPolicy);
  const prefillSource = editing ? null : latestPolicy(policies);
  const [draft, setDraft] = useState(
    editing
      ? { startDate: editing.startDate, endDate: editing.endDate, content: editing.content }
      : { ...emptyDraft, content: prefillSource?.content ?? "" }
  );
  const status = editing?.status ?? "Draft";

  function handleSaveDraft() {
    if (!draft.startDate || !draft.endDate) return;
    if (editing) updatePolicy(editing.id, draft);
    else savePolicy(draft, false);
    onDone();
  }

  function handlePublish() {
    if (!draft.startDate || !draft.endDate) return;
    if (editing) {
      updatePolicy(editing.id, draft);
      publishPolicy(editing.id);
    } else {
      savePolicy(draft, true);
    }
    onDone();
  }

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={onDone}
            className="inline-flex h-7 items-center gap-1.5 rounded-sm border border-border bg-surface px-2.5 text-xs font-semibold text-ink-2 hover:border-border-strong"
          >
            <BackIcon />
            Policies
          </button>
          <span className="text-border">/</span>
          <span className="text-[13.5px] font-semibold text-ink">
            {editing ? fmtPolicyPeriod(editing) : "New Policy"}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span
            className={`rounded-full px-3 py-1 text-[11.5px] font-bold ${
              status === "Published"
                ? "bg-secondary-50 text-secondary-600 border border-secondary-100"
                : "bg-amber-50 text-amber-600 border border-amber-100"
            }`}
          >
            {status}
          </span>
          {/* A Published policy must never see "Save as Draft" — editing it
              only ever updates the same record in place and never demotes
              its status (updatePolicy's patch below carries no `status`
              field either way), so the label is the only thing that
              changes here. */}
          <Button size="sm" variant={status === "Published" ? "secondary" : "ghost"} onClick={handleSaveDraft}>
            {status === "Published" ? "Update Policy" : "Save as Draft"}
          </Button>
          {status !== "Published" && (
            <Button size="sm" variant="secondary" onClick={handlePublish}>
              <CheckIcon />
              Publish
            </Button>
          )}
        </div>
      </div>

      <div className="mb-5 grid grid-cols-2 gap-3.5">
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-muted">
            Policy Start Date <span className="text-danger">*</span>
          </span>
          <input
            type="date"
            value={draft.startDate}
            onChange={(e) => setDraft((d) => ({ ...d, startDate: e.target.value }))}
            className="h-[38px] w-full rounded-sm border border-border px-3 text-sm outline-none focus:border-primary"
          />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-muted">
            Policy End Date <span className="text-danger">*</span>
          </span>
          <input
            type="date"
            value={draft.endDate}
            onChange={(e) => setDraft((d) => ({ ...d, endDate: e.target.value }))}
            className="h-[38px] w-full rounded-sm border border-border px-3 text-sm outline-none focus:border-primary"
          />
        </label>
      </div>

      {prefillSource && (
        <p className="mb-1.5 text-xs text-primary-700">
          Content prefilled from the most recent CSR Policy. Edit, rewrite, or start fresh as needed.
        </p>
      )}
      <span className="mb-2 block text-xs font-bold uppercase tracking-wide text-muted">Policy Content</span>
      {/* Same document editor (toolbar + paper canvas) Project Details →
          Documents uses, via the shared DocumentEditorCanvas — no separate
          CSR-specific rich-text editor. No title prop: a policy's "title" is
          just its Start/End Date period shown above, not a separate field. */}
      <div className="relative flex h-[560px] min-h-[420px] flex-col overflow-hidden rounded-sm border border-border bg-[#f4f5f7]">
        <DocumentEditorCanvas
          canEdit
          contentHtml={draft.content}
          contentKey={editing?.id ?? "new"}
          onChange={(html) => setDraft((d) => ({ ...d, content: html }))}
          placeholder="Write your CSR policy content here…"
        />
      </div>
    </div>
  );
}
