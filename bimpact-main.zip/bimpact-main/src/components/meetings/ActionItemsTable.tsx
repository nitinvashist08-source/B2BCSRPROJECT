"use client";

import { useState } from "react";
import { useMeetingStore } from "@/store/meetingStore";
import { ActionItem, ActionStatus } from "@/types/meeting";
import { Badge, BadgeTone } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

const STATUS_TONE: Record<ActionStatus, BadgeTone> = {
  Open: "muted",
  "In-Progress": "amber",
  Done: "secondary",
};

const STATUSES: ActionStatus[] = ["Open", "In-Progress", "Done"];

function ChecklistIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="m9 11 3 3L22 4" />
      <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
    </svg>
  );
}

// This feature has no reachable equivalent in the source mockup (its own
// action-table code is written but never wired up) — kept as-is per
// product decision, just restyled with the same card+header shell used by
// every other section in this module so it doesn't look out of place next
// to them.
export function ActionItemsTable({ meetingId, actions }: { meetingId: string; actions: ActionItem[] }) {
  const addAction = useMeetingStore((s) => s.addAction);
  const removeAction = useMeetingStore((s) => s.removeAction);
  const setActionStatus = useMeetingStore((s) => s.setActionStatus);
  const [draft, setDraft] = useState({ task: "", owner: "", dueDate: "" });

  function handleAdd() {
    if (!draft.task.trim() || !draft.owner.trim()) return;
    addAction(meetingId, { ...draft, status: "Open" });
    setDraft({ task: "", owner: "", dueDate: "" });
  }

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-surface shadow-sm">
      <div className="flex items-center gap-1.5 border-b border-border bg-surface-2 px-[18px] py-3.5 text-xs font-bold uppercase tracking-wide text-ink-2">
        <ChecklistIcon />
        Action Items
      </div>
      <table className="w-full border-collapse text-sm [&_td:first-child]:pl-[18px] [&_td:last-child]:pr-[18px] [&_th:first-child]:pl-[18px] [&_th:last-child]:pr-[18px]">
        <thead>
          <tr className="border-b border-border text-left text-xs text-muted">
            <th className="py-2 font-medium">Task</th>
            <th className="py-2 font-medium">Owner</th>
            <th className="py-2 font-medium">Due date</th>
            <th className="py-2 font-medium">Status</th>
            <th className="py-2" />
          </tr>
        </thead>
        <tbody>
          {actions.map((a) => (
            <tr key={a.id} className="border-b border-border">
              <td className="py-2 pr-2">{a.task}</td>
              <td className="py-2 pr-2 text-ink-2">{a.owner}</td>
              <td className="py-2 pr-2 text-ink-2">{a.dueDate || "—"}</td>
              <td className="py-2 pr-2">
                <select
                  value={a.status}
                  onChange={(e) => setActionStatus(meetingId, a.id, e.target.value as ActionStatus)}
                  className="rounded-sm border border-border bg-transparent px-1.5 py-0.5 text-xs"
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                <span className="ml-2">
                  <Badge tone={STATUS_TONE[a.status]} dot={false}>
                    {a.status}
                  </Badge>
                </span>
              </td>
              <td className="py-2 text-right">
                <button
                  onClick={() => removeAction(meetingId, a.id)}
                  className="text-xs text-danger hover:underline"
                >
                  Remove
                </button>
              </td>
            </tr>
          ))}
          <tr>
            <td className="py-2 pr-2">
              <input
                value={draft.task}
                onChange={(e) => setDraft((d) => ({ ...d, task: e.target.value }))}
                placeholder="New action item"
                className="w-full rounded-sm border border-border px-2 py-1 text-sm outline-none focus:border-primary"
              />
            </td>
            <td className="py-2 pr-2">
              <input
                value={draft.owner}
                onChange={(e) => setDraft((d) => ({ ...d, owner: e.target.value }))}
                placeholder="Owner"
                className="w-full rounded-sm border border-border px-2 py-1 text-sm outline-none focus:border-primary"
              />
            </td>
            <td className="py-2 pr-2">
              <input
                type="date"
                value={draft.dueDate}
                onChange={(e) => setDraft((d) => ({ ...d, dueDate: e.target.value }))}
                className="w-full rounded-sm border border-border px-2 py-1 text-sm outline-none focus:border-primary"
              />
            </td>
            <td colSpan={2} className="py-2 text-right">
              <Button size="sm" variant="ghost" onClick={handleAdd}>
                + Add
              </Button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
