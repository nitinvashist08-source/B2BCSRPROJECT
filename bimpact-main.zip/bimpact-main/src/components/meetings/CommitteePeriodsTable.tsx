"use client";

import { useMeetingStore } from "@/store/meetingStore";
import { CommitteePeriod } from "@/types/meeting";

function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
// stcFmtDate, bImpact_MeetingSplit_v10.html:12347-12352
export function fmtDate(iso: string) {
  if (!iso) return "—";
  const [y, m, d] = iso.split("-");
  const month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][parseInt(m, 10) - 1] ?? "";
  return `${parseInt(d, 10)} ${month} ${y}`;
}
export function periodLabel(p: CommitteePeriod) {
  return `${fmtDate(p.startDate)} – ${fmtDate(p.endDate)}`;
}
// stcPeriodStatus, bImpact_MeetingSplit_v10.html:12354-12360
export function periodStatus(p: CommitteePeriod): "Expired" | "Upcoming" | "Active" {
  const t = todayIso();
  if (p.endDate < t) return "Expired";
  if (p.startDate > t) return "Upcoming";
  return "Active";
}
export function periodStatusLabel(p: CommitteePeriod): "Completed" | "Upcoming" | "Active" {
  const s = periodStatus(p);
  return s === "Expired" ? "Completed" : s;
}

const STATUS_CLS: Record<string, string> = {
  Active: "bg-secondary-50 text-secondary-600 border-secondary-100",
  Upcoming: "bg-amber-50 text-amber-600 border-amber-100",
  Completed: "bg-bg text-muted border-border",
};

function CalendarIcon() {
  return (
    <svg fill="none" height="22" width="22" stroke="currentColor" strokeWidth="1.6" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}

// Committees, one per period — click View to open that period's org-chart
// committee structure. New periods are created from the page header's
// "+ New Period" CTA, not from this section.
export function CommitteePeriodsTable({ onView }: { onView: (id: string) => void }) {
  const periods = useMeetingStore((s) => s.periods);

  return (
    <div className="rounded-md border border-border bg-surface p-3.5">
      <div className="mb-2.5 text-[13px] font-bold text-ink">Committee Periods</div>

      {periods.length === 0 ? (
        <div className="flex flex-col items-center gap-1 rounded-sm border border-dashed border-border bg-bg px-6 py-8 text-center">
          <span className="mb-1 flex h-11 w-11 items-center justify-center rounded-full bg-primary-50 text-primary">
            <CalendarIcon />
          </span>
          <div className="text-[13.5px] font-bold text-ink">No committee periods yet</div>
          <p className="max-w-[360px] text-[12px] leading-snug text-muted">
            Click <strong>+ New Period</strong> above to create the first CSR Committee period.
          </p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-sm border border-border">
          <table className="w-full table-fixed border-collapse text-[12.5px]">
            <thead>
              <tr className="bg-surface-2">
                <th className="w-[38%] px-3.5 py-2 text-left text-[10.5px] font-bold uppercase tracking-[0.05em] text-muted">Committee Period</th>
                <th className="w-[18%] px-3.5 py-2 text-left text-[10.5px] font-bold uppercase tracking-[0.05em] text-muted">Members</th>
                <th className="w-[20%] px-3.5 py-2 text-left text-[10.5px] font-bold uppercase tracking-[0.05em] text-muted">Status</th>
                <th className="w-[24%] px-3.5 py-2 text-right text-[10.5px] font-bold uppercase tracking-[0.05em] text-muted">Action</th>
              </tr>
            </thead>
            <tbody>
              {periods.map((p) => {
                const status = periodStatusLabel(p);
                return (
                  <tr key={p.id} className="border-t border-border">
                    <td className="px-3.5 py-3 font-semibold text-ink">{periodLabel(p)}</td>
                    <td className="px-3.5 py-3 text-ink-2">
                      {p.members.length} member{p.members.length !== 1 ? "s" : ""}
                    </td>
                    <td className="px-3.5 py-3">
                      <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-semibold ${STATUS_CLS[status]}`}>
                        {status}
                      </span>
                    </td>
                    <td className="px-3.5 py-3 text-right">
                      <button
                        onClick={() => onView(p.id)}
                        className="inline-flex h-7 items-center rounded-sm border-[1.5px] border-border bg-surface px-2.5 text-xs font-semibold text-ink-2 hover:border-border-strong"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
