"use client";

import { Meeting } from "@/types/meeting";
import { useMeetingStore } from "@/store/meetingStore";
import { Avatar } from "@/components/ui/Avatar";

function ClockIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
function PinIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
function CalIcon({ size = 12 }: { size?: number }) {
  return (
    <svg fill="none" height={size} width={size} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}
function AgendaIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="8" y1="6" x2="21" y2="6" />
      <line x1="8" y1="12" x2="21" y2="12" />
      <line x1="8" y1="18" x2="21" y2="18" />
      <line x1="3" y1="6" x2="3.01" y2="6" />
      <line x1="3" y1="12" x2="3.01" y2="12" />
      <line x1="3" y1="18" x2="3.01" y2="18" />
    </svg>
  );
}
function PeopleIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

// .mtg-ov-slbl, source :9824-9825 — an uppercase section label with a
// trailing hairline that fills the rest of the row.
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-2 mt-4 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-muted">
      {children}
      <span className="h-px flex-1 bg-border" />
    </div>
  );
}

// mtgRenderStep1Preview, bImpact_MeetingSplit_v10.html:10826-10871 — a
// single read-only recap card (title, meta chips, agenda w/ left accent
// border, attendee chips) reused across Upcoming/InProgress/Completed.
export function MeetingRecapCard({ meeting }: { meeting: Meeting }) {
  const committee = useMeetingStore((s) => s.committee);
  // mtgRenderStep1Preview, source :10854 — this recap lists present
  // attendees only; the separate live Attendance section
  // (MeetingExecutionSection.tsx) is where present/absent actually gets
  // tracked and shown side by side once execution starts.
  const invited = committee.filter((m) => meeting.attendees.present.includes(m.id));
  const attendeeCount = invited.length + meeting.attendees.guests.length;

  return (
    <div className="overflow-hidden rounded-[14px] border border-border bg-surface shadow-sm">
      {/* .mtg-ov-hd, source :9818-9819 */}
      <div className="flex items-center justify-between gap-3 border-b border-border bg-surface-2 px-5 py-3.5">
        <div className="flex items-center gap-2">
          <span className="text-primary">
            <CalIcon size={14} />
          </span>
          <span className="text-xs font-bold text-ink-2">Meeting Details</span>
        </div>
        <span className="font-mono text-[11px] font-bold tracking-wide text-muted">{meeting.id}</span>
      </div>

      <div className="p-5">
        {/* .mtg-ov-title, source :9821 */}
        <div className="mb-3.5 text-xl font-extrabold leading-tight tracking-tight text-ink">
          {meeting.title || "Untitled Meeting"}
        </div>

        {/* .mtg-ov-meta-i, source :9823 */}
        <div className="mb-1 flex flex-wrap gap-1.5">
          {meeting.date && (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-bg px-3 py-1.5 text-[12.5px] font-medium text-ink-2">
              <CalIcon />
              {meeting.date}
            </span>
          )}
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-bg px-3 py-1.5 text-[12.5px] font-medium text-ink-2">
            <ClockIcon />
            {meeting.startTime}–{meeting.endTime}
          </span>
          {meeting.location && (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-bg px-3 py-1.5 text-[12.5px] font-medium text-ink-2">
              <PinIcon />
              {meeting.location}
            </span>
          )}
        </div>

        {meeting.agendaHtml && (
          <>
            <SectionLabel>
              <AgendaIcon />
              Agenda
            </SectionLabel>
            {/* .mtg-ov-agenda, source :9826 */}
            <div
              className="rounded-r-md border-l-[3px] border-primary bg-bg px-3.5 py-3 text-[13.5px] leading-relaxed text-ink"
              dangerouslySetInnerHTML={{ __html: meeting.agendaHtml }}
            />
          </>
        )}

        {attendeeCount > 0 && (
          <>
            <SectionLabel>
              <PeopleIcon />
              Attendees ({attendeeCount})
            </SectionLabel>
            {/* .mtg-ov-att-chip, source :9829-9831 — committee = primary
                tint, guest = neutral surface-2 tint. */}
            <div className="flex flex-wrap gap-1.5">
              {invited.map((m) => (
                <span
                  key={m.id}
                  className="flex items-center gap-1.5 rounded-full border border-primary-100 bg-primary-50 py-1 pl-1 pr-2.5 text-xs font-semibold text-primary-700"
                >
                  <Avatar name={m.name} size="sm" color={m.color} />
                  {m.name}
                </span>
              ))}
              {meeting.attendees.guests.map((g) => (
                <span
                  key={g.id}
                  className="flex items-center gap-1.5 rounded-full border border-border bg-surface-2 py-1 pl-1 pr-2.5 text-xs font-semibold text-ink-2"
                >
                  <Avatar name={g.name} size="sm" />
                  {g.name} <span className="font-normal text-muted">(Guest)</span>
                </span>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
