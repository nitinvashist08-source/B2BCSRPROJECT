"use client";

import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useMeetingStore } from "@/store/meetingStore";

export function CloseMeetingModal({
  open,
  onClose,
  meetingId,
}: {
  open: boolean;
  onClose: () => void;
  meetingId: string;
}) {
  const markComplete = useMeetingStore((s) => s.markComplete);

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Mark meeting complete?"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={() => {
              markComplete(meetingId);
              onClose();
            }}
          >
            Mark complete
          </Button>
        </>
      }
    >
      This closes the meeting for further edits to attendance and notes. You&apos;ll still be able
      to share the minutes of meeting afterwards.
    </Modal>
  );
}
