"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Meeting, MEETING_STATUS_LABEL } from "@/types/meeting";
import { Badge, BadgeTone } from "@/components/ui/Badge";

const STATUS_TONE: Record<Meeting["status"], BadgeTone> = {
  Draft: "muted",
  Upcoming: "primary",
  InProgress: "amber",
  Completed: "secondary",
};

const ACCENT: Record<Meeting["status"], string> = {
  Draft: "bg-border-strong",
  Upcoming: "bg-primary",
  InProgress: "bg-amber",
  Completed: "bg-secondary",
};

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function fmtDay(iso: string) {
  const [, , d] = iso.split("-");
  return d ? parseInt(d, 10) : "—";
}
function fmtMon(iso: string) {
  const [, m] = iso.split("-");
  return m ? MONTHS[parseInt(m, 10) - 1] : "";
}
function PinIcon() {
  return (
    <svg fill="none" height="10" width="10" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
function TrashIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
    </svg>
  );
}

// mtgRenderMeetingList card, bImpact_MeetingSplit_v10.html:10520-10547 —
// left accent strip colored by status, day/month date block, hover-reveal
// delete icon.
export function MeetingCard({ meeting, onDelete }: { meeting: Meeting; onDelete: () => void }) {
  const pathname = usePathname();
  const active = pathname === `/meetings/${meeting.id}`;

  return (
    <Link
      href={`/meetings/${meeting.id}`}
      className={`group relative flex items-stretch gap-3 overflow-hidden rounded-lg border pr-3 ${
        active ? "border-primary bg-primary-50" : "border-border bg-surface hover:border-border-strong"
      }`}
    >
      <span className={`w-1 shrink-0 ${ACCENT[meeting.status]}`} />
      <div className="my-2 flex w-10 shrink-0 flex-col items-center justify-center rounded-md border border-border bg-bg py-1.5">
        <span className="text-base font-bold leading-none text-ink">{fmtDay(meeting.date)}</span>
        <span className="mt-0.5 text-[9px] font-bold uppercase tracking-wide text-muted">{fmtMon(meeting.date)}</span>
      </div>
      <div className="min-w-0 flex-1 py-2.5">
        <div className="flex items-center justify-between gap-2">
          <span className="truncate text-sm font-medium text-ink">{meeting.title || "Untitled Meeting"}</span>
          <Badge tone={STATUS_TONE[meeting.status]}>{MEETING_STATUS_LABEL[meeting.status]}</Badge>
        </div>
        <div className="mt-1 flex items-center gap-2 text-xs text-muted">
          <span>
            {meeting.startTime}–{meeting.endTime}
          </span>
          {meeting.location && (
            <span className="flex items-center gap-1 truncate">
              <PinIcon />
              {meeting.location}
            </span>
          )}
        </div>
      </div>
      <button
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onDelete();
        }}
        title="Delete meeting"
        className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-sm text-muted opacity-0 hover:bg-danger-50 hover:text-danger group-hover:opacity-100"
      >
        <TrashIcon />
      </button>
    </Link>
  );
}
