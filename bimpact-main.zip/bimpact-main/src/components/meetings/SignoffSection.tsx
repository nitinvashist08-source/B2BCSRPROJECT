"use client";

import { useMeetingStore } from "@/store/meetingStore";
import { Meeting } from "@/types/meeting";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";

function roBox(content: string) {
  // .mtg-sf-input (read-only variant), source :9764 — 38px/1.5px
  // border/8px radius, surface-2 fill.
  return (
    <div className="flex h-[38px] items-center rounded-lg border-[1.5px] border-border bg-surface-2 px-3 text-[13px] text-ink">
      {content || "—"}
    </div>
  );
}
function CheckCircleIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
function inputCls() {
  return "h-[38px] w-full rounded-lg border-[1.5px] border-border bg-bg px-3 text-[13px] text-ink outline-none focus:border-primary";
}

// mtgRenderSignoffV2, bImpact_MeetingSplit_v10.html:10957-11028 — a 4-field
// grid (Chaired By / Minutes Recorded By / Meeting Closed At / Next
// Meeting), a confirm checkbox with a dynamic label, and a bottom CTA that
// mirrors the topbar's Mark Complete / Share MoM action. Everything renders
// as plain grey read-only boxes once the meeting is Completed.
export function SignoffSection({
  meeting,
  readOnly,
  onMarkComplete,
  onShareMoM,
}: {
  meeting: Meeting;
  readOnly: boolean;
  onMarkComplete?: () => void;
  onShareMoM?: () => void;
}) {
  const committee = useMeetingStore((s) => s.committee);
  const saveDraft = useMeetingStore((s) => s.saveDraft);
  const signoff = meeting.signoff;

  function patch(next: Partial<Meeting["signoff"]>) {
    saveDraft(meeting.id, { signoff: { ...signoff, ...next } });
  }

  function toggleChair(id: string) {
    if (readOnly) return;
    const chairIds = signoff.chairIds.includes(id)
      ? signoff.chairIds.filter((c) => c !== id)
      : [...signoff.chairIds, id];
    patch({ chairIds });
  }

  const chairs = committee.filter((m) => signoff.chairIds.includes(m.id));

  return (
    <div className="overflow-hidden rounded-[14px] border border-border bg-surface shadow-sm">
      {/* This section is the "Closing & Sign-off" card inside
          mtgRenderExecutionSection, source :10948 — same icon-badge +
          title + subtitle header shape as the setup cards, just with a
          checkmark badge (secondary-50/secondary) instead of a numeral. */}
      <div className="flex items-center gap-3 border-b border-border bg-surface-2 px-5 py-4">
        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-secondary-50 text-secondary">
          <CheckCircleIcon />
        </span>
        <div>
          <div className="text-[13.5px] font-bold text-ink">Closing & Sign-off</div>
          <div className="mt-px text-xs text-muted">Chair confirmation and closure details</div>
        </div>
      </div>

      <div className="p-5">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wide text-muted">Meeting Chaired By</span>
          {readOnly ? (
            roBox(chairs.map((c) => c.name).join(", "))
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {committee.map((m) => (
                <button
                  key={m.id}
                  onClick={() => toggleChair(m.id)}
                  className={`flex items-center gap-1.5 rounded-full border px-2 py-1 text-xs ${
                    signoff.chairIds.includes(m.id)
                      ? "border-primary bg-primary-50 text-primary-700"
                      : "border-border text-ink-2"
                  }`}
                >
                  <Avatar name={m.name} size="sm" color={m.color} />
                  {m.name}
                </button>
              ))}
              {committee.length === 0 && <p className="text-xs text-muted">No committee members.</p>}
            </div>
          )}
        </div>

        <label className="block">
          <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wide text-muted">Minutes Recorded By</span>
          {readOnly ? (
            roBox(signoff.minutesPreparedBy)
          ) : (
            <input
              value={signoff.minutesPreparedBy}
              onChange={(e) => patch({ minutesPreparedBy: e.target.value })}
              placeholder="Name of person recording minutes"
              className={inputCls()}
            />
          )}
        </label>

        <label className="block">
          <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wide text-muted">Meeting Closed At</span>
          {readOnly ? (
            roBox(signoff.closingTime ?? "")
          ) : (
            <input
              type="time"
              value={signoff.closingTime ?? ""}
              onChange={(e) => patch({ closingTime: e.target.value })}
              className={inputCls()}
            />
          )}
        </label>

        <label className="block">
          <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wide text-muted">Next Meeting</span>
          {readOnly ? (
            roBox(signoff.nextMeeting ?? "")
          ) : (
            <input
              type="date"
              value={signoff.nextMeeting ?? ""}
              onChange={(e) => patch({ nextMeeting: e.target.value })}
              className={inputCls()}
            />
          )}
        </label>
      </div>

      {/* .mtg-sf-confirm, source :9770-9772 — 12px gap, 16/18px padding,
          10px radius. */}
      <label className="mt-4 flex items-start gap-3 rounded-[10px] border-[1.5px] border-secondary-100 bg-secondary-50 px-[18px] py-4 text-[13px]">
        <input
          type="checkbox"
          checked={signoff.confirmed}
          disabled={readOnly}
          onChange={(e) => patch({ confirmed: e.target.checked })}
          className="mt-0.5 h-[18px] w-[18px] shrink-0 accent-secondary"
        />
        <span className="font-semibold leading-relaxed text-secondary-700">
          {signoff.confirmed
            ? "✓ Minutes confirmed and approved by the Chair."
            : "I confirm that the above minutes are a true and accurate record of the meeting."}
        </span>
      </label>

      {/* source :11015/:11020 — mt-22px/pt-18px border-top; not-readonly is
          right-aligned only, readonly splits a left note from the CTA. */}
      <div className="mt-[22px] flex items-center justify-between gap-4 border-t border-border pt-[18px]">
        {!readOnly ? (
          <Button size="sm" variant="secondary" onClick={onMarkComplete} className="ml-auto">
            <CheckCircleIcon />
            Mark Complete
          </Button>
        ) : (
          !signoff.confirmed && (
            <>
              <p className="text-xs leading-relaxed text-muted">
                This meeting is completed. Share the Minutes of Meeting with all attendees.
              </p>
              <Button size="sm" onClick={onShareMoM} className="shrink-0">
                Share MoM with Attendees
              </Button>
            </>
          )
        )}
      </div>
      </div>
    </div>
  );
}
