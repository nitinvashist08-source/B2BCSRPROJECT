"use client";

import { useState } from "react";
import { Meeting } from "@/types/meeting";
import { useMeetingStore } from "@/store/meetingStore";
import { MeetingMOMHeader } from "./MeetingMOMHeader";
import { MeetingStep1Form, Step1FieldKey, Step1Local } from "./MeetingStep1Form";
import { MeetingUpcomingView } from "./MeetingUpcomingView";
import { MeetingExecutionSection } from "./MeetingExecutionSection";
import { AttendeesModal } from "./AttendeesModal";
import { DeleteMeetingModal } from "./DeleteMeetingModal";
import { CloseMeetingModal } from "./CloseMeetingModal";

function toLocal(m: Meeting): Step1Local {
  return { title: m.title, date: m.date, startTime: m.startTime, endTime: m.endTime, location: m.location };
}

function stripHtml(html: string) {
  return html.replace(/<[^>]*>/g, "").trim();
}

// mtgRenderMOM, bImpact_MeetingSplit_v10.html:10680-10693 — body switches
// entirely on status; this component owns the Draft-phase form state +
// validation (mtgSaveDraft/mtgSaveAndSendInvite, :16095-16129) and wires the
// shared topbar's status-specific CTAs.
export function MOMPanel({ meeting }: { meeting: Meeting }) {
  const saveDraft = useMeetingStore((s) => s.saveDraft);
  const sendInvite = useMeetingStore((s) => s.sendInvite);
  const startMeeting = useMeetingStore((s) => s.startMeeting);
  const shareMoM = useMeetingStore((s) => s.shareMoM);

  const [attendeesOpen, setAttendeesOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [closeOpen, setCloseOpen] = useState(false);

  const [local, setLocal] = useState<Step1Local>(() => toLocal(meeting));
  const [fieldErrors, setFieldErrors] = useState<Set<Step1FieldKey>>(new Set());
  const [formNotice, setFormNotice] = useState<string | null>(null);

  function validateRequired(l: Step1Local): Set<Step1FieldKey> {
    const bad = new Set<Step1FieldKey>();
    if (!l.title.trim()) bad.add("title");
    if (!l.date) bad.add("date");
    if (!l.startTime) bad.add("startTime");
    if (!l.endTime) bad.add("endTime");
    if (!l.location.trim()) bad.add("location");
    return bad;
  }

  function handleSaveDraft() {
    saveDraft(meeting.id, local);
    const bad = validateRequired(local);
    setFieldErrors(bad);
    setFormNotice(bad.size > 0 ? "Fill in the required fields to save this meeting." : null);
  }

  function handleSendInvite() {
    saveDraft(meeting.id, local);
    const bad = validateRequired(local);
    setFieldErrors(bad);
    if (bad.size > 0) {
      setFormNotice("Fill in the required fields before sending the invite.");
      return;
    }
    if (!stripHtml(meeting.agendaHtml)) {
      setFormNotice("Add an agenda before sending the invite.");
      return;
    }
    const attendeeCount = meeting.attendees.present.length + meeting.attendees.guests.length;
    if (attendeeCount === 0) {
      setFormNotice("Add at least one attendee before sending the invite.");
      return;
    }
    setFormNotice(null);
    sendInvite(meeting.id);
  }

  return (
    <div className="flex flex-col gap-4 pb-8">
      <MeetingMOMHeader
        meeting={meeting}
        titleOverride={meeting.status === "Draft" ? local.title : undefined}
        onSaveDraft={handleSaveDraft}
        onSendInvite={handleSendInvite}
        onStartMeeting={() => startMeeting(meeting.id)}
        onMarkComplete={() => setCloseOpen(true)}
        onShareMoM={() => shareMoM(meeting.id)}
        onDelete={() => setDeleteOpen(true)}
      />

      {meeting.status === "Draft" && (
        <MeetingStep1Form
          meeting={meeting}
          local={local}
          onFieldChange={(patch) => setLocal((l) => ({ ...l, ...patch }))}
          onFieldBlur={(patch) => saveDraft(meeting.id, patch)}
          fieldErrors={fieldErrors}
          formNotice={formNotice}
          onManageAttendees={() => setAttendeesOpen(true)}
        />
      )}
      {meeting.status === "Upcoming" && (
        <MeetingUpcomingView meeting={meeting} onStartMeeting={() => startMeeting(meeting.id)} />
      )}
      {(meeting.status === "InProgress" || meeting.status === "Completed") && (
        <MeetingExecutionSection
          meeting={meeting}
          readOnly={meeting.status === "Completed"}
          onManageAttendees={() => setAttendeesOpen(true)}
          onMarkComplete={() => setCloseOpen(true)}
        />
      )}

      <AttendeesModal open={attendeesOpen} onClose={() => setAttendeesOpen(false)} meeting={meeting} />
      <DeleteMeetingModal
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        meetingId={meeting.id}
        meetingTitle={meeting.title}
      />
      <CloseMeetingModal open={closeOpen} onClose={() => setCloseOpen(false)} meetingId={meeting.id} />
    </div>
  );
}
