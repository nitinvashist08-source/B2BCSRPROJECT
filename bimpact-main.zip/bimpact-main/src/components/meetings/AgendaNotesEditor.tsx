"use client";

import { RichTextEditor } from "@/components/ui/RichTextEditor";

export function AgendaNotesEditor({
  label,
  value,
  onChange,
  placeholder,
  minHeight,
  bare,
}: {
  label: string;
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  minHeight?: number;
  bare?: boolean;
}) {
  return (
    <div>
      {label && <span className="mb-1 block text-sm font-medium text-ink-2">{label}</span>}
      <RichTextEditor value={value} onChange={onChange} placeholder={placeholder} minHeight={minHeight} bare={bare} />
    </div>
  );
}
