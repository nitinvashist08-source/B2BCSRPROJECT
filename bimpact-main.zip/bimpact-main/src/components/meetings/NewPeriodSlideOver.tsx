"use client";

import { useState } from "react";
import { useMeetingStore } from "@/store/meetingStore";

function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function CloseIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}
function CalendarIcon() {
  return (
    <svg fill="none" height="18" width="18" stroke="currentColor" strokeWidth="1.6" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}

// stcCreatePeriod, bImpact_MeetingSplit_v10.html:12415-12429 — period
// creation only; committee membership is built separately once the user
// clicks View on the new period.
export function NewPeriodSlideOver({ open, onClose }: { open: boolean; onClose: () => void }) {
  const createPeriod = useMeetingStore((s) => s.createPeriod);

  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [startError, setStartError] = useState(false);
  const [endError, setEndError] = useState(false);
  const [dateError, setDateError] = useState<string | null>(null);

  function handleClose() {
    onClose();
  }

  function handleCreate() {
    setStartError(!start);
    setEndError(!end);
    if (!start || !end) {
      setDateError(null);
      return;
    }
    if (end < start) {
      setEndError(true);
      setDateError("End date must be on or after start date.");
      return;
    }
    if (end < todayIso()) {
      setEndError(true);
      setDateError("Cannot create a committee period that has already ended.");
      return;
    }
    setDateError(null);
    createPeriod(start, end);
    handleClose();
  }

  const dateCls = (hasError: boolean) =>
    `box-border h-10 w-full rounded-sm border-[1.5px] bg-bg px-3 text-sm text-ink outline-none transition-colors focus:border-primary ${
      hasError ? "border-danger" : "border-border"
    }`;

  return (
    <>
      <div
        className={`fixed inset-0 z-[900] bg-black/40 transition-opacity ${open ? "opacity-100" : "pointer-events-none opacity-0"}`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) handleClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[901] flex h-full w-[400px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 border-b border-border px-5 py-4">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-sm bg-primary-50 text-primary">
            <CalendarIcon />
          </span>
          <div>
            <div className="text-[0.95rem] font-bold text-ink">New Committee Period</div>
            <div className="mt-px text-[11.5px] text-muted">Create a new period for the CSR Committee.</div>
          </div>
          <button onClick={handleClose} className="ml-auto flex h-8 w-8 shrink-0 items-center justify-center rounded-sm text-muted hover:bg-bg hover:text-ink">
            <CloseIcon />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          <div className="mb-2 text-[12.5px] font-semibold text-ink-2">Committee Period</div>
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="mb-1 block text-[11px] font-bold uppercase text-muted">
                Start Date <span className="text-danger">*</span>
              </label>
              <input
                autoFocus
                type="date"
                value={start}
                onChange={(e) => setStart(e.target.value)}
                className={dateCls(startError)}
              />
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-bold uppercase text-muted">
                End Date <span className="text-danger">*</span>
              </label>
              <input type="date" value={end} onChange={(e) => setEnd(e.target.value)} className={dateCls(endError)} />
            </div>
          </div>
          {dateError && <p className="mt-1.5 text-[11.5px] font-medium text-danger">{dateError}</p>}
        </div>

        <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
          <button onClick={handleClose} className="flex h-9 items-center rounded-sm border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 hover:border-border-strong">
            Cancel
          </button>
          <button onClick={handleCreate} className="flex h-9 items-center rounded-sm bg-primary px-4 text-sm font-semibold text-white hover:bg-primary-600">
            Create Period
          </button>
        </div>
      </div>
    </>
  );
}
