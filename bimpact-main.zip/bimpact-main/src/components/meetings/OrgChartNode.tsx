"use client";

import { CommitteeMember } from "@/types/meeting";
import { useMeetingStore } from "@/store/meetingStore";

function initials(name: string) {
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "")).toUpperCase();
}

function PlusIcon() {
  return (
    <svg fill="none" height="10" width="10" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function EditIcon() {
  return (
    <svg fill="none" height="10" width="10" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
    </svg>
  );
}
function XIcon() {
  return (
    <svg fill="none" height="10" width="10" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}
function ChevronIcon({ collapsed }: { collapsed: boolean }) {
  return (
    <svg
      fill="none"
      height="9"
      width="9"
      stroke="currentColor"
      strokeWidth="2.5"
      viewBox="0 0 24 24"
      className="transition-transform duration-200"
      style={{ transform: `rotate(${collapsed ? -90 : 0}deg)` }}
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

// mtgRenderOrgNode/stcRenderOrgNode's .mtg-og/.mtg-on card tree,
// bImpact_MeetingSplit_v10.html:9491-9534 (CSS), :10345-10406 &
// :12481-12526 — the org-chart card tree, now the single CSR Committee
// experience (Management → CSR Committee), scoped per period via
// `reportsToId`.
export function OrgChartNode({
  member,
  isRoot,
  collapsedMap,
  onToggleCollapse,
  onAddChild,
  onEdit,
  onRemove,
}: {
  member: CommitteeMember;
  isRoot: boolean;
  collapsedMap: Record<string, boolean>;
  onToggleCollapse: (id: string) => void;
  onAddChild: (parentId: string) => void;
  onEdit: (member: CommitteeMember) => void;
  onRemove: (member: CommitteeMember) => void;
}) {
  const committee = useMeetingStore((s) => s.committee);
  const collapsed = collapsedMap[member.id] ?? false;
  const children = committee.filter((m) => m.reportsToId === member.id);
  const hasKids = children.length > 0;

  return (
    <div className="flex flex-col items-center">
      <div className="group relative">
        <div
          className={`flex min-w-[200px] max-w-[240px] items-center gap-3 rounded-xl border-[1.5px] p-3 pr-3.5 shadow-sm transition-all hover:border-primary hover:shadow-[0_0_0_3px_rgba(10,151,217,0.08)] ${
            isRoot ? "border-primary bg-primary-50" : "border-border bg-surface"
          }`}
        >
          <span
            className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-full text-[13px] font-bold text-white"
            style={{ background: member.color || "var(--color-primary)" }}
          >
            {initials(member.name)}
          </span>
          <div className="min-w-0 flex-1">
            <div className="truncate text-[13.5px] font-bold text-ink">{member.name}</div>
            <div className="mt-0.5 truncate text-[11.5px] text-muted">{member.role}</div>
            {member.organization && <div className="mt-0.5 truncate text-[11px] text-muted-2">{member.organization}</div>}
          </div>
        </div>

        <div className="absolute -right-2 -top-2 z-[2] hidden gap-[3px] group-hover:flex">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddChild(member.id);
            }}
            title="Add subordinate"
            className="flex h-[22px] w-[22px] items-center justify-center rounded-full border-[1.5px] border-border bg-surface text-muted shadow-sm transition-colors hover:border-primary hover:bg-primary hover:text-white"
          >
            <PlusIcon />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit(member);
            }}
            title="Edit member"
            className="flex h-[22px] w-[22px] items-center justify-center rounded-full border-[1.5px] border-border bg-surface text-muted shadow-sm transition-colors hover:border-primary hover:bg-primary hover:text-white"
          >
            <EditIcon />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onRemove(member);
            }}
            title="Remove member"
            className="flex h-[22px] w-[22px] items-center justify-center rounded-full border-[1.5px] border-border bg-surface text-muted shadow-sm transition-colors hover:border-danger hover:bg-danger hover:text-white"
          >
            <XIcon />
          </button>
        </div>
      </div>

      {hasKids && (
        <>
          <button
            onClick={() => onToggleCollapse(member.id)}
            title={collapsed ? "Expand children" : "Collapse children"}
            className="relative z-[1] flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 border-border bg-surface transition-colors hover:border-primary hover:bg-primary-50"
          >
            <span className="pointer-events-none absolute bottom-full left-1/2 h-2 w-0.5 -translate-x-1/2 bg-border" />
            {!collapsed && <span className="pointer-events-none absolute top-full left-1/2 h-2 w-0.5 -translate-x-1/2 bg-border" />}
            <ChevronIcon collapsed={collapsed} />
          </button>

          {!collapsed && (
            <>
              <span className="h-4 w-0.5 shrink-0 bg-border" />
              <div className="relative flex items-start">
                {children.length > 1 && <span className="pointer-events-none absolute left-0 right-0 top-0 h-0.5 bg-border" />}
                {children.map((child, i) => (
                  <div key={child.id} className="relative flex flex-col items-center px-5">
                    {children.length > 1 && i === 0 && <span className="pointer-events-none absolute left-0 top-0 z-[1] h-1.5 w-1/2 bg-bg" />}
                    {children.length > 1 && i === children.length - 1 && (
                      <span className="pointer-events-none absolute right-0 top-0 z-[1] h-1.5 w-1/2 bg-bg" />
                    )}
                    {children.length > 1 && <span className="h-6 w-0.5 shrink-0 bg-border" />}
                    <OrgChartNode
                      member={child}
                      isRoot={false}
                      collapsedMap={collapsedMap}
                      onToggleCollapse={onToggleCollapse}
                      onAddChild={onAddChild}
                      onEdit={onEdit}
                      onRemove={onRemove}
                    />
                  </div>
                ))}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
