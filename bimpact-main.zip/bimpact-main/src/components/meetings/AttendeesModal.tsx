"use client";

import { useState } from "react";
import { useMeetingStore } from "@/store/meetingStore";
import { Meeting } from "@/types/meeting";
import { SlideOver } from "@/components/ui/SlideOver";
import { Button } from "@/components/ui/Button";
import { Avatar } from "@/components/ui/Avatar";

const emptyGuest = { name: "", email: "", org: "", role: "", reportsTo: "" };

function CheckIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

// mtgRenderAttModal/mtgRenderAttModalCommitteeTab/mtgRenderAttModalGuestsTab,
// bImpact_MeetingSplit_v10.html:15794-15913 — at setup time this only picks
// WHO is invited (mtgAttToggleMember, a plain boolean toggle into
// `present`); it does not track present/absent/excluded here at all — that
// only happens live, during Execute & MoM (see MeetingExecutionSection.tsx).
export function AttendeesModal({
  open,
  onClose,
  meeting,
}: {
  open: boolean;
  onClose: () => void;
  meeting: Meeting;
}) {
  const committee = useMeetingStore((s) => s.committee);
  const toggleAttendeeInvite = useMeetingStore((s) => s.toggleAttendeeInvite);
  const addGuest = useMeetingStore((s) => s.addGuest);
  const removeGuest = useMeetingStore((s) => s.removeGuest);

  const [tab, setTab] = useState<"committee" | "guests">("committee");
  const [search, setSearch] = useState("");
  const [guestDraft, setGuestDraft] = useState(emptyGuest);

  const q = search.trim().toLowerCase();
  const filtered = committee.filter(
    (m) => m.name.toLowerCase().includes(q) || m.role.toLowerCase().includes(q)
  );

  const invitedIds = new Set([...meeting.attendees.present, ...meeting.attendees.absent]);
  const committeeCount = committee.filter((m) => invitedIds.has(m.id)).length;
  const guestCount = meeting.attendees.guests.length;
  const totalSelected = committeeCount + guestCount;

  function handleAddGuest() {
    if (!guestDraft.name.trim() || !guestDraft.email.trim() || !guestDraft.org.trim()) return;
    addGuest(meeting.id, guestDraft);
    setGuestDraft(emptyGuest);
  }

  return (
    <SlideOver open={open} onClose={onClose} title="Manage attendees" width={480}>
      <div className="mb-3 flex gap-1 border-b border-border">
        <button
          onClick={() => setTab("committee")}
          className={`border-b-2 px-3 py-2 text-sm font-medium ${
            tab === "committee" ? "border-primary text-primary" : "border-transparent text-muted"
          }`}
        >
          Committee Members <span className="text-xs text-muted">({committeeCount})</span>
        </button>
        <button
          onClick={() => setTab("guests")}
          className={`border-b-2 px-3 py-2 text-sm font-medium ${
            tab === "guests" ? "border-primary text-primary" : "border-transparent text-muted"
          }`}
        >
          External Guests <span className="text-xs text-muted">({guestCount})</span>
        </button>
      </div>

      {tab === "committee" ? (
        <div className="flex flex-col gap-3">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or role…"
            className="w-full rounded-sm border border-border px-3 py-2 text-sm outline-none focus:border-primary"
          />
          <div className="flex flex-col gap-2">
            {filtered.map((m) => {
              const invited = invitedIds.has(m.id);
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => toggleAttendeeInvite(meeting.id, m.id)}
                  className={`flex items-center justify-between gap-2 rounded-sm border px-3 py-2 text-left ${
                    invited ? "border-primary bg-primary-50" : "border-border hover:border-border-strong"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Avatar name={m.name} size="sm" color={m.color} />
                    <div>
                      <div className="text-sm font-medium text-ink">{m.name}</div>
                      <div className="text-xs text-muted">{m.role}</div>
                    </div>
                  </div>
                  <span
                    className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-sm border ${
                      invited ? "border-primary bg-primary text-white" : "border-border-strong text-transparent"
                    }`}
                  >
                    <CheckIcon />
                  </span>
                </button>
              );
            })}
            {filtered.length === 0 && (
              <p className="py-6 text-center text-sm text-muted">No members found.</p>
            )}
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {meeting.attendees.guests.map((g) => (
            <div
              key={g.id}
              className="flex items-center justify-between gap-2 rounded-sm border border-border px-3 py-2"
            >
              <div>
                <div className="text-sm font-medium text-ink">{g.name}</div>
                <div className="text-xs text-muted">
                  {g.role} · {g.org}
                  {g.reportsTo && ` · Reports to: ${committee.find((m) => m.id === g.reportsTo)?.name ?? g.reportsTo}`}
                </div>
              </div>
              <button
                onClick={() => removeGuest(meeting.id, g.id)}
                className="text-xs text-danger hover:underline"
              >
                Remove
              </button>
            </div>
          ))}
          <div className="rounded-sm border border-dashed border-border-strong p-3">
            <div className="mb-2 text-xs font-medium text-ink-2">Add a guest</div>
            <div className="flex flex-col gap-2">
              <input
                value={guestDraft.name}
                onChange={(e) => setGuestDraft((g) => ({ ...g, name: e.target.value }))}
                placeholder="Full Name *"
                className="w-full rounded-sm border border-border px-2 py-1.5 text-sm outline-none focus:border-primary"
              />
              <input
                value={guestDraft.email}
                onChange={(e) => setGuestDraft((g) => ({ ...g, email: e.target.value }))}
                placeholder="Email *"
                className="w-full rounded-sm border border-border px-2 py-1.5 text-sm outline-none focus:border-primary"
              />
              <input
                value={guestDraft.org}
                onChange={(e) => setGuestDraft((g) => ({ ...g, org: e.target.value }))}
                placeholder="Organisation *"
                className="w-full rounded-sm border border-border px-2 py-1.5 text-sm outline-none focus:border-primary"
              />
              <input
                value={guestDraft.role}
                onChange={(e) => setGuestDraft((g) => ({ ...g, role: e.target.value }))}
                placeholder="Role / Designation"
                className="w-full rounded-sm border border-border px-2 py-1.5 text-sm outline-none focus:border-primary"
              />
              <select
                value={guestDraft.reportsTo}
                onChange={(e) => setGuestDraft((g) => ({ ...g, reportsTo: e.target.value }))}
                className="w-full rounded-sm border border-border bg-surface px-2 py-1.5 text-sm text-ink-2 outline-none focus:border-primary"
              >
                <option value="">Reports To (Committee Member)</option>
                {committee.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
              <Button size="sm" onClick={handleAddGuest}>
                + Add guest
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="mt-4 flex items-center justify-between border-t border-border pt-3">
        <span className="text-xs text-muted">
          {totalSelected} attendee{totalSelected !== 1 ? "s" : ""} selected · {committeeCount} committee ·{" "}
          {guestCount} guest{guestCount !== 1 ? "s" : ""}
        </span>
        <Button size="sm" onClick={onClose}>
          Done
        </Button>
      </div>
    </SlideOver>
  );
}
