"use client";

import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useMeetingStore } from "@/store/meetingStore";
import { CommitteeMember } from "@/types/meeting";

function countDescendants(committee: CommitteeMember[], id: string): number {
  const kids = committee.filter((m) => m.reportsToId === id);
  return kids.length + kids.reduce((sum, k) => sum + countDescendants(committee, k.id), 0);
}

// Confirms cascading removal — removing a member also removes every direct
// and indirect subordinate (Rule: recursive removal, no orphaned nodes left
// dangling in the tree). See meetingStore.ts's removeMember for the actual
// cascade.
export function RemoveMemberModal({ member, onClose }: { member: CommitteeMember | null; onClose: () => void }) {
  const committee = useMeetingStore((s) => s.committee);
  const removeMember = useMeetingStore((s) => s.removeMember);

  if (!member) return null;
  const descendantCount = countDescendants(committee, member.id);

  return (
    <Modal
      open={!!member}
      onClose={onClose}
      title="Remove Committee Member?"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              removeMember(member.id);
              onClose();
            }}
          >
            Remove Member
          </Button>
        </>
      }
    >
      You are about to remove <strong>{member.name}</strong>.{" "}
      {descendantCount > 0 ? (
        <>
          This will also remove <strong>{descendantCount}</strong> connected subordinate member{descendantCount !== 1 ? "s" : ""} from the
          committee structure.
        </>
      ) : (
        "This member has no subordinates in the committee structure."
      )}{" "}
      This action cannot be undone.
    </Modal>
  );
}
