﻿"use client";

import { useState } from "react";
import { useFinanceStore } from "@/store/financeStore";
import { ExpenseType, GstSlab } from "@/types/finance";

const GST_OPTIONS: { value: GstSlab; label: string }[] = [
  { value: 0, label: "0% (Nil Rated / Exempt)" },
  { value: 5, label: "5% (CGST 2.5% + SGST 2.5%)" },
  { value: 12, label: "12% (CGST 6% + SGST 6%)" },
  { value: 18, label: "18% (CGST 9% + SGST 9%)" },
  { value: 28, label: "28% (CGST 14% + SGST 14%)" },
];

function CloseIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}
function DocIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
    </svg>
  );
}

// .fin-lbl, bImpact_MeetingSplit_v10.html:6471-6475
function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div className="mb-3.5">
      <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.06em] text-muted">
        {label}
        {required && <span className="ml-0.5 text-danger">*</span>}
      </label>
      {children}
    </div>
  );
}

const inputCls =
  "box-border h-[38px] w-full rounded-sm border-[1.5px] border-border bg-bg px-3 text-[13px] text-ink outline-none transition-colors focus:border-primary";
const selCls =
  "box-border h-[38px] w-full cursor-pointer rounded-sm border-[1.5px] border-border bg-bg px-2.5 text-[13px] text-ink outline-none transition-colors focus:border-primary";

type Draft = {
  date: string;
  type: ExpenseType | "";
  amount: string;
  gstSlab: GstSlab;
  fileName: string;
  description: string;
};

function emptyDraft(): Draft {
  return { date: "", type: "", amount: "", gstSlab: 18, fileName: "", description: "" };
}

// calcExpTotal, bImpact_MeetingSplit_v10.html:14049-14058
function gstBreakdown(amount: string, gstSlab: GstSlab) {
  const base = parseFloat(amount) || 0;
  const tax = base * (gstSlab / 100);
  const total = base + tax;
  return { tax, total };
}

export function BookExpenseSlideOver({
  projectId,
  projectName,
  open,
  onClose,
}: {
  projectId: string;
  projectName: string;
  open: boolean;
  onClose: () => void;
}) {
  const addExpense = useFinanceStore((s) => s.addExpense);
  const [draft, setDraft] = useState<Draft>(emptyDraft);

  function handleClose() {
    setDraft(emptyDraft());
    onClose();
  }

  // saveExpense, bImpact_MeetingSplit_v10.html:14060-14071 — date, type,
  // amount, and a supporting document are ALL mandatory; description is the
  // only optional field.
  function handleSave() {
    if (!draft.date || !draft.type || !draft.amount || !draft.fileName) return;
    const { total } = gstBreakdown(draft.amount, draft.gstSlab);
    addExpense({
      projectId,
      date: new Date(draft.date).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }),
      type: draft.type,
      description: draft.description.trim(),
      amount: Math.round(total),
      gstSlab: draft.gstSlab,
      docFileName: draft.fileName,
    });
    handleClose();
  }

  const { tax, total } = gstBreakdown(draft.amount, draft.gstSlab);
  const canSave = !!(draft.date && draft.type && draft.amount && draft.fileName);

  return (
    <>
      <div
        className={`fixed inset-0 z-[400] bg-black/40 backdrop-blur-[2px] transition-opacity ${open ? "opacity-100" : "pointer-events-none opacity-0"}`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) handleClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[401] flex h-full w-[480px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 border-b border-border px-5 py-4">
          <span className="flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-[9px] bg-secondary-50 text-secondary">
            <DocIcon />
          </span>
          <div>
            <div className="text-[0.95rem] font-bold text-ink">Book Expense</div>
            <div className="mt-px text-[11.5px] text-muted">Record an actual expense against a project budget</div>
          </div>
          <button onClick={handleClose} className="ml-auto flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-[7px] text-muted hover:bg-bg hover:text-ink">
            <CloseIcon />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          <div className="mb-4 rounded-md border border-[rgba(22,163,74,0.2)] bg-secondary-50 px-3 py-2.5">
            <div className="mb-0.5 text-[11px] font-semibold uppercase text-secondary">Target Project</div>
            <div className="text-[13px] font-semibold text-ink">{projectName}</div>
          </div>

          <Field label="Expense Date" required>
            <input type="date" className={inputCls} value={draft.date} onChange={(e) => setDraft((d) => ({ ...d, date: e.target.value }))} />
          </Field>

          <Field label="Expense Type" required>
            <select className={selCls} value={draft.type} onChange={(e) => setDraft((d) => ({ ...d, type: e.target.value as ExpenseType }))}>
              <option value="" disabled>
                Select expense type…
              </option>
              <option value="CAPEX">CAPEX</option>
              <option value="OPEX">OPEX</option>
            </select>
          </Field>

          <div className="mb-3.5 grid grid-cols-2 gap-4">
            <Field label="Amount (₹)" required>
              <div className="relative">
                <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[13px] text-muted">₹</span>
                <input
                  type="number"
                  className={`${inputCls} pl-6`}
                  placeholder="0"
                  value={draft.amount}
                  onChange={(e) => setDraft((d) => ({ ...d, amount: e.target.value }))}
                />
              </div>
            </Field>
            <Field label="GST Slab" required>
              <select
                className={selCls}
                value={draft.gstSlab}
                onChange={(e) => setDraft((d) => ({ ...d, gstSlab: Number(e.target.value) as GstSlab }))}
              >
                {GST_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </Field>
          </div>

          <div className="mb-3.5 grid grid-cols-2 gap-4">
            <Field label="GST Tax Amount (₹)">
              <div className="relative">
                <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[13px] text-muted">₹</span>
                <input readOnly className={`${inputCls} pl-6 text-muted`} value={tax ? tax.toLocaleString("en-IN") : ""} />
              </div>
            </Field>
            <Field label="Total Amount (Incl. GST)">
              <div className="relative">
                <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[13px] font-bold text-secondary">₹</span>
                <input
                  readOnly
                  className={`${inputCls} border-[rgba(22,163,74,0.3)] bg-secondary-50 pl-6 font-bold text-secondary`}
                  value={total ? total.toLocaleString("en-IN") : ""}
                />
              </div>
            </Field>
          </div>

          <Field label="Supporting Document (Invoice/Receipt)" required>
            <label className="flex cursor-pointer flex-col items-center gap-1 rounded-sm border-[1.5px] border-dashed border-border bg-bg px-4 py-4 text-center">
              <svg fill="none" height="18" width="18" stroke="var(--color-muted)" strokeWidth="2" viewBox="0 0 24 24" className="mb-1">
                <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
              </svg>
              <span className={`text-xs font-medium ${draft.fileName ? "text-secondary" : "text-ink"}`}>
                {draft.fileName || "Click to upload mandatory document"}
              </span>
              <span className="text-[11px] text-muted">PDF, JPG or PNG required</span>
              <input
                type="file"
                accept=".pdf,.jpg,.png"
                className="hidden"
                onChange={(e) => setDraft((d) => ({ ...d, fileName: e.target.files?.[0]?.name ?? "" }))}
              />
            </label>
          </Field>

          <Field label="Description / Remarks (Optional)">
            <textarea
              className="box-border h-[68px] w-full resize-none rounded-sm border-[1.5px] border-border bg-bg px-3 py-2.5 text-[13px] text-ink outline-none focus:border-primary"
              placeholder="Specify details about this expense…"
              value={draft.description}
              onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
            />
          </Field>
        </div>

        <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
          <button onClick={handleClose} className="flex h-[38px] items-center rounded-sm border border-border bg-surface px-3.5 text-[13.5px] font-semibold text-ink-2 hover:border-border-strong">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!canSave}
            className="flex h-[38px] items-center rounded-sm bg-primary px-3.5 text-[13.5px] font-semibold text-white shadow-[0_1px_2px_rgba(10,151,217,0.3)] hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-50"
          >
            Book Expense
          </button>
        </div>
      </div>
    </>
  );
}
