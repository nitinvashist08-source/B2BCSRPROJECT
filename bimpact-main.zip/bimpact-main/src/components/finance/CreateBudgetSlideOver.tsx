"use client";

import { useState } from "react";
import { useFinanceStore, periodBudgetAllocated } from "@/store/financeStore";
import { PeriodBudget } from "@/types/finance";

function CloseIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-3.5">
      <label className="mb-1.5 block text-xs font-semibold text-ink-2">{label}</label>
      {children}
    </div>
  );
}

const inputCls =
  "box-border h-[38px] w-full rounded-lg border-[1.5px] border-border bg-bg px-3 text-[13px] text-ink outline-none transition-colors focus:border-primary";
const errCls = "border-danger";

function fmtINR(n: number) {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

// Budget Planning → Create Budget: creates ONLY the overall sanctioned
// budget (Planning Duration + Total Sanctioned Amount) — deliberately no
// Project selection or allocation here at all. Assigning a Project to a
// budget is a fully separate action ("Assign Project", see
// AssignProjectSlideOver.tsx, reached via its own CTA in
// PeriodBudgetsPanel.tsx) so budget creation and project allocation never
// happen in the same step. Also serves as the Edit flow (`editing` set) for
// an existing budget's period fields only — it can never touch that
// budget's allocations, so editing can never delete/reset/duplicate them.
export function CreateBudgetSlideOver({
  open,
  onClose,
  editing = null,
}: {
  open: boolean;
  onClose: () => void;
  editing?: PeriodBudget | null;
}) {
  const addPeriodBudget = useFinanceStore((s) => s.addPeriodBudget);
  const updatePeriodBudgetPeriod = useFinanceStore((s) => s.updatePeriodBudgetPeriod);

  const [startDate, setStartDate] = useState(editing?.startDate ?? "");
  const [endDate, setEndDate] = useState(editing?.endDate ?? "");
  const [sanctioned, setSanctioned] = useState(editing ? String(editing.totalSanctionedAmount) : "");
  const [touched, setTouched] = useState<Set<"dates" | "sanctioned">>(new Set());

  function markTouched(field: "dates" | "sanctioned") {
    setTouched((t) => new Set(t).add(field));
  }

  function reset() {
    setStartDate(editing?.startDate ?? "");
    setEndDate(editing?.endDate ?? "");
    setSanctioned(editing ? String(editing.totalSanctionedAmount) : "");
    setTouched(new Set());
  }
  function handleClose() {
    reset();
    onClose();
  }

  const sanctionedNum = Number(sanctioned) || 0;
  const alreadyAllocated = editing ? periodBudgetAllocated(editing) : 0;

  const dateError = !startDate
    ? "Start date is required."
    : !endDate
      ? "End date is required."
      : endDate < startDate
        ? "End date cannot be earlier than start date."
        : null;
  const sanctionedError = !sanctioned.trim()
    ? "Total sanctioned amount is required."
    : !(sanctionedNum > 0)
      ? "Enter a valid positive amount."
      : editing && sanctionedNum < alreadyAllocated
        ? `Cannot be less than the ${fmtINR(alreadyAllocated)} already allocated to Projects.`
        : null;
  const invalid = !!dateError || !!sanctionedError;

  function handleSave() {
    setTouched(new Set(["dates", "sanctioned"]));
    if (invalid) return;

    if (editing) {
      updatePeriodBudgetPeriod(editing.id, { startDate, endDate, totalSanctionedAmount: sanctionedNum });
    } else {
      addPeriodBudget({ startDate, endDate, totalSanctionedAmount: sanctionedNum });
    }
    handleClose();
  }

  return (
    <>
      <div
        className={`fixed inset-0 z-[400] bg-black/40 backdrop-blur-[2px] transition-opacity ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) handleClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[401] flex h-full w-[420px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 border-b border-border px-5 py-4">
          <span className="flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-[9px] bg-primary-50 text-primary">
            <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <rect x="2" y="4" width="20" height="16" rx="2" />
              <line x1="12" y1="8" x2="12" y2="16" />
              <line x1="8" y1="12" x2="16" y2="12" />
            </svg>
          </span>
          <div>
            <div className="text-[0.95rem] font-bold text-ink">{editing ? "Edit Budget" : "Create Budget"}</div>
            <div className="mt-px text-[11.5px] text-muted">
              {editing ? "Update the planning period and sanctioned amount." : "Define a planning period and the total sanctioned amount."}
            </div>
          </div>
          <button
            onClick={handleClose}
            className="ml-auto flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-md text-muted hover:bg-bg hover:text-ink"
          >
            <CloseIcon />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          <div className="mb-3 text-[12.5px] font-bold uppercase tracking-wide text-muted">Planning Duration</div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Start Date *">
              <input
                type="date"
                className={`${inputCls} ${touched.has("dates") && dateError ? errCls : ""}`}
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                onBlur={() => markTouched("dates")}
              />
            </Field>
            <Field label="End Date *">
              <input
                type="date"
                className={`${inputCls} ${touched.has("dates") && dateError ? errCls : ""}`}
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                onBlur={() => markTouched("dates")}
              />
            </Field>
          </div>
          {touched.has("dates") && dateError && <p className="-mt-2 mb-3.5 text-xs text-danger">{dateError}</p>}

          <Field label="Total Sanctioned Amount (₹) *">
            <div className="relative">
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[13px] text-muted">₹</span>
              <input
                type="number"
                min="0"
                className={`${inputCls} pl-6 ${touched.has("sanctioned") && sanctionedError ? errCls : ""}`}
                placeholder="Enter sanctioned amount"
                value={sanctioned}
                onChange={(e) => setSanctioned(e.target.value)}
                onBlur={() => markTouched("sanctioned")}
              />
            </div>
            {touched.has("sanctioned") && sanctionedError && <p className="mt-1 text-xs text-danger">{sanctionedError}</p>}
          </Field>

          {editing && alreadyAllocated > 0 && (
            <p className="rounded-lg border border-border bg-surface-2 p-3 text-xs leading-snug text-muted">
              {fmtINR(alreadyAllocated)} of this budget is already allocated to Projects — manage
              those allocations from the Budget Periods list, not here.
            </p>
          )}
        </div>

        <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
          <button
            onClick={handleClose}
            className="flex h-9 items-center rounded-lg border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 hover:border-border-strong"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={invalid}
            className="flex h-9 items-center rounded-lg bg-primary px-4 text-sm font-semibold text-white hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {editing ? "Save Changes" : "Create Budget"}
          </button>
        </div>
      </div>
    </>
  );
}
