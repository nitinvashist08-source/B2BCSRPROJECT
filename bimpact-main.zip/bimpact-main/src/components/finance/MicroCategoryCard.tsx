"use client";

import { useMicroUiStore } from "@/store/microUiStore";
import { MicroCategory, MicroLineItem, FundingType, MonthlyPlan, MONTHS } from "@/types/finance";

function pINR(n: number) {
  return n.toLocaleString("en-IN");
}
function fAmt(n: number) {
  return n.toLocaleString("en-IN", { maximumFractionDigits: 2 });
}
function fmtOrDash(n: number) {
  return n > 0 ? n.toLocaleString("en-IN") : "-";
}

// borderClass in the source's month-header/data-cell builders,
// bImpact_MeetingSplit_v10.html:14321, :14336 — solid border at each
// quarter boundary (every 3rd month), dashed otherwise, none after March.
function monthBorderClass(m: number) {
  if (m === 11) return "";
  return (m + 1) % 3 === 0 ? "border-r border-border" : "border-r border-dashed border-border";
}

const TYPE_META: Record<FundingType, { badge: string; badgeBg: string; labelShort: string; labelColor: string }> = {
  ds: { badge: "DS", badgeBg: "#0ea5e9", labelShort: "Direct Support", labelColor: "#0369a1" },
  bs: { badge: "BC", badgeBg: "#16a34a", labelShort: "Beneficiary Contrib", labelColor: "#15803d" },
  as: { badge: "AO", badgeBg: "#9333ea", labelShort: "Agency / Other", labelColor: "#7e22ce" },
};

function ChevronIcon({ open }: { open: boolean }) {
  return (
    <svg
      fill="none"
      height="14"
      width="14"
      stroke="#94a3b8"
      strokeWidth="2"
      viewBox="0 0 24 24"
      className="shrink-0 transition-transform duration-200"
      style={{ transform: open ? "rotate(0deg)" : "rotate(-90deg)" }}
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}
function LocationIcon() {
  return (
    <svg fill="none" height="16" width="16" stroke="var(--color-muted)" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
function ArrowRightIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="#0ea5e9" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M5 12h14" />
      <path d="M12 5l7 7-7 7" />
    </svg>
  );
}
function EditIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
    </svg>
  );
}
function PlusIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}

function monthlyTotals(monthly: MonthlyPlan): number[] {
  return Array.from({ length: 12 }, (_, m) => (monthly.ds[m] || 0) + (monthly.bs[m] || 0) + (monthly.as[m] || 0));
}
function itemMonthlyTotals(item: MicroLineItem): number[] {
  if (item.subItems.length) {
    const totals = Array(12).fill(0);
    for (const sub of item.subItems) {
      const subTotals = monthlyTotals(sub.monthly);
      for (let m = 0; m < 12; m++) totals[m] += subTotals[m];
    }
    return totals;
  }
  return monthlyTotals(item.monthly);
}

// renderMicroBudget's category card + wide monthly-grid table,
// bImpact_MeetingSplit_v10.html:14237-14520.
export function MicroCategoryCard({
  category,
  projectName,
  canEdit,
  onEditItem,
  onAddSubItem,
}: {
  category: MicroCategory;
  projectName: string;
  // Same permission gate as the "+ Add Line Item" button in
  // MicroBudgetView.tsx — a read-only viewer (per the project's configured
  // Micro-Budgeting ownership) keeps seeing every line item/value, just
  // without the Edit/Add Sub Item affordances. The store's own
  // saveMicroLineItem already refuses the mutation regardless (see
  // financeStore.ts) — this is only the UI half of that enforcement.
  canEdit: boolean;
  onEditItem: (categoryId: string, item: MicroLineItem) => void;
  onAddSubItem: (categoryId: string, item: MicroLineItem) => void;
}) {
  const collapsedCategories = useMicroUiStore((s) => s.collapsedCategories);
  const toggleCategory = useMicroUiStore((s) => s.toggleCategory);
  const open = !collapsedCategories.has(category.id);
  const catTotal = category.items.reduce((sum, i) => sum + itemMonthlyTotals(i).reduce((a, b) => a + b, 0), 0);

  const catMonthlyTotals = Array(12).fill(0);
  for (const item of category.items) {
    const t = itemMonthlyTotals(item);
    for (let m = 0; m < 12; m++) catMonthlyTotals[m] += t[m];
  }

  return (
    <div className="mb-4 overflow-hidden rounded-md border border-border">
      <div
        onClick={() => toggleCategory(category.id)}
        className="flex cursor-pointer items-center justify-between border-b border-[#f0f0f0] bg-surface px-4 py-3"
      >
        <div className="flex items-center gap-2">
          <span className="h-4 w-1 rounded-[2px] bg-[#0ea5e9]" />
          <LocationIcon />
          <span className="text-sm font-bold text-ink">{category.name}</span>
          <ChevronIcon open={open} />
        </div>
        <div className="flex items-center gap-4">
          <div className="flex gap-2">
            {(["ds", "bs", "as"] as FundingType[]).map((t) => (
              <span
                key={t}
                className="rounded-[4px] px-2 py-0.5 text-[11.5px] font-semibold tracking-[0.02em]"
                style={{
                  background: t === "ds" ? "#f0f9ff" : t === "bs" ? "#f0fdf4" : "#faf5ff",
                  color: t === "ds" ? "#0ea5e9" : t === "bs" ? "#16a34a" : "#9333ea",
                }}
              >
                {TYPE_META[t].badge} - {t === "ds" ? "Direct Support" : t === "bs" ? "Beneficiary Contribution" : "Agency/Other Support"} ₹--
              </span>
            ))}
          </div>
          <span className="font-mono text-sm font-bold text-ink">₹{pINR(catTotal)}</span>
        </div>
      </div>

      {open && (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[800px] border-collapse text-right text-[11px]">
            <thead className="border-b border-border bg-surface">
              <tr>
                <th className="sticky left-0 z-[2] border-b border-r border-border bg-surface p-3 text-left text-[10px] uppercase tracking-[0.05em] text-muted">
                  Funding Type
                </th>
                {["Q1", "Q2", "Q3", "Q4"].map((q, qi) => (
                  <th
                    key={q}
                    colSpan={3}
                    className={`border-b border-border p-3 text-center text-[11px] font-semibold tracking-[0.05em] text-muted ${qi < 3 ? "border-r" : ""}`}
                  >
                    {q}
                  </th>
                ))}
              </tr>
              <tr className="bg-[#e0f2fe]">
                <th className="sticky left-0 z-[2] border-b border-r border-border bg-[#e0f2fe] p-3 text-left text-[10px] font-bold uppercase tracking-[0.05em] text-ink-2">
                  Line Item
                </th>
                {MONTHS.map((m, i) => (
                  <th key={m} className={`border-b border-border p-2.5 text-[10px] font-bold text-muted ${monthBorderClass(i)}`}>
                    {m.toUpperCase()}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {category.items.length === 0 && (
                <tr>
                  <td colSpan={13} className="p-4 text-center italic text-muted">
                    No line items added.
                  </td>
                </tr>
              )}
              {category.items.length > 0 && (
                <tr className="border-b-2 border-border bg-[#fef9c3]">
                  <td className="sticky left-0 z-[1] border-r border-border bg-[#fef9c3] px-4 py-2.5 text-left text-[11.5px] font-bold text-ink">
                    {projectName} (Monthly Total)
                  </td>
                  {catMonthlyTotals.map((v, m) => (
                    <td key={m} className={`bg-[#fef9c3] px-2 py-2.5 font-mono text-xs font-bold text-ink ${monthBorderClass(m)}`}>
                      {fmtOrDash(v)}
                    </td>
                  ))}
                </tr>
              )}
              {category.items.map((item) => (
                <ItemRows key={item.id} categoryId={category.id} item={item} canEdit={canEdit} onEdit={onEditItem} onAddSub={onAddSubItem} />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ItemRows({
  categoryId,
  item,
  canEdit,
  onEdit,
  onAddSub,
}: {
  categoryId: string;
  item: MicroLineItem;
  canEdit: boolean;
  onEdit: (categoryId: string, item: MicroLineItem) => void;
  onAddSub: (categoryId: string, item: MicroLineItem) => void;
}) {
  const hasSub = item.subItems.length > 0;
  const totals = itemMonthlyTotals(item);

  return (
    <>
      <tr className="bg-surface">
        <td className="sticky left-0 z-[1] border-b border-r border-t-2 border-border bg-surface px-4 py-3 text-left">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowRightIcon />
              <span className="text-[13px] font-bold text-ink">{item.name}</span>
            </div>
            {canEdit && (
              <div className="flex gap-1.5">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit(categoryId, item);
                  }}
                  title="Edit Line Item"
                  className="flex h-[26px] w-[26px] items-center justify-center rounded-[4px] border border-border bg-surface text-ink-2 hover:bg-bg"
                >
                  <EditIcon />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddSub(categoryId, item);
                  }}
                  title="Add Sub Item"
                  className="flex h-[26px] w-[26px] items-center justify-center rounded-[4px] border border-border bg-surface text-ink-2 hover:bg-bg"
                >
                  <PlusIcon />
                </button>
              </div>
            )}
          </div>
        </td>
        {totals.map((v, m) => (
          <td key={m} className={`border-b border-t-2 border-border bg-surface px-2.5 py-2.5 text-right text-[11px] font-bold text-ink ${monthBorderClass(m)}`}>
            {fmtOrDash(v)}
          </td>
        ))}
      </tr>

      {!hasSub &&
        (["ds", "bs", "as"] as FundingType[]).map((t) => {
          const data = item.monthly[t];
          const sum = data.reduce((a, b) => a + b, 0);
          if (sum <= 0) return null;
          return (
            <tr key={t} className="bg-[#fcfcfc]">
              <td className="sticky left-0 z-[1] border-b border-r border-border bg-[#fcfcfc] px-4 py-2.5 text-left">
                <div className="flex items-center gap-2">
                  <span className="rounded-[4px] px-1 py-0.5 text-[9px] font-bold text-white" style={{ background: TYPE_META[t].badgeBg }}>
                    {TYPE_META[t].badge}
                  </span>
                  <span className="text-[11.5px] font-semibold" style={{ color: TYPE_META[t].labelColor }}>
                    {TYPE_META[t].labelShort}
                  </span>
                </div>
              </td>
              {data.map((v, m) => (
                <td key={m} className={`border-b border-border px-2 py-2.5 font-mono text-[11.5px] text-ink-2 ${monthBorderClass(m)}`}>
                  {fAmt(v || 0)}
                </td>
              ))}
            </tr>
          );
        })}

      {hasSub &&
        item.subItems.map((sub) => {
          const subTotals = monthlyTotals(sub.monthly);
          return (
            <SubItemRows key={sub.id} subTotals={subTotals} sub={sub} />
          );
        })}
    </>
  );
}

function SubItemRows({ sub, subTotals }: { sub: MicroLineItem; subTotals: number[] }) {
  return (
    <>
      <tr className="bg-[#fafafa]">
        <td className="sticky left-0 z-[1] border-b border-r border-t border-dashed border-border bg-[#fafafa] py-2.5 pl-8 pr-4 text-left">
          <div className="flex items-center gap-2">
            <span className="h-1 w-1 rounded-full bg-muted" />
            <span className="text-[12.5px] font-semibold text-ink-2">{sub.name}</span>
          </div>
        </td>
        {subTotals.map((v, m) => (
          <td
            key={m}
            className={`border-b border-t border-dashed border-border bg-[#fafafa] px-2.5 py-2.5 text-right text-[11px] font-semibold text-ink-2 ${monthBorderClass(m)}`}
          >
            {fmtOrDash(v)}
          </td>
        ))}
      </tr>
      {(["ds", "bs", "as"] as FundingType[]).map((t) => {
        const data = sub.monthly[t];
        const sum = data.reduce((a, b) => a + b, 0);
        if (sum <= 0) return null;
        return (
          <tr key={t} className="bg-surface">
            <td className="sticky left-0 z-[1] border-b border-r border-border bg-surface py-2 pl-12 pr-4 text-left">
              <div className="flex items-center gap-2">
                <span className="rounded-[4px] px-1 py-px text-[9px] font-bold text-white" style={{ background: TYPE_META[t].badgeBg }}>
                  {TYPE_META[t].badge}
                </span>
                <span className="text-[11px] font-medium" style={{ color: TYPE_META[t].labelColor }}>
                  {TYPE_META[t].labelShort}
                </span>
              </div>
            </td>
            {data.map((v, m) => (
              <td key={m} className={`border-b border-border px-2 py-2 font-mono text-[11.5px] text-ink-2 ${monthBorderClass(m)}`}>
                {fAmt(v || 0)}
              </td>
            ))}
          </tr>
        );
      })}
    </>
  );
}
