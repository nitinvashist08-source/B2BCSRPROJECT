"use client";

import { usePathname } from "next/navigation";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore, microCategoryTotal } from "@/store/financeStore";
import { useMicroUiStore } from "@/store/microUiStore";
import { useSessionStore } from "@/store/sessionStore";
import { useSettingsStore } from "@/store/settingsStore";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";

function fmtINR(n: number) {
  return n.toLocaleString("en-IN");
}

function MoneyIcon() {
  return (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="12" x2="12" y1="1" y2="23" />
      <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
    </svg>
  );
}

// dyn-fin-title/dyn-fin-sub per finTab(), bImpact_MeetingSplit_v10.html:7411-7448
const TAB_META: Record<string, { title: string; sub: string }> = {
  "/finance/hlp": { title: "Planning Duration & Budget Allocation", sub: "Define the financial plan for this project period" },
  "/finance/micro": {
    title: "Micro Budgeting (Line Item Planning)",
    sub: "Plan comprehensive nested budget structures across all active projects simultaneously.",
  },
  "/finance/expense": { title: "Expense Booking (Actuals)", sub: "Book actual expenses against project activities or budget heads" },
  "/finance/disbursement": { title: "Disbursement Schedule (Tranches)", sub: "Schedule milestone-linked fund releases to implementing partners" },
};
const DEFAULT_META = { title: "Finance & Budgeting", sub: "Hybrid planning · Micro-budgeting · Disbursements" };

function Kpi({ label, value, valueColor, caption, captionColor }: { label: string; value: string; valueColor?: string; caption?: string; captionColor?: string }) {
  return (
    <div className="flex shrink-0 flex-col items-end">
      <div className="text-[10px] font-semibold uppercase tracking-[0.05em] text-muted">{label}</div>
      <div className="font-mono text-sm font-bold" style={{ color: valueColor ?? "var(--color-ink)" }}>
        {value}
      </div>
      {caption && (
        <div className="mt-0.5 text-[10px]" style={{ color: captionColor ?? "var(--color-muted)" }}>
          {caption}
        </div>
      )}
    </div>
  );
}
function Divider() {
  return <div className="h-6 w-px shrink-0 bg-border" />;
}

// fin-topbar (icon + dynamic title/subtitle + per-tab KPI cluster),
// bImpact_MeetingSplit_v10.html:6379-6396, :6716-6796. Navigation itself
// lives in the sidebar's Finance sub-nav (already ported — matches the
// original's `.nav-sub-item` list, :1923-1926), not an in-page tab strip;
// the source defines `.fin-tabs`/`.fin-tab` CSS but never renders any
// element with those classes, so no in-page tab bar exists to port.
export function FinanceTopBar() {
  const pathname = usePathname();

  const meta = Object.entries(TAB_META).find(([href]) => pathname.startsWith(href))?.[1] ?? DEFAULT_META;

  const projects = useProjectStore((s) => s.projects);
  const disbursements = useFinanceStore((s) => s.disbursements);
  const expenses = useFinanceStore((s) => s.expenses);
  const microBudgets = useFinanceStore((s) => s.microBudgets);
  const microUi = useMicroUiStore();
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const partners = useSettingsStore((s) => s.partners);
  const projectPartners = useSettingsStore((s) => s.projectPartners);

  // Every KPI below must be scoped to the partner's own assigned projects —
  // this topbar is shared across all Finance modules, so unfiltered totals
  // here would leak every other partner's sanctioned/disbursed/expense
  // figures. Sponsors are unaffected: visibleProjects === projects, and the
  // tranche/expense filters below are no-ops (their predicate is always
  // true), so the computed values are unchanged for that role.
  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const visibleProjects =
    role === "partner"
      ? projects.filter((p) => isProjectAssignedToPartner(p, projectPartners, partnerName))
      : projects;
  const visibleProjectIds = new Set(visibleProjects.map((p) => p.id));

  const sanctioned = visibleProjects.reduce((s, p) => s + p.budget, 0);
  const allTranches = Object.values(disbursements)
    .flat()
    .filter((t) => role !== "partner" || visibleProjectIds.has(t.projectId));
  const released = allTranches.filter((t) => t.status === "released").reduce((s, t) => s + t.amount, 0);

  return (
    <div className="flex min-w-0 items-center gap-0 border-b border-border bg-surface px-[22px]">
      <div className="mr-5 flex shrink-0 items-center gap-2.5 py-3.5">
        <span className="flex h-8 w-8 items-center justify-center rounded-sm bg-primary-50 text-primary">
          <MoneyIcon />
        </span>
        <div>
          <div className="text-base font-bold text-ink">{meta.title}</div>
          <div className="mt-px text-[11.5px] text-muted">{meta.sub}</div>
        </div>
      </div>

      <div className="ml-auto flex shrink-0 items-center gap-4 py-3.5">
        {pathname.startsWith("/finance/hlp") && (
          <>
            <Kpi label="Allocated" value={`₹${fmtINR(sanctioned)}`} />
            <Divider />
            <Kpi label="Disbursed" value={`₹${fmtINR(released)}`} valueColor="#16a34a" />
            <Divider />
            <Kpi label="Balance" value={`₹${fmtINR(sanctioned - released)}`} valueColor="var(--color-amber)" />
          </>
        )}

        {pathname.startsWith("/finance/disbursement") &&
          (() => {
            const planned = allTranches.reduce((s, t) => s + t.amount, 0);
            const releasedCount = allTranches.filter((t) => t.status === "released").length;
            const pending = planned - released;
            const pendingCount = allTranches.length - releasedCount;
            return (
              <>
                <Kpi label="Total Planned" value={`₹${fmtINR(planned)}`} caption={`${allTranches.length} tranches planned`} />
                <Divider />
                <Kpi label="Released" value={`₹${fmtINR(released)}`} valueColor="#0ea5e9" caption={`${releasedCount} tranche${releasedCount === 1 ? "" : "s"} released`} captionColor="var(--color-secondary)" />
                <Divider />
                <Kpi label="Pending Release" value={`₹${fmtINR(pending)}`} caption={`${pendingCount} tranche${pendingCount === 1 ? "" : "s"} pending`} />
              </>
            );
          })()}

        {pathname.startsWith("/finance/expense") &&
          (() => {
            const allExp = expenses.filter((e) => role !== "partner" || visibleProjectIds.has(e.projectId));
            const booked = allExp.reduce((s, e) => s + e.amount, 0);
            const approvedExp = allExp.filter((e) => e.status === "approved");
            const approved = approvedExp.reduce((s, e) => s + e.amount, 0);
            const pendingExp = allExp.filter((e) => e.status === "pending" || e.status === "pendingfc");
            const pending = pendingExp.reduce((s, e) => s + e.amount, 0);
            return (
              <>
                <Kpi label="Total Booked" value={`₹${fmtINR(booked)}`} caption={`${allExp.length} expense entries`} />
                <Divider />
                <Kpi label="Verified & Approved" value={`₹${fmtINR(approved)}`} caption={`${approvedExp.length} entries verified`} captionColor="var(--color-secondary)" />
                <Divider />
                <Kpi label="Pending Approval" value={`₹${fmtINR(pending)}`} caption={`${pendingExp.length} entries pending`} captionColor="var(--color-amber)" />
              </>
            );
          })()}

        {pathname.startsWith("/finance/micro") &&
          (() => {
            const globalTotal = visibleProjects.reduce(
              (s, p) => s + (microBudgets[p.id] ?? []).reduce((s2, c) => s2 + microCategoryTotal(c), 0),
              0
            );
            return (
              <div className="flex items-center gap-3">
                <div className="flex h-[30px] items-center gap-2 rounded-md border border-border bg-surface px-2.5 text-xs">
                  <span className="text-muted">Total Micro-Budget:</span>
                  <span id="micro-global-total" className="font-mono font-bold text-ink">
                    ₹{fmtINR(globalTotal)}
                  </span>
                </div>
                <button
                  onClick={() => microUi.expandAll()}
                  className="h-[30px] rounded-md bg-primary px-3.5 text-xs font-semibold text-white hover:bg-primary-600"
                >
                  Expand All
                </button>
                <button
                  onClick={() =>
                    microUi.collapseAll(
                      Object.values(microBudgets).flat().map((c) => c.id),
                      projects.map((p) => p.id)
                    )
                  }
                  className="h-[30px] rounded-md border border-border bg-bg px-3.5 text-xs font-semibold text-ink-2 hover:bg-surface-2"
                >
                  Collapse All
                </button>
              </div>
            );
          })()}
      </div>
    </div>
  );
}
