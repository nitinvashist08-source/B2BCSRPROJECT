"use client";

import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { useFinanceStore } from "@/store/financeStore";
import { PeriodBudget } from "@/types/finance";

export function DeleteBudgetPeriodModal({ budget, onClose }: { budget: PeriodBudget | null; onClose: () => void }) {
  const removePeriodBudget = useFinanceStore((s) => s.removePeriodBudget);

  return (
    <Modal
      open={!!budget}
      onClose={onClose}
      title="Delete Budget Period?"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              if (budget) removePeriodBudget(budget.id);
              onClose();
            }}
          >
            Delete
          </Button>
        </>
      }
    >
      Are you sure you want to delete this budget period? This action cannot be undone.
    </Modal>
  );
}
