"use client";

import { useEffect, useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore, disbListStatus } from "@/store/financeStore";
import { useSessionStore } from "@/store/sessionStore";
import { useSettingsStore } from "@/store/settingsStore";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";
import { Project } from "@/types/project";
import { ProjectStatusBadge } from "@/components/projects/ProjectStatusBadge";
import { AssignProjectSlideOver } from "./AssignProjectSlideOver";

function fmtINR(n: number) {
  return n.toLocaleString("en-IN");
}

// hlp-dot per-tranche-status colors, bImpact_MeetingSplit_v10.html:6855 etc.
// The original's 5-state dot (overdue/duesoon/upcoming/released/noplan)
// collapses to 4 here — "due soon" needs a date-proximity threshold that
// isn't otherwise part of this app's tranche model, so it's folded into
// "upcoming"; a deliberate, minor simplification of a decorative indicator.
const DOT_STYLE: Record<string, string> = {
  overdue: "bg-danger",
  upcoming: "bg-amber",
  released: "bg-secondary",
  noplan: "border-2 border-border-strong bg-transparent",
};

function TrancheDot({ tone, label }: { tone: string; label: string }) {
  return <span className={`inline-block h-2.5 w-2.5 rounded-full ${DOT_STYLE[tone]}`} title={label} />;
}

// hlp-tbl, bImpact_MeetingSplit_v10.html:6832-6977 — per-project Finance
// summary. "Allocated (₹)" reads Project.budget, which Budget Planning →
// Create Budget (PeriodBudgetsPanel.tsx, rendered above this table on the
// same page) write-through syncs whenever a Project is allocated from a
// sanctioned budget — see financeStore.ts's syncProjectBudget. This row's
// own "Edit" button (Sponsor-only) opens AssignProjectSlideOver (fixed to
// this project, Budget Period still selectable), which
// edits/creates the underlying PeriodBudget allocation for this project
// (Project.budget itself is never editable directly any more, to keep it
// from drifting out of sync with whichever allocation actually backs it).
// No category/line-item breakdown lives here — that's Micro Budgeting
// instead (MicroBudgetView.tsx, a separate module, untouched by this change).
export function HighLevelBudgetTable() {
  const projects = useProjectStore((s) => s.projects);
  const disbursements = useFinanceStore((s) => s.disbursements);
  const ensureDisbursements = useFinanceStore((s) => s.ensureDisbursements);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const partners = useSettingsStore((s) => s.partners);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  useEffect(() => {
    projects.forEach((p, i) => {
      ensureDisbursements(p.id, i);
    });
  }, [projects, ensureDisbursements]);

  // Partners only see rows for projects assigned to their own org; sponsors
  // (role !== "partner") get visibleProjects === projects, unchanged.
  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const visibleProjects =
    role === "partner"
      ? projects.filter((p) => isProjectAssignedToPartner(p, projectPartners, partnerName))
      : projects;

  const rows = visibleProjects.map((p) => {
    const tranches = disbursements[p.id] ?? [];
    const disbursed = tranches.filter((t) => t.status === "released").reduce((s, t) => s + t.amount, 0);
    const balance = p.budget - disbursed;
    const st = disbListStatus(tranches);
    const dotTone = !tranches.length
      ? "noplan"
      : tranches.some((t) => t.status === "overdue")
        ? "overdue"
        : tranches.some((t) => t.status === "upcoming")
          ? "upcoming"
          : "released";
    return { p, disbursed, balance, st, dotTone };
  });

  const totalAlloc = rows.reduce((s, r) => s + r.p.budget, 0);
  const totalDisb = rows.reduce((s, r) => s + r.disbursed, 0);
  const totalBal = rows.reduce((s, r) => s + r.balance, 0);

  return (
    <div className="p-[22px]">
    <div className="overflow-hidden rounded-[10px] border border-border bg-surface">
      <table className="w-full table-fixed border-collapse text-[12.5px]">
        <thead>
          <tr className="bg-surface-2">
            <th className="w-[190px] px-4 py-[9px] text-left text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Project</th>
            <th className="w-[140px] px-4 py-[9px] text-left text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Partner</th>
            <th className="w-[110px] px-4 py-[9px] text-right text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Allocated (₹)</th>
            <th className="w-[110px] px-4 py-[9px] text-right text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Disbursed (₹)</th>
            <th className="w-[110px] px-4 py-[9px] text-right text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Balance (₹)</th>
            <th className="w-[80px] px-4 py-[9px] text-center text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Status</th>
            <th className="w-[60px] px-4 py-[9px] text-center text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted" title="Current / next tranche disbursement status">
              Tranche
            </th>
            {role !== "partner" && (
              <th className="w-[70px] px-4 py-[9px] text-right text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Action</th>
            )}
          </tr>
        </thead>
        <tbody>
          {rows.map(({ p, disbursed, balance, st, dotTone }) => (
            <tr key={p.id} className="border-t border-border">
              <td className="px-4 py-3">
                <div className="overflow-hidden text-ellipsis whitespace-nowrap text-[13.5px] font-semibold text-ink">{p.name}</div>
                <div className="mt-0.5 font-mono text-[10.5px] font-bold text-muted">{p.code}</div>
              </td>
              <td className="px-4 py-3 text-[12.5px] text-ink-2">{p.partner}</td>
              <td className="px-4 py-3 text-right font-mono text-[13px] font-bold text-ink">{fmtINR(p.budget)}</td>
              <td className="px-4 py-3 text-right font-mono text-[13px] font-bold text-ink">{fmtINR(disbursed)}</td>
              <td className={`px-4 py-3 text-right font-mono text-[13px] font-bold ${balance < p.budget * 0.15 ? "text-amber" : "text-secondary"}`}>
                {fmtINR(balance)}
              </td>
              <td className="px-4 py-3 text-center">
                <ProjectStatusBadge status={p.status} />
              </td>
              <td className="px-4 py-3 text-center">
                <TrancheDot tone={dotTone} label={st.label} />
              </td>
              {role !== "partner" && (
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => setEditingProject(p)}
                    className="rounded-md border border-border bg-surface px-2.5 py-1 text-[11.5px] font-semibold text-ink-2 hover:border-border-strong hover:bg-bg"
                  >
                    Edit
                  </button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan={2} className="border-t-[1.5px] border-border bg-surface-2 px-4 py-2.5 text-[12.5px] font-bold text-ink">
              {visibleProjects.length} project{visibleProjects.length === 1 ? "" : "s"} ·{" "}
              <span className="ml-1 inline-flex items-center gap-1.5 text-[11px] font-medium">
                <span className="inline-block h-2 w-2 rounded-full bg-danger" /> Overdue
                <span className="inline-block h-2 w-2 rounded-full bg-amber" /> Upcoming
                <span className="inline-block h-2 w-2 rounded-full bg-secondary" /> Released
                <span className="inline-block h-2 w-2 rounded-full border-2 border-border-strong" /> No Plan
              </span>
            </td>
            <td className="border-t-[1.5px] border-border bg-surface-2 px-4 py-2.5 text-right font-mono text-[13px] font-bold text-ink">
              {fmtINR(totalAlloc)}
            </td>
            <td className="border-t-[1.5px] border-border bg-surface-2 px-4 py-2.5 text-right font-mono text-[13px] font-bold text-ink">
              {fmtINR(totalDisb)}
            </td>
            <td className="border-t-[1.5px] border-border bg-surface-2 px-4 py-2.5 text-right font-mono text-[13px] font-bold text-secondary">
              {fmtINR(totalBal)}
            </td>
            <td colSpan={role !== "partner" ? 3 : 2} className="border-t-[1.5px] border-border bg-surface-2" />
          </tr>
        </tfoot>
      </table>
    </div>

    {role !== "partner" && (
      <AssignProjectSlideOver
        key={editingProject?.id ?? "none"}
        open={!!editingProject}
        onClose={() => setEditingProject(null)}
        fixedProjectId={editingProject?.id}
      />
    )}
    </div>
  );
}
