"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useFinanceStore } from "@/store/financeStore";
import { useProjectStore } from "@/store/projectStore";
import { useAlertStore } from "@/store/alertStore";
import { getPartnersByProject } from "@/lib/dashboardScope";
import { TrancheMilestoneType } from "@/types/finance";

function fmtInr(n: number): string {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

type MilestoneType = TrancheMilestoneType;

function CloseIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-3.5">
      <label className="mb-1.5 block text-xs font-semibold text-ink-2">{label}</label>
      {children}
    </div>
  );
}

const inputCls =
  "box-border h-[38px] w-full rounded-lg border-[1.5px] border-border bg-bg px-3 text-[13px] text-ink outline-none transition-colors focus:border-primary";
const selCls =
  "box-border h-[38px] w-full cursor-pointer rounded-lg border-[1.5px] border-border bg-bg px-2.5 text-[13px] text-ink outline-none transition-colors focus:border-primary";

type Draft = {
  name: string;
  amount: string;
  milestoneType: MilestoneType;
  // References the Project's own WBS row id (WbsRow.id) — never a copied
  // task label. See ScheduleTrancheSlideOver's own header comment.
  wbsRowId: string;
  timeDate: string;
  expPct: string;
  expOf: string;
  balance: string;
  custom: string;
  remarks: string;
};

function emptyDraft(): Draft {
  return { name: "", amount: "", milestoneType: "task", wbsRowId: "", timeDate: "", expPct: "", expOf: "Previous Tranche", balance: "", custom: "", remarks: "" };
}

// The original's "Save Milestone" button calls a `saveCustomTranche()`
// function that is never defined anywhere in the source (only `saveTranche()`
// exists, bImpact_MeetingSplit_v10.html:7380 vs :13613) — a dead-button typo
// bug that makes Add Tranche permanently non-functional. That's a defect to
// fix, not replicate (project plan's "known source defects" bucket), so this
// wires to the equivalent of the real `saveTranche()` logic.
// `taskLabel` is the SELECTED WBS row's current task-name cell (looked up by
// the caller, which has the live WBS state) — this only ever becomes the
// persisted tranche's cached fallback `condition` text; the live, always-
// up-to-date name is resolved separately at render time via
// `linkedWbsRowId` (see TranchePipeline.tsx).
function buildConditionAndDate(d: Draft, taskLabel: string): { condition: string; date: string } {
  switch (d.milestoneType) {
    case "task":
      return { condition: `Task '${taskLabel || "Specific Task"}' Completed`, date: "" };
    case "time":
      return { condition: `Time trigger — ${d.timeDate || "TBD"}`, date: d.timeDate };
    case "expenditure":
      return { condition: `${d.expPct || "0"}% utilization of ${d.expOf}`, date: "" };
    case "balance":
      return { condition: `Balance falls below ₹${Number(d.balance || 0).toLocaleString("en-IN")}`, date: "" };
    case "custom":
      return { condition: d.custom || "Custom condition", date: "" };
  }
}

// Matches the "Schedule Tranche" slide-over, bImpact_MeetingSplit_v10.html:7307-7381
export function ScheduleTrancheSlideOver({
  projectId,
  projectName,
  budget,
  open,
  onClose,
}: {
  projectId: string;
  projectName: string;
  budget: number;
  open: boolean;
  onClose: () => void;
}) {
  const addTranche = useFinanceStore((s) => s.addTranche);
  // WBS is the single source of truth for this project's tasks — no
  // separate/duplicated task list lives inside Disbursement (see
  // types/project.ts's WbsState). The first column is treated as the
  // task-name field, matching the WBS table's own default schema
  // ("Task / Activity Name" is always column 0).
  const wbs = useProjectStore((s) => s.wbs[projectId]);
  const wbsRows = wbs?.rows ?? [];
  const taskColumnId = wbs?.columns[0]?.id;
  const router = useRouter();
  const [draft, setDraft] = useState<Draft>(emptyDraft);

  function handleClose() {
    setDraft(emptyDraft());
    onClose();
  }

  function goToWbs() {
    handleClose();
    router.push(`/projects/${projectId}/wbs`);
  }

  function handleSave() {
    const selectedRow = wbsRows.find((r) => r.id === draft.wbsRowId);
    const taskLabel = selectedRow && taskColumnId ? selectedRow.cells[taskColumnId] ?? "" : "";
    const { condition, date } = buildConditionAndDate(draft, taskLabel);
    const trancheName = draft.name.trim() || "New Tranche";
    const amount = Number(draft.amount) || 0;
    addTranche(projectId, {
      name: trancheName,
      condition,
      date,
      amount,
      remarks: draft.remarks.trim() || undefined,
      milestoneType: draft.milestoneType,
      linkedWbsRowId: draft.milestoneType === "task" && selectedRow ? selectedRow.id : undefined,
    });
    // Event push (not derived — "a tranche was just created" is a moment,
    // not a recomputable condition; the overdue/due-soon/upcoming/released
    // alerts for this SAME tranche are still handled separately and
    // entirely by alertRules.ts's derived rules once it exists in state).
    const partner = getPartnersByProject(projectId)[0];
    if (partner) {
      useAlertStore.getState().pushHistoryEvent({
        key: `tranche_created:project:${projectId}`,
        type: "tranche_created",
        category: "finance",
        severity: "info",
        title: "New tranche scheduled",
        message: `A new tranche "${trancheName}" of ${fmtInr(amount)} has been added to ${projectName}'s disbursement plan.`,
        targetPartnerOrgId: partner.id,
        entityType: "tranche",
        entityId: projectId,
        projectId,
        action: { label: "View Tranche", route: `/finance/disbursement/${projectId}` },
      });
    }
    handleClose();
  }

  const pct = budget ? ((Number(draft.amount) || 0) / budget) * 100 : 0;

  return (
    <>
      <div
        className={`fixed inset-0 z-[400] bg-black/40 backdrop-blur-[2px] transition-opacity ${open ? "opacity-100" : "pointer-events-none opacity-0"}`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) handleClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[401] flex h-full w-[480px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 border-b border-border px-5 py-4">
          <span className="flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-[9px]" style={{ background: "rgba(124,58,237,0.08)", color: "#7c3aed" }}>
            <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <line x1="22" x2="11" y1="2" y2="13" />
              <polygon points="22 2 15 22 11 13 2 9 22 2" />
            </svg>
          </span>
          <div>
            <div className="text-[0.95rem] font-bold text-ink">Disbursement Planning</div>
            <div className="mt-px text-[11.5px] text-muted">Plan a disbursement schedule for Tranche</div>
          </div>
          <button onClick={handleClose} className="ml-auto flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-md text-muted hover:bg-bg hover:text-ink">
            <CloseIcon />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          <div className="mb-4 rounded-md border border-[rgba(10,151,217,0.2)] bg-primary-50 px-3 py-2.5">
            <div className="mb-0.5 text-[11px] font-semibold uppercase tracking-wide text-primary-700">Target Project</div>
            <div className="text-[13px] font-semibold text-ink">{projectName}</div>
          </div>

          <Field label="Tranche Name *">
            <input
              className={inputCls}
              placeholder="e.g. Tranche 3 — Mid-Term Release"
              value={draft.name}
              onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
            />
          </Field>

          <Field label="Release Amount (₹) *">
            <div className="relative">
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[13px] text-muted">₹</span>
              <input
                type="number"
                className={`${inputCls} pl-6`}
                placeholder="0"
                value={draft.amount}
                onChange={(e) => setDraft((d) => ({ ...d, amount: e.target.value }))}
              />
            </div>
            {draft.amount && <div className="mt-1 text-[11px] text-muted">{pct.toFixed(1)}% of project budget</div>}
          </Field>

          <div className="mb-3.5 rounded-lg border-[1.5px] border-border bg-surface p-3">
            <div className="mb-3 text-[12.5px] font-semibold text-ink">
              Trigger Milestone <span className="text-danger">*</span>
            </div>
            <Field label="Milestone Type">
              <select
                className={selCls}
                value={draft.milestoneType}
                onChange={(e) => setDraft((d) => ({ ...d, milestoneType: e.target.value as MilestoneType }))}
              >
                <option value="task">Specific Task Completion</option>
                <option value="time">Time Frame (Date based)</option>
                <option value="expenditure">Expenditure / Utilization %</option>
                <option value="balance">Remaining Balance Amount</option>
                <option value="custom">Custom Condition</option>
              </select>
            </Field>

            {draft.milestoneType === "task" && (
              <div className="mb-1 rounded-md border border-[rgba(245,158,11,0.2)] bg-[rgba(245,158,11,0.05)] p-3">
                <label className="mb-1.5 block text-xs font-semibold text-amber-700">Link WBS Task</label>
                {wbsRows.length === 0 ? (
                  <div className="rounded-md border border-dashed border-border bg-surface px-3 py-3 text-center">
                    <div className="mb-1 text-[12.5px] font-semibold text-ink-2">No WBS tasks available for this project.</div>
                    <p className="mb-2 text-[11.5px] leading-snug text-muted">
                      Create tasks in the project&apos;s Work Breakdown Structure before assigning them to Disbursement.
                    </p>
                    <button type="button" onClick={goToWbs} className="text-[12px] font-semibold text-primary hover:underline">
                      Go to Work Breakdown Structure
                    </button>
                  </div>
                ) : (
                  <select className={selCls} value={draft.wbsRowId} onChange={(e) => setDraft((d) => ({ ...d, wbsRowId: e.target.value }))}>
                    <option value="" disabled>
                      Select from active project tasks…
                    </option>
                    {wbsRows.map((row) => (
                      <option key={row.id} value={row.id}>
                        {row.id} — {(taskColumnId ? row.cells[taskColumnId] : "") || "(untitled task)"}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            )}
            {draft.milestoneType === "time" && (
              <Field label="Trigger Date">
                <input type="date" className={inputCls} value={draft.timeDate} onChange={(e) => setDraft((d) => ({ ...d, timeDate: e.target.value }))} />
              </Field>
            )}
            {draft.milestoneType === "expenditure" && (
              <div className="grid grid-cols-2 gap-3">
                <Field label="Min. Utilization %">
                  <input
                    type="number"
                    max={100}
                    className={inputCls}
                    placeholder="e.g. 75"
                    value={draft.expPct}
                    onChange={(e) => setDraft((d) => ({ ...d, expPct: e.target.value }))}
                  />
                </Field>
                <Field label="Of Tranche">
                  <select className={selCls} value={draft.expOf} onChange={(e) => setDraft((d) => ({ ...d, expOf: e.target.value }))}>
                    <option>Previous Tranche</option>
                    <option>Total Disbursed</option>
                  </select>
                </Field>
              </div>
            )}
            {draft.milestoneType === "balance" && (
              <Field label="Trigger when balance falls below (₹)">
                <input
                  type="number"
                  className={inputCls}
                  placeholder="e.g. 500000"
                  value={draft.balance}
                  onChange={(e) => setDraft((d) => ({ ...d, balance: e.target.value }))}
                />
              </Field>
            )}
            {draft.milestoneType === "custom" && (
              <Field label="Condition Description">
                <input
                  className={inputCls}
                  placeholder="e.g. Board approval of phase 1"
                  value={draft.custom}
                  onChange={(e) => setDraft((d) => ({ ...d, custom: e.target.value }))}
                />
              </Field>
            )}
          </div>

          <Field label="Remarks / Documents required">
            <textarea
              className="box-border h-[68px] w-full resize-none rounded-lg border-[1.5px] border-border bg-bg px-3 py-2.5 text-[13px] text-ink outline-none focus:border-primary"
              placeholder="Specify any audit certificates or proofs required…"
              value={draft.remarks}
              onChange={(e) => setDraft((d) => ({ ...d, remarks: e.target.value }))}
            />
          </Field>
        </div>

        <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
          <button onClick={handleClose} className="flex h-9 items-center rounded-lg border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 hover:border-border-strong">
            Cancel
          </button>
          <button onClick={handleSave} className="flex h-9 items-center rounded-lg bg-primary px-4 text-sm font-semibold text-white hover:bg-primary-600">
            Save Milestone
          </button>
        </div>
      </div>
    </>
  );
}
