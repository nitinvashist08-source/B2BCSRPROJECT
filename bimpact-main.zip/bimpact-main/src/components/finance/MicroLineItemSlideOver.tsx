"use client";

import { useState } from "react";
import { FundingType, MonthlyPlan, MONTHS } from "@/types/finance";

// inp-cat-lineitem-sel options, bImpact_MeetingSplit_v10.html:15389-15393
const PRESET_LINE_ITEMS = ["Training Logistics", "Field Equipment", "Awareness Campaigns"];

const TYPE_META: Record<FundingType, { badge: string; badgeBg: string; label: string }> = {
  ds: { badge: "DS", badgeBg: "#0ea5e9", label: "Direct Support" },
  bs: { badge: "BC", badgeBg: "#16a34a", label: "Beneficiary Contribution" },
  as: { badge: "AO", badgeBg: "#9333ea", label: "Agency / Other" },
};

function emptyMonthly(): MonthlyPlan {
  return { ds: Array(12).fill(0), bs: Array(12).fill(0), as: Array(12).fill(0) };
}

export type MicroLineItemInitial = {
  mode: "add" | "edit";
  categoryId?: string;
  itemId?: string;
  subItemId?: string;
  lineItemName: string;
  subLineItemName: string;
  showSubLineItem: boolean;
  monthly: MonthlyPlan;
};

function CloseIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}
function LocationIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}
function ChevronIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="#64748b" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

// fin-so-category, bImpact_MeetingSplit_v10.html:15352-15478 — the ONE
// reachable add/edit entry point for micro-budget line items. Two sibling
// slide-overs exist in the source (#fin-so-lineitem, #fin-so-micro-lineitem)
// but neither is ever opened from a real button (addMicroLineItem itself is
// never called, and fin-so-lineitem's own Save button just closes without
// saving) — genuinely dead UI, not ported.
export function MicroLineItemSlideOver({
  projectLabel,
  location,
  open,
  onClose,
  initial,
  onSave,
}: {
  projectLabel: string;
  location: string;
  open: boolean;
  onClose: () => void;
  initial: MicroLineItemInitial;
  onSave: (input: {
    editing?: { categoryId: string; itemId: string; subItemId?: string };
    lineItemName: string;
    subLineItemName: string;
    monthly: MonthlyPlan;
  }) => void;
}) {
  const isPreset = PRESET_LINE_ITEMS.includes(initial.lineItemName);
  const [lineItemSel, setLineItemSel] = useState(() => (isPreset ? initial.lineItemName : initial.lineItemName ? "_new" : ""));
  const [lineItemNew, setLineItemNew] = useState(() => (isPreset ? "" : initial.lineItemName));
  const [showSubLine, setShowSubLine] = useState(initial.showSubLineItem);
  const [subLineItem, setSubLineItem] = useState(initial.subLineItemName);
  const [monthly, setMonthly] = useState<MonthlyPlan>(() => initial.monthly ?? emptyMonthly());
  const [supported, setSupported] = useState<Record<FundingType, boolean>>({ ds: true, bs: true, as: true });

  function reset() {
    setLineItemSel("");
    setLineItemNew("");
    setShowSubLine(false);
    setSubLineItem("");
    setMonthly(emptyMonthly());
    setSupported({ ds: true, bs: true, as: true });
  }
  function handleClose() {
    reset();
    onClose();
  }

  function updateCell(type: FundingType, monthIndex: number, value: string) {
    setMonthly((d) => {
      const next = { ...d, [type]: [...d[type]] };
      next[type][monthIndex] = Number(value) || 0;
      return next;
    });
  }

  // saveMicroCat's alert-and-abort guard, bImpact_MeetingSplit_v10.html:14584-14587
  const lineItemName = lineItemSel === "_new" ? lineItemNew.trim() : lineItemSel;
  const total = (Object.keys(monthly) as FundingType[]).reduce((sum, t) => sum + monthly[t].reduce((a, b) => a + b, 0), 0);

  function handleSave() {
    if (!lineItemName) return;
    onSave({
      editing: initial.mode === "edit" ? { categoryId: initial.categoryId!, itemId: initial.itemId!, subItemId: initial.subItemId } : undefined,
      lineItemName,
      subLineItemName: showSubLine ? subLineItem.trim() : "",
      monthly,
    });
    reset();
  }

  const selectLabelText = supported.ds && supported.bs && supported.as
    ? "All support types"
    : !supported.ds && !supported.bs && !supported.as
      ? "Select support types…"
      : (["ds", "bs", "as"] as FundingType[]).filter((t) => supported[t]).map((t) => TYPE_META[t].label).join(", ");

  return (
    <>
      <div
        className={`fixed inset-0 z-[400] bg-black/40 backdrop-blur-[2px] transition-opacity ${open ? "opacity-100" : "pointer-events-none opacity-0"}`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) handleClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[401] flex h-full w-[550px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 border-b border-border px-5 py-4">
          <span className="flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-sm bg-primary-50 text-primary">
            <LocationIcon />
          </span>
          <div>
            <div className="text-[0.95rem] font-bold text-ink">{initial.mode === "edit" ? "Edit Line Item" : "Add Line Item"}</div>
            <div className="mt-px text-[11.5px] text-muted">Add a budget line item to the targeted project</div>
          </div>
          <button onClick={handleClose} className="ml-auto flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-md text-muted hover:bg-bg hover:text-ink">
            <CloseIcon />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          <div className="mb-[18px] rounded-md border border-[rgba(10,151,217,0.2)] bg-primary-50 px-3.5 py-3">
            <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-[0.05em] text-primary">Targeted Project</div>
            <div className="mb-1 text-[13.5px] font-bold text-ink">{projectLabel}</div>
            <div className="flex items-center gap-1 text-xs text-muted">
              <LocationIcon />
              <span>{location || "Location not specified"}</span>
            </div>
          </div>

          <div className="mb-4">
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.06em] text-muted">
              Line Item Name <span className="text-danger">*</span>
            </label>
            <div className="relative">
              <select
                value={lineItemSel}
                onChange={(e) => setLineItemSel(e.target.value)}
                className="box-border h-[38px] w-full cursor-pointer appearance-none rounded-sm border-[1.5px] border-border bg-bg pl-3 pr-8 text-[13px] text-ink outline-none focus:border-primary"
              >
                <option value="" disabled>
                  Select Line Item…
                </option>
                {PRESET_LINE_ITEMS.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
                <option value="_new">+ Create New Line Item</option>
              </select>
              <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2">
                <ChevronIcon />
              </span>
            </div>
            {lineItemSel === "_new" && (
              <input
                value={lineItemNew}
                onChange={(e) => setLineItemNew(e.target.value)}
                placeholder="Enter new line item name"
                className="mt-2 box-border h-[38px] w-full rounded-sm border-[1.5px] border-border bg-bg px-3 text-[13px] text-ink outline-none focus:border-primary"
              />
            )}
          </div>

          {!showSubLine ? (
            <div className="mb-4 flex justify-end">
              <button
                onClick={() => setShowSubLine(true)}
                className="inline-flex h-6 items-center rounded-md border border-border bg-surface px-2.5 text-[11px] font-medium text-ink-2 hover:bg-bg"
              >
                + Add Sub Line Item
              </button>
            </div>
          ) : (
            <div className="mb-4">
              <div className="mb-1 flex items-center justify-between">
                <label className="text-[11px] font-bold uppercase tracking-[0.06em] text-muted">Sub Line Item Name</label>
                <button
                  onClick={() => {
                    setSubLineItem("");
                    setShowSubLine(false);
                  }}
                  className="text-[11px] font-medium text-danger"
                >
                  Remove
                </button>
              </div>
              <input
                value={subLineItem}
                onChange={(e) => setSubLineItem(e.target.value)}
                placeholder="e.g., Venue Booking, Lenovo M10…"
                className="box-border h-[38px] w-full rounded-sm border-[1.5px] border-border bg-bg px-3 text-[13px] text-ink outline-none focus:border-primary"
              />
            </div>
          )}

          <div className="mb-6">
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.06em] text-muted">
              Supported By <span className="text-danger">*</span>
            </label>
            <details className="relative w-full rounded-sm border border-border bg-surface">
              <summary className="flex h-9 list-none items-center justify-between px-3 text-[13px] text-ink outline-none [&::-webkit-details-marker]:hidden">
                <span>{selectLabelText}</span>
                <ChevronIcon />
              </summary>
              <div className="absolute left-0 right-0 top-[calc(100%+4px)] z-10 flex flex-col gap-1 rounded-md border border-border bg-surface p-2 shadow-[0_4px_12px_rgba(0,0,0,0.1)]">
                {(["ds", "bs", "as"] as FundingType[]).map((t) => (
                  <label key={t} className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-[13px] hover:bg-bg">
                    <input
                      type="checkbox"
                      checked={supported[t]}
                      onChange={(e) => setSupported((s) => ({ ...s, [t]: e.target.checked }))}
                    />
                    <span className="flex items-center gap-1.5">
                      <span className="rounded-[3px] px-1 py-0.5 text-[9px] font-bold text-white" style={{ background: TYPE_META[t].badgeBg }}>
                        {TYPE_META[t].badge}
                      </span>
                      {TYPE_META[t].label}
                    </span>
                  </label>
                ))}
              </div>
            </details>
          </div>

          <div className="mb-6">
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.06em] text-muted">
              Monthly Planning for Direct Support, Beneficiary Contribution and Agency/Other Support (₹)
            </label>
            <div className="mt-1 overflow-hidden rounded-md border border-border">
              <table className="w-full table-fixed border-collapse text-left text-[11px]">
                <thead className="bg-surface-2 shadow-[0_1px_0_var(--color-border)]">
                  <tr>
                    <th className="w-[60px] border-r border-border p-2 font-semibold text-muted">Month</th>
                    {supported.ds && <th className="w-[90px] p-2 font-semibold text-muted">Direct Support</th>}
                    {supported.bs && <th className="w-[90px] p-2 font-semibold text-muted">Benef. contribution</th>}
                    {supported.as && <th className="w-[90px] p-2 font-semibold text-muted">Agency / Other Support</th>}
                  </tr>
                </thead>
                <tbody>
                  {MONTHS.map((m, i) => (
                    <tr key={m} className="border-b border-border bg-surface">
                      <td className="border-r border-border px-2 py-1.5 font-medium">{m}</td>
                      {supported.ds && (
                        <td className="px-2 py-1.5">
                          <input
                            type="number"
                            min={0}
                            value={monthly.ds[i] || ""}
                            onChange={(e) => updateCell("ds", i, e.target.value)}
                            className="box-border h-6 w-full max-w-[75px] rounded-sm border border-border px-1.5 text-[11px]"
                          />
                        </td>
                      )}
                      {supported.bs && (
                        <td className="px-2 py-1.5">
                          <input
                            type="number"
                            min={0}
                            value={monthly.bs[i] || ""}
                            onChange={(e) => updateCell("bs", i, e.target.value)}
                            className="box-border h-6 w-full max-w-[75px] rounded-sm border border-border px-1.5 text-[11px]"
                          />
                        </td>
                      )}
                      {supported.as && (
                        <td className="px-2 py-1.5">
                          <input
                            type="number"
                            min={0}
                            value={monthly.as[i] || ""}
                            onChange={(e) => updateCell("as", i, e.target.value)}
                            className="box-border h-6 w-full max-w-[75px] rounded-sm border border-border px-1.5 text-[11px]"
                          />
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.06em] text-muted">Total Budget Amount (₹)</label>
            <div className="font-mono text-base font-bold text-ink">{total.toLocaleString("en-IN")}</div>
          </div>
        </div>

        <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
          <button onClick={handleClose} className="flex h-9 items-center rounded-sm border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 hover:border-border-strong">
            Cancel
          </button>
          <button onClick={handleSave} className="flex h-9 items-center rounded-sm bg-primary px-4 text-sm font-semibold text-white hover:bg-primary-600">
            {initial.mode === "edit" ? "Save Line Item" : "Add Line Item"}
          </button>
        </div>
      </div>
    </>
  );
}
