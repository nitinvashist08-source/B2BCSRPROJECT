"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useFinanceStore } from "@/store/financeStore";
import { useProjectStore } from "@/store/projectStore";
import { useSessionStore } from "@/store/sessionStore";
import { pushOwnershipAlerts } from "@/lib/ownershipAlerts";
import { OwnershipMode } from "@/types/project";

// Same three options/labels/descriptions as WbsTable.tsx's "Who creates the
// WBS?" strip / DocumentOwnershipStrip.tsx's "Who will create the
// documents?" strip — same OwnershipMode values, same governance model.
// Unlike those, this doesn't stay permanently pinned at the top of the page:
// per spec, Micro-Budgeting's existing layout/design must stay unchanged, so
// this renders as a small "Ownership: X ▾" control the caller places
// wherever fits the existing header, opening a compact panel with the same
// three choices instead of a permanent 3-card strip.
const OPTIONS: { mode: OwnershipMode; label: string; sub: string }[] = [
  { mode: "self", label: "You (CSR Head / PM)", sub: "You edit  ·  Partner views only" },
  { mode: "partner", label: "Partner (Implementing Org)", sub: "Partner edits  ·  You view only" },
  { mode: "both", label: "Both (Collaborative)", sub: "Both can edit  ·  Full collaboration" },
];
const LABELS: Record<OwnershipMode, string> = {
  self: "You (CSR Head / PM)",
  partner: "Partner (Implementing Org)",
  both: "Both (Collaborative)",
};

function ChevronIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

const PANEL_WIDTH = 280;
const PANEL_HEIGHT_ESTIMATE = 230;
const GAP = 6;

// Sponsor-only, exactly like DocumentOwnershipStrip.tsx — an invited partner
// never sees or triggers this (only inherits whatever mode the sponsor
// already configured; see setMicroBudgetOwnership's own sponsor-only guard
// in financeStore.ts, which refuses the change even via a direct call).
//
// Rendered via a portal to document.body (same fix as
// BudgetPeriodActionMenu.tsx) rather than a plain position:absolute panel —
// MicroBudgetView.tsx's project card uses overflow-hidden for its
// rounded-corner clipping, which was cutting this panel off (invisible
// whether the card was collapsed or expanded, since the card itself clips
// regardless of that state, not just while collapsed). A portal escapes
// that ancestor's overflow entirely.
export function MicroBudgetOwnershipDropdown({ projectId }: { projectId: string }) {
  const role = useSessionStore((s) => s.role);
  const mode = useFinanceStore((s) => s.microBudgetOwnership[projectId] ?? null);
  const setMicroBudgetOwnership = useFinanceStore((s) => s.setMicroBudgetOwnership);
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));
  const [open, setOpen] = useState(false);

  // Shared algorithm (ownershipAlerts.ts) — now the ONE source of both the
  // "assigned to you" and "changed" alerts for this resource (previously
  // "assigned" was a separate derived rule in alertRules.ts's
  // microBudgetAlerts; removed, since the shared algorithm already covers
  // that exact condition — null→partner — and per the corrected spec, the
  // old derived rule ALSO incorrectly notified the Sponsor on initial
  // assignment, which this shared version deliberately never does). See
  // DocumentOwnershipStrip.tsx's handleNotifyPartner for the full rule.
  function handleNotifyPartnerOfChange(newMode: OwnershipMode, previousMode: OwnershipMode | null) {
    if (!project) return;
    pushOwnershipAlerts("micro_budget", projectId, project.name, previousMode, newMode);
  }
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  function openPanel() {
    const rect = triggerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const spaceBelow = window.innerHeight - rect.bottom;
    const openUpward = spaceBelow < PANEL_HEIGHT_ESTIMATE + GAP && rect.top > PANEL_HEIGHT_ESTIMATE + GAP;
    const top = openUpward ? rect.top - PANEL_HEIGHT_ESTIMATE - GAP : rect.bottom + GAP;
    const left = Math.max(8, Math.min(rect.right - PANEL_WIDTH, window.innerWidth - PANEL_WIDTH - 8));
    setPos({ top, left });
    setOpen(true);
  }

  useEffect(() => {
    if (!open) return;
    function handlePointerDown(e: MouseEvent) {
      const target = e.target as Node;
      if (triggerRef.current?.contains(target) || panelRef.current?.contains(target)) return;
      setOpen(false);
    }
    function handleDismiss() {
      setOpen(false);
    }
    document.addEventListener("mousedown", handlePointerDown);
    window.addEventListener("scroll", handleDismiss, true);
    window.addEventListener("resize", handleDismiss);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      window.removeEventListener("scroll", handleDismiss, true);
      window.removeEventListener("resize", handleDismiss);
    };
  }, [open]);

  if (role === "partner") return null;

  return (
    <>
      <button
        ref={triggerRef}
        onClick={(e) => {
          e.stopPropagation();
          open ? setOpen(false) : openPanel();
        }}
        className="flex h-7 items-center gap-1.5 rounded-md border border-border bg-surface px-2.5 text-xs font-semibold text-ink-2 hover:border-border-strong"
      >
        Ownership: {mode ? LABELS[mode] : "Not set"}
        <ChevronIcon />
      </button>
      {open &&
        pos &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            ref={panelRef}
            onClick={(e) => e.stopPropagation()}
            style={{ position: "fixed", top: pos.top, left: pos.left, width: PANEL_WIDTH }}
            className="z-[500] rounded-lg border border-border bg-surface p-3 shadow-[0_8px_24px_rgba(0,0,0,0.12)]"
          >
            <p className="mb-2.5 text-xs font-bold text-ink">Who will create the Micro Budget?</p>
            <div className="flex flex-col gap-1.5">
              {OPTIONS.map((opt) => {
                const on = mode === opt.mode;
                return (
                  <button
                    key={opt.mode}
                    onClick={() => {
                      setMicroBudgetOwnership(projectId, opt.mode);
                      handleNotifyPartnerOfChange(opt.mode, mode);
                      setOpen(false);
                    }}
                    className={`flex items-start gap-2 rounded-md border p-2 text-left transition-colors ${
                      on ? "border-primary bg-primary-50" : "border-border hover:bg-bg"
                    }`}
                  >
                    <span
                      className={`mt-0.5 flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full border-2 ${
                        on ? "border-primary bg-primary" : "border-border-strong bg-surface"
                      }`}
                    >
                      {on && <span className="h-1.5 w-1.5 rounded-full bg-white" />}
                    </span>
                    <span>
                      <span className="block text-xs font-semibold text-ink">{opt.label}</span>
                      <span className="block text-[11px] leading-snug text-muted">{opt.sub}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          </div>,
          document.body
        )}
    </>
  );
}
