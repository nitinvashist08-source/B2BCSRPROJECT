"use client";

import { useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore, periodBudgetBalance } from "@/store/financeStore";

function CloseIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-3.5">
      <label className="mb-1.5 block text-xs font-semibold text-ink-2">{label}</label>
      {children}
    </div>
  );
}

const inputCls =
  "box-border h-[38px] w-full rounded-lg border-[1.5px] border-border bg-bg px-3 text-[13px] text-ink outline-none transition-colors focus:border-primary disabled:bg-surface-2 disabled:text-muted";
const selCls =
  "box-border h-[38px] w-full cursor-pointer rounded-lg border-[1.5px] border-border bg-bg px-2.5 text-[13px] text-ink outline-none transition-colors focus:border-primary disabled:bg-surface-2 disabled:text-muted disabled:cursor-not-allowed";
const errCls = "border-danger";

function fmtINR(n: number) {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}
function fmtDate(iso: string) {
  if (!iso) return "—";
  const [y, m, d] = iso.split("-");
  const month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][parseInt(m, 10) - 1] ?? "";
  return `${parseInt(d, 10)} ${month} ${y}`;
}

// Budget Planning → Assign Project — the ONE place a Project's budget
// allocation is created or edited, entirely separate from Create Budget
// (which only ever sets up the sanctioned pool). One component covers
// every entry point in the app rather than duplicating this logic per
// call site:
//   - Budget Planning's own top-level "Assign Project" CTA: nothing fixed,
//     Sponsor picks both Budget Period and Project.
//   - A Budget Period row's "Allocate to Project": `fixedBudgetId` set,
//     Project still open (excluding ones already allocated in it).
//   - A Project row's "Edit" (HighLevelBudgetTable.tsx): `fixedProjectId`
//     set, Budget Period still open (pick which period to allocate/edit
//     this project's amount in).
//   - An existing allocation's own "Edit" (inside an expanded Budget
//     Period row): both fixed — only the amount is editable.
// Whether this is an add or an edit is derived, not passed in: if the
// currently-selected Budget+Project pair already has an allocation, saving
// updates it (excluding its own current amount from the balance check);
// otherwise saving creates a new one.
export function AssignProjectSlideOver({
  open,
  onClose,
  fixedBudgetId,
  fixedProjectId,
}: {
  open: boolean;
  onClose: () => void;
  fixedBudgetId?: string;
  fixedProjectId?: string;
}) {
  const projects = useProjectStore((s) => s.projects);
  const periodBudgets = useFinanceStore((s) => s.periodBudgets);
  const addAllocation = useFinanceStore((s) => s.addAllocation);
  const updateAllocation = useFinanceStore((s) => s.updateAllocation);

  function existingAmountFor(budgetId: string, projectId: string): string {
    const b = periodBudgets.find((x) => x.id === budgetId);
    const a = b?.allocations.find((x) => x.projectId === projectId);
    return a ? String(a.allocatedAmount) : "";
  }

  const [budgetId, setBudgetId] = useState(fixedBudgetId ?? "");
  const [projectId, setProjectId] = useState(fixedProjectId ?? "");
  const [amount, setAmount] = useState(fixedBudgetId && fixedProjectId ? existingAmountFor(fixedBudgetId, fixedProjectId) : "");
  const [touched, setTouched] = useState(false);

  function reset() {
    setBudgetId(fixedBudgetId ?? "");
    setProjectId(fixedProjectId ?? "");
    setAmount(fixedBudgetId && fixedProjectId ? existingAmountFor(fixedBudgetId, fixedProjectId) : "");
    setTouched(false);
  }
  function handleClose() {
    reset();
    onClose();
  }

  function handleBudgetChange(id: string) {
    setBudgetId(id);
    setAmount(projectId ? existingAmountFor(id, projectId) : "");
  }
  function handleProjectChange(id: string) {
    setProjectId(id);
    setAmount(budgetId ? existingAmountFor(budgetId, id) : "");
  }

  const selectedBudget = periodBudgets.find((b) => b.id === budgetId) ?? null;
  const existingAllocation = selectedBudget ? selectedBudget.allocations.find((a) => a.projectId === projectId) ?? null : null;

  // Budgets a Sponsor can pick: ones with spare balance, plus (once a
  // Project is chosen) any budget that already allocates to THAT project —
  // so an already-fully-allocated budget still shows up when you're just
  // editing its own existing allocation for this project.
  const selectableBudgets = periodBudgets.filter(
    (b) => periodBudgetBalance(b) > 0 || (projectId && b.allocations.some((a) => a.projectId === projectId))
  );
  // Projects a Sponsor can pick for the selected budget: exclude ones
  // already allocated in it, except the one currently selected (so editing
  // an existing allocation doesn't lock you out of your own row) — prevents
  // duplicate allocation records for the same Project/Budget pair.
  const takenInBudget = new Set((selectedBudget?.allocations ?? []).map((a) => a.projectId).filter((id) => id !== projectId));

  const amountNum = Number(amount) || 0;
  const otherAllocated = selectedBudget
    ? selectedBudget.allocations.filter((a) => a.projectId !== projectId).reduce((sum, a) => sum + a.allocatedAmount, 0)
    : 0;
  const balance = selectedBudget ? selectedBudget.totalSanctionedAmount - otherAllocated : 0;

  const amountError = !selectedBudget
    ? "Select a Budget Period."
    : !projectId
      ? "Select a Project."
      : !(amountNum > 0)
        ? "Allocated Budget must be greater than ₹0."
        : amountNum > balance
          ? `Allocated budget cannot exceed the available balance of ${fmtINR(balance)}.`
          : null;

  function handleSave() {
    setTouched(true);
    if (amountError || !selectedBudget || !projectId) return;
    if (existingAllocation) {
      updateAllocation(selectedBudget.id, projectId, amountNum);
    } else {
      addAllocation(selectedBudget.id, projectId, amountNum);
    }
    handleClose();
  }

  const title = existingAllocation ? "Edit Project Allocation" : "Assign Project";
  const noBudgetsAtAll = periodBudgets.length === 0;

  return (
    <>
      <div
        className={`fixed inset-0 z-[400] bg-black/40 backdrop-blur-[2px] transition-opacity ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) handleClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[401] flex h-full w-[420px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 border-b border-border px-5 py-4">
          <span className="flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-[9px] bg-primary-50 text-primary">
            <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </span>
          <div>
            <div className="text-[0.95rem] font-bold text-ink">{title}</div>
            <div className="mt-px text-[11.5px] text-muted">
              {existingAllocation ? "Update the amount allocated to this project." : "Allocate part of a sanctioned budget to a project."}
            </div>
          </div>
          <button
            onClick={handleClose}
            className="ml-auto flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-md text-muted hover:bg-bg hover:text-ink"
          >
            <CloseIcon />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          {noBudgetsAtAll ? (
            <p className="text-[13px] leading-snug text-muted">
              No Budget Period exists yet. Create a Budget in Budget Planning first, then come back here to assign it
              to a project.
            </p>
          ) : (
            <>
              <Field label="Budget Period">
                {fixedBudgetId ? (
                  <div className={`${inputCls} flex items-center`}>
                    {selectedBudget ? `${fmtDate(selectedBudget.startDate)} – ${fmtDate(selectedBudget.endDate)}` : "—"}
                  </div>
                ) : (
                  <select value={budgetId} onChange={(e) => handleBudgetChange(e.target.value)} className={selCls}>
                    <option value="">Select Budget Period</option>
                    {selectableBudgets.map((b) => (
                      <option key={b.id} value={b.id}>
                        {fmtDate(b.startDate)} – {fmtDate(b.endDate)} · Balance {fmtINR(periodBudgetBalance(b))}
                      </option>
                    ))}
                  </select>
                )}
              </Field>

              <Field label="Project">
                {fixedProjectId ? (
                  <div className={`${inputCls} flex items-center`}>
                    {projects.find((p) => p.id === fixedProjectId)?.name ?? fixedProjectId}
                  </div>
                ) : (
                  <select
                    value={projectId}
                    disabled={!budgetId}
                    onChange={(e) => handleProjectChange(e.target.value)}
                    className={selCls}
                  >
                    <option value="">Select Project</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id} disabled={takenInBudget.has(p.id)}>
                        {p.name} ({p.code})
                      </option>
                    ))}
                  </select>
                )}
              </Field>

              <Field label="Allocated Budget (₹)">
                <div className="relative">
                  <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[13px] text-muted">₹</span>
                  <input
                    type="number"
                    min="0"
                    disabled={!selectedBudget || !projectId}
                    className={`${inputCls} pl-6 ${touched && amountError ? errCls : ""}`}
                    placeholder="Enter amount to allocate"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    onBlur={() => setTouched(true)}
                  />
                </div>
                {touched && amountError && <p className="mt-1 text-xs text-danger">⚠ {amountError}</p>}
              </Field>

              {selectedBudget && (
                <div className="rounded-lg border border-border bg-surface-2 p-3.5">
                  <div className="flex items-center justify-between py-1 text-sm">
                    <span className="text-ink-2">Total Sanctioned Amount</span>
                    <span className="font-semibold text-ink">{fmtINR(selectedBudget.totalSanctionedAmount)}</span>
                  </div>
                  <div className="flex items-center justify-between py-1 text-sm">
                    <span className="text-ink-2">Already Allocated (other Projects)</span>
                    <span className="font-semibold text-ink">{fmtINR(otherAllocated)}</span>
                  </div>
                  <div className="flex items-center justify-between border-t border-border py-1 pt-2 text-sm">
                    <span className="text-ink-2">Available Balance</span>
                    <span className={`font-bold ${amountError ? "text-danger" : "text-secondary-600"}`}>{fmtINR(balance)}</span>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
          <button
            onClick={handleClose}
            className="flex h-9 items-center rounded-lg border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 hover:border-border-strong"
          >
            {noBudgetsAtAll ? "Close" : "Cancel"}
          </button>
          {!noBudgetsAtAll && (
            <button
              onClick={handleSave}
              disabled={!!amountError}
              className="flex h-9 items-center rounded-lg bg-primary px-4 text-sm font-semibold text-white hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {existingAllocation ? "Save Changes" : "Assign Project"}
            </button>
          )}
        </div>
      </div>
    </>
  );
}
