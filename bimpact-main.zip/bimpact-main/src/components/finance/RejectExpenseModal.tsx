"use client";

import { useState } from "react";
import { useFinanceStore } from "@/store/financeStore";

function CloseIcon({ size = 18 }: { size?: number }) {
  return (
    <svg fill="none" height={size} width={size} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}

// #exp-reject-modal, bImpact_MeetingSplit_v10.html:15323-15347
export function RejectExpenseModal({
  open,
  onClose,
  expenseId,
}: {
  open: boolean;
  onClose: () => void;
  expenseId: string | null;
}) {
  const rejectExpense = useFinanceStore((s) => s.rejectExpense);
  const [reason, setReason] = useState("");

  function handleClose() {
    setReason("");
    onClose();
  }

  // confirmRejectExpense, bImpact_MeetingSplit_v10.html:15639-15664 — an
  // empty reason is rejected with an alert; the original's DOM-patch here
  // writes the result into the wrong table columns (a copy-paste bug, off
  // by one against the real Date/Description/Document/Category/Amount/
  // Status/Actions layout) — not replicated, the store's rejectExpense
  // action correctly updates the row's actual status instead.
  function handleConfirm() {
    if (!expenseId || !reason.trim()) return;
    rejectExpense(expenseId, reason.trim());
    handleClose();
  }

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[9998] bg-black/50"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
    >
      <div className="fixed left-1/2 top-1/2 z-[9999] w-[400px] max-w-[92vw] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-xl bg-bg shadow-[0_10px_25px_rgba(0,0,0,0.2)]">
        <div className="flex items-center justify-between border-b border-border bg-[#fef2f2] px-5 py-4">
          <div className="flex items-center gap-2.5">
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-danger text-white">
              <CloseIcon size={14} />
            </span>
            <div>
              <div className="text-sm font-bold text-ink">Reject Expense</div>
              <div className="text-[11px] text-muted">Return entry to submitter with reason</div>
            </div>
          </div>
          <button onClick={handleClose} className="text-muted hover:text-ink">
            <CloseIcon />
          </button>
        </div>

        <div className="p-5">
          <label className="mb-2 block text-[11px] font-bold uppercase tracking-[0.06em] text-muted">
            Rejection Reason <span className="text-danger">*</span>
          </label>
          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Please specify why this expense is being rejected and returned…"
            className="box-border h-20 w-full resize-none rounded-sm border-[1.5px] border-border bg-surface px-3 py-2.5 text-[13px] text-ink outline-none focus:border-primary"
          />
          <div className="mt-2 text-[11px] text-muted">The submitter will be notified and asked to resubmit the entry.</div>
        </div>

        <div className="flex justify-end gap-2 border-t border-border bg-surface px-5 py-3">
          <button onClick={handleClose} className="h-8 rounded-md border border-border bg-surface px-3.5 text-xs font-semibold text-ink-2 hover:bg-bg">
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={!reason.trim()}
            className="h-8 rounded-md bg-danger px-3.5 text-xs font-semibold text-white hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-50"
          >
            Reject &amp; Return
          </button>
        </div>
      </div>
    </div>
  );
}
