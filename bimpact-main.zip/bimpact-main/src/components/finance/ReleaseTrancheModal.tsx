"use client";

import { useFinanceStore } from "@/store/financeStore";
import { Tranche } from "@/types/finance";

function fmtINR(n: number) {
  return n.toLocaleString("en-IN");
}

function CheckIcon({ size = 20 }: { size?: number }) {
  return (
    <svg fill="none" height={size} width={size} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
function AlertIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="#B45309" strokeWidth="2" viewBox="0 0 24 24" className="mt-px shrink-0">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
}

// Matches the "Confirm Fund Release" modal, bImpact_MeetingSplit_v10.html:7138-7185
export function ReleaseTrancheModal({
  projectId,
  projectName,
  open,
  onClose,
  tranche,
}: {
  projectId: string;
  projectName: string;
  open: boolean;
  onClose: () => void;
  tranche: Tranche | null;
}) {
  const releaseTranche = useFinanceStore((s) => s.releaseTranche);

  if (!open || !tranche) return null;

  return (
    <div
      className="fixed inset-0 z-[9500] flex items-center justify-center bg-[rgba(15,23,42,0.5)] backdrop-blur-[3px]"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-[440px] max-w-[92vw] rounded-2xl bg-white px-7 pb-6 pt-7 shadow-[0_24px_72px_rgba(15,23,42,0.22)]">
        <div className="mb-5 flex items-center gap-3.5">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-secondary-50 text-secondary">
            <CheckIcon />
          </div>
          <div>
            <div className="text-[15px] font-extrabold tracking-tight text-ink">Confirm Fund Release</div>
            <div className="mt-0.5 text-[12.5px] text-muted">Manually record this disbursement in the system</div>
          </div>
        </div>

        <div className="mb-4 rounded-[10px] border border-border bg-surface-2 px-4 py-3.5">
          <div className="mb-3 text-[11.5px] text-muted">You are releasing payment for the following tranche:</div>
          <div className="flex flex-col gap-2.5">
            <div className="flex items-start justify-between gap-3">
              <span className="whitespace-nowrap pt-0.5 text-[10.5px] font-bold uppercase tracking-wide text-muted">Tranche</span>
              <span className="text-right text-[13px] font-bold text-ink">{tranche.name}</span>
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="whitespace-nowrap text-[10.5px] font-bold uppercase tracking-wide text-muted">Amount</span>
              <span className="font-mono text-[15px] font-extrabold text-secondary">₹{fmtINR(tranche.amount)}</span>
            </div>
            <div className="flex items-start justify-between gap-3 border-t border-border pt-2">
              <span className="whitespace-nowrap pt-0.5 text-[10.5px] font-bold uppercase tracking-wide text-muted">Project</span>
              <span className="text-right text-[12.5px] text-ink-2">{projectName}</span>
            </div>
          </div>
        </div>

        <div className="mb-5 flex gap-2.5 rounded-lg border border-[#FDE68A] bg-[#FFFBEB] px-3.5 py-2.5">
          <AlertIcon />
          <span className="text-xs leading-relaxed text-[#B45309]">Ensure the payment has been processed before confirming. This action cannot be undone.</span>
        </div>

        <div className="flex justify-end gap-2.5">
          <button onClick={onClose} className="h-9 rounded-lg border-[1.5px] border-border bg-surface px-5 text-[13px] font-semibold text-ink-2 hover:border-border-strong">
            Cancel
          </button>
          <button
            onClick={() => {
              releaseTranche(projectId, tranche.id);
              onClose();
            }}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-secondary px-5 text-[13px] font-semibold text-white hover:brightness-95"
          >
            <CheckIcon size={12} />
            Confirm Release
          </button>
        </div>
      </div>
    </div>
  );
}
