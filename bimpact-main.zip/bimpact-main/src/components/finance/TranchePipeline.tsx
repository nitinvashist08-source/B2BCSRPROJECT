"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore } from "@/store/financeStore";
import { canManuallyRelease } from "@/store/financeStore";
import { useSessionStore } from "@/store/sessionStore";
import { Tranche, TrancheStatus } from "@/types/finance";
import { WbsState } from "@/types/project";
import { ScheduleTrancheSlideOver } from "./ScheduleTrancheSlideOver";
import { ReleaseTrancheModal } from "./ReleaseTrancheModal";

function fmtINR(n: number) {
  return n.toLocaleString("en-IN");
}

function fmtReleaseDate(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

// WBS is the single source of truth for a task's name — a tranche whose
// trigger is "Specific Task Completion" only ever stores a stable reference
// to the WBS row (linkedWbsRowId, see types/finance.ts), so a later rename
// in the WBS shows up here automatically. Falls back to the tranche's own
// cached `condition` text if the row was since deleted, so nothing breaks.
function resolveCondition(tranche: Tranche, wbs: WbsState | undefined): string {
  if (!tranche.linkedWbsRowId) return tranche.condition;
  const row = wbs?.rows.find((r) => r.id === tranche.linkedWbsRowId);
  const taskColumnId = wbs?.columns[0]?.id;
  const liveName = row && taskColumnId ? row.cells[taskColumnId] : undefined;
  return liveName ? `Task '${liveName}' Completed` : tranche.condition;
}

function BackIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}
function PlusIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
function ClockIcon() {
  return (
    <svg fill="none" height="9" width="9" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
function AlertIcon() {
  return (
    <svg fill="none" height="9" width="9" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
}
function CalIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}
function CondIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M9 11l3 3L22 4" />
      <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
    </svg>
  );
}
function RemarkIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" className="mt-0.5 shrink-0">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  );
}

// _disbTrancheBadge, bImpact_MeetingSplit_v10.html:13402-13410
const BADGE_STYLE: Record<TrancheStatus, string> = {
  released: "bg-secondary-50 text-secondary-600 border border-secondary-100",
  upcoming: "bg-primary-50 text-primary-600 border border-primary-100",
  overdue: "bg-danger-50 text-danger border border-[rgba(239,68,68,0.2)]",
  scheduled: "bg-[#F1F5F9] text-muted border border-border",
};
const BADGE_LABEL: Record<TrancheStatus, string> = {
  released: "Released",
  upcoming: "Upcoming",
  overdue: "Overdue",
  scheduled: "Scheduled",
};
const BADGE_ICON: Record<TrancheStatus, () => React.ReactElement> = {
  released: CheckIcon,
  upcoming: ClockIcon,
  overdue: AlertIcon,
  scheduled: CalIcon,
};

function Badge({ status }: { status: TrancheStatus }) {
  const Icon = BADGE_ICON[status];
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-[9px] py-[3px] text-[11px] font-semibold whitespace-nowrap ${BADGE_STYLE[status]}`}>
      <Icon />
      {BADGE_LABEL[status]}
    </span>
  );
}

// .disb-pipe-circle per-status colors, bImpact_MeetingSplit_v10.html:6626-6629
const CIRCLE_STYLE: Record<TrancheStatus, string> = {
  released: "bg-secondary text-white",
  upcoming: "bg-primary text-white",
  overdue: "bg-danger text-white",
  scheduled: "bg-[#F1F5F9] text-[#94A3B8] border-2 border-dashed border-[#CBD5E1]",
};
// .disb-pipe-card left-border accent per status, :6636-6639
const CARD_ACCENT: Record<TrancheStatus, string> = {
  released: "border-l-secondary",
  upcoming: "border-l-primary",
  overdue: "border-l-danger bg-[#FFF9F9]",
  scheduled: "border-l-[#CBD5E1]",
};

function PipelineItem({
  tranche,
  index,
  budget,
  releasable,
  isLast,
  condition,
  onRelease,
}: {
  tranche: Tranche;
  index: number;
  budget: number;
  releasable: boolean;
  isLast: boolean;
  // Live-resolved display text — see resolveCondition() above; may differ
  // from tranche.condition if this is a task-linked tranche and the WBS
  // task's name has since changed.
  condition: string;
  onRelease: () => void;
}) {
  const pct = budget ? ((tranche.amount / budget) * 100).toFixed(1) : "0.0";
  return (
    <div className="grid grid-cols-[52px_1fr] gap-x-4">
      <div className="flex flex-col items-center pt-0.5">
        <div className={`z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[13px] font-extrabold shadow-[0_0_0_4px_var(--color-bg)] ${CIRCLE_STYLE[tranche.status]}`}>
          {tranche.status === "released" ? <CheckIcon /> : index + 1}
        </div>
        {!isLast && (
          <div className={`mt-[5px] min-h-4 w-0.5 flex-1 rounded-sm ${tranche.status === "released" ? "bg-secondary opacity-30" : "bg-border"}`} />
        )}
      </div>
      <div className={`mb-4 overflow-hidden rounded-xl border border-border shadow-[0_1px_4px_rgba(15,23,42,0.04)] transition-shadow hover:shadow-[0_4px_16px_rgba(15,23,42,0.09)] border-l-[3px] ${CARD_ACCENT[tranche.status]}`}>
        <div className="flex flex-wrap items-center gap-3 px-[18px] py-[13px]">
          <div className="min-w-0 flex-1 text-sm font-bold text-ink">{tranche.name}</div>
          <div className="shrink-0 whitespace-nowrap font-mono text-sm font-extrabold text-ink">
            ₹{fmtINR(tranche.amount)}
            <span className="ml-[5px] text-[11px] font-semibold text-muted">{pct}%</span>
          </div>
          <Badge status={tranche.status} />
        </div>
        <div className="flex flex-wrap gap-7 border-t border-border bg-surface-2 px-[18px] py-2.5">
          <div className="flex items-center gap-1.5 text-[12.5px] text-ink-2">
            <span className="mr-0.5 text-[10px] font-bold uppercase tracking-wide text-muted">Condition</span>
            <CondIcon /> {condition}
          </div>
          <div className="flex items-center gap-1.5 text-[12.5px] text-ink-2">
            <span className="mr-0.5 text-[10px] font-bold uppercase tracking-wide text-muted">Target Date</span>
            <CalIcon /> {tranche.date || "—"}
          </div>
          {tranche.status === "released" && tranche.releasedAt && (
            <div className="flex items-center gap-1.5 text-[12.5px] text-ink-2">
              <span className="mr-0.5 text-[10px] font-bold uppercase tracking-wide text-muted">Released On</span>
              <CheckIcon /> {fmtReleaseDate(tranche.releasedAt)}
            </div>
          )}
          {tranche.remarks && (
            <div className="mt-1.5 flex basis-full items-start gap-1.5 border-t border-dashed border-border pt-1.5 text-xs italic leading-snug text-ink-2">
              <RemarkIcon />
              <span>
                <span className="mr-1.5 text-[10px] font-bold uppercase tracking-wide text-muted">Remarks</span>
                {tranche.remarks}
              </span>
            </div>
          )}
        </div>
        {releasable && (
          <div className="flex justify-end border-t border-border bg-surface-2 px-[18px] py-2.5">
            <button
              onClick={onRelease}
              className="inline-flex h-7 items-center gap-1.5 rounded-lg border border-secondary-100 bg-secondary-50 px-3.5 text-[11.5px] font-semibold text-secondary-600 hover:brightness-95"
            >
              <CheckIcon />
              Mark as Released
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export function TranchePipeline({ projectId, seedIndex }: { projectId: string; seedIndex: number }) {
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));
  const wbs = useProjectStore((s) => s.wbs[projectId]);
  const disbursements = useFinanceStore((s) => s.disbursements);
  const tranches = disbursements[projectId] ?? [];
  const ensureDisbursements = useFinanceStore((s) => s.ensureDisbursements);
  const role = useSessionStore((s) => s.role);
  const router = useRouter();
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [releasing, setReleasing] = useState<Tranche | null>(null);

  useEffect(() => {
    ensureDisbursements(projectId, seedIndex);
  }, [projectId, seedIndex, ensureDisbursements]);

  if (!project) {
    return <div className="p-6 text-sm text-muted">Project not found.</div>;
  }

  const released = tranches.filter((t) => t.status === "released").reduce((s, t) => s + t.amount, 0);

  return (
    <div className="p-5">
      {/* exp-detail-hd, bImpact_MeetingSplit_v10.html:7102-7120 */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => router.push("/finance/disbursement")}
            className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-ink-2 hover:text-primary"
          >
            <BackIcon />
            Disbursement Planning
          </button>
          <svg fill="none" height="10" width="10" stroke="var(--color-border)" strokeWidth="2" viewBox="0 0 24 24">
            <polyline points="9 18 15 12 9 6" />
          </svg>
          <span className="rounded-md bg-surface-2 px-2 py-0.5 font-mono text-[11px] font-bold text-muted">{project.code}</span>
          <span className="text-[13.5px] font-semibold text-ink">{project.name}</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-[12.5px] text-muted">
            Budget: <strong className="text-ink">₹{fmtINR(project.budget)}</strong>
          </span>
          <span className="text-[12.5px] text-muted">
            Released: <strong className="text-secondary">₹{fmtINR(released)}</strong>
          </span>
          {/* Strictly view-only for partners: no Add Tranche entry point at all. */}
          {role !== "partner" && (
            <button
              onClick={() => setScheduleOpen(true)}
              className="inline-flex h-[30px] items-center gap-1.5 rounded-lg bg-primary px-3.5 text-[12.5px] font-semibold text-white hover:bg-primary-600"
            >
              <PlusIcon />
              Add Tranche
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-col py-1">
        {tranches.length === 0 && (
          <div className="rounded-lg border border-dashed border-border-strong px-5 py-8 text-center text-[13px] text-muted">
            No disbursement tranches planned yet. Click “Add Tranche” to create one.
          </div>
        )}
        {tranches.map((t, i) => (
          <PipelineItem
            key={t.id}
            tranche={t}
            index={i}
            budget={project.budget}
            isLast={i === tranches.length - 1}
            condition={resolveCondition(t, wbs)}
            // Strictly view-only for partners: never offer the release
            // action, even when the tranche would otherwise be releasable.
            // canManuallyRelease extends the existing sequential
            // upcoming/overdue-or-follows-a-released-one rule with an
            // always-available Release for Custom Condition tranches (see
            // financeStore.ts) — every other milestone type's gating is
            // unchanged.
            releasable={role !== "partner" && canManuallyRelease(tranches, i)}
            onRelease={() => setReleasing(t)}
          />
        ))}
      </div>

      {/* Neither slide-over/modal is mounted for partners — their only entry
          points (Add Tranche, Mark as Released) are hidden above, matching
          this app's established pattern. */}
      {role !== "partner" && (
        <>
          <ScheduleTrancheSlideOver projectId={projectId} projectName={project.name} budget={project.budget} open={scheduleOpen} onClose={() => setScheduleOpen(false)} />
          <ReleaseTrancheModal
            projectId={projectId}
            projectName={project.name}
            open={releasing !== null}
            onClose={() => setReleasing(null)}
            tranche={releasing}
          />
        </>
      )}
    </div>
  );
}
