"use client";

import { Fragment, useState } from "react";
import { useFinanceStore, periodBudgetAllocated, periodBudgetBalance } from "@/store/financeStore";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";
import { PeriodBudget } from "@/types/finance";
import { CreateBudgetSlideOver } from "./CreateBudgetSlideOver";
import { DeleteBudgetPeriodModal } from "./DeleteBudgetPeriodModal";
import { BudgetPeriodActionMenu } from "./BudgetPeriodActionMenu";
import { AssignProjectSlideOver } from "./AssignProjectSlideOver";

function fmtINR(n: number) {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}
function fmtDate(iso: string) {
  if (!iso) return "—";
  const [y, m, d] = iso.split("-");
  const month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][parseInt(m, 10) - 1] ?? "";
  return `${parseInt(d, 10)} ${month} ${y}`;
}

function PlusIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function CalendarIcon({ size = 22 }: { size?: number }) {
  return (
    <svg fill="none" height={size} width={size} stroke="currentColor" strokeWidth="1.6" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}
function ChevronIcon({ open }: { open: boolean }) {
  return (
    <svg
      fill="none"
      height="13"
      width="13"
      stroke="currentColor"
      strokeWidth="2"
      viewBox="0 0 24 24"
      className={`shrink-0 transition-transform ${open ? "rotate-90" : ""}`}
    >
      <polyline points="9 18 15 12 9 6" />
    </svg>
  );
}
function TrashIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M3 6h18" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}
function AssignIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

// Budget Planning → Create Budget's list of created budgets — sits above
// the existing per-project HighLevelBudgetTable (untouched otherwise; only
// its own "Edit"/CreateBudgetSlideOver wiring was removed since editing a
// Project's allocated amount now happens per-budget here instead).
export function PeriodBudgetsPanel() {
  const periodBudgets = useFinanceStore((s) => s.periodBudgets);
  const removeAllocation = useFinanceStore((s) => s.removeAllocation);
  const projects = useProjectStore((s) => s.projects);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const partners = useSettingsStore((s) => s.partners);
  const projectPartners = useSettingsStore((s) => s.projectPartners);

  const [createOpen, setCreateOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<PeriodBudget | null>(null);
  const [deletingBudget, setDeletingBudget] = useState<PeriodBudget | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  // Three ways into the same AssignProjectSlideOver: the top-level "Assign
  // Project" CTA (nothing fixed), a Budget row's "Allocate to Project"
  // (budget fixed), and an existing allocation's own "Edit" (both fixed).
  const [assignOpen, setAssignOpen] = useState(false);
  const [allocatingBudgetId, setAllocatingBudgetId] = useState<string | null>(null);
  const [editingAllocation, setEditingAllocation] = useState<{ budgetId: string; projectId: string } | null>(null);

  // A Partner only ever sees a budget that allocates to (at least) one of
  // their own assigned Projects — the shared Project Finance data this
  // reads is the same permission-filtered surface HighLevelBudgetTable
  // already uses (see isProjectAssignedToPartner), not a separate Partner
  // copy of the allocation.
  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const visiblePeriodBudgets =
    role === "partner"
      ? periodBudgets.filter((b) =>
          b.allocations.some((a) => {
            const project = projects.find((p) => p.id === a.projectId);
            return !!project && isProjectAssignedToPartner(project, projectPartners, partnerName);
          })
        )
      : periodBudgets;

  const sorted = [...visiblePeriodBudgets].sort((a, b) => (a.startDate < b.startDate ? 1 : -1));

  const formOpen = createOpen || !!editingBudget;
  function closeForm() {
    setCreateOpen(false);
    setEditingBudget(null);
  }

  const assignSlideOpen = assignOpen || !!allocatingBudgetId || !!editingAllocation;
  const assignFixedBudgetId = editingAllocation?.budgetId ?? allocatingBudgetId ?? undefined;
  const assignFixedProjectId = editingAllocation?.projectId ?? undefined;
  function closeAssign() {
    setAssignOpen(false);
    setAllocatingBudgetId(null);
    setEditingAllocation(null);
  }

  function projectLabel(projectId: string) {
    const p = projects.find((pr) => pr.id === projectId);
    return p ? `${p.name} (${p.code})` : projectId;
  }

  return (
    <div className="px-[22px] pt-[22px]">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <div className="text-[13.5px] font-bold text-ink">Budget Planning</div>
          <p className="mt-0.5 text-xs text-muted">Create a sanctioned budget, then assign it to one or more projects.</p>
        </div>
        {/* No creation/assignment entry point at all for a partner, same
            pattern as ProjectsTable.tsx's Create Project gating. "Assign
            Project" is visually secondary (ghost) to "Create Budget"
            (primary) — budget creation is the more common first step, but
            both are top-level, always-available CTAs (not nested inside
            each other), matching the spec's explicit ask to keep the two
            actions separate. */}
        {role !== "partner" && (
          <div className="flex shrink-0 gap-2">
            <button
              onClick={() => setAssignOpen(true)}
              className="flex h-9 items-center gap-1.5 rounded-md border-[1.5px] border-border bg-surface px-3.5 text-[12.5px] font-semibold text-ink-2 hover:border-border-strong hover:bg-bg"
            >
              <AssignIcon />
              Assign Project
            </button>
            <button
              onClick={() => setCreateOpen(true)}
              className="flex h-9 items-center gap-1.5 rounded-md bg-primary px-3.5 text-[12.5px] font-semibold text-white hover:bg-primary-600"
            >
              <PlusIcon />
              Create Budget
            </button>
          </div>
        )}
      </div>

      {sorted.length === 0 ? (
        <div className="flex flex-col items-center gap-1 rounded-[10px] border border-dashed border-border bg-surface px-6 py-10 text-center">
          <span className="mb-2 flex h-11 w-11 items-center justify-center rounded-full bg-primary-50 text-primary">
            <CalendarIcon />
          </span>
          <div className="text-[14px] font-bold text-ink">No budgets created yet</div>
          <p className="max-w-[380px] text-[12.5px] leading-snug text-muted">
            Create a budget for a specific period and allocate the sanctioned amount to one or more projects.
          </p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-[10px] border border-border bg-surface">
          <table className="w-full table-fixed border-collapse text-[12.5px]">
            <thead>
              <tr className="bg-surface-2">
                <th className="w-[24%] px-4 py-[9px] text-left text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Period</th>
                <th className="w-[16%] px-4 py-[9px] text-right text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Sanctioned</th>
                <th className="w-[16%] px-4 py-[9px] text-right text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Allocated</th>
                <th className="w-[16%] px-4 py-[9px] text-right text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Balance</th>
                <th className="w-[12%] px-4 py-[9px] text-right text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Action</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((b) => {
                const allocated = periodBudgetAllocated(b);
                const balance = periodBudgetBalance(b);
                const expanded = expandedId === b.id;
                return (
                  <Fragment key={b.id}>
                    <tr className="cursor-pointer border-t border-border hover:bg-surface-2" onClick={() => setExpandedId(expanded ? null : b.id)}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5 font-semibold text-ink">
                          <ChevronIcon open={expanded} />
                          {fmtDate(b.startDate)} – {fmtDate(b.endDate)}
                        </div>
                        <div className="mt-0.5 pl-[19px] font-mono text-[10.5px] text-muted">
                          {b.allocations.length} project{b.allocations.length === 1 ? "" : "s"} allocated
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-ink">{fmtINR(b.totalSanctionedAmount)}</td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-primary-600">{fmtINR(allocated)}</td>
                      <td className={`px-4 py-3 text-right font-mono font-bold ${balance < 0 ? "text-danger" : "text-secondary"}`}>{fmtINR(balance)}</td>
                      <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                        {role !== "partner" && <BudgetPeriodActionMenu onEdit={() => setEditingBudget(b)} onDelete={() => setDeletingBudget(b)} />}
                      </td>
                    </tr>
                    {expanded && (
                      <tr className="border-t border-border bg-bg">
                        <td colSpan={5} className="px-4 py-3">
                          {b.allocations.length === 0 ? (
                            <p className="text-xs text-muted">No projects allocated yet.</p>
                          ) : (
                            <div className="mb-2 flex flex-col gap-1.5">
                              {b.allocations.map((a) => (
                                <div key={a.projectId} className="flex items-center justify-between rounded-md border border-border bg-surface px-3 py-2 text-[12.5px]">
                                  <span className="font-medium text-ink-2">{projectLabel(a.projectId)}</span>
                                  <div className="flex items-center gap-3">
                                    <span className="font-mono font-bold text-ink">{fmtINR(a.allocatedAmount)}</span>
                                    {role !== "partner" && (
                                      <>
                                        <button
                                          onClick={() => setEditingAllocation({ budgetId: b.id, projectId: a.projectId })}
                                          className="rounded-md border border-border bg-surface px-2 py-1 text-[11px] font-semibold text-ink-2 hover:border-border-strong hover:bg-bg"
                                        >
                                          Edit
                                        </button>
                                        <button
                                          onClick={() => removeAllocation(b.id, a.projectId)}
                                          className="flex h-[26px] w-[26px] items-center justify-center rounded-md border border-border text-muted hover:border-danger hover:text-danger"
                                          title="Remove allocation"
                                        >
                                          <TrashIcon />
                                        </button>
                                      </>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                          {role !== "partner" && balance > 0 && (
                            <button
                              onClick={() => setAllocatingBudgetId(b.id)}
                              className="flex items-center gap-1.5 rounded-md border-[1.5px] border-dashed border-border px-2.5 py-1.5 text-xs font-semibold text-muted hover:border-primary hover:text-primary"
                            >
                              <PlusIcon />
                              Allocate to Project
                            </button>
                          )}
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {role !== "partner" && (
        <>
          <CreateBudgetSlideOver key={editingBudget?.id ?? "create"} open={formOpen} onClose={closeForm} editing={editingBudget} />
          <DeleteBudgetPeriodModal budget={deletingBudget} onClose={() => setDeletingBudget(null)} />
          <AssignProjectSlideOver
            key={`${assignFixedBudgetId ?? "none"}-${assignFixedProjectId ?? "none"}`}
            open={assignSlideOpen}
            onClose={closeAssign}
            fixedBudgetId={assignFixedBudgetId}
            fixedProjectId={assignFixedProjectId}
          />
        </>
      )}
    </div>
  );
}
