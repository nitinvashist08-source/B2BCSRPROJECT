"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

function MoreIcon() {
  return (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
      <circle cx="5" cy="12" r="1" />
    </svg>
  );
}

const MENU_WIDTH = 160;
const MENU_HEIGHT_ESTIMATE = 84; // Edit + Delete rows
const GAP = 6;

// The Budget Period table's row action menu ("⋯" → Edit/Delete) rendered
// via a portal to document.body instead of the generic Dropdown component
// (src/components/ui/Dropdown.tsx). The table's own rounded-corner
// container uses overflow-hidden, which clips Dropdown's normal
// position:absolute-within-a-relative-ancestor menu — a portal escapes that
// entirely regardless of any ancestor's overflow, and lets the menu flip
// upward when the row is near the bottom of the visible table. Scoped to
// this one table only; Dropdown itself and its other consumers are
// untouched.
export function BudgetPeriodActionMenu({ onEdit, onDelete }: { onEdit: () => void; onDelete: () => void }) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  function openMenu() {
    const rect = triggerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const spaceBelow = window.innerHeight - rect.bottom;
    const openUpward = spaceBelow < MENU_HEIGHT_ESTIMATE + GAP && rect.top > MENU_HEIGHT_ESTIMATE + GAP;
    const top = openUpward ? rect.top - MENU_HEIGHT_ESTIMATE - GAP : rect.bottom + GAP;
    const left = Math.max(8, Math.min(rect.right - MENU_WIDTH, window.innerWidth - MENU_WIDTH - 8));
    setPos({ top, left });
    setOpen(true);
  }

  useEffect(() => {
    if (!open) return;
    function handlePointerDown(e: MouseEvent) {
      const target = e.target as Node;
      if (triggerRef.current?.contains(target) || menuRef.current?.contains(target)) return;
      setOpen(false);
    }
    function handleDismiss() {
      setOpen(false);
    }
    document.addEventListener("mousedown", handlePointerDown);
    window.addEventListener("scroll", handleDismiss, true);
    window.addEventListener("resize", handleDismiss);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      window.removeEventListener("scroll", handleDismiss, true);
      window.removeEventListener("resize", handleDismiss);
    };
  }, [open]);

  return (
    <>
      <button
        ref={triggerRef}
        onClick={() => (open ? setOpen(false) : openMenu())}
        className="rounded-sm p-1 text-muted hover:bg-surface-2"
      >
        <MoreIcon />
      </button>
      {open &&
        pos &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            ref={menuRef}
            style={{ position: "fixed", top: pos.top, left: pos.left, width: MENU_WIDTH }}
            className="z-[500] rounded-sm border border-border bg-surface py-1 shadow-md"
          >
            <button
              onClick={() => {
                setOpen(false);
                onEdit();
              }}
              className="block w-full px-3 py-1.5 text-left text-sm text-ink-2 hover:bg-surface-2"
            >
              Edit
            </button>
            <button
              onClick={() => {
                setOpen(false);
                onDelete();
              }}
              className="block w-full px-3 py-1.5 text-left text-sm text-danger hover:bg-surface-2"
            >
              Delete
            </button>
          </div>,
          document.body
        )}
    </>
  );
}
