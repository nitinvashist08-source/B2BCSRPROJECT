"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore } from "@/store/financeStore";
import { useSessionStore } from "@/store/sessionStore";
import { Expense, ExpenseStatus } from "@/types/finance";
import { BookExpenseSlideOver } from "./BookExpenseSlideOver";
import { RejectExpenseModal } from "./RejectExpenseModal";

function fmtINR(n: number) {
  return n.toLocaleString("en-IN");
}

function BackIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}
function PlusIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function DocIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg fill="none" height="9" width="9" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
function ClockIcon() {
  return (
    <svg fill="none" height="9" width="9" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
function XIcon() {
  return (
    <svg fill="none" height="9" width="9" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}

// _expBadgeHTML, bImpact_MeetingSplit_v10.html:13838-13846 + .exp-sbadge CSS, :2598-2603
const BADGE_STYLE: Record<ExpenseStatus, string> = {
  approved: "bg-secondary-50 text-secondary-600 border border-secondary-100",
  pending: "bg-[#FEF3C7] text-[#B45309] border border-[#FDE68A]",
  pendingfc: "bg-[#FEF3C7] text-[#B45309] border border-[#FDE68A]",
  rejected: "bg-danger-50 text-danger border border-[rgba(239,68,68,0.2)]",
};
const BADGE_LABEL: Record<ExpenseStatus, string> = {
  approved: "Approved",
  pending: "Pending PM",
  pendingfc: "Pending FC",
  rejected: "Rejected",
};
const BADGE_ICON: Record<ExpenseStatus, () => React.ReactElement> = {
  approved: CheckIcon,
  pending: ClockIcon,
  pendingfc: ClockIcon,
  rejected: XIcon,
};

function StatusBadge({ status }: { status: ExpenseStatus }) {
  const Icon = BADGE_ICON[status];
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-[9px] py-[3px] text-[11px] font-semibold whitespace-nowrap ${BADGE_STYLE[status]}`}>
      <Icon />
      {BADGE_LABEL[status]}
    </span>
  );
}

const FILTERS: { key: "all" | ExpenseStatus; label: string }[] = [
  { key: "all", label: "All" },
  { key: "pending", label: "Pending" },
  { key: "approved", label: "Approved" },
  { key: "rejected", label: "Rejected" },
];

export function ExpenseTable({ projectId }: { projectId: string }) {
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));
  const allExpenses = useFinanceStore((s) => s.expenses);
  const expenses = allExpenses.filter((e) => e.projectId === projectId);
  const ensureExpenses = useFinanceStore((s) => s.ensureExpenses);
  const approveAsPM = useFinanceStore((s) => s.approveAsPM);
  const approveAsFC = useFinanceStore((s) => s.approveAsFC);
  const role = useSessionStore((s) => s.role);
  const router = useRouter();
  const [bookOpen, setBookOpen] = useState(false);
  const [rejecting, setRejecting] = useState<Expense | null>(null);
  const [filter, setFilter] = useState<"all" | ExpenseStatus>("all");

  useEffect(() => {
    ensureExpenses(projectId);
  }, [projectId, ensureExpenses]);

  if (!project) {
    return <div className="p-6 text-sm text-muted">Project not found.</div>;
  }

  // expFilter, bImpact_MeetingSplit_v10.html:13958-13966 — the "Pending" tab
  // groups both pending statuses together.
  const filtered = expenses.filter((e) => {
    if (filter === "all") return true;
    if (filter === "pending") return e.status === "pending" || e.status === "pendingfc";
    return e.status === filter;
  });
  const expensed = expenses.reduce((s, e) => s + e.amount, 0);

  return (
    <div className="p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3.5">
        <div className="flex min-w-0 items-center gap-2">
          <button
            onClick={() => router.push("/finance/expense")}
            className="inline-flex h-7 shrink-0 items-center gap-[5px] rounded-[7px] border border-border bg-surface px-2.5 text-xs font-semibold text-ink-2 hover:bg-bg"
          >
            <BackIcon />
            Expense Booking
          </button>
          <svg fill="none" height="10" width="10" stroke="var(--color-border)" strokeWidth="2" viewBox="0 0 24 24" className="shrink-0">
            <polyline points="9 18 15 12 9 6" />
          </svg>
          <span className="shrink-0 rounded-[4px] border border-primary-100 bg-primary-50 px-2 py-0.5 font-mono text-[11px] font-extrabold text-primary-700">
            {project.code}
          </span>
          <span className="truncate text-sm font-bold text-ink">{project.name}</span>
        </div>
        <div className="flex shrink-0 items-center gap-3">
          <span className="text-[12.5px] text-muted">
            Expensed: <strong className="text-ink">₹{fmtINR(expensed)}</strong>
          </span>
          <button
            onClick={() => setBookOpen(true)}
            className="inline-flex h-[30px] items-center gap-[5px] rounded-sm bg-primary px-3.5 text-[12.5px] font-semibold text-white shadow-[0_1px_2px_rgba(10,151,217,0.3)] hover:bg-primary-600"
          >
            <PlusIcon />
            Book Expense
          </button>
        </div>
      </div>

      <div className="mb-4 inline-flex w-fit gap-0.5 self-start rounded-sm border border-border bg-surface-2 p-[3px]">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`rounded-md px-[13px] py-[5px] text-xs font-semibold transition-colors ${
              filter === f.key ? "bg-surface text-ink shadow-[0_1px_3px_rgba(0,0,0,0.1)]" : "text-muted hover:text-ink-2"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="overflow-hidden rounded-[10px] border border-border bg-surface">
        <table className="w-full table-fixed border-collapse text-[12.5px]">
          <colgroup>
            <col className="w-[13%]" />
            <col className="w-[27%]" />
            <col className="w-[18%]" />
            <col className="w-[16%]" />
            <col className="w-[13%]" />
            <col className="w-[13%]" />
          </colgroup>
          <thead>
            <tr className="bg-surface-2">
              <th className="px-3.5 py-2 text-left text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Date</th>
              <th className="px-3.5 py-2 text-left text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Description</th>
              <th className="px-3.5 py-2 text-left text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Document</th>
              <th className="px-3.5 py-2 text-left text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Category</th>
              <th className="px-3.5 py-2 text-right text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Amount</th>
              <th className="px-3.5 py-2 text-center text-[10.5px] font-bold uppercase tracking-[0.06em] text-muted">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((e) => (
              <tr key={e.id} className="border-t border-border">
                <td className="px-3.5 py-2.5 text-[12.5px] font-semibold text-ink">{e.date}</td>
                <td className="truncate px-3.5 py-2.5 text-[12.5px] text-ink" title={e.description}>
                  {e.description || "No description"}
                  {e.status === "rejected" && e.rejectReason && <div className="mt-0.5 text-[11px] text-danger">{e.rejectReason}</div>}
                </td>
                <td className="px-3.5 py-2.5">
                  <span className="inline-flex max-w-full items-center gap-1 overflow-hidden text-[11.5px] font-medium text-primary" title={e.docFileName}>
                    <DocIcon />
                    <span className="truncate">{e.docFileName}</span>
                  </span>
                </td>
                <td className="px-3.5 py-2.5">
                  <span className="inline-block rounded-[4px] border border-border bg-surface-2 px-2 py-0.5 text-[11.5px] font-semibold text-ink-2">{e.type}</span>
                </td>
                <td className="px-3.5 py-2.5 text-right">
                  <div className="font-mono text-[13px] font-bold text-ink">₹{fmtINR(e.amount)}</div>
                  <div className="mt-0.5 text-[10px] text-muted">{e.gstSlab}% GST incl.</div>
                </td>
                <td className="px-3.5 py-2.5 text-center">
                  {/* No separate Actions column — Approve/Reject (same
                      conditions/handlers as before, sponsor-only, only on a
                      pending expense) now live under the badge in this cell
                      instead of their own dedicated column. Partners keep
                      full visibility of status via the badge but never see
                      these controls at all, not just disabled ones. */}
                  <div className="flex flex-col items-center gap-1.5">
                    <StatusBadge status={e.status} />
                    {role !== "partner" && (e.status === "pending" || e.status === "pendingfc") && (
                      <div className="flex justify-center gap-1.5">
                        <button
                          onClick={() => setRejecting(e)}
                          className="h-6 rounded-sm border border-border bg-bg px-2 text-[10px] font-semibold text-ink-2 hover:border-danger hover:text-danger"
                        >
                          Reject
                        </button>
                        <button
                          onClick={() => (e.status === "pending" ? approveAsPM(e.id) : approveAsFC(e.id))}
                          className="h-6 rounded-sm bg-amber px-2 text-[10px] font-semibold text-white hover:brightness-95"
                        >
                          Approve
                        </button>
                      </div>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="px-3.5 py-10 text-center text-sm text-muted">
                  No expenses in this view.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <BookExpenseSlideOver projectId={projectId} projectName={`${project.code}: ${project.name}`} open={bookOpen} onClose={() => setBookOpen(false)} />
      {/* Never mounted for partners — its only entry point (the Reject
          button above) is hidden for them, matching this app's established
          pattern of not mounting a modal/slide-over whose trigger is hidden. */}
      {role !== "partner" && (
        <RejectExpenseModal open={rejecting !== null} onClose={() => setRejecting(null)} expenseId={rejecting?.id ?? null} />
      )}
    </div>
  );
}
