"use client";

import { useEffect, useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore, microCategoryTotal } from "@/store/financeStore";
import { useMicroUiStore } from "@/store/microUiStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";
import { canEditProjectResource } from "@/lib/permissions";
import { MicroLineItem } from "@/types/finance";
import { MicroCategoryCard } from "./MicroCategoryCard";
import { MicroBudgetOwnershipDropdown } from "./MicroBudgetOwnershipDropdown";
import { MicroLineItemSlideOver, MicroLineItemInitial } from "./MicroLineItemSlideOver";

function pINR(n: number) {
  return n.toLocaleString("en-IN");
}

let addKeySeq = 0;

// themes, bImpact_MeetingSplit_v10.html:14185-14192 — cycled by project
// index (theme.bg is defined in the source but never actually referenced
// anywhere in the template, only theme.b is used).
const THEMES = ["var(--color-primary)", "var(--color-secondary)", "var(--color-purple)", "var(--color-amber)", "#ec4899"];

function BriefcaseIcon() {
  return (
    <svg fill="none" height="20" width="20" stroke="#0ea5e9" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
    </svg>
  );
}
function ChevronIcon({ open }: { open: boolean }) {
  return (
    <svg
      fill="none"
      height="16"
      width="16"
      stroke="#cbd5e1"
      strokeWidth="2"
      viewBox="0 0 24 24"
      className="shrink-0 transition-transform duration-200"
      style={{ transform: open ? "rotate(0deg)" : "rotate(-90deg)" }}
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function empty12() {
  return { ds: Array(12).fill(0), bs: Array(12).fill(0), as: Array(12).fill(0) };
}

// renderMicroBudget's all-projects dashboard, bImpact_MeetingSplit_v10.html:14176-14524.
export function MicroBudgetView() {
  const projects = useProjectStore((s) => s.projects);
  const microBudgets = useFinanceStore((s) => s.microBudgets);
  const microBudgetOwnership = useFinanceStore((s) => s.microBudgetOwnership);
  const ensureMicroBudget = useFinanceStore((s) => s.ensureMicroBudget);
  const saveMicroLineItem = useFinanceStore((s) => s.saveMicroLineItem);
  const collapsedProjects = useMicroUiStore((s) => s.collapsedProjects);
  const toggleProject = useMicroUiStore((s) => s.toggleProject);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const partners = useSettingsStore((s) => s.partners);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const [slideOver, setSlideOver] = useState<{ projectId: string; initial: MicroLineItemInitial; key: string } | null>(null);

  // Partners only ever see (and seed a micro-budget for) projects assigned
  // to their own org — mirrors ProjectsTable.tsx's exact pattern. Sponsors
  // (and the null/unauthenticated edge case) remain fully unrestricted.
  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const visibleProjects =
    role === "partner"
      ? projects.filter((p) => isProjectAssignedToPartner(p, projectPartners, partnerName))
      : projects;

  useEffect(() => {
    visibleProjects.forEach((p) => ensureMicroBudget(p.id, p.location));
  }, [visibleProjects, ensureMicroBudget]);

  // addMicroCat, bImpact_MeetingSplit_v10.html:14551-14558
  function openAddLineItem(projectId: string) {
    setSlideOver({
      projectId,
      key: `add-${projectId}-${addKeySeq++}`,
      initial: { mode: "add", lineItemName: "", subLineItemName: "", showSubLineItem: false, monthly: empty12() },
    });
  }
  // editMicroLineItem, :14825-14888
  function openEditItem(projectId: string, categoryId: string, item: MicroLineItem) {
    const hasSub = item.subItems.length > 0;
    setSlideOver({
      projectId,
      key: `edit-${item.id}`,
      initial: {
        mode: "edit",
        categoryId,
        itemId: item.id,
        lineItemName: item.name,
        subLineItemName: hasSub ? item.subItems[0].name : "",
        showSubLineItem: hasSub,
        monthly: hasSub ? item.subItems[0].monthly : item.monthly,
      },
    });
  }
  // addMicroSubItem, :14764-14821 — always ADD mode; lineItemName pre-filled
  // with the existing item's name so the store's match-by-name dedup finds
  // it and appends a new sub-item instead of creating a duplicate item.
  function openAddSubItem(projectId: string, categoryId: string, item: MicroLineItem) {
    setSlideOver({
      projectId,
      key: `addsub-${item.id}-${addKeySeq++}`,
      initial: { mode: "add", lineItemName: item.name, subLineItemName: "", showSubLineItem: true, monthly: empty12() },
    });
  }

  return (
    <div className="p-5">
      <div className="flex flex-col">
        {visibleProjects.map((p, pIdx) => {
          const categories = microBudgets[p.id] ?? [];
          const planned = categories.reduce((sum, c) => sum + microCategoryTotal(c), 0);
          const balance = p.budget - planned;
          const isOpen = !collapsedProjects.has(p.id);
          const theme = THEMES[pIdx % THEMES.length];
          // Same permission model as WBS (see canEditProjectResource) — a
          // read-only viewer keeps seeing every existing line item/value,
          // just without the create/edit affordances below.
          const ownershipConfigured = (microBudgetOwnership[p.id] ?? null) !== null;
          const canEdit = canEditProjectResource(microBudgetOwnership[p.id] ?? null, role);

          return (
            <div
              key={p.id}
              className="mb-5 overflow-hidden rounded-lg border-[1.5px] border-l-4 border-border bg-surface shadow-[0_2px_8px_rgba(0,0,0,0.02)]"
              style={{ borderLeftColor: theme }}
            >
              <div
                onClick={() => toggleProject(p.id)}
                className="flex cursor-pointer items-start justify-between border-b border-[#f0f0f0] bg-surface px-5 py-4"
              >
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 shrink-0">
                    <BriefcaseIcon />
                  </span>
                  <div>
                    <div className="text-base font-bold text-ink">{p.name}</div>
                    <div className="mt-1 flex items-center gap-3 text-xs text-muted">
                      <span>{p.code}</span>
                      <span>&bull;</span>
                      <span>FY 2024-25</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                  <MicroBudgetOwnershipDropdown projectId={p.id} />
                  {canEdit && (
                    <button
                      onClick={() => openAddLineItem(p.id)}
                      className="h-8 rounded-md border border-dashed border-[#94a3b8] bg-surface px-3.5 text-xs font-semibold text-[#475569] hover:bg-bg"
                    >
                      + Add Line Item
                    </button>
                  )}
                  <span onClick={() => toggleProject(p.id)}>
                    <ChevronIcon open={isOpen} />
                  </span>
                </div>
              </div>

              {/* Budget summary — its own row below the Project header, not
                  the header's own crowded right-hand side, so the header
                  stays about Project identity/actions and the table below
                  gets more breathing room. Always visible (not tied to
                  isOpen) — a summary figure, not line-item detail. */}
              <div className="grid grid-cols-3 gap-4 border-b border-[#f0f0f0] bg-surface px-5 py-3.5">
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.05em] text-muted">Assigned</div>
                  <div className="mt-1 font-mono text-base font-bold text-ink">₹{pINR(p.budget)}</div>
                </div>
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.05em] text-muted">Allocated</div>
                  <div className="mt-1 font-mono text-base font-bold text-[#0ea5e9]">₹{pINR(planned)}</div>
                </div>
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.05em] text-muted">Balance</div>
                  <div className={`mt-1 font-mono text-base font-bold ${balance < 0 ? "text-danger" : "text-muted"}`}>
                    ₹{pINR(balance)}
                  </div>
                </div>
              </div>

              {isOpen && (
                <div className="p-5">
                  {categories.length === 0 ? (
                    // Sponsor-only pre-ownership state — a Partner still sees
                    // the existing empty-state copy regardless of ownership
                    // (this message is only about the Sponsor's own "set up
                    // ownership first" sequence, not a change to Partner
                    // behavior).
                    role !== "partner" && !ownershipConfigured ? (
                      <div className="p-5 text-center text-[13px] text-muted">
                        <p className="font-semibold text-ink-2">
                          Please set up Micro-Budgeting ownership before creating the Micro Budget.
                        </p>
                        <p className="mt-1">Choose who will create and manage the Micro Budget for this project.</p>
                      </div>
                    ) : (
                      <div className="p-5 text-center text-[13px] italic text-muted">
                        No budget lines allocated. Click &lsquo;+ Add Line Item&rsquo; above to begin planning.
                      </div>
                    )
                  ) : (
                    categories.map((cat) => (
                      <MicroCategoryCard
                        key={cat.id}
                        category={cat}
                        projectName={p.name}
                        canEdit={canEdit}
                        onEditItem={(categoryId, item) => openEditItem(p.id, categoryId, item)}
                        onAddSubItem={(categoryId, item) => openAddSubItem(p.id, categoryId, item)}
                      />
                    ))
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {slideOver &&
        (() => {
          const project = visibleProjects.find((p) => p.id === slideOver.projectId)!;
          return (
            <MicroLineItemSlideOver
              key={slideOver.key}
              open
              onClose={() => setSlideOver(null)}
              projectLabel={`${project.code} · ${project.name}`}
              location={project.location}
              initial={slideOver.initial}
              onSave={(input) => {
                saveMicroLineItem(slideOver.projectId, { ...input, locationName: project.location });
                setSlideOver(null);
              }}
            />
          );
        })()}
    </div>
  );
}
