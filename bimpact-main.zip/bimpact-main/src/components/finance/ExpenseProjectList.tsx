"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore } from "@/store/financeStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";

function fmtINR(n: number) {
  return n.toLocaleString("en-IN");
}

function ChevronIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="var(--color-muted)" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="9 18 15 12 9 6" />
    </svg>
  );
}

type PillTone = "pending" | "rejected" | "approved";

const PILL_STYLE: Record<PillTone, string> = {
  pending: "bg-amber-50 text-[#B45309] border border-[rgba(245,158,11,0.25)]",
  rejected: "bg-danger-50 text-[#B91C1C] border border-[rgba(239,68,68,0.2)]",
  approved: "bg-secondary-50 text-secondary-600 border border-secondary-100",
};

function CountPill({ count, tone }: { count: number; tone: PillTone }) {
  return (
    <span
      className={`inline-flex h-6 min-w-[34px] items-center justify-center rounded-full px-2.5 text-[13px] font-semibold tabular-nums ${PILL_STYLE[tone]}`}
    >
      {count}
    </span>
  );
}

// Alignment/layout matches DisbProjectList.tsx (px-based column widths, pl-9
// column rhythm, td-level borders, per-cell hover) — headings and values
// (project/partner/₹ total/status pills) unchanged from the earlier design.
export function ExpenseProjectList() {
  const projects = useProjectStore((s) => s.projects);
  const allExpenses = useFinanceStore((s) => s.expenses);
  const ensureExpenses = useFinanceStore((s) => s.ensureExpenses);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const partners = useSettingsStore((s) => s.partners);
  const router = useRouter();

  // Partners only ever see (and only ever trigger expense-seeding for)
  // projects assigned to their own org — mirrors ProjectsTable.tsx's
  // visibleProjects pattern. Sponsor branch is unrestricted, as before.
  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const visibleProjects =
    role === "partner"
      ? projects.filter((p) => isProjectAssignedToPartner(p, projectPartners, partnerName))
      : projects;

  useEffect(() => {
    visibleProjects.forEach((p) => ensureExpenses(p.id));
  }, [visibleProjects, ensureExpenses]);

  return (
    <div className="p-[22px]">
      <div className="overflow-hidden rounded-[10px] border border-border">
        <table className="w-full table-fixed border-collapse">
          <thead>
            <tr className="bg-surface-2">
              <th className="w-[220px] whitespace-nowrap px-4 py-2.5 text-left text-[10.5px] font-bold uppercase tracking-wide text-muted">Project</th>
              <th className="w-[150px] whitespace-nowrap px-4 py-2.5 pl-9 text-left text-[10.5px] font-bold uppercase tracking-wide text-muted">Implementing Partner</th>
              <th className="w-[130px] whitespace-nowrap px-4 py-2.5 pl-9 text-right text-[10.5px] font-bold uppercase tracking-wide text-muted">Total Expensed</th>
              <th className="w-[90px] whitespace-nowrap px-4 py-2.5 pl-9 text-center text-[10.5px] font-bold uppercase tracking-wide text-muted">Pending</th>
              <th className="w-[90px] whitespace-nowrap px-4 py-2.5 pl-9 text-center text-[10.5px] font-bold uppercase tracking-wide text-muted">Rejected</th>
              <th className="w-[90px] whitespace-nowrap px-4 py-2.5 pl-9 text-center text-[10.5px] font-bold uppercase tracking-wide text-muted">Approved</th>
              <th className="w-8" />
            </tr>
          </thead>
          <tbody>
            {visibleProjects.map((p) => {
              const expenses = allExpenses.filter((e) => e.projectId === p.id);
              const pending = expenses.filter((e) => e.status === "pending" || e.status === "pendingfc").length;
              const approved = expenses.filter((e) => e.status === "approved").length;
              const rejected = expenses.filter((e) => e.status === "rejected").length;
              const totalAmt = expenses.reduce((s, e) => s + e.amount, 0);
              return (
                <tr
                  key={p.id}
                  onClick={() => router.push(`/finance/expense/${p.id}`)}
                  className="cursor-pointer bg-surface last:[&>td]:border-b-0 hover:[&>td]:!bg-primary-50"
                >
                  <td className="border-b border-border px-4 py-3.5">
                    <div className="truncate text-[13.5px] font-semibold text-ink">{p.name}</div>
                    <div className="font-mono text-[10.5px] font-bold text-muted">{p.code}</div>
                  </td>
                  <td className="border-b border-border px-4 py-3.5 pl-9 text-[12.5px] text-ink-2">{p.partner}</td>
                  <td className="border-b border-border px-4 py-3.5 pl-9 text-right font-mono text-[13px] font-bold text-ink">₹{fmtINR(totalAmt)}</td>
                  <td className="border-b border-border px-4 py-3.5 pl-9 text-center">
                    <CountPill count={pending} tone="pending" />
                  </td>
                  <td className="border-b border-border px-4 py-3.5 pl-9 text-center">
                    <CountPill count={rejected} tone="rejected" />
                  </td>
                  <td className="border-b border-border px-4 py-3.5 pl-9 text-center">
                    <CountPill count={approved} tone="approved" />
                  </td>
                  <td className="border-b border-border px-4 py-3.5 text-center">
                    <ChevronIcon />
                  </td>
                </tr>
              );
            })}
            {visibleProjects.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center text-sm text-muted">
                  No projects yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
