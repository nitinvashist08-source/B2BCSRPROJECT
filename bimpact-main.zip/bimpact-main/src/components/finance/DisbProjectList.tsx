"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore, disbListStatus } from "@/store/financeStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";

function fmtINR(n: number) {
  return n.toLocaleString("en-IN");
}

function ChevronIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="var(--color-muted)" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="9 18 15 12 9 6" />
    </svg>
  );
}

const STATUS_STYLE: Record<string, string> = {
  attention: "bg-danger-50 text-danger",
  ontrack: "bg-secondary-50 text-secondary-600",
  noplan: "bg-[#F1F5F9] text-muted",
};

// Matches the Disbursement Planning project listing table,
// bImpact_MeetingSplit_v10.html:7071-7094 (columns) + :13549-13569 (rollups).
export function DisbProjectList() {
  const projects = useProjectStore((s) => s.projects);
  const disbursements = useFinanceStore((s) => s.disbursements);
  const ensureDisbursements = useFinanceStore((s) => s.ensureDisbursements);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const partners = useSettingsStore((s) => s.partners);
  const router = useRouter();

  // Partners only ever see (and only ever trigger disbursement-seeding for)
  // projects assigned to their own org — mirrors ProjectsTable.tsx's
  // visibleProjects pattern. Sponsor branch is unrestricted, as before.
  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const visibleProjects =
    role === "partner"
      ? projects.filter((p) => isProjectAssignedToPartner(p, projectPartners, partnerName))
      : projects;

  useEffect(() => {
    visibleProjects.forEach((p, i) => ensureDisbursements(p.id, i));
  }, [visibleProjects, ensureDisbursements]);

  return (
    <div className="p-[22px]">
    <div className="overflow-hidden rounded-[10px] border border-border">
      <table className="w-full table-fixed border-collapse">
        <thead>
          <tr className="bg-surface-2">
            <th className="w-[220px] whitespace-nowrap px-4 py-2.5 text-left text-[10.5px] font-bold uppercase tracking-wide text-muted">Project</th>
            <th className="w-[150px] whitespace-nowrap px-4 py-2.5 pl-9 text-left text-[10.5px] font-bold uppercase tracking-wide text-muted">Implementing Partner</th>
            <th className="w-[120px] whitespace-nowrap px-4 py-2.5 pl-9 text-right text-[10.5px] font-bold uppercase tracking-wide text-muted">Budget</th>
            <th className="w-[120px] whitespace-nowrap px-4 py-2.5 pl-9 text-right text-[10.5px] font-bold uppercase tracking-wide text-muted">Released</th>
            <th className="w-[120px] whitespace-nowrap px-4 py-2.5 pl-9 text-right text-[10.5px] font-bold uppercase tracking-wide text-muted">In Pipeline</th>
            <th className="w-[100px] whitespace-nowrap px-4 py-2.5 pl-9 text-center text-[10.5px] font-bold uppercase tracking-wide text-muted">Tranches</th>
            <th className="w-[110px] whitespace-nowrap px-4 py-2.5 pl-9 text-center text-[10.5px] font-bold uppercase tracking-wide text-muted">Status</th>
            <th className="w-8" />
          </tr>
        </thead>
        <tbody>
          {visibleProjects.map((p) => {
            const tranches = disbursements[p.id] ?? [];
            const released = tranches.filter((t) => t.status === "released").reduce((s, t) => s + t.amount, 0);
            const pipeline = tranches.filter((t) => t.status !== "released").reduce((s, t) => s + t.amount, 0);
            const st = disbListStatus(tranches);
            return (
              <tr
                key={p.id}
                onClick={() => router.push(`/finance/disbursement/${p.id}`)}
                className="cursor-pointer bg-surface last:[&>td]:border-b-0 hover:[&>td]:!bg-primary-50"
              >
                <td className="border-b border-border px-4 py-3.5">
                  <div className="truncate text-[13.5px] font-semibold text-ink">{p.name}</div>
                  <div className="font-mono text-[10.5px] font-bold text-muted">{p.code}</div>
                </td>
                <td className="border-b border-border px-4 py-3.5 pl-9 text-[12.5px] text-ink-2">{p.partner}</td>
                <td className="border-b border-border px-4 py-3.5 pl-9 text-right font-mono text-[13px] font-bold">₹{fmtINR(p.budget)}</td>
                <td className="border-b border-border px-4 py-3.5 pl-9 text-right">
                  {released ? <span className="font-mono text-[13px] font-bold text-secondary">₹{fmtINR(released)}</span> : <span className="text-muted">—</span>}
                </td>
                <td className="border-b border-border px-4 py-3.5 pl-9 text-right">
                  {pipeline ? <span className="font-mono text-[13px] font-bold text-primary">₹{fmtINR(pipeline)}</span> : <span className="text-muted">—</span>}
                </td>
                <td className="border-b border-border px-4 py-3.5 pl-9 text-center">
                  {tranches.length ? <span className="text-[13px] font-semibold text-ink">{tranches.length}</span> : <span className="text-muted">—</span>}
                </td>
                <td className="border-b border-border px-4 py-3.5 pl-9 text-center">
                  <span className={`inline-flex items-center gap-1 rounded-full px-[9px] py-[3px] text-[11px] font-bold ${STATUS_STYLE[st.tone]}`}>{st.label}</span>
                </td>
                <td className="border-b border-border px-4 py-3.5 text-center">
                  <ChevronIcon />
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
    </div>
  );
}
