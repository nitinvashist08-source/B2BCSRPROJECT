"use client";

import Link from "next/link";
import { useSettingsStore } from "@/store/settingsStore";
import { useMeetingStore } from "@/store/meetingStore";
import { useProjectStore } from "@/store/projectStore";
import { ChecklistBaseline } from "@/store/workspaceStore";
import { Button } from "@/components/ui/Button";

function CheckIcon() {
  return (
    <svg
      aria-hidden="true"
      fill="none"
      height="14"
      width="14"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="3"
      viewBox="0 0 24 24"
    >
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}

type ChecklistItem = { key: string; title: string; description: string; href?: string; done: boolean };

function ChecklistRow({ item }: { item: ChecklistItem }) {
  const content = (
    <>
      <span
        className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 ${
          item.done ? "border-secondary bg-secondary text-white" : "border-border-strong bg-surface text-transparent"
        }`}
      >
        {item.done && <CheckIcon />}
      </span>
      <span className="flex-1">
        <span className={`block text-[13.5px] font-semibold ${item.done ? "text-muted line-through decoration-border-strong" : "text-ink"}`}>
          {item.title}
        </span>
        <span className="mt-0.5 block text-[12.5px] leading-snug text-muted">{item.description}</span>
        {item.done && (
          <span className="mt-1.5 inline-block text-[11.5px] font-semibold uppercase tracking-wide text-secondary-600">
            Completed
          </span>
        )}
      </span>
    </>
  );

  const rowClass = "flex h-full items-start gap-3 rounded-lg border border-border bg-surface p-3.5 transition-colors";

  if (item.done || !item.href) {
    return <div className={rowClass}>{content}</div>;
  }
  return (
    <Link href={item.href} className={`${rowClass} hover:border-primary hover:bg-primary-50`}>
      {content}
    </Link>
  );
}

// One-time "getting started" prompt shown as the final step of sign-up
// onboarding (not a persistent dashboard widget) — see AppShell.tsx: once
// completeOnboarding() runs, the session's onboardingComplete flips true, so
// this step renders inside the full Sidebar/Header shell rather than
// standalone, meaning every link here (and the sidebar itself) already works
// for free navigation — nothing here blocks reaching the dashboard or any
// other module.
export function GettingStartedStep({ baseline, onContinue }: { baseline: ChecklistBaseline; onContinue: () => void }) {
  const teamMembers = useSettingsStore((s) => s.teamMembers).length;
  const partners = useSettingsStore((s) => s.partners).length;
  const committeeMembers = useMeetingStore((s) => s.committee).length;
  const projects = useProjectStore((s) => s.projects).length;

  const items: ChecklistItem[] = [
    {
      key: "partners",
      title: "Invite Partners",
      description: "Onboard NGOs, implementing partners, co-sponsors, and other collaborators.",
      href: "/partners",
      done: partners > baseline.partners,
    },
    {
      key: "project",
      title: "Create First Project",
      description: "Create your first CSR project and assign implementing partners.",
      done: projects > baseline.projects,
    },
    {
      key: "committee",
      title: "Set Up CSR Committee",
      description: "Define your CSR Committee structure and set up the committee for the current period.",
      href: "/meetings/committee",
      done: committeeMembers > baseline.committeeMembers,
    },
    {
      key: "team",
      title: "Invite Team Members",
      description: "Bring your CSR, finance, programme, and management teams into your workspace.",
      href: "/settings/user",
      done: teamMembers > baseline.teamMembers,
    },
  ];

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-5 py-4">
      <div>
        <h1 className="text-lg font-bold tracking-tight text-ink">Get started with bImpact</h1>
        <p className="mt-1 text-[13px] text-muted">
          Complete these steps to start managing your CSR initiatives — or skip ahead, you can always do this later.
        </p>
      </div>

      <div className="flex flex-col gap-3">
        {items.map((item) => (
          <ChecklistRow key={item.key} item={item} />
        ))}
      </div>

      <div>
        <Button type="button" variant="primary" onClick={onContinue}>
          Go to Dashboard
        </Button>
      </div>
    </div>
  );
}
