// Macro registration-progress indicator shown at the top of /onboarding.
// This page is only ever reached after Account creation, Verification, and
// Profile are already complete (AppShell redirects here only for an
// authenticated-but-not-onboarded session — see AppShell.tsx's guard), so
// those three steps are always "done" and "Workspace" (this page, covering
// the user-type / role / company questions below) is always the current
// step. Deliberately static — no props — since nothing here ever changes.
const STEPS = ["Account", "Verification", "Profile", "Workspace"] as const;
const CURRENT_INDEX = 3;

export function StepProgress() {
  return (
    <ol className="flex items-center" aria-label="Registration progress">
      {STEPS.map((label, i) => {
        const done = i < CURRENT_INDEX;
        const current = i === CURRENT_INDEX;
        return (
          <li key={label} className="flex items-center">
            <span className="flex items-center gap-1.5">
              <span
                aria-hidden
                className={
                  done
                    ? "h-2 w-2 rounded-full bg-primary"
                    : current
                      ? "h-2 w-2 rounded-full border-[1.5px] border-primary bg-surface"
                      : "h-2 w-2 rounded-full bg-border-strong"
                }
              />
              <span className={`text-[11px] font-medium ${current ? "text-ink" : "text-muted"}`}>
                {label}
              </span>
            </span>
            {i < STEPS.length - 1 && <span aria-hidden className="mx-2 h-px w-5 bg-border" />}
          </li>
        );
      })}
    </ol>
  );
}
