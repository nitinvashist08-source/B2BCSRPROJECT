import Link from "next/link";
import { ReactNode } from "react";
import { StepProgress } from "./StepProgress";

// Visually consistent with AuthCard (same bI mark, centered white card on a
// bg-bg screen, same border/radius language) but with a StepProgress slot
// above the card and a wider default width so the two-up selection cards in
// Q1/Q2 have room — AuthCard itself is left untouched (owned/shared, not
// suited to this page's wider selection-card steps).
export function OnboardingShell({
  title,
  subtitle,
  children,
  width = "460px",
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  width?: string;
}) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-bg px-4 py-10">
      <Link href="/" className="flex items-center gap-2.5">
        <span
          className="flex h-9 w-9 items-center justify-center rounded-[9px] text-[14px] font-extrabold tracking-tight text-white"
          style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
        >
          bI
        </span>
        <span className="text-[15px] font-semibold tracking-tight text-ink">bImpact</span>
      </Link>

      <StepProgress />

      <div
        className="w-full rounded-xl border border-border bg-surface p-7 shadow-sm"
        style={{ maxWidth: width }}
      >
        <h2 className="text-lg font-bold text-ink">{title}</h2>
        {subtitle && <p className="mt-1 text-[13px] text-muted">{subtitle}</p>}
        <div className="mt-5">{children}</div>
      </div>
    </div>
  );
}
