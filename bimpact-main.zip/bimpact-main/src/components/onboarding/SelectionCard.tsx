// Accessible selection card for the onboarding questions (Q1 user type,
// Q2 role) — a real <button> (not a bare `<div onClick>`) so it gets
// keyboard focus, a visible focus ring, and works with screen readers via
// aria-pressed.
export function SelectionCard({
  title,
  description,
  selected,
  onClick,
}: {
  title: string;
  description?: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={selected}
      onClick={onClick}
      className={`flex-1 rounded-lg border-[1.5px] p-4 text-left transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ${
        selected
          ? "border-primary bg-primary-50"
          : "border-border bg-surface hover:border-border-strong hover:bg-surface-2"
      }`}
    >
      <div className={`text-[13.5px] font-semibold ${selected ? "text-primary-700" : "text-ink"}`}>
        {title}
      </div>
      {description && (
        <p className="mt-1 text-[12.5px] leading-snug text-muted">{description}</p>
      )}
    </button>
  );
}
