"use client";

import { ReactElement, useState } from "react";
import { DndContext, DragEndEvent, PointerSensor, closestCenter, useSensor, useSensors } from "@dnd-kit/core";
import { SortableContext, arrayMove, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useProjectStore } from "@/store/projectStore";
import { useSessionStore } from "@/store/sessionStore";
import { pushOwnershipAlerts } from "@/lib/ownershipAlerts";
import { canEditProjectResource } from "@/lib/permissions";
import { OwnershipMode, WbsColumn, WbsRow } from "@/types/project";
import { WBS_COL, dependencyIdsFromCell, dependencyToken } from "@/lib/wbsColumns";
import { RICH_TEXT_DISPLAY_CLS, isEmptyHtml } from "./WbsRemarksField";
import { WbsRowMenu } from "./WbsRowMenu";
import { WbsDeleteConfirmModal } from "./WbsDeleteConfirmModal";
import { TaskFormSlideOver } from "./TaskFormSlideOver";

// Pill styling per mode (mode-only — same visual regardless of viewer).
// Label text, however, must say "You" vs. the *other* side correctly for
// whichever role is looking at it, so it's computed per-viewer below rather
// than baked into this table.
const MODE_CFG: Record<OwnershipMode, { pillCls: string }> = {
  self: { pillCls: "bg-primary-50 text-primary-700 border-primary-100" },
  partner: { pillCls: "bg-[rgba(0,166,81,0.08)] text-[#00853a] border-[rgba(0,166,81,0.2)]" },
  both: { pillCls: "bg-[rgba(124,58,237,0.07)] text-[#6d28d9] border-[rgba(124,58,237,0.18)]" },
};

// "Managed by" wording from the current viewer's own point of view — matches
// spec section 17 (ownership must always be visible) without misleading a
// Partner into thinking "You are creating" when the Sponsor owns it, or vice
// versa.
function pillLabelFor(mode: OwnershipMode, isPartner: boolean): string {
  // "Collaborative"/"You are creating"/"Partner is creating" wording is
  // verbatim from the source mockup's own MODE_CFG.pillHtml — only the
  // opposite-viewer strings (Partner seeing a Sponsor-owned WBS, and vice
  // versa) are this app's own addition, since the mockup is a single-viewer
  // static demo with no Partner-login concept to have ever needed them.
  if (mode === "both") return "👥 Collaborative";
  if (mode === "self") return isPartner ? "👤 Sponsor is creating" : "👤 You are creating";
  return isPartner ? "🤝 You are creating" : "🤝 Partner is creating";
}

const OPTIONS: {
  mode: OwnershipMode;
  label: string;
  sub: string;
  iconBg: string;
  iconColor: string;
  onCls: string;
}[] = [
  {
    mode: "self",
    label: "You (CSR Head / PM)",
    sub: "You edit  ·  Partner views only",
    iconBg: "var(--color-primary-50)",
    iconColor: "var(--color-primary)",
    onCls: "border-primary bg-primary-50 shadow-[0_0_0_3px_rgba(10,151,217,0.1)]",
  },
  {
    mode: "partner",
    label: "Partner (Implementing Org)",
    sub: "Partner edits  ·  You view only",
    iconBg: "var(--color-secondary-50)",
    iconColor: "var(--color-secondary)",
    onCls: "border-secondary bg-[rgba(0,166,81,0.04)] shadow-[0_0_0_3px_rgba(0,166,81,0.1)]",
  },
  {
    mode: "both",
    label: "Both (Collaborative)",
    sub: "Both can edit  ·  Full collaboration",
    iconBg: "rgba(124,58,237,0.08)",
    iconColor: "#7c3aed",
    onCls: "border-[#7c3aed] bg-[rgba(124,58,237,0.04)] shadow-[0_0_0_3px_rgba(124,58,237,0.1)]",
  },
];

function PersonIcon() {
  return (
    <svg fill="none" height="18" width="18" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

function PartnerIcon() {
  return (
    <svg fill="none" height="18" width="18" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

function BothIcon() {
  return (
    <svg fill="none" height="18" width="18" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H8" />
      <circle cx="12" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

const ICONS: Record<OwnershipMode, () => ReactElement> = { self: PersonIcon, partner: PartnerIcon, both: BothIcon };

function AddTaskIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M12 5v14" />
      <path d="M5 12h14" />
    </svg>
  );
}

function DragHandleIcon() {
  return (
    <svg fill="currentColor" height="13" width="13" viewBox="0 0 24 24">
      <circle cx="9" cy="6" r="1.5" />
      <circle cx="9" cy="12" r="1.5" />
      <circle cx="9" cy="18" r="1.5" />
      <circle cx="15" cy="6" r="1.5" />
      <circle cx="15" cy="12" r="1.5" />
      <circle cx="15" cy="18" r="1.5" />
    </svg>
  );
}

// Per-column minimum widths — a few fixed Task fields (Description,
// Dependency, Remarks) need more room than a plain short text/date cell.
const COL_MIN_WIDTH: Record<string, number> = {
  [WBS_COL.title]: 180,
  [WBS_COL.description]: 220,
  [WBS_COL.assignee]: 160,
  [WBS_COL.start]: 140,
  [WBS_COL.end]: 140,
  [WBS_COL.status]: 130,
  [WBS_COL.completion]: 120,
  [WBS_COL.priority]: 120,
  [WBS_COL.dependency]: 220,
  [WBS_COL.remarks]: 200,
};

// Plain, read-only rendering for one Task cell — the table no longer edits
// anything inline (see the spec: clicking any cell opens Edit Task
// instead), so every column just needs to display its stored value
// legibly, not collect input.
function WbsCellDisplay({ col, row, allRows }: { col: WbsColumn; row: WbsRow; allRows: WbsRow[] }) {
  const raw = row.cells[col.id] ?? "";

  if (col.inputType === "number") {
    return <span className="text-sm text-ink">{raw || "0"}%</span>;
  }

  if (col.inputType === "select") {
    return raw ? (
      <span className="inline-flex rounded-full bg-surface-2 px-2 py-0.5 text-xs font-semibold text-ink-2">{raw}</span>
    ) : (
      <span className="text-sm text-muted-2">—</span>
    );
  }

  if (col.inputType === "dependency") {
    const tokens = dependencyIdsFromCell(raw)
      .map((id) => allRows.find((r) => r.id === id))
      .filter((r): r is WbsRow => !!r)
      .map(dependencyToken);
    if (tokens.length === 0) return <span className="text-sm text-muted-2">—</span>;
    return (
      <div className="flex flex-wrap gap-1">
        {tokens.map((t) => (
          <span key={t} className="rounded-full bg-surface-2 px-2 py-0.5 text-xs text-ink-2">
            {t}
          </span>
        ))}
      </div>
    );
  }

  if (col.inputType === "remarks") {
    if (isEmptyHtml(raw)) return <span className="text-sm text-muted-2">—</span>;
    return (
      <div className={`line-clamp-2 text-sm text-ink ${RICH_TEXT_DISPLAY_CLS}`} dangerouslySetInnerHTML={{ __html: raw }} />
    );
  }

  // text / date / assignee — plain value, or an em dash when unset.
  return raw ? <span className="block truncate text-sm text-ink">{raw}</span> : <span className="text-sm text-muted-2">—</span>;
}

// One WBS Task row — read-only; clicking anywhere in the row (other than
// the drag handle or the row menu, both of which stop the click from
// bubbling) opens Edit Task. Extracted so useSortable (a hook) has a
// stable per-row component to call from, per dnd-kit's own required
// pattern (same as DashboardPageTabs.tsx's PageTab). Drag is initiated
// ONLY from the handle icon ({...attributes}/{...listeners} live there,
// not on the <tr>) — per spec, dragging the row must not open Edit Task.
function SortableWbsRow({
  row,
  rows,
  columns,
  canDrag,
  showRowMenu,
  onOpenTask,
  onDeleteRow,
}: {
  row: WbsRow;
  rows: WbsRow[];
  columns: WbsColumn[];
  canDrag: boolean;
  showRowMenu: boolean;
  onOpenTask: () => void;
  onDeleteRow: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: row.id,
    disabled: !canDrag,
  });
  const [hovering, setHovering] = useState(false);
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.6 : 1,
  };

  return (
    <tr
      ref={setNodeRef}
      style={style}
      onClick={onOpenTask}
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => setHovering(false)}
      title="Click to view/edit task"
      className="cursor-pointer transition-colors hover:bg-surface-2"
    >
      <td className="border-b border-r border-border bg-surface-2 px-2 text-xs text-muted">
        <div className="flex items-center gap-1.5">
          {canDrag && (
            <button
              type="button"
              onClick={(e) => e.stopPropagation()}
              className={`flex h-5 w-4 shrink-0 items-center justify-center text-muted-2 ${
                hovering ? "cursor-grab opacity-100 active:cursor-grabbing" : "opacity-0"
              }`}
              aria-label="Reorder task"
              {...attributes}
              {...listeners}
            >
              <DragHandleIcon />
            </button>
          )}
          <span className="shrink-0 font-mono font-semibold tracking-wide text-ink-2">{row.id}</span>
          {showRowMenu && (
            <span className={`ml-auto shrink-0 ${hovering ? "opacity-100" : "opacity-0"}`}>
              <WbsRowMenu onDelete={onDeleteRow} />
            </span>
          )}
        </div>
      </td>
      {columns.map((col) => (
        <td key={col.id} className="border-b border-r border-border px-3 py-2.5 last:border-r-0">
          <WbsCellDisplay col={col} row={row} allRows={rows} />
        </td>
      ))}
    </tr>
  );
}

export function WbsTable({ projectId }: { projectId: string }) {
  const wbs = useProjectStore((s) => s.wbs[projectId]);
  const setWbsMode = useProjectStore((s) => s.setWbsMode);
  const removeWbsRow = useProjectStore((s) => s.removeWbsRow);
  const reorderWbsRows = useProjectStore((s) => s.reorderWbsRows);
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));
  const role = useSessionStore((s) => s.role);
  const isPartner = role === "partner";

  // Shared algorithm (ownershipAlerts.ts) — see DocumentOwnershipStrip.tsx's
  // handleNotifyPartner for the full rule this defers to.
  function handleNotifyPartner(newMode: OwnershipMode, previousMode: OwnershipMode | null) {
    if (!project) return;
    pushOwnershipAlerts("wbs", projectId, project.name, previousMode, newMode);
  }
  const [deleteRowId, setDeleteRowId] = useState<string | null>(null);
  // null = closed; { row: null } = Add Task; { row } = Edit Task for that
  // Task. One slide-over instance handles both (see TaskFormSlideOver.tsx).
  const [taskFormTarget, setTaskFormTarget] = useState<{ row: WbsRow | null } | null>(null);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));

  const mode = wbs?.mode ?? null;
  const columns = wbs?.columns ?? [];
  const rows = wbs?.rows ?? [];
  const cfg = mode ? MODE_CFG[mode] : null;
  // Per-viewer permission — see canEditProjectResource() in permissions.ts, the single
  // source of truth for the ownership-mode permission matrix, also enforced
  // again at the store/action layer so this UI check is defense-in-depth,
  // not the only gate.
  const canEdit = canEditProjectResource(mode, role);
  const readOnly = !canEdit;
  // View-only banner text depends on *which* side is looking, not just the
  // mode: a Partner viewing a Sponsor-owned WBS sees different copy than a
  // Sponsor viewing a Partner-owned one.
  const showSelfViewBanner = mode === "self" && isPartner;
  const showPartnerViewBanner = mode === "partner" && !isPartner;
  const showBothBanner = mode === "both";

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const ids = rows.map((r) => r.id);
    const oldIndex = ids.indexOf(String(active.id));
    const newIndex = ids.indexOf(String(over.id));
    if (oldIndex === -1 || newIndex === -1) return;
    reorderWbsRows(projectId, arrayMove(ids, oldIndex, newIndex));
  }

  function handleConfirmDelete() {
    if (!deleteRowId) return;
    removeWbsRow(projectId, deleteRowId);
  }

  return (
    <div className="overflow-hidden bg-surface">
      {/* Owner strip — governance decision made by the sponsor only; an
          invited partner must never see or trigger this picker (they only
          ever inherit whatever mode the sponsor already configured). */}
      {!isPartner && (
        <div className="border-b border-border bg-surface px-5 pb-3.5 pt-[18px]">
          <div className="mb-3.5 flex items-baseline gap-2.5">
            <h3 className="text-sm font-bold text-ink">Who creates the WBS?</h3>
            <p className="text-[0.8rem] text-muted">Select responsibility — the table below updates immediately.</p>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {OPTIONS.map((opt) => {
              const on = mode === opt.mode;
              const Icon = ICONS[opt.mode];
              return (
                <button
                  key={opt.mode}
                  onClick={() => {
                    setWbsMode(projectId, opt.mode);
                    handleNotifyPartner(opt.mode, mode);
                  }}
                  className={`relative flex items-center gap-3 rounded-[10px] border-2 p-3.5 text-left transition-all ${
                    on ? opt.onCls : "border-border bg-surface hover:border-border-strong hover:shadow-[0_3px_10px_rgba(0,0,0,0.06)]"
                  }`}
                >
                  <span
                    className={`absolute right-3 top-2.5 flex h-[17px] w-[17px] items-center justify-center rounded-full border-2 ${
                      on ? "border-transparent" : "border-border-strong bg-surface"
                    }`}
                    style={on ? { background: opt.iconColor } : undefined}
                  >
                    {on && <span className="h-1.5 w-1.5 rounded-full bg-white" />}
                  </span>
                  <span
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[9px]"
                    style={{ background: opt.iconBg, color: opt.iconColor }}
                  >
                    <Icon />
                  </span>
                  <span>
                    <span className="mb-0.5 block text-sm font-bold text-ink">{opt.label}</span>
                    <span className="block text-[11px] leading-snug text-muted">{opt.sub}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Table header bar */}
      <div className="flex flex-wrap items-center gap-2.5 border-b border-border bg-surface px-[18px] py-3">
        <span className="flex-1 text-[0.9rem] font-bold text-ink">Work Breakdown Structure</span>
        {mode && cfg && (
          <span className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-[3px] text-[11.5px] font-bold ${cfg.pillCls}`}>
            {pillLabelFor(mode, isPartner)}
          </span>
        )}
        {canEdit && (
          <button
            onClick={() => setTaskFormTarget({ row: null })}
            className="flex h-8 items-center gap-1 rounded-sm bg-primary px-2.5 text-[0.8rem] font-semibold text-white hover:bg-primary-600"
          >
            <AddTaskIcon />
            Add Task
          </button>
        )}
      </div>

      {/* Info banners — copy is per-viewer, not per-mode, so a read-only
          user always sees which side actually owns the WBS. */}
      {showPartnerViewBanner && (
        <div className="flex items-start gap-2 border-b border-[rgba(245,158,11,0.18)] bg-[rgba(245,158,11,0.06)] px-[18px] py-2.5 text-[12.5px] leading-snug text-[#92400e]">
          <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" className="mt-px shrink-0">
            <circle cx="12" cy="12" r="10" />
            <line x1="12" x2="12" y1="8" y2="12" />
            <line x1="12" x2="12.01" y1="16" y2="16" />
          </svg>
          <span>
            <strong>View-only.</strong> Your partner is responsible for building this WBS. You can monitor but cannot make edits.
          </span>
        </div>
      )}
      {showSelfViewBanner && (
        <div className="flex items-start gap-2 border-b border-[rgba(245,158,11,0.18)] bg-[rgba(245,158,11,0.06)] px-[18px] py-2.5 text-[12.5px] leading-snug text-[#92400e]">
          <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" className="mt-px shrink-0">
            <circle cx="12" cy="12" r="10" />
            <line x1="12" x2="12" y1="8" y2="12" />
            <line x1="12" x2="12.01" y1="16" y2="16" />
          </svg>
          <span>
            <strong>View-only.</strong> Your Sponsor (CSR Head / PM) is responsible for building this WBS. You can monitor but cannot make edits.
          </span>
        </div>
      )}
      {showBothBanner && (
        <div className="flex items-start gap-2 border-b border-[rgba(124,58,237,0.14)] bg-[rgba(124,58,237,0.05)] px-[18px] py-2.5 text-[12.5px] leading-snug text-[#5b21b6]">
          <PartnerIcon />
          <span>
            <strong>Collaborative mode.</strong> Both you and your partner can edit this WBS.
          </span>
        </div>
      )}

      {/* Empty state */}
      {!mode && (
        <div className="flex min-h-[260px] flex-col items-center justify-center gap-2.5 p-8 text-center text-muted">
          <div className="mb-1 flex h-[52px] w-[52px] items-center justify-center rounded-full border-2 border-dashed border-border-strong bg-bg">
            <svg fill="none" height="22" width="22" stroke="var(--color-muted-2)" strokeWidth="1.5" viewBox="0 0 24 24">
              <rect height="18" rx="2" ry="2" width="18" x="3" y="3" />
              <line x1="3" x2="21" y1="9" y2="9" />
              <line x1="9" x2="9" y1="21" y2="9" />
            </svg>
          </div>
          <div className="text-sm font-semibold text-ink-2">
            {isPartner ? "Waiting for your Sponsor to configure who creates this WBS." : "Select who will create the WBS above"}
          </div>
          <div className="max-w-[280px] text-[0.8rem] leading-snug text-muted">
            {isPartner
              ? "Once they choose You, Partner, or Both, this table will appear here automatically."
              : "Choose You, Partner, or Both — the table will appear and configure itself instantly."}
          </div>
        </div>
      )}

      {/* Table */}
      {mode && (
        // DndContext wraps the WHOLE scroll container (table included) —
        // it renders a hidden accessibility <div> alongside its children,
        // which is invalid HTML (and triggers a hydration warning) if
        // placed directly inside <table> between <thead>/<tbody>. Only
        // SortableContext (a pure context provider, no DOM output of its
        // own) needs to sit closer to the <tbody> it actually scopes.
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <div className="max-w-full overflow-x-auto pb-2">
          <table className="w-max min-w-full table-fixed border-collapse">
            <thead>
              <tr>
                {/* ID is a system-generated, mandatory column — no menu at
                    all, so it can never be deleted or reconfigured (per
                    spec section 5). */}
                <th className="border-b border-r border-border-strong bg-surface-2 px-2 text-left text-xs font-semibold text-muted" style={{ minWidth: 96 }}>
                  ID
                </th>
                {columns.map((col) => (
                  <th key={col.id} className="border-b border-r border-border-strong bg-surface-2 px-3 text-left last:border-r-0" style={{ minWidth: COL_MIN_WIDTH[col.id] ?? 150 }}>
                    {/* Columns are a fixed Task schema now (lib/wbsColumns.ts) —
                        no rename input, no data-type/sort menu; just the label. */}
                    <span className="flex h-10 items-center truncate text-sm font-semibold text-ink-2">{col.label}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <SortableContext items={rows.map((r) => r.id)} strategy={verticalListSortingStrategy}>
              <tbody>
                {rows.map((row) => (
                  <SortableWbsRow
                    key={row.id}
                    row={row}
                    rows={rows}
                    columns={columns}
                    canDrag={canEdit}
                    showRowMenu={canEdit}
                    onOpenTask={() => setTaskFormTarget({ row })}
                    onDeleteRow={() => setDeleteRowId(row.id)}
                  />
                ))}
              </tbody>
            </SortableContext>
          </table>
        </div>
        </DndContext>
      )}

      {rows.length === 0 && mode && (
        <div className="flex flex-col items-center justify-center gap-1 py-8 text-center">
          <p className="text-sm font-semibold text-ink-2">No tasks yet</p>
          <p className="text-xs text-muted">
            {canEdit ? "Click + Add Task above to create the first task." : "Waiting for the WBS owner to add tasks."}
          </p>
        </div>
      )}

      <WbsDeleteConfirmModal rowId={deleteRowId} onClose={() => setDeleteRowId(null)} onConfirm={handleConfirmDelete} />

      <TaskFormSlideOver
        open={!!taskFormTarget}
        onClose={() => setTaskFormTarget(null)}
        projectId={projectId}
        task={taskFormTarget?.row ?? null}
        readOnly={!!taskFormTarget?.row && readOnly}
      />
    </div>
  );
}
