"use client";

import { useState } from "react";
import Link from "next/link";
import { useProjectStore } from "@/store/projectStore";
import { FormField } from "@/types/project";
import { DynamicField, FieldGroup } from "./DynamicIndicatorField";
import { Button } from "@/components/ui/Button";

function BrandMark() {
  return (
    <Link href="/" className="flex items-center gap-2.5">
      <span
        className="flex h-9 w-9 items-center justify-center rounded-[9px] text-[14px] font-extrabold tracking-tight text-white"
        style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
      >
        bI
      </span>
      <span className="text-[15px] font-semibold tracking-tight text-ink">bImpact</span>
    </Link>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col items-center gap-6 bg-bg px-4 py-10">
      <BrandMark />
      <div className="w-full max-w-[640px] rounded-xl border border-border bg-surface p-7 shadow-sm">{children}</div>
    </div>
  );
}

function CheckIcon() {
  return (
    <svg fill="none" height="28" width="28" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}

// Public respondent view for Workplace → Beneficiary Indicators → "Share
// Form" — reached at /beneficiary-form/[token] (see AppShell.tsx's
// PUBLIC_PREFIXES/PUBLIC_DATA_PREFIXES; no login required). `token` resolves
// to an IndicatorFormShareLink (projectStore.ts), which resolves to the SAME
// Indicator Form/questions the Sponsor or Partner configured under
// Beneficiary Indicators — never a separate form definition. Submitting
// writes into the SAME indicatorFormResponses collection Add Record writes
// into (via submitIndicatorFormResponseViaShareLink), stamped with the
// link's sharer identity as `submittedBy` — the respondent filling this out
// is never asked to identify themselves beyond whatever questions the form
// itself asks.
export function BeneficiaryShareRespond({ token }: { token: string }) {
  const link = useProjectStore((s) => s.indicatorFormShareLinks[token]);
  const formState = useProjectStore((s) => (link ? s.indicatorForms[link.projectId] : undefined));
  const submitIndicatorFormResponseViaShareLink = useProjectStore((s) => s.submitIndicatorFormResponseViaShareLink);

  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  if (!link) {
    return (
      <Shell>
        <h1 className="text-lg font-bold text-ink">This link isn&apos;t valid</h1>
        <p className="mt-2 text-sm text-muted">
          This form link has expired or no longer exists. Please contact whoever shared it with you for a new link.
        </p>
      </Shell>
    );
  }

  if (!formState) {
    return (
      <Shell>
        <h1 className="text-lg font-bold text-ink">This form is no longer available</h1>
        <p className="mt-2 text-sm text-muted">Please contact whoever shared this link with you.</p>
      </Shell>
    );
  }

  if (submitted) {
    return (
      <Shell>
        <div className="flex flex-col items-center gap-3 py-4 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-secondary-50 text-secondary-600">
            <CheckIcon />
          </span>
          <h1 className="text-lg font-bold text-ink">Thank you</h1>
          <p className="max-w-[380px] text-sm text-muted">Your response has been submitted successfully.</p>
        </div>
      </Shell>
    );
  }

  const flatFields: FormField[] = formState.sections.flatMap((sec) => sec.fields);

  function handleSubmit() {
    const nextErrors: Record<string, string> = {};
    flatFields.forEach((f) => {
      if (f.required && !answers[f.id]?.trim()) nextErrors[f.id] = "This field is required.";
    });
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    const result = submitIndicatorFormResponseViaShareLink(token, answers);
    if (result.ok) setSubmitted(true);
  }

  return (
    <Shell>
      <h1 className="text-lg font-bold text-ink">{formState.title || "Beneficiary Indicator Form"}</h1>
      {formState.description && <p className="mt-1 text-[13px] text-muted">{formState.description}</p>}

      <div className="mt-5">
        {flatFields.length === 0 ? (
          <p className="text-[13px] text-muted">This form has no questions yet.</p>
        ) : (
          flatFields.map((f) => (
            <FieldGroup key={f.id} label={f.label} required={f.required} error={errors[f.id]}>
              <DynamicField
                field={f}
                value={answers[f.id] ?? ""}
                onChange={(v) => setAnswers((a) => ({ ...a, [f.id]: v }))}
                invalid={!!errors[f.id]}
              />
            </FieldGroup>
          ))
        )}
      </div>

      <div className="mt-2 flex justify-end">
        <Button onClick={handleSubmit}>Submit</Button>
      </div>
    </Shell>
  );
}
