"use client";

import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";

// WBS Task delete confirmation — `rowId` is the pending Task's id, or null
// when nothing is pending deletion. Columns are a fixed schema now (see
// lib/wbsColumns.ts), so this only ever confirms deleting a Task/row.
export function WbsDeleteConfirmModal({
  rowId,
  onClose,
  onConfirm,
}: {
  rowId: string | null;
  onClose: () => void;
  onConfirm: () => void;
}) {
  return (
    <Modal
      open={!!rowId}
      onClose={onClose}
      title="Delete Task?"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              onConfirm();
              onClose();
            }}
          >
            Delete
          </Button>
        </>
      }
    >
      Are you sure you want to delete this task? This action cannot be undone.
    </Modal>
  );
}
