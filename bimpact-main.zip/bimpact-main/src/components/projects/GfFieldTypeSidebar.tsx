"use client";

import { FormFieldType } from "@/types/project";

type SidebarItem = { type: FormFieldType; label: string; path: string };

// The default question label a new field gets when added — matches
// TYPE_LABELS in gfSidebarAdd(), bImpact_MeetingSplit_v10.html:6029-6036
// (wording differs slightly from the sidebar button labels below for a few
// types, e.g. "phone" is a "Phone" button but defaults the new question's
// label to "Phone Number").
export const NEW_FIELD_LABEL: Record<FormFieldType, string> = {
  text: "Short Text",
  para: "Paragraph",
  number: "Number",
  email: "Email",
  phone: "Phone Number",
  url: "Website URL",
  currency: "Currency Amount",
  date: "Date",
  time: "Time",
  radio: "Multiple Choice",
  checkbox: "Checkboxes",
  dropdown: "Dropdown",
  yesno: "Yes / No",
  rating: "Star Rating",
  scale: "Linear Scale",
  address: "Full Address",
  signature: "Signature",
  file: "File Upload",
};

const SECTIONS: { title: string; items: SidebarItem[] }[] = [
  {
    title: "Text & Input",
    items: [
      { type: "text", label: "Short Text", path: "M17 10H3M21 6H3M21 14H3M17 18H3" },
      { type: "para", label: "Paragraph", path: "M21 6H3M21 10H3M21 14H3M21 18H3" },
      { type: "number", label: "Number", path: "M4 9h16M4 15h16M10 3 8 21M16 3l-2 18" },
      { type: "email", label: "Email", path: "M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" },
      { type: "phone", label: "Phone", path: "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.24h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" },
      { type: "currency", label: "Currency", path: "M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" },
      { type: "url", label: "Website URL", path: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" },
    ],
  },
  {
    title: "Choice",
    items: [
      { type: "radio", label: "Multiple Choice", path: "" },
      { type: "checkbox", label: "Checkboxes", path: "" },
      { type: "dropdown", label: "Dropdown", path: "M6 9l6 6 6-6" },
      { type: "yesno", label: "Yes / No", path: "" },
    ],
  },
  {
    title: "Date & Time",
    items: [
      { type: "date", label: "Date", path: "" },
      { type: "time", label: "Time", path: "" },
    ],
  },
  {
    title: "Scale & Rating",
    items: [
      { type: "rating", label: "Star Rating", path: "" },
      { type: "scale", label: "Linear Scale", path: "" },
    ],
  },
  {
    title: "Special",
    items: [
      { type: "address", label: "Full Address", path: "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" },
      { type: "signature", label: "Signature", path: "M20 19.5c-2.5 0-2.5-1-5-1s-2.5 1-5 1-2.5-1-5-1M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z" },
      { type: "file", label: "File Upload", path: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" },
    ],
  },
];

function SidebarIcon({ type }: { type: FormFieldType }) {
  switch (type) {
    case "radio":
      return (
        <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10" />
          <circle cx="12" cy="12" r="3" />
        </svg>
      );
    case "checkbox":
      return (
        <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <polyline points="9 11 12 14 22 4" />
          <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
        </svg>
      );
    case "yesno":
      return (
        <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
          <polyline points="22 4 12 14.01 9 11.01" />
        </svg>
      );
    case "date":
      return (
        <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <rect height="18" rx="2" width="18" x="3" y="4" />
          <line x1="16" x2="16" y1="2" y2="6" />
          <line x1="8" x2="8" y1="2" y2="6" />
          <line x1="3" x2="21" y1="10" y2="10" />
        </svg>
      );
    case "time":
      return (
        <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10" />
          <polyline points="12 6 12 12 16 14" />
        </svg>
      );
    case "rating":
      return (
        <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
      );
    case "scale":
      return (
        <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
        </svg>
      );
    default:
      return (
        <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <path d="M4 4h16v16H4z" />
        </svg>
      );
  }
}

export function GfFieldTypeSidebar({ onAdd }: { onAdd: (type: FormFieldType) => void }) {
  return (
    <div className="sticky top-0 w-[212px] shrink-0 self-start border-l border-border bg-surface">
      <div className="border-b border-border px-3.5 py-2.5 text-[12.5px] font-bold text-ink">Add Field</div>
      {SECTIONS.map((section, idx) => (
        <div key={section.title}>
          {idx > 0 && <div className="mx-3.5 my-1.5 h-px bg-border" />}
          <div className="px-3.5 pb-1 pt-2.5 text-[10px] font-bold uppercase tracking-wide text-muted-2">
            {section.title}
          </div>
          {section.items.map((item) => (
            <button
              key={item.type}
              onClick={() => onAdd(item.type)}
              className="group flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-[13px] font-medium text-ink-2 transition-colors hover:bg-primary-50 hover:text-primary-700"
            >
              <span className="flex h-[26px] w-[26px] shrink-0 items-center justify-center rounded-md border border-border bg-bg text-ink-2 transition-colors group-hover:border-primary group-hover:bg-primary group-hover:text-white">
                <SidebarIcon type={item.type} />
              </span>
              {item.label}
            </button>
          ))}
        </div>
      ))}
    </div>
  );
}
