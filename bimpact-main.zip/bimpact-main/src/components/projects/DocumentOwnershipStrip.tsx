"use client";

import { ReactElement } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useSessionStore } from "@/store/sessionStore";
import { pushOwnershipAlerts } from "@/lib/ownershipAlerts";
import { OwnershipMode } from "@/types/project";

// Byte-for-byte the same container/card classes, icons, and interaction as
// WbsTable.tsx's "Who creates the WBS?" strip (per spec: "use the same UI
// design, interaction pattern, and component structure") — only the
// heading and OPTIONS content differ. A sponsor-only governance decision;
// an invited partner must never see or trigger this picker, only inherit
// whatever mode the sponsor already configured (see setDocumentOwnership's
// own sponsor-only guard in projectStore.ts).
const OPTIONS: {
  mode: OwnershipMode;
  label: string;
  sub: string;
  iconBg: string;
  iconColor: string;
  onCls: string;
}[] = [
  {
    mode: "self",
    label: "You (CSR Head / PM)",
    sub: "You edit  ·  Partner views only",
    iconBg: "var(--color-primary-50)",
    iconColor: "var(--color-primary)",
    onCls: "border-primary bg-primary-50 shadow-[0_0_0_3px_rgba(10,151,217,0.1)]",
  },
  {
    mode: "partner",
    label: "Partner (Implementing Org)",
    sub: "Partner edits  ·  You view only",
    iconBg: "var(--color-secondary-50)",
    iconColor: "var(--color-secondary)",
    onCls: "border-secondary bg-[rgba(0,166,81,0.04)] shadow-[0_0_0_3px_rgba(0,166,81,0.1)]",
  },
  {
    mode: "both",
    label: "Both (Collaborative)",
    sub: "Both can edit  ·  Full collaboration",
    iconBg: "rgba(124,58,237,0.08)",
    iconColor: "#7c3aed",
    onCls: "border-[#7c3aed] bg-[rgba(124,58,237,0.04)] shadow-[0_0_0_3px_rgba(124,58,237,0.1)]",
  },
];

function PersonIcon() {
  return (
    <svg fill="none" height="18" width="18" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

function PartnerIcon() {
  return (
    <svg fill="none" height="18" width="18" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

function BothIcon() {
  return (
    <svg fill="none" height="18" width="18" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H8" />
      <circle cx="12" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

const ICONS: Record<OwnershipMode, () => ReactElement> = { self: PersonIcon, partner: PartnerIcon, both: BothIcon };

export function DocumentOwnershipStrip({ projectId }: { projectId: string }) {
  const mode = useProjectStore((s) => s.documentOwnership[projectId] ?? null);
  const setDocumentOwnership = useProjectStore((s) => s.setDocumentOwnership);
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));
  const role = useSessionStore((s) => s.role);
  const isPartner = role === "partner";

  // Shared algorithm (ownershipAlerts.ts) used identically by every
  // ownership-governed resource — see that file for the full rule: assign
  // alert ONLY on null→partner (once, ever); changed alert ONLY to whoever
  // just lost exclusive/shared access; no alert when nothing changed for
  // anyone.
  function handleNotifyPartner(newMode: OwnershipMode, previousMode: OwnershipMode | null) {
    if (!project) return;
    pushOwnershipAlerts("document", projectId, project.name, previousMode, newMode);
  }

  if (isPartner) return null;

  return (
    <div className="border-b border-border bg-surface px-5 pb-3.5 pt-[18px]">
      <div className="mb-3.5 flex items-baseline gap-2.5">
        <h3 className="text-sm font-bold text-ink">Who will create the documents?</h3>
        <p className="text-[0.8rem] text-muted">Select responsibility — the Documents panel updates immediately.</p>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {OPTIONS.map((opt) => {
          const on = mode === opt.mode;
          const Icon = ICONS[opt.mode];
          return (
            <button
              key={opt.mode}
              onClick={() => {
                setDocumentOwnership(projectId, opt.mode);
                handleNotifyPartner(opt.mode, mode);
              }}
              className={`relative flex items-center gap-3 rounded-[10px] border-2 p-3.5 text-left transition-all ${
                on ? opt.onCls : "border-border bg-surface hover:border-border-strong hover:shadow-[0_3px_10px_rgba(0,0,0,0.06)]"
              }`}
            >
              <span
                className={`absolute right-3 top-2.5 flex h-[17px] w-[17px] items-center justify-center rounded-full border-2 ${
                  on ? "border-transparent" : "border-border-strong bg-surface"
                }`}
                style={on ? { background: opt.iconColor } : undefined}
              >
                {on && <span className="h-1.5 w-1.5 rounded-full bg-white" />}
              </span>
              <span
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[9px]"
                style={{ background: opt.iconBg, color: opt.iconColor }}
              >
                <Icon />
              </span>
              <span>
                <span className="mb-0.5 block text-sm font-bold text-ink">{opt.label}</span>
                <span className="block text-[11px] leading-snug text-muted">{opt.sub}</span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
