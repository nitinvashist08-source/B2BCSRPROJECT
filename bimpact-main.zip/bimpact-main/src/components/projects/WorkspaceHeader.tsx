import Link from "next/link";
import { Project } from "@/types/project";
import { ProjectStatusBadge } from "./ProjectStatusBadge";

function BackArrowIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="19" x2="5" y1="12" y2="12" />
      <polyline points="12 19 5 12 12 5" />
    </svg>
  );
}

function ProjectIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
      <path d="M6 12v5c3 3 9 3 12 0v-5" />
    </svg>
  );
}

function PartnerIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" style={{ verticalAlign: "middle", opacity: 0.5, marginRight: 3 }}>
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
    </svg>
  );
}

function LocationIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" style={{ verticalAlign: "middle", opacity: 0.5, marginRight: 3 }}>
      <circle cx="12" cy="10" r="3" />
      <path d="M12 2a8 8 0 0 0-8 8c0 5.25 8 14 8 14s8-8.75 8-14a8 8 0 0 0-8-8z" />
    </svg>
  );
}

function Sep() {
  return <div className="mx-2.5 h-[18px] w-px shrink-0 bg-border" />;
}

export function WorkspaceHeader({ project }: { project: Project }) {
  return (
    <div className="flex flex-wrap items-center gap-y-1.5 border-b border-border pb-3.5">
      <Link
        href="/projects"
        className="inline-flex h-7 shrink-0 items-center gap-1.5 rounded-[5px] px-2.5 text-[12.5px] font-medium text-muted transition-colors hover:bg-bg hover:text-ink"
      >
        <BackArrowIcon />
        Projects
      </Link>
      <Sep />
      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-primary-50 text-primary">
        <ProjectIcon />
      </div>
      <span className="ml-2 whitespace-nowrap text-[0.93rem] font-bold text-ink">{project.name}</span>
      <span className="ml-1.5 font-mono text-xs text-muted">{project.code}</span>

      <div className="ml-auto flex items-center">
        <Sep />
        <span className="whitespace-nowrap text-[0.78rem] text-ink-2">
          <PartnerIcon />
          {project.partner}
        </span>
        <Sep />
        <span className="whitespace-nowrap text-[0.78rem] text-ink-2">
          <LocationIcon />
          {project.location}
        </span>
        <Sep />
        <ProjectStatusBadge status={project.status} />
      </div>
    </div>
  );
}
