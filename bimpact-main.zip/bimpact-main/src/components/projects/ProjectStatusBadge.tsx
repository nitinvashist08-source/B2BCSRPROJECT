import { ProjectStatus } from "@/types/project";
import { Badge, BadgeTone } from "@/components/ui/Badge";

const TONE: Record<ProjectStatus, BadgeTone> = {
  Planning: "primary",
  Execution: "secondary",
  Review: "amber",
  Closing: "purple",
};

const LABEL: Record<ProjectStatus, string> = {
  Planning: "Planning",
  Execution: "Execution",
  Review: "In Review",
  Closing: "Closing",
};

export function ProjectStatusBadge({ status }: { status: ProjectStatus }) {
  return <Badge tone={TONE[status]}>{LABEL[status]}</Badge>;
}
