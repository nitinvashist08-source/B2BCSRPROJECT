"use client";

import { useProjectStore } from "@/store/projectStore";
import { IndicatorFormResponse } from "@/types/project";

function CloseIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-[160px_1fr] border-b border-border last:border-b-0">
      <div className="bg-surface-2 px-3.5 py-2.5 text-xs font-semibold text-muted">{label}</div>
      <div className="whitespace-pre-wrap px-3.5 py-2.5 text-[13px] text-ink">{value || "—"}</div>
    </div>
  );
}

function fmtDateTime(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" });
}

// Read-only detail view for one Indicator-Form-driven submission (see
// AddRecordSlideOver.tsx) — mirrors BiDetailSlideOver.tsx's shell/DetailRow
// pattern for the older fixed-shape BeneficiaryRecord, but generic per
// question since an Indicator Form's fields are project-defined, not fixed.
export function IndicatorResponseDetailSlideOver({
  response,
  onClose,
}: {
  response: IndicatorFormResponse | null;
  onClose: () => void;
}) {
  const open = !!response;
  const formState = useProjectStore((s) => (response ? s.indicatorForms[response.projectId] : undefined));
  const flatFields = (formState?.sections ?? []).flatMap((sec) => sec.fields);

  return (
    <>
      <div
        className={`fixed inset-0 z-[400] bg-black/40 backdrop-blur-[2px] transition-opacity ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[401] flex h-full w-[520px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {response && (
          <>
            <div className="flex items-center gap-3 border-b border-border px-5 py-4">
              <div>
                <div className="text-[0.95rem] font-bold text-ink">Beneficiary Record</div>
                <div className="mt-px text-[11.5px] text-muted">Submitted {fmtDateTime(response.submittedAt)}</div>
              </div>
              <button
                onClick={onClose}
                className="ml-auto flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-md text-muted transition-colors hover:bg-bg hover:text-ink"
              >
                <CloseIcon />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5">
              <div className="overflow-hidden rounded-[10px] border border-border bg-surface">
                {flatFields.length === 0 ? (
                  <p className="px-3.5 py-3 text-[13px] text-muted">No questions were configured on this Indicator Form.</p>
                ) : (
                  flatFields.map((f) => {
                    const raw = response.responses[f.id] ?? "";
                    // Checkbox answers are stored "||"-joined (see
                    // AddRecordSlideOver.tsx's DynamicField) — shown
                    // comma-separated here for readability.
                    const value = f.type === "checkbox" && raw ? raw.split("||").join(", ") : raw;
                    return <DetailRow key={f.id} label={f.label} value={value} />;
                  })
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
              <button
                onClick={onClose}
                className="flex h-9 items-center rounded-lg border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 hover:border-border-strong"
              >
                Close
              </button>
            </div>
          </>
        )}
      </div>
    </>
  );
}
