"use client";

import { useState } from "react";
import { RichTextEditor } from "@/components/ui/RichTextEditor";

// Bullet/numbered lists render fine from RichTextEditor's own
// execCommand("insertUnorderedList"/"insertOrderedList") output, but need
// explicit list-style CSS wherever that HTML is displayed outside an
// editor — Tailwind's preflight strips default UL/OL markers. Exported so
// WbsTable.tsx's own read-only Remarks cell preview renders saved HTML
// identically instead of redefining this.
export const RICH_TEXT_DISPLAY_CLS = "[&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5";

// Caps the active editor's growth and scrolls internally past that —
// targets RichTextEditor's own inner contentEditable div (its last child)
// without touching the shared component itself, so every other
// RichTextEditor caller (DocEditor.tsx, AgendaNotesEditor.tsx,
// CsrPolicyEditor.tsx) keeps growing unbounded exactly as before. The
// toolbar (first child) is unaffected and never overflows horizontally.
const RICH_TEXT_CAPPED_HEIGHT_CLS =
  "[&>div>div:last-child]:max-h-[240px] [&>div>div:last-child]:overflow-y-auto [&>div>div:last-child]:overflow-x-hidden";

// Exported for WbsTable.tsx's read-only Remarks cell (empty vs. has-content
// decides whether to show "—" or the formatted preview).
export function isEmptyHtml(html: string): boolean {
  return !html || html.replace(/<br\s*\/?>/gi, "").trim() === "";
}

// Jira-style "click to activate" Remarks field, used by TaskFormSlideOver.tsx
// for both Add Task and Edit Task. Starts as a plain, lightweight box (no
// toolbar); clicking it swaps in the full RichTextEditor (toolbar +
// contentEditable, same component DocEditor.tsx/AgendaNotesEditor.tsx/
// CsrPolicyEditor.tsx already use), with the caret placed immediately.
// There is no separate Remarks overlay for the Add/Edit Task form — Remarks
// always saves with the rest of the Task on Save, exactly like every other
// field. (The WBS table itself no longer edits Remarks at all — the whole
// table is read-only now; any cell click opens Edit Task instead.)
//
// Once activated it stays expanded for the rest of this component's
// lifetime — no auto-collapse-on-blur, which would risk yanking the
// toolbar away mid-edit (e.g. while clicking a formatting button) for no
// real benefit here.
export function WbsRemarksField({
  value,
  onChange,
  placeholder = "Add remarks...",
  readOnly = false,
  minHeight = 140,
}: {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  readOnly?: boolean;
  minHeight?: number;
}) {
  const [active, setActive] = useState(false);
  const empty = isEmptyHtml(value);

  if (readOnly) {
    return empty ? (
      <span className="block rounded-sm border border-border bg-bg px-3 py-2 text-sm text-muted-2">—</span>
    ) : (
      <div
        className={`rounded-sm border border-border bg-bg px-3 py-2 text-sm text-ink ${RICH_TEXT_DISPLAY_CLS}`}
        dangerouslySetInnerHTML={{ __html: value }}
      />
    );
  }

  if (!active) {
    return (
      <button
        type="button"
        onClick={() => setActive(true)}
        className="block max-h-24 w-full overflow-hidden rounded-sm border border-border bg-bg px-3 py-2 text-left text-sm outline-none hover:border-border-strong focus-visible:border-primary"
      >
        {empty ? (
          <span className="text-muted-2">{placeholder}</span>
        ) : (
          <div className={`line-clamp-3 text-ink ${RICH_TEXT_DISPLAY_CLS}`} dangerouslySetInnerHTML={{ __html: value }} />
        )}
      </button>
    );
  }

  return (
    <div className={RICH_TEXT_CAPPED_HEIGHT_CLS}>
      <RichTextEditor
        value={value}
        onChange={onChange}
        placeholder="Enter your remarks here..."
        minHeight={minHeight}
        autoFocus
      />
    </div>
  );
}
