"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";

function FormIcon() {
  return (
    <svg fill="none" height="22" width="22" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
      <rect height="18" rx="2" ry="2" width="18" x="3" y="3" />
      <line x1="3" x2="21" y1="9" y2="9" />
      <line x1="9" x2="9" y1="21" y2="9" />
    </svg>
  );
}

// Workplace → Beneficiary Indicators → "Share Form" — a public link into
// the SAME Indicator Form configured for this project (see
// getOrCreateIndicatorFormShareLink in projectStore.ts, called by the
// caller BEFORE opening this modal — a mutating store call has no business
// running during this component's render) so a respondent can submit a
// beneficiary record without logging into the app at all. The link resolves
// at /beneficiary-form/[token] (a public route — see AppShell.tsx's
// PUBLIC_PREFIXES). `token` is null when the project has no Indicator Form
// yet (or the current user has no edit access to it) — this reuses the
// exact same empty-state copy as Add Record's own no-form state instead of
// a second message.
export function ShareIndicatorFormModal({
  token,
  open,
  onClose,
}: {
  token: string | null;
  open: boolean;
  onClose: () => void;
}) {
  const [copied, setCopied] = useState(false);

  const link = token && typeof window !== "undefined" ? `${window.location.origin}/beneficiary-form/${token}` : "";

  function handleClose() {
    setCopied(false);
    onClose();
  }

  async function handleCopy() {
    if (!link) return;
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(link);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch {
      // best-effort, same as PartnerOrgsTable's copyInviteLink
    }
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title="Share Beneficiary Indicator Form"
      icon={
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[9px] bg-primary-50 text-primary">
          <FormIcon />
        </span>
      }
      footer={<Button variant="ghost" onClick={handleClose}>Close</Button>}
    >
      {token ? (
        <>
          <p className="mb-3">Share this form using the link below.</p>
          <div className="flex items-center gap-2 rounded-md border border-border bg-bg px-3 py-2.5">
            <span className="min-w-0 flex-1 truncate font-mono text-xs text-ink">{link}</span>
            <button
              type="button"
              onClick={handleCopy}
              className="shrink-0 rounded-md border border-border bg-surface px-2.5 py-1 text-xs font-semibold text-ink-2 hover:border-border-strong"
            >
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
          <p className="mt-3 text-xs text-muted">Anyone with this link can submit the beneficiary form.</p>
        </>
      ) : (
        <p className="max-w-[320px] text-sm font-semibold text-ink">
          Please create a indicator form to capture beneficiary details.
        </p>
      )}
    </Modal>
  );
}
