﻿"use client";

import { useProjectStore } from "@/store/projectStore";
import { FormField, FormFieldType } from "@/types/project";

// Matches the type <select> in gfFieldHTML() exactly (order + wording),
// bImpact_MeetingSplit_v10.html:5744-5761
const TYPE_LABEL: Record<FormFieldType, string> = {
  text: "Short Text",
  para: "Paragraph",
  number: "Number",
  email: "Email",
  phone: "Phone Number",
  date: "Date",
  time: "Time",
  radio: "Multiple Choice",
  checkbox: "Checkboxes",
  dropdown: "Dropdown",
  yesno: "Yes / No",
  rating: "Star Rating",
  scale: "Linear Scale",
  currency: "Currency / Amount",
  url: "Website / URL",
  address: "Full Address",
  signature: "Signature",
  file: "File Upload",
};

const HAS_OPTIONS: FormFieldType[] = ["radio", "checkbox", "dropdown"];

function DateIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}

function TimeIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}

// Matches gfAnswerHTML() exactly, bImpact_MeetingSplit_v10.html:5789-5840
function AnswerPreview({ field }: { field: FormField }) {
  switch (field.type) {
    case "text":
      return <input type="text" disabled placeholder="Short answer text" className="h-8 w-full border-0 border-b border-border bg-transparent text-[13px] text-muted-2 outline-none" />;
    case "para":
      return <textarea disabled placeholder="Long answer text" className="h-12 w-full resize-none border-0 border-b border-border bg-transparent text-[13px] text-muted-2 outline-none" />;
    case "number":
      return <input type="text" disabled placeholder="Number" className="h-8 w-full border-0 border-b border-border bg-transparent text-[13px] text-muted-2 outline-none" />;
    case "email":
      return <input type="text" disabled placeholder="name@example.com" className="h-8 w-full border-0 border-b border-border bg-transparent text-[13px] text-muted-2 outline-none" />;
    case "phone":
      return <input type="text" disabled placeholder="+91 98765 43210" className="h-8 w-full border-0 border-b border-border bg-transparent text-[13px] text-muted-2 outline-none" />;
    case "url":
      return <input type="text" disabled placeholder="https://example.com" className="h-8 w-full border-0 border-b border-border bg-transparent text-[13px] text-muted-2 outline-none" />;
    case "date":
      return (
        <div className="flex items-center gap-2 border-b border-border pb-1 text-[13px] text-ink-2">
          <DateIcon />
          <span className="text-muted-2">DD / MM / YYYY</span>
        </div>
      );
    case "time":
      return (
        <div className="flex items-center gap-2 border-b border-border pb-1 text-[13px] text-ink-2">
          <TimeIcon />
          <span className="text-muted-2">HH : MM</span>
        </div>
      );
    case "currency":
      return (
        <div className="flex items-center">
          <span className="flex h-8 items-center rounded-l-md border-[1.5px] border-r-0 border-border bg-surface-2 px-2.5 text-[13px] font-bold text-muted">₹</span>
          <input type="text" disabled placeholder="0.00" className="h-8 flex-1 rounded-r-md border-[1.5px] border-border bg-bg px-2.5 font-mono text-[13px] text-muted-2 outline-none" />
        </div>
      );
    case "address":
      return <textarea disabled placeholder={"House No., Street, Village/Ward\nCity, District, State, PIN"} className="h-12 w-full resize-none border-0 border-b border-border bg-transparent text-[13px] text-muted-2 outline-none" />;
    case "yesno":
      return (
        <div className="mt-1.5 flex gap-2.5">
          <label className="flex items-center gap-2 rounded-lg border-[1.5px] border-border bg-surface px-[18px] py-2 text-[13px] font-semibold text-ink-2">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--color-secondary)" strokeWidth="2.5">
              <polyline points="20 6 9 17 4 12" />
            </svg>
            Yes
          </label>
          <label className="flex items-center gap-2 rounded-lg border-[1.5px] border-border bg-surface px-[18px] py-2 text-[13px] font-semibold text-ink-2">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--color-danger)" strokeWidth="2.5">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
            No
          </label>
        </div>
      );
    case "rating":
      return (
        <div>
          <div className="mt-1.5 flex gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <svg
                key={i}
                width="26"
                height="26"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#d1d5db"
                strokeWidth="1.5"
                className="cursor-pointer transition-colors hover:fill-amber hover:stroke-amber"
              >
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
            ))}
          </div>
          <div className="mt-1 text-[11.5px] text-muted">Tap to rate</div>
        </div>
      );
    case "scale": {
      const min = field.min ?? 1;
      const max = field.max ?? 5;
      const nums = Array.from({ length: max - min + 1 }, (_, i) => min + i);
      return (
        <div>
          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            {nums.map((n) => (
              <div key={n} className="flex h-9 w-9 items-center justify-center rounded-full border-[1.5px] border-border text-[13px] font-semibold text-ink-2">
                {n}
              </div>
            ))}
          </div>
          <div className="mt-1 flex justify-between text-[11px] text-muted" style={{ maxWidth: 48 * nums.length + 8 * (nums.length - 1) }}>
            <span>Low</span>
            <span>High</span>
          </div>
        </div>
      );
    }
    case "signature":
      return (
        <div className="mt-2 rounded-lg border-[1.5px] border-dashed border-border bg-[#fafafa] p-5 text-center">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-muted)" strokeWidth="1.5" className="mx-auto mb-1.5">
            <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z" />
            <path d="M20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" />
          </svg>
          <div className="text-[12.5px] text-muted">Sign here</div>
          <div className="mt-0.5 text-[11px] text-muted-2">Draw your signature in the app</div>
        </div>
      );
    case "file":
      return (
        <div className="flex items-center gap-2 rounded-lg border-[1.5px] border-dashed border-border bg-bg px-3.5 py-2.5 text-[13px] text-muted">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          Click to upload file
        </div>
      );
    case "dropdown": {
      const opts = field.options?.length ? field.options : ["Option 1", "Option 2"];
      return (
        <select disabled className="h-9 w-full rounded-md border-[1.5px] border-border bg-bg px-2.5 text-[13px] text-ink-2 outline-none">
          <option value="" disabled>
            Select an optionâ€¦
          </option>
          {opts.map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
      );
    }
    case "radio":
    case "checkbox": {
      const opts = field.options?.length ? field.options : ["Option 1", "Option 2"];
      return (
        <>
          {opts.map((o, i) => (
            <div key={i} className="mb-1.5 flex items-center gap-2.5 text-[13px] text-ink-2">
              <input type={field.type === "checkbox" ? "checkbox" : "radio"} disabled className="h-[15px] w-[15px] accent-primary" />
              <span>{o}</span>
            </div>
          ))}
        </>
      );
    }
    default:
      return null;
  }
}

export function GfFieldCard({
  projectId,
  sectionId,
  field,
  active,
  readOnly,
  onActivate,
}: {
  projectId: string;
  sectionId: string;
  field: FormField;
  active: boolean;
  // Preview-only viewer per the Indicator Form's ownership permission (see
  // canEditProjectResource in permissions.ts) — content stays fully visible
  // (label/description/options/answer preview all still render), only the
  // mutating controls below are gated on this.
  readOnly: boolean;
  onActivate: () => void;
}) {
  const updateField = useProjectStore((s) => s.updateField);
  const duplicateField = useProjectStore((s) => s.duplicateField);
  const removeField = useProjectStore((s) => s.removeField);
  const changeFieldType = useProjectStore((s) => s.changeFieldType);

  const isChoice = HAS_OPTIONS.includes(field.type);

  function updateOption(index: number, value: string) {
    const options = [...(field.options ?? [])];
    options[index] = value;
    updateField(projectId, sectionId, field.id, { options });
  }

  function addOption() {
    updateField(projectId, sectionId, field.id, { options: [...(field.options ?? []), `Option ${(field.options?.length ?? 0) + 1}`] });
  }

  function removeOption(index: number) {
    updateField(projectId, sectionId, field.id, { options: (field.options ?? []).filter((_, i) => i !== index) });
  }

  return (
    <div
      onClick={onActivate}
      className={`relative border-b border-border bg-surface px-5 py-3.5 transition-colors last:border-b-0 ${
        active ? "cursor-default border-l-[3px] border-l-primary pl-[17px] shadow-[inset_3px_0_0_0_var(--color-primary)]" : "cursor-pointer hover:bg-surface-2"
      }`}
    >
      <div className="flex items-start gap-2.5">
        <input
          value={field.label}
          onChange={(e) => updateField(projectId, sectionId, field.id, { label: e.target.value })}
          onClick={(e) => e.stopPropagation()}
          placeholder="Question"
          disabled={readOnly}
          className="flex-1 border-0 border-b-[1.5px] border-border bg-transparent pb-1 text-sm font-medium text-ink outline-none focus:border-primary disabled:text-muted"
        />
        {field.required && <span className="text-sm text-danger">*</span>}
        {active && !readOnly && (
          <select
            value={field.type}
            onClick={(e) => e.stopPropagation()}
            onChange={(e) => changeFieldType(projectId, sectionId, field.id, e.target.value as FormFieldType)}
            className="h-8 min-w-[130px] rounded-md border-[1.5px] border-border bg-bg px-2 text-xs font-semibold text-ink-2 outline-none focus:border-primary"
          >
            {Object.entries(TYPE_LABEL).map(([type, label]) => (
              <option key={type} value={type}>
                {label}
              </option>
            ))}
          </select>
        )}
      </div>

      {active && (
        <input
          value={field.description ?? ""}
          onChange={(e) => updateField(projectId, sectionId, field.id, { description: e.target.value })}
          onClick={(e) => e.stopPropagation()}
          placeholder="Description or help text (optional)"
          disabled={readOnly}
          className="mt-1.5 w-full border-0 border-b border-transparent bg-transparent pb-0.5 text-[12.5px] text-muted outline-none focus:border-border-strong disabled:text-muted-2"
        />
      )}

      {/* When active on a choice type, the options editor replaces the answer preview
          (matching gfActivateField: answer is hidden, opts editor shown). A
          read-only viewer still gets this same options list (per "form
          structure should be visible"), just with the inputs disabled and
          the add/remove controls gone. */}
      {active && isChoice ? (
        <div className="mt-3" onClick={(e) => e.stopPropagation()}>
          {(field.options ?? []).map((opt, i) => (
            <div key={i} className="mb-1.5 flex items-center gap-2">
              {field.type === "checkbox" ? (
                <span className="h-3.5 w-3.5 shrink-0 rounded-[3px] border-2 border-border-strong" />
              ) : (
                <span className="h-4 w-4 shrink-0 rounded-full border-2 border-border-strong" />
              )}
              <input
                value={opt}
                onChange={(e) => updateOption(i, e.target.value)}
                placeholder="Option"
                disabled={readOnly}
                className="flex-1 border-0 border-b border-transparent bg-transparent pb-0.5 text-[13px] text-ink-2 outline-none focus:border-primary disabled:text-muted"
              />
              {!readOnly && (
                <button onClick={() => removeOption(i)} title="Remove option" className="rounded p-0.5 text-muted hover:text-danger">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="18" y1="6" x2="6" y2="18" />
                    <line x1="6" y1="6" x2="18" y2="18" />
                  </svg>
                </button>
              )}
            </div>
          ))}
          {!readOnly && (
            <button onClick={addOption} className="mt-0.5 flex items-center gap-1.5 text-[12.5px] font-semibold text-primary hover:opacity-75">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
              Add option
            </button>
          )}
        </div>
      ) : (
        <div className="mt-2.5">
          <AnswerPreview field={field} />
        </div>
      )}

      {active && !readOnly && (
        <div className="mt-3 flex items-center justify-end gap-3 border-t border-border pt-3" onClick={(e) => e.stopPropagation()}>
          <button onClick={() => duplicateField(projectId, sectionId, field.id)} title="Duplicate" className="flex items-center gap-1.5 rounded px-1.5 py-1 text-xs font-semibold text-muted hover:bg-bg hover:text-ink">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="9" y="9" width="13" height="13" rx="2" />
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
            </svg>
            Duplicate
          </button>
          <div className="h-5 w-px bg-border" />
          <button onClick={() => removeField(projectId, sectionId, field.id)} title="Delete" className="flex items-center gap-1.5 rounded px-1.5 py-1 text-xs font-semibold text-muted hover:bg-danger-50 hover:text-danger">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 6h18" />
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
              <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
            </svg>
            Delete
          </button>
          <div className="flex-1" />
          <label
            onClick={(e) => {
              e.stopPropagation();
              updateField(projectId, sectionId, field.id, { required: !field.required });
            }}
            className="flex cursor-pointer select-none items-center gap-1.5 text-xs font-semibold text-ink-2"
          >
            Required
            <span className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${field.required ? "bg-primary" : "bg-border"}`}>
              <span
                className={`absolute top-[3px] h-3.5 w-3.5 rounded-full bg-white shadow transition-transform ${
                  field.required ? "translate-x-4" : "translate-x-[3px]"
                }`}
              />
            </span>
          </label>
        </div>
      )}
    </div>
  );
}
