"use client";

import { ChangeEvent, useRef, useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useSessionStore } from "@/store/sessionStore";
import { canEditProjectResource } from "@/lib/permissions";
import { processUploadedFile } from "@/lib/docUpload";
import { Dropdown, DropdownItem } from "@/components/ui/Dropdown";
import { CreateDocumentModal } from "./CreateDocumentModal";
import { PlusIcon, UploadIcon, DocEmptyIcon } from "./DocEditorIcons";

export function DocSidebar({ projectId }: { projectId: string }) {
  const doc = useProjectStore((s) => s.docs[projectId]);
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));
  const documentMode = useProjectStore((s) => s.documentOwnership[projectId] ?? null);
  const createDoc = useProjectStore((s) => s.createDoc);
  const uploadDoc = useProjectStore((s) => s.uploadDoc);
  const deleteDoc = useProjectStore((s) => s.deleteDoc);
  const saveDoc = useProjectStore((s) => s.saveDoc);
  const role = useSessionStore((s) => s.role);
  // Single source of truth for "who may create/edit this project's
  // Documents" — same canEditProjectResource() matrix WBS/Indicator Form
  // use, keyed off documentOwnership (see DocumentOwnershipStrip.tsx's
  // picker, which writes it). Viewing an existing document is never gated —
  // only the mutating actions below (Create/Upload/Rename/Delete) are.
  const canEdit = canEditProjectResource(documentMode, role);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [renaming, setRenaming] = useState(false);
  const [titleDraft, setTitleDraft] = useState("");
  const [uploading, setUploading] = useState(false);
  const [creating, setCreating] = useState(false);

  // "Create Document" now opens the section-picker modal (replicates the
  // reference mockup's pd-custom-newdoc-modal flow) instead of instantly
  // creating a blank doc — the existing "this will replace it" confirm still
  // gates opening it, matching today's single-document-per-project rule.
  function handleNewDocClick() {
    if (doc && !confirm("This project already has a document. Creating a new one will replace it. Continue?")) {
      return;
    }
    setCreating(true);
  }

  function handleGenerated({ title, contentHtml }: { title: string; contentHtml: string }) {
    createDoc(projectId, title);
    saveDoc(projectId, { contentHtml });
  }

  async function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (doc && !confirm("This project already has a document. Uploading a new one will replace it. Continue?")) {
      return;
    }
    setUploading(true);
    try {
      const payload = await processUploadedFile(file);
      uploadDoc(projectId, payload);
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="flex w-[236px] shrink-0 flex-col overflow-hidden border-l border-border bg-surface">
      <div className="flex shrink-0 items-center justify-between border-b border-border px-3.5 pb-3 pt-[13px]">
        <span className="text-[11px] font-bold uppercase tracking-wide text-muted">Documents</span>
      </div>

      <div className="flex flex-1 flex-col gap-0.5 overflow-y-auto overflow-x-hidden p-2">
        {doc ? (
          <div className="group relative flex items-center gap-2.5 rounded-[7px] bg-primary-50 px-2.5 py-2.5">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-[5px] border border-primary-100 bg-primary-50 text-primary">
              <DocEmptyIcon />
            </div>
            {renaming ? (
              <input
                autoFocus
                value={titleDraft}
                onChange={(e) => setTitleDraft(e.target.value)}
                onBlur={() => {
                  saveDoc(projectId, { title: titleDraft || doc.title });
                  setRenaming(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") e.currentTarget.blur();
                }}
                className="w-full min-w-0 flex-1 rounded-sm border border-border px-1 py-0.5 text-[13px] outline-none focus:border-primary"
              />
            ) : (
              <span className="min-w-0 flex-1 truncate text-[13px] font-semibold text-primary-700">
                {doc.title}
              </span>
            )}
            {canEdit && (
              <Dropdown
                trigger={
                  <button className="flex h-5 w-5 items-center justify-center rounded text-muted opacity-0 hover:bg-bg hover:text-ink group-hover:opacity-100">
                    ⋮
                  </button>
                }
              >
                <DropdownItem
                  onClick={() => {
                    setTitleDraft(doc.title);
                    setRenaming(true);
                  }}
                >
                  Rename
                </DropdownItem>
                <DropdownItem danger onClick={() => deleteDoc(projectId)}>
                  Delete
                </DropdownItem>
              </Dropdown>
            )}
          </div>
        ) : (
          <p className="px-1.5 py-3 text-xs leading-relaxed text-muted">
            {!documentMode
              ? "No document yet. Select who creates documents above to get started."
              : canEdit
                ? "No document yet. Each project holds a single document."
                : "No document yet. Waiting for the owning side to create one."}
          </p>
        )}
      </div>

      {/* Read-only viewers never get the create/upload/manage controls —
          same "hide, and also enforce at the data layer" pattern as
          WBS/Indicator Form (see canEditProjectResource guards on
          createDoc/uploadDoc/saveDoc/deleteDoc in projectStore.ts). */}
      {canEdit ? (
        <div className="flex shrink-0 flex-col gap-1.5 border-t border-border bg-surface p-2">
          <button
            onClick={handleNewDocClick}
            className="flex h-8 w-full items-center gap-1.5 rounded-[7px] border-[1.5px] border-primary bg-primary px-2.5 text-left text-[12.5px] font-semibold text-white transition-colors hover:bg-primary-600"
          >
            <PlusIcon />
            Create Document
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="flex h-8 w-full items-center gap-1.5 rounded-[7px] border-[1.5px] border-border bg-surface px-2.5 text-left text-[12.5px] font-semibold text-ink-2 transition-colors hover:border-primary-100 hover:bg-primary-50 hover:text-primary disabled:opacity-60"
          >
            <UploadIcon />
            {uploading ? "Uploading…" : "Upload Document"}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".docx,.pdf,.doc"
            className="hidden"
            onChange={handleFileChange}
          />
        </div>
      ) : (
        <div className="shrink-0 border-t border-border bg-surface p-2.5 text-center text-[11.5px] font-semibold text-muted">
          View only
        </div>
      )}

      {project && canEdit && (
        <CreateDocumentModal
          open={creating}
          onClose={() => setCreating(false)}
          project={project}
          onGenerate={handleGenerated}
        />
      )}
    </div>
  );
}
