"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

function DetailsIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" x2="12" y1="8" y2="12" />
      <line x1="12" x2="12.01" y1="16" y2="16" />
    </svg>
  );
}

function WbsIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="18" rx="2" ry="2" width="18" x="3" y="3" />
      <line x1="3" x2="21" y1="9" y2="9" />
      <line x1="9" x2="9" y1="21" y2="9" />
    </svg>
  );
}

function IndicatorsIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
    </svg>
  );
}

export function WorkspaceTabs({ projectId }: { projectId: string }) {
  const pathname = usePathname();
  const tabs = [
    { href: `/projects/${projectId}/details`, label: "Project Details", icon: <DetailsIcon /> },
    { href: `/projects/${projectId}/wbs`, label: "Work Breakdown Structure", icon: <WbsIcon /> },
    { href: `/projects/${projectId}/indicators`, label: "Beneficiary Indicators", icon: <IndicatorsIcon /> },
  ];

  return (
    <div className="mt-4 flex gap-0 rounded-t-lg border border-b-0 border-border bg-surface-2 px-1.5">
      {tabs.map((tab) => {
        const active = pathname === tab.href;
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className={`group -mb-px inline-flex items-center gap-1.5 whitespace-nowrap border-b-[3px] px-[18px] py-[11px] text-sm font-semibold transition-colors ${
              active
                ? "border-primary bg-surface text-primary [&_svg]:opacity-100"
                : "border-transparent text-muted hover:text-ink-2 [&_svg]:opacity-50 hover:[&_svg]:opacity-70"
            }`}
          >
            {tab.icon}
            {tab.label}
          </Link>
        );
      })}
    </div>
  );
}
