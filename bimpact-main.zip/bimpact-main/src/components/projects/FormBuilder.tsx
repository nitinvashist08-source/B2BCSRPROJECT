"use client";

import { useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { FormFieldType } from "@/types/project";
import { GfFieldCard } from "./GfFieldCard";
import { GfFieldTypeSidebar, NEW_FIELD_LABEL } from "./GfFieldTypeSidebar";

const HAS_OPTIONS: FormFieldType[] = ["radio", "checkbox", "dropdown"];
const DEVICE_WIDTH = { desktop: 780, tablet: 700, mobile: 390 };

function DesktopIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="14" rx="2" width="20" x="2" y="3" />
      <line x1="8" x2="16" y1="21" y2="21" />
      <line x1="12" x2="12" y1="17" y2="21" />
    </svg>
  );
}
function TabletIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="20" rx="2" width="16" x="4" y="2" />
      <line x1="12" x2="12.01" y1="18" y2="18" />
    </svg>
  );
}
function MobileIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="20" rx="2" width="14" x="5" y="2" />
      <line x1="12" x2="12.01" y1="18" y2="18" />
    </svg>
  );
}

export function FormBuilder({
  projectId,
  readOnly,
  locked,
  onActivate,
}: {
  projectId: string;
  // Ownership-based preview-only permission (see canEditProjectResource in
  // permissions.ts) — distinct from `locked` below, which is the
  // pre-existing "Activate & Save" finalization state (read-only for
  // everyone, including the owner, once set). Either one alone is enough to
  // fall back to preview.
  readOnly: boolean;
  locked: boolean;
  onActivate: () => void;
}) {
  const formState = useProjectStore((s) => s.indicatorForms[projectId]);
  const addField = useProjectStore((s) => s.addField);
  const updateIndicatorFormMeta = useProjectStore((s) => s.updateIndicatorFormMeta);
  const [device, setDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [mode, setMode] = useState<"edit" | "preview">("edit");
  const [activeFieldId, setActiveFieldId] = useState<string | null>(null);

  const title = formState?.title ?? "";
  const description = formState?.description ?? "";
  const sections = formState?.sections ?? [];
  const noEdit = locked || readOnly;
  const effectiveMode = noEdit ? "preview" : mode;

  // gfRenderForm flattens every section's fields into ONE card with no
  // section headers (bImpact_MeetingSplit_v10.html:5702-5727: "single flat
  // card, no sections") — sections still exist in the data model (and drive
  // the View Form summary), they just aren't shown as dividers in the canvas.
  const flatFields = sections.flatMap((sec) => sec.fields.map((field) => ({ sectionId: sec.id, field })));

  function handleAdd(type: FormFieldType) {
    const defaultOptions = HAS_OPTIONS.includes(type) ? ["Option 1", "Option 2", "Option 3"] : undefined;
    const newField = { type, label: NEW_FIELD_LABEL[type], required: false, options: defaultOptions };

    // gfSidebarAdd: insert after the active field if one is active, else
    // append to the last section (bImpact_MeetingSplit_v10.html:6037-6062).
    const activeEntry = activeFieldId ? flatFields.find((e) => e.field.id === activeFieldId) : undefined;
    if (activeEntry) {
      addField(projectId, activeEntry.sectionId, newField, activeFieldId ?? undefined);
      return;
    }
    const lastSection = sections[sections.length - 1];
    if (lastSection) addField(projectId, lastSection.id, newField);
  }

  return (
    <div className="flex flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b border-border bg-surface px-4 py-2.5">
        <input
          value={title}
          onChange={(e) => updateIndicatorFormMeta(projectId, { title: e.target.value })}
          disabled={noEdit}
          className="min-w-[120px] flex-1 border-0 border-b-2 border-transparent bg-transparent pb-0.5 text-[0.9rem] font-bold text-ink outline-none focus:border-primary disabled:text-muted"
        />
        <div className="h-[18px] w-px shrink-0 bg-border" />
        <div className="flex shrink-0 gap-0.5 rounded-lg border border-border bg-bg p-[3px]">
          {(
            [
              { key: "desktop", Icon: DesktopIcon, label: "Desktop" },
              { key: "tablet", Icon: TabletIcon, label: "Tablet" },
              { key: "mobile", Icon: MobileIcon, label: "Mobile" },
            ] as const
          ).map(({ key, Icon, label }) => (
            <button
              key={key}
              onClick={() => setDevice(key)}
              className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-[11.5px] font-semibold transition-colors ${
                device === key ? "bg-surface text-ink shadow-sm" : "text-muted"
              }`}
            >
              <Icon />
              {label}
            </button>
          ))}
        </div>
        {!noEdit && (
          <div className="flex shrink-0 gap-0.5 rounded-lg border border-border bg-bg p-[3px]">
            {(["edit", "preview"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`rounded-md px-3 py-1 text-xs font-semibold capitalize transition-colors ${
                  mode === m ? "border border-border-strong bg-surface-2 text-ink" : "border border-transparent text-muted"
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        )}
        {!noEdit && effectiveMode === "edit" && (
          <div className="hidden text-xs text-muted md:block">ⓘ Click any field to edit</div>
        )}
        {!noEdit ? (
          <button
            onClick={onActivate}
            className="ml-auto flex h-8 shrink-0 items-center gap-1.5 rounded-lg px-3.5 text-[12.5px] font-bold text-white shadow-[0_2px_8px_rgba(91,33,182,0.25)] transition-shadow hover:shadow-[0_4px_14px_rgba(91,33,182,0.4)]"
            style={{ background: "linear-gradient(135deg, #5b21b6, #1d4ed8)" }}
          >
            ✓ Activate &amp; Save
          </button>
        ) : (
          <span className="ml-auto text-xs font-semibold text-secondary-600">
            {locked ? "Locked — read-only preview" : "View only — you don't have edit access"}
          </span>
        )}
      </div>

      <div className="flex items-start">
        <div className="min-w-0 flex-1 bg-[#f0f2f5] px-5 pb-12 pt-5">
          <div className="mx-auto transition-[max-width] duration-200" style={{ maxWidth: DEVICE_WIDTH[device] }}>
            <div className="mb-2.5 overflow-hidden rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.08)]">
              <div className="h-2.5" style={{ background: "linear-gradient(90deg, var(--color-primary), #7c3aed, var(--color-secondary))" }} />
              <div className="rounded-b-xl border border-t-0 border-border bg-surface px-6 pb-5 pt-[22px]">
                <input
                  value={title}
                  onChange={(e) => updateIndicatorFormMeta(projectId, { title: e.target.value })}
                  disabled={noEdit}
                  className="w-full border-0 border-b-[1.5px] border-transparent bg-transparent pb-1 text-2xl font-bold text-ink outline-none focus:border-primary disabled:text-muted"
                />
                <textarea
                  value={description}
                  onChange={(e) => updateIndicatorFormMeta(projectId, { description: e.target.value })}
                  disabled={noEdit}
                  placeholder="Form description…"
                  className="mt-2 h-[22px] w-full resize-none border-0 border-b border-transparent bg-transparent pb-0.5 text-[13px] text-muted outline-none focus:border-border-strong disabled:text-muted-2"
                />
              </div>
            </div>

            <div className="overflow-hidden rounded-xl border border-border bg-surface shadow-[0_1px_2px_rgba(0,0,0,0.05)]">
              {flatFields.map(({ sectionId, field }) => (
                <GfFieldCard
                  key={field.id}
                  projectId={projectId}
                  sectionId={sectionId}
                  field={field}
                  active={effectiveMode === "edit" && activeFieldId === field.id}
                  readOnly={noEdit}
                  onActivate={() => effectiveMode === "edit" && setActiveFieldId(field.id)}
                />
              ))}
            </div>
          </div>
        </div>

        {effectiveMode === "edit" && <GfFieldTypeSidebar onAdd={handleAdd} />}
      </div>
    </div>
  );
}
