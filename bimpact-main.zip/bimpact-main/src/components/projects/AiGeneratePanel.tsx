"use client";

import { useState } from "react";
import { CloseIcon, SparkleIcon } from "./DocEditorIcons";

const SUGGESTIONS = [
  "Executive summary",
  "Project objectives",
  "Impact assessment",
  "Stakeholder analysis",
  "Budget narrative",
  "Risk register",
  "Theory of change",
  "Monitoring plan",
];

const CANNED_CONTENT: Record<string, string> = {
  "Executive summary":
    "<h3>Executive Summary</h3><p>This project addresses a critical development gap identified through community consultations and baseline assessments conducted in the target region.</p>",
  "Project objectives":
    "<h3>Project Objectives</h3><ul><li>Improve access to essential services for the target beneficiary group.</li><li>Build sustainable local capacity to continue program activities beyond the funding period.</li><li>Establish measurable indicators to track impact over the project lifecycle.</li></ul>",
  "Impact assessment":
    "<h3>Impact Assessment</h3><p>By the end of the project period, the initiative is expected to directly benefit the target population, with improvements tracked against the baseline indicators.</p>",
  "Stakeholder analysis":
    "<h3>Stakeholder Analysis</h3><p>Key stakeholders include the implementing partner, local government bodies, beneficiary communities, and the funding sponsor, each engaged through a structured communication plan.</p>",
  "Budget narrative":
    "<h3>Budget Narrative</h3><p>The proposed budget allocates resources across program delivery, monitoring and evaluation, and administrative overhead, in line with the sponsor's funding guidelines.</p>",
  "Risk register":
    "<h3>Risk Register</h3><p>Key risks include delays in partner onboarding, seasonal accessibility constraints, and fluctuations in local material costs. Mitigation plans are outlined for each.</p>",
  "Theory of change":
    "<h3>Theory of Change</h3><p>If target beneficiaries receive consistent access to program services, then measurable improvements in the target outcome area will follow, contributing to long-term community resilience.</p>",
  "Monitoring plan":
    "<h3>Monitoring Plan</h3><p>Progress will be tracked through monthly field visits, a structured indicator dashboard, and quarterly reviews with the implementing partner and sponsor.</p>",
};

function generateFromPrompt(prompt: string): string {
  const trimmed = prompt.trim();
  const match = SUGGESTIONS.find((s) => trimmed.toLowerCase().includes(s.toLowerCase()));
  if (match) return CANNED_CONTENT[match];
  return `<p>${trimmed || "New section"}</p><p>This is a demo AI assistant — it inserts sample content rather than calling a real AI model.</p>`;
}

export function AiGeneratePanel({
  open,
  onClose,
  onInsert,
}: {
  open: boolean;
  onClose: () => void;
  onInsert: (html: string) => void;
}) {
  const [prompt, setPrompt] = useState("");

  if (!open) return null;

  function generate() {
    onInsert(generateFromPrompt(prompt));
    setPrompt("");
    onClose();
  }

  return (
    <div className="absolute bottom-7 left-1/2 z-[200] flex w-4/5 max-w-[640px] -translate-x-1/2 flex-col overflow-hidden rounded-[14px] border border-purple-500/20 bg-surface shadow-[0_-4px_8px_rgba(0,0,0,0.04),0_12px_40px_rgba(91,33,182,0.16),0_4px_16px_rgba(0,0,0,0.1)]">
      <div className="flex items-center gap-3 px-5 py-3" style={{ background: "linear-gradient(135deg, #5b21b6, #2563eb)" }}>
        <div className="flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-[7px] bg-white/15">
          <SparkleIcon size={15} stroke="white" />
        </div>
        <div>
          <div className="text-[0.9rem] font-bold text-white">Generate with AI</div>
          <div className="mt-px text-[11px] text-white/[0.72]">Describe what you want — content is inserted at cursor position</div>
        </div>
        <button
          onClick={onClose}
          className="ml-auto flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-white/15 text-white hover:bg-white/25"
        >
          <CloseIcon size={13} />
        </button>
      </div>

      <div className="px-5 py-4">
        <label className="mb-[7px] block text-[11px] font-bold uppercase tracking-wide text-muted">
          What do you want to write?
        </label>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => {
            if (e.ctrlKey && e.key === "Enter") generate();
          }}
          placeholder="e.g. Write an executive summary for a rural literacy CSR project in Bihar and Jharkhand…"
          className="h-[72px] w-full resize-none rounded-lg border-[1.5px] border-border bg-bg px-3 py-[9px] text-[13px] leading-relaxed text-ink outline-none transition-colors focus:border-purple-500 focus:shadow-[0_0_0_3px_rgba(124,58,237,0.1)]"
        />
        <div className="mt-[9px] flex flex-wrap gap-[5px]">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => setPrompt(s)}
              className="rounded-full border-[1.5px] border-border bg-surface px-2.5 py-[3px] text-[11.5px] font-medium text-ink-2 transition-colors hover:border-purple-500 hover:bg-purple-500/5 hover:text-purple-700"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-2 border-t border-border bg-surface-2 px-5 py-[11px]">
        <span className="mr-auto text-[11.5px] text-muted">Ctrl+Enter to generate</span>
        <button
          onClick={generate}
          className="flex h-9 items-center gap-[7px] rounded-lg px-[18px] text-[13px] font-bold text-white shadow-[0_2px_10px_rgba(91,33,182,0.28)] transition-opacity hover:opacity-90"
          style={{ background: "linear-gradient(135deg, #5b21b6, #2563eb)" }}
        >
          <SparkleIcon size={12} stroke="white" />
          Generate
        </button>
      </div>
    </div>
  );
}
