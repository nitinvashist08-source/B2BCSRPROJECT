"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { ProjectStatus } from "@/types/project";
import { ProjectStatusBadge } from "./ProjectStatusBadge";
import { CreateProjectSlideOver } from "./CreateProjectSlideOver";
import { Button } from "@/components/ui/Button";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";

const FILTER_TABS: (ProjectStatus | "All")[] = ["All", "Planning", "Execution", "Closing"];

function PlusIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}

function FunnelIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
    </svg>
  );
}

function MapPinIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  );
}

function CalendarIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="18" rx="2" width="18" x="3" y="4" />
      <line x1="16" x2="16" y1="2" y2="6" />
      <line x1="8" x2="8" y1="2" y2="6" />
      <line x1="3" x2="21" y1="10" y2="10" />
    </svg>
  );
}

function SortIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="4" x2="4" y1="21" y2="14" />
      <line x1="4" x2="4" y1="10" y2="3" />
      <line x1="12" x2="12" y1="21" y2="12" />
      <line x1="12" x2="12" y1="8" y2="3" />
      <line x1="20" x2="20" y1="21" y2="16" />
      <line x1="20" x2="20" y1="12" y2="3" />
      <line x1="1" x2="7" y1="14" y2="14" />
      <line x1="9" x2="15" y1="8" y2="8" />
      <line x1="17" x2="23" y1="16" y2="16" />
    </svg>
  );
}

function ChevronRightIcon() {
  return (
    <svg
      fill="none"
      height="14"
      width="14"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2.5"
      viewBox="0 0 24 24"
      className="transition-transform duration-200 ease-out group-hover:translate-x-1"
    >
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </svg>
  );
}

export function ProjectsTable() {
  const projects = useProjectStore((s) => s.projects);
  const projectStates = useSettingsStore((s) => s.projectStates);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const partners = useSettingsStore((s) => s.partners);
  const router = useRouter();
  const [tab, setTab] = useState<ProjectStatus | "All">("All");
  const [createOpen, setCreateOpen] = useState(false);

  // Partners only ever see projects assigned to their own org (sponsor role,
  // and the unauthenticated/null edge case which shouldn't normally reach
  // this route, remain unrestricted — exactly as before).
  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const visibleProjects =
    role === "partner"
      ? projects.filter((p) => isProjectAssignedToPartner(p, projectPartners, partnerName))
      : projects;

  // Onboarding-review status, surfaced to the partner themselves since the
  // onboarding wizard itself is off-limits to change — see
  // ApprovePartnerDialog/RequestChangesModal/RejectPartnerModal, which set
  // this via the Sponsor's review decision.
  const ownPartner = role === "partner" ? partners.find((p) => p.id === partnerOrgId) : undefined;
  const reviewBanner = ownPartner && ownPartner.reviewStatus && ownPartner.reviewStatus !== "Approved"
    ? ownPartner.reviewStatus === "Pending Review"
      ? {
          tone: "info" as const,
          text: (
            <>
              To complete your onboarding process, please{" "}
              <button
                type="button"
                onClick={() => router.push("/compliance")}
                className="font-semibold underline underline-offset-2 hover:text-primary-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 rounded-sm"
              >
                click here
              </button>
              .
            </>
          ),
        }
      : ownPartner.reviewStatus === "Changes Requested"
        ? {
            tone: "warning" as const,
            text: (
              <>
                Your Sponsor has requested changes: {ownPartner.changeRequestMessage ?? ""}, go to Compliance to
                upload the remaining document or{" "}
                <button
                  type="button"
                  onClick={() => router.push("/compliance")}
                  className="font-semibold underline underline-offset-2 hover:text-amber-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-sm"
                >
                  click here
                </button>
                .
              </>
            ),
          }
        : { tone: "danger" as const, text: `Your onboarding submission was rejected: ${ownPartner.rejectionReason ?? ""}` }
    : null;

  const filtered = visibleProjects.filter((p) => tab === "All" || p.status === tab);
  const tabCount = (t: ProjectStatus | "All") =>
    t === "All" ? visibleProjects.length : visibleProjects.filter((p) => p.status === t).length;

  return (
    <div>
      {reviewBanner && (
        <div
          className={`mb-4 rounded-lg border px-4 py-3 text-[13px] leading-relaxed ${
            reviewBanner.tone === "info"
              ? "border-primary-100 bg-primary-50 text-primary-700"
              : reviewBanner.tone === "warning"
                ? "border-amber-100 bg-amber-50 text-amber-600"
                : "border-danger-50 bg-danger-50 text-danger"
          }`}
        >
          {reviewBanner.text}
        </div>
      )}
      <div className="mb-6 flex items-end justify-between gap-6">
        <div>
          <h1 className="mb-1 text-[22px] font-bold tracking-tight text-ink">Workplace</h1>
          <p className="text-[13.5px] text-muted">
            All projects you&apos;re executing, with live progress and sponsor approvals.
          </p>
        </div>
        {role !== "partner" && (
          <Button onClick={() => setCreateOpen(true)} className="shrink-0">
            <PlusIcon />
            Create Project
          </Button>
        )}
      </div>

      <div className="flex items-center gap-2.5 rounded-t-lg border border-b-0 border-border bg-surface p-2.5">
        <div className="flex gap-0.5 rounded-lg bg-bg p-[3px]">
          {FILTER_TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-md px-3 py-1.5 text-[12.5px] font-semibold ${
                tab === t ? "bg-surface text-ink shadow-sm" : "text-muted"
              }`}
            >
              {t} <span className="font-medium text-muted-2">{tabCount(t)}</span>
            </button>
          ))}
        </div>
        <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-[12.5px] font-medium text-ink-2 hover:border-border-strong">
          <FunnelIcon />
          Sponsor <span className="text-muted-2">·</span> All
        </button>
        <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-[12.5px] font-medium text-ink-2 hover:border-border-strong">
          <MapPinIcon />
          Region
        </button>
        <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-[12.5px] font-medium text-ink-2 hover:border-border-strong">
          <CalendarIcon />
          Timeframe
        </button>
        <div className="ml-auto flex items-center gap-2">
          <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-2.5 py-1.5 text-[12.5px] font-medium text-ink-2 hover:border-border-strong">
            <SortIcon />
            Sort
          </button>
        </div>
      </div>

      <div className="overflow-hidden rounded-b-lg border border-border bg-surface">
        <table className="w-full border-collapse text-[var(--fs-body)]">
          <thead>
            <tr>
              <th className="whitespace-nowrap bg-surface-2 py-[var(--pad-cell)] px-[var(--pad-cell)] text-left text-[11.5px] font-semibold uppercase tracking-wide text-muted" style={{ width: "28%" }}>
                Project Name &amp; ID
              </th>
              <th className="whitespace-nowrap bg-surface-2 py-[var(--pad-cell)] px-[var(--pad-cell)] text-left text-[11.5px] font-semibold uppercase tracking-wide text-muted" style={{ width: "20%" }}>
                Location
              </th>
              <th className="whitespace-nowrap bg-surface-2 py-[var(--pad-cell)] px-[var(--pad-cell)] text-left text-[11.5px] font-semibold uppercase tracking-wide text-muted" style={{ width: "25%" }}>
                Assigned Partner
              </th>
              <th className="whitespace-nowrap bg-surface-2 py-[var(--pad-cell)] px-[var(--pad-cell)] text-left text-[11.5px] font-semibold uppercase tracking-wide text-muted" style={{ width: "15%" }}>
                Stage
              </th>
              <th className="whitespace-nowrap bg-surface-2 py-[var(--pad-cell)] px-[var(--pad-cell)] text-right text-[11.5px] font-semibold uppercase tracking-wide text-muted" style={{ width: "12%" }}>
                Action
              </th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) => (
              <tr
                key={p.id}
                onClick={() => router.push(`/projects/${p.id}`)}
                className="group cursor-pointer border-b border-border transition-colors last:border-0 hover:bg-surface-2"
              >
                <td className="py-[var(--pad-cell)] px-[var(--pad-cell)] align-middle">
                  <div className="flex min-w-[280px] items-center gap-3">
                    <div className="h-[38px] w-[38px] shrink-0 rounded-lg bg-primary-50" />
                    <div>
                      <div className="font-semibold text-ink">{p.name}</div>
                      <div className="text-[11.5px] tabular-nums text-muted">{p.code}</div>
                    </div>
                  </div>
                </td>
                <td className="py-[var(--pad-cell)] px-[var(--pad-cell)] align-middle text-[0.875rem] text-ink-2">
                  {(() => {
                    const states = projectStates[p.id];
                    const primaryLocation = states?.[0] ?? p.location;
                    return primaryLocation || "—";
                  })()}
                </td>
                <td className="py-[var(--pad-cell)] px-[var(--pad-cell)] align-middle">
                  {(() => {
                    // Always render assigned partners as tags — one consistent
                    // chip style whether the project has multiple partners
                    // (projectPartners side-table) or just the single legacy
                    // `partner` field, instead of the latter falling back to
                    // plain bold text.
                    const names = projectPartners[p.id]?.length ? projectPartners[p.id] : p.partner ? [p.partner] : [];
                    if (names.length === 0) return "—";
                    return (
                      <div className="flex flex-wrap gap-1">
                        {names.map((name) => (
                          <span
                            key={name}
                            className="rounded-[5px] border border-secondary-100 bg-secondary-50 px-2 py-0.5 text-[11.5px] font-semibold text-secondary-600"
                          >
                            {name}
                          </span>
                        ))}
                      </div>
                    );
                  })()}
                </td>
                <td className="py-[var(--pad-cell)] px-[var(--pad-cell)] align-middle">
                  <ProjectStatusBadge status={p.status} />
                </td>
                <td className="overflow-visible py-[var(--pad-cell)] px-[var(--pad-cell)] text-right align-middle">
                  <div className="pointer-events-none inline-flex items-center justify-end gap-1 whitespace-nowrap text-[13px] font-semibold text-primary opacity-80 transition-all duration-200 group-hover:opacity-100 group-hover:underline">
                    Open Project
                    <ChevronRightIcon />
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-sm text-muted">
                  No projects in this filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {filtered.length < visibleProjects.length && (
        <div className="mt-4 text-center text-[12.5px] text-muted">
          Showing {filtered.length} of {visibleProjects.length}
        </div>
      )}

      {/* Not just gated by never being opened — skip mounting it entirely for
          the partner role, per spec: no project-creation entry point at all. */}
      {role !== "partner" && <CreateProjectSlideOver open={createOpen} onClose={() => setCreateOpen(false)} />}
    </div>
  );
}
