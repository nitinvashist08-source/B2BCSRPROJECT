"use client";

import { BeneficiaryRecord, BeneficiaryStatus } from "@/types/project";

const BI_ST_LBL: Record<BeneficiaryStatus, string> = {
  enrolled: "Enrolled",
  "at-risk": "At Risk",
  dropout: "Dropout",
  completed: "Completed",
};

const STATUS_STYLE: Record<BeneficiaryStatus, string> = {
  enrolled: "bg-[rgba(0,166,81,0.08)] text-[#00853a]",
  "at-risk": "bg-[rgba(245,158,11,0.09)] text-[#b45309]",
  dropout: "bg-[rgba(239,68,68,0.08)] text-[#b91c1c]",
  completed: "bg-primary-50 text-primary-700",
};

function CloseIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}

// biDR, bImpact_MeetingSplit_v10.html:6229-6231
function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-[130px_1fr] border-b border-border last:border-b-0">
      <div className="bg-surface-2 px-3.5 py-2.5 text-xs font-semibold text-muted">{label}</div>
      <div className="px-3.5 py-2.5 text-[13px] text-ink">{value || "—"}</div>
    </div>
  );
}

function DetailSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-5 overflow-hidden rounded-[10px] border border-border bg-surface">
      <div className="border-b border-border bg-surface-2 px-3.5 py-[9px] text-[10.5px] font-bold uppercase tracking-wide text-muted">
        {title}
      </div>
      {children}
    </div>
  );
}

// Matches biOpenDetail (:6193-6227): dedicated 5-section read-only detail
// view, not a reuse of the Add Record form.
export function BiDetailSlideOver({ record, onClose }: { record: BeneficiaryRecord | null; onClose: () => void }) {
  const open = !!record;
  const r = record;

  return (
    <>
      <div
        className={`fixed inset-0 z-[400] bg-black/40 backdrop-blur-[2px] transition-opacity ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[401] flex h-full w-[560px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {r && (
          <>
            <div className="flex items-center gap-3 border-b border-border px-5 py-4">
              <span
                className="flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-full text-xl font-bold text-white"
                style={{
                  background:
                    r.gender === "Female" ? "linear-gradient(135deg, #ec4899, #be185d)" : "linear-gradient(135deg, var(--color-primary), #0565a0)",
                }}
              >
                {r.name ? r.name.charAt(0).toUpperCase() : "?"}
              </span>
              <div>
                <div className="text-[0.95rem] font-bold text-ink">{r.name}</div>
                <div className="mt-px text-[11.5px] text-muted">
                  {r.program} · {r.district}, {r.state}
                </div>
              </div>
              <span
                className={`ml-auto mr-2 inline-flex items-center gap-1.5 rounded-full px-[9px] py-[3px] text-[11.5px] font-semibold ${STATUS_STYLE[r.status]}`}
              >
                <span className="h-1.5 w-1.5 rounded-full bg-current" />
                {BI_ST_LBL[r.status] || r.status}
              </span>
              <button
                onClick={onClose}
                className="flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-md text-muted transition-colors hover:bg-bg hover:text-ink"
              >
                <CloseIcon />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5">
              <DetailSection title="Identity">
                <DetailRow label="Full Name" value={r.name} />
                <DetailRow label="Gender" value={r.gender} />
                <DetailRow label="Age" value={`${r.age} years`} />
                <DetailRow label="Social Category" value={r.cat} />
              </DetailSection>
              <DetailSection title="Location">
                <DetailRow label="Village / Ward" value={r.village} />
                <DetailRow label="District" value={r.district} />
                <DetailRow label="State" value={r.state} />
              </DetailSection>
              <DetailSection title="Program Enrollment">
                <DetailRow label="Program" value={r.program} />
                <DetailRow label="Enrollment Date" value={r.date} />
                <DetailRow label="Status" value={BI_ST_LBL[r.status] || r.status} />
              </DetailSection>
              <DetailSection title="Guardian">
                <DetailRow label="Guardian Name" value={r.guardian} />
                <DetailRow label="Contact" value={r.contact} />
              </DetailSection>
              <DetailSection title="Field Officer">
                <DetailRow label="Officer Name" value={r.officer} />
              </DetailSection>
            </div>

            <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
              <button
                onClick={onClose}
                className="flex h-9 items-center rounded-lg border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 hover:border-border-strong"
              >
                Close
              </button>
            </div>
          </>
        )}
      </div>
    </>
  );
}
