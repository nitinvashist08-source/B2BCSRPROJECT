"use client";

import { useState } from "react";
import { Project } from "@/types/project";
import { Button } from "@/components/ui/Button";
import { SparkleIcon } from "./DocEditorIcons";

function fmtINR(n: number) {
  return n.toLocaleString("en-IN");
}

// Canonical section list for the "Create Document" flow — mirrors the
// reference mockup's #pd-headings-list checkbox set exactly (bImpact_
// MeetingSplit_v10.html, pd-custom-newdoc-modal). `key` is the FULL heading
// text used as the generated <h2>, matching the mockup's checkbox `value`
// attributes; `label` is the shorter text shown on the picker card.
const SECTIONS: { key: string; label: string }[] = [
  { key: "Project Summary", label: "Project Summary" },
  { key: "Problem Statement & Needs Assessment", label: "Problem Statement" },
  { key: "Project Objectives & Outcomes", label: "Objectives & Outcomes" },
  { key: "Timeline & Implementation Plan", label: "Implementation Plan" },
  { key: "Budget & Resource Allocation", label: "Budget Allocation" },
  { key: "Monitoring & Evaluation Framework", label: "M&E Framework" },
  { key: "Target Beneficiaries & Geography", label: "Target Beneficiaries" },
  { key: "Sustainability & Exit Strategy", label: "Exit Strategy" },
];

// Draft-with-AI content per section, grounded in the ACTUAL open project's
// own fields (name/partner/location/description/budget) — unlike the
// mockup, which hardcodes one demo project's numbers/names into every
// section, this never invents project information that isn't already in
// the app.
function draftSectionContent(sectionKey: string, project: Project): string {
  const { name, partner, location, budget } = project;
  // Trim any trailing punctuation so it never collides with the sentence
  // punctuation this template adds after it (avoids a double "..").
  const description = project.description.trim().replace(/[.!?]+$/, "");
  switch (sectionKey) {
    case "Project Summary":
      return `<p><strong>${name}</strong> is implemented by ${partner} in ${location}${
        description ? `, focused on ${description.toLowerCase()}` : ""
      }.</p>`;
    case "Problem Statement & Needs Assessment":
      return `<p>Baseline consultations in ${location} identified the gap this project is designed to address, forming the basis for ${name}'s scope and design.</p>`;
    case "Project Objectives & Outcomes":
      return (
        `<ul>` +
        `<li>Deliver measurable outcomes aligned with ${name}'s core objectives.</li>` +
        `<li>Build local capacity in ${location} to sustain results beyond the funding period.</li>` +
        `<li>Track progress against clear indicators across the project lifecycle.</li>` +
        `</ul>`
      );
    case "Timeline & Implementation Plan":
      return (
        `<p><strong>Phase 1:</strong> Baseline assessment and mobilisation.<br/>` +
        `<strong>Phase 2:</strong> Core activity rollout in ${location}.<br/>` +
        `<strong>Phase 3:</strong> Consolidation and mid-term review.</p>`
      );
    case "Budget & Resource Allocation":
      return `<p>The estimated budget for ${name} is ₹ ${fmtINR(budget)}, allocated across program delivery, monitoring &amp; evaluation, and administrative overhead, in coordination with ${partner}.</p>`;
    case "Monitoring & Evaluation Framework":
      return `<p>Progress on ${name} will be tracked through a structured indicator dashboard, periodic field visits, and joint reviews between the sponsor and ${partner}.</p>`;
    case "Target Beneficiaries & Geography":
      return `<p>The primary beneficiaries are communities in ${location}, reached through ${partner}'s local presence and delivery network.</p>`;
    case "Sustainability & Exit Strategy":
      return `<p>Post-implementation, local stakeholders and ${partner} will take ownership of continued activities, supported by a structured handover and sustainability plan.</p>`;
    default:
      return "<p><br/></p>";
  }
}

// Blank starting content for a manually-drafted section — matches the
// mockup's own blank-lines fallback when "Draft with AI" is off.
const BLANK_SECTION_CONTENT = "<p><br/></p><p><br/></p><p><br/></p>";

function buildDocumentContent(sectionKeys: string[], useAI: boolean, project: Project): string {
  return sectionKeys
    .map((key) => {
      const body = useAI ? draftSectionContent(key, project) : BLANK_SECTION_CONTENT;
      // Each section renders as its own distinct card ("one section per
      // page") inside the existing rich-text body — sized to the editor's
      // own content width rather than a fixed print-page size, so it never
      // overflows the surrounding paper.
      return (
        `<div class="doc-generated-section" style="background:#fff;border:1px solid var(--border,#e5e5e5);border-radius:8px;` +
        `box-shadow:0 1px 3px rgba(0,0,0,0.05);padding:28px 32px;margin:0 0 20px;">` +
        `<h2>${key}</h2>${body}</div>`
      );
    })
    .join("");
}

function ChevronToggle({ checked }: { checked: boolean }) {
  return (
    <span
      className={`relative inline-flex h-7 w-[46px] shrink-0 items-center rounded-full transition-colors ${
        checked ? "bg-gradient-to-r from-[#9333ea] to-[#d946ef]" : "bg-[#e9d5ff]"
      }`}
    >
      <span
        className={`inline-block h-[22px] w-[22px] transform rounded-full bg-white shadow transition-transform ${
          checked ? "translate-x-[21px]" : "translate-x-[3px]"
        }`}
      />
    </span>
  );
}

// Replicates the reference mockup's #pd-custom-newdoc-modal flow: pick
// which sections to include (one card per section, "one section per page"),
// optionally toggle "Draft with AI Assistant" to pre-fill each chosen
// section with drafted content instead of a blank starting point, then
// Generate Document assembles it all into a single new document for this
// project. See src/components/projects/DocSidebar.tsx for where this is
// wired into the existing single-document-per-project Create Document flow
// (no document-model changes needed — this only builds the initial title/
// contentHtml handed to the existing createDoc/saveDoc actions).
export function CreateDocumentModal({
  open,
  onClose,
  project,
  onGenerate,
}: {
  open: boolean;
  onClose: () => void;
  project: Project;
  onGenerate: (input: { title: string; contentHtml: string }) => void;
}) {
  const [checked, setChecked] = useState<Record<string, boolean>>({});
  const [useAI, setUseAI] = useState(false);
  const [sectionsError, setSectionsError] = useState(false);

  if (!open) return null;

  function reset() {
    setChecked({});
    setUseAI(false);
    setSectionsError(false);
  }
  function handleClose() {
    reset();
    onClose();
  }
  function toggleSection(key: string) {
    setChecked((c) => ({ ...c, [key]: !c[key] }));
    setSectionsError(false);
  }

  function handleGenerate() {
    const selected = SECTIONS.filter((s) => checked[s.key]).map((s) => s.key);
    if (selected.length === 0) {
      setSectionsError(true);
      return;
    }
    onGenerate({ title: project.name, contentHtml: buildDocumentContent(selected, useAI, project) });
    reset();
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center bg-ink/40 backdrop-blur-[1px]"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
    >
      <div className="flex max-h-[90vh] w-[600px] max-w-[90%] flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-lg">
        <div className="flex items-center justify-between border-b border-border bg-surface-2 px-8 py-5">
          <h3 className="text-lg font-semibold text-ink">{project.name}</h3>
          <button
            onClick={handleClose}
            className="rounded p-1 text-xl leading-none text-muted hover:bg-surface"
            aria-label="Close"
          >
            ×
          </button>
        </div>

        <div className="flex flex-col gap-6 overflow-y-auto px-8 py-6">
          <div>
            <label className="mb-2 block text-sm font-semibold text-ink">
              Include Sections <span className="font-normal text-muted">(One section per page)</span>
            </label>
            <div className="grid grid-cols-2 gap-3">
              {SECTIONS.map((s) => {
                const isChecked = !!checked[s.key];
                return (
                  <label
                    key={s.key}
                    className={`flex cursor-pointer items-start gap-2.5 rounded-lg border p-3 text-sm transition-colors ${
                      isChecked ? "border-primary bg-primary-50" : "border-border hover:bg-surface-2"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggleSection(s.key)}
                      className="mt-0.5 h-4 w-4 shrink-0 accent-primary"
                    />
                    <span className="font-medium leading-snug text-ink">{s.label}</span>
                  </label>
                );
              })}
            </div>
            {sectionsError && (
              <span className="mt-2 block text-xs text-danger">
                Please select at least one section to include in the document.
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={() => setUseAI((v) => !v)}
            className="flex items-start gap-4 rounded-xl border border-[#d8b4fe] bg-gradient-to-br from-[#f3e8ff] to-[#faf5ff] p-4 text-left shadow-sm transition-transform hover:-translate-y-px"
          >
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#9333ea] to-[#c026d3] shadow">
              <SparkleIcon size={22} stroke="white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-[1.05rem] font-bold text-[#4c1d95]">
                  Draft with AI Assistant
                  <span className="rounded-full bg-[#a855f7] px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-white">
                    Smart
                  </span>
                </span>
                <ChevronToggle checked={useAI} />
              </div>
              <p className="mt-1.5 text-[13px] leading-relaxed text-[#6b21a8]">
                Automatically generate high quality content tailored to this project.
              </p>
            </div>
          </button>
        </div>

        <div className="flex justify-end gap-3 border-t border-border bg-surface-2 px-8 py-4">
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleGenerate}>Generate Document</Button>
        </div>
      </div>
    </div>
  );
}
