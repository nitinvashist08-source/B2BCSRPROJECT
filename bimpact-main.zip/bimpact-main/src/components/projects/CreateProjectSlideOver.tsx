"use client";

import { useRef, useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useAlertStore } from "@/store/alertStore";
import { ALL_STATES, districtsFor } from "@/lib/geography";
import { isPartnerEligibleForAssignment } from "@/lib/partnerEligibility";
import { SlideOver } from "@/components/ui/SlideOver";
import { Button } from "@/components/ui/Button";
import { MultiSelect } from "@/components/ui/MultiSelect";
import { useClickOutside } from "@/hooks/useClickOutside";

function nextProjectCode(existing: number): string {
  const year = new Date().getFullYear();
  return `PRJ-${year}-${String(existing + 1).padStart(3, "0")}`;
}

function SearchIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="11" cy="11" r="8" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  );
}
function ChevronIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" className="shrink-0 text-muted">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

// New Workplace-level "Create Project" flow: one form capturing name, a
// single implementing partner, and location (one state + multiple
// districts) in a single step — unlike Settings > Activity's separate
// name-only Create + Assign flow, which is untouched by this feature.
// Partner/state/district assignments write to the same side-tables
// (projectPartners/projectStates/projectDistricts in settingsStore) that
// Activity's Assign Project flow already reads and writes, so a project's
// assignments stay consistent no matter which flow created or edited them
// (projectPartners itself stays an array for that reason, even though this
// form only ever writes at most one entry into it).
export function CreateProjectSlideOver({ open, onClose }: { open: boolean; onClose: () => void }) {
  const projects = useProjectStore((s) => s.projects);
  const addProject = useProjectStore((s) => s.addProject);
  const partners = useSettingsStore((s) => s.partners);
  const setProjectPartners = useSettingsStore((s) => s.setProjectPartners);
  const setProjectStates = useSettingsStore((s) => s.setProjectStates);
  const setProjectDistricts = useSettingsStore((s) => s.setProjectDistricts);

  const [name, setName] = useState("");
  const [nameError, setNameError] = useState(false);
  const [partnerOpen, setPartnerOpen] = useState(false);
  const [partnerSearch, setPartnerSearch] = useState("");
  const [selectedPartnerId, setSelectedPartnerId] = useState("");
  const [partnerError, setPartnerError] = useState(false);
  const [state, setState] = useState("");
  const [stateError, setStateError] = useState(false);
  const [districts, setDistricts] = useState<string[]>([]);
  const [districtError, setDistrictError] = useState(false);

  const partnerRef = useRef<HTMLDivElement>(null);
  useClickOutside(partnerRef, () => setPartnerOpen(false), partnerOpen);

  const selectedPartner = partners.find((p) => p.id === selectedPartnerId) ?? null;
  // Only Active/Approved partners are selectable at all — a partner still
  // Pending Review, Changes Requested, or Rejected cannot be picked here.
  const eligiblePartners = partners.filter(isPartnerEligibleForAssignment);
  const filteredPartners = eligiblePartners.filter((p) =>
    p.name.toLowerCase().includes(partnerSearch.trim().toLowerCase())
  );
  const availableDistricts = districtsFor(state);

  function reset() {
    setName("");
    setNameError(false);
    setPartnerOpen(false);
    setPartnerSearch("");
    setSelectedPartnerId("");
    setPartnerError(false);
    setState("");
    setStateError(false);
    setDistricts([]);
    setDistrictError(false);
  }
  function handleClose() {
    reset();
    onClose();
  }

  function selectPartner(id: string) {
    setSelectedPartnerId(id);
    setPartnerError(false);
    setPartnerOpen(false);
    setPartnerSearch("");
  }
  function handleStateChange(next: string) {
    setState(next);
    setStateError(false);
    setDistricts([]); // changing State clears Districts from the previous State
    setDistrictError(false);
  }
  function handleDistrictsChange(next: string[]) {
    setDistricts(next);
    setDistrictError(false);
  }

  function handleCreate() {
    const nameBad = !name.trim();
    // Re-verify eligibility here too (not just via the dropdown filter
    // above) — defense in depth against selectedPartnerId being set to an
    // ineligible partner through direct state manipulation rather than the
    // filtered dropdown UI.
    const partnerBad = !selectedPartner || !isPartnerEligibleForAssignment(selectedPartner);
    const stateBad = !state;
    const districtBad = districts.length === 0;

    setNameError(nameBad);
    setPartnerError(partnerBad);
    setStateError(stateBad);
    setDistrictError(districtBad);

    if (nameBad || partnerBad || stateBad || districtBad) return;

    const id = addProject({
      code: nextProjectCode(projects.length),
      name: name.trim(),
      location: state,
      partner: selectedPartner?.name ?? "",
      status: "Planning",
      budget: 0,
      startDate: "",
      endDate: "",
      description: "",
    });
    if (selectedPartner) {
      setProjectPartners(id, [selectedPartner.name]);
      // Event push (not derived — a new project only ever gets created
      // once, this isn't a recomputable snapshot condition). Only source of
      // "a project was assigned to a partner" in the whole app — see the
      // research this alert was built from: setProjectPartners has no other
      // caller today.
      useAlertStore.getState().pushEvent({
        key: `project_assigned_partner:project:${id}`,
        type: "project_assigned_partner",
        category: "project",
        severity: "info",
        title: "New project assigned to you",
        message: `You've been assigned to a new project: ${name.trim()}.`,
        targetPartnerOrgId: selectedPartner.id,
        entityType: "project",
        entityId: id,
        projectId: id,
        action: { label: "View Project", route: `/projects/${id}/details` },
      });
    }
    if (state) setProjectStates(id, [state]);
    if (districts.length > 0) setProjectDistricts(id, districts);

    reset();
    onClose();
  }

  return (
    <SlideOver
      open={open}
      onClose={handleClose}
      title="Create Project"
      footer={
        <>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleCreate}>Create Project</Button>
        </>
      }
    >
      <p className="mb-5 -mt-2 text-xs text-muted">
        Add a new project, assign implementing partners, and define the project location.
      </p>

      <label className="mb-5 block text-sm">
        <span className="mb-1.5 block font-medium text-ink-2">
          Project Name <span className="text-danger">*</span>
        </span>
        <input
          autoFocus
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            setNameError(false);
          }}
          placeholder="Enter project name"
          className={`w-full rounded-sm border px-3 py-2 text-sm outline-none focus:border-primary ${
            nameError ? "border-danger" : "border-border"
          }`}
        />
        {nameError && <span className="mt-1 block text-xs text-danger">Project name is required.</span>}
      </label>

      <div className="mb-5 border-t border-border pt-5">
        <span className="block text-sm font-medium text-ink-2">
          Implementing Partner <span className="text-danger">*</span>
        </span>
        <p className="mb-2.5 mt-0.5 text-xs text-muted">Select the implementing partner for this project.</p>
        <div className="relative" ref={partnerRef}>
          <button
            type="button"
            onClick={() => setPartnerOpen((o) => !o)}
            className={`flex h-9 w-full items-center justify-between gap-2 rounded-sm border bg-surface px-3 text-left text-sm outline-none focus:border-primary ${
              partnerError ? "border-danger" : "border-border"
            }`}
          >
            <span className={`truncate ${selectedPartner ? "text-ink" : "text-muted-2"}`}>
              {selectedPartner ? selectedPartner.name : "Select Implementing Partner"}
            </span>
            <ChevronIcon />
          </button>

          {partnerOpen && (
            <div className="absolute z-50 mt-1 w-full rounded-sm border border-border bg-surface shadow-md">
              <div className="flex h-8 items-center gap-2 border-b border-border px-2.5">
                <SearchIcon />
                <input
                  autoFocus
                  value={partnerSearch}
                  onChange={(e) => setPartnerSearch(e.target.value)}
                  placeholder="Search partners..."
                  className="w-full bg-transparent text-xs outline-none placeholder:text-muted"
                />
              </div>
              <div className="max-h-40 overflow-y-auto py-1">
                {filteredPartners.length === 0 ? (
                  <p className="px-3 py-3 text-center text-xs text-muted">No partners found.</p>
                ) : (
                  filteredPartners.map((p) => {
                    const checked = p.id === selectedPartnerId;
                    return (
                      <button
                        type="button"
                        key={p.id}
                        onClick={() => selectPartner(p.id)}
                        className={`flex w-full items-center px-3 py-2 text-left text-sm ${
                          checked ? "bg-primary-50 font-medium text-primary-700" : "text-ink-2 hover:bg-surface-2"
                        }`}
                      >
                        {p.name}
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>
        {partnerError && <span className="mt-1 block text-xs text-danger">Please select an implementing partner.</span>}
      </div>

      <div className="border-t border-border pt-5">
        <span className="mb-2.5 block text-sm font-medium text-ink-2">
          Location <span className="text-danger">*</span>
        </span>

        <label className="mb-4 block text-sm">
          <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">State</span>
          <select
            value={state}
            onChange={(e) => handleStateChange(e.target.value)}
            className={`w-full rounded-sm border px-3 py-2 text-sm outline-none focus:border-primary ${
              stateError ? "border-danger" : "border-border"
            }`}
          >
            <option value="">Select State</option>
            {ALL_STATES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          {stateError && <span className="mt-1 block text-xs text-danger">Please select a state.</span>}
        </label>

        <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">District</span>
        {!state ? (
          <p className="rounded-sm border border-dashed border-border bg-bg px-3 py-3 text-center text-xs text-muted">
            Select a state first to see districts.
          </p>
        ) : (
          <div className={districtError ? "rounded-sm ring-1 ring-danger" : ""}>
            <MultiSelect
              options={availableDistricts}
              value={districts}
              onChange={handleDistrictsChange}
              placeholder="Select Districts"
              openUpward
              showSelectAll
            />
          </div>
        )}
        {state && districtError && <span className="mt-1 block text-xs text-danger">Please select at least one district.</span>}
      </div>
    </SlideOver>
  );
}
