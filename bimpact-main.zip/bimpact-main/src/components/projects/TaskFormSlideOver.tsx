"use client";

import { useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useSessionStore } from "@/store/sessionStore";
import { useAlertStore } from "@/store/alertStore";
import { getPartnersByProject } from "@/lib/dashboardScope";
import { SlideOver } from "@/components/ui/SlideOver";
import { Button } from "@/components/ui/Button";
import { MultiSelect } from "@/components/ui/MultiSelect";
import { WbsFieldLabel } from "@/components/ui/InfoTooltip";
import { WbsRemarksField } from "./WbsRemarksField";
import { WbsRow } from "@/types/project";
import {
  WBS_COL,
  WBS_PRIORITY_OPTIONS,
  WBS_STATUS_OPTIONS,
  dependencyIdFromToken,
  dependencyIdsFromCell,
  dependencyToken,
  syncStatusAndCompletion,
} from "@/lib/wbsColumns";

const fieldCls = (error: boolean) =>
  `w-full rounded-sm border px-3 py-2 text-sm outline-none focus:border-primary disabled:cursor-not-allowed disabled:bg-surface-2 disabled:text-muted ${
    error ? "border-danger" : "border-border"
  }`;

// The single Task form — Add Task (task=null) and Edit Task (task=an
// existing WbsRow) both render through here, per spec ("reuse the Add Task
// form structure for Edit Task") rather than a second near-duplicate
// implementation. WbsTable.tsx opens this in "add" mode from its own
// header button, and in "edit" mode when any cell of an existing Task row
// is clicked (the table itself is read-only — see WbsTable.tsx). Field
// order/content is exact per spec: Title → Description → Assigned To →
// Start/End Date → Status → Completion % → Priority → Dependency →
// Remarks → Cancel/Save.
export function TaskFormSlideOver({
  open,
  onClose,
  projectId,
  task,
  readOnly = false,
}: {
  open: boolean;
  onClose: () => void;
  projectId: string;
  // Present = Edit Task (loads/updates this row); absent/null = Add Task.
  task?: WbsRow | null;
  // A viewer without WBS-edit permission can still open this to view an
  // existing Task's details (matches this app's established "you can
  // monitor but not edit" convention — see WbsTable.tsx's view-only
  // banners) — every field renders disabled and there is no Save action.
  readOnly?: boolean;
}) {
  const isEdit = !!task;
  const wbs = useProjectStore((s) => s.wbs[projectId]);
  const addWbsTask = useProjectStore((s) => s.addWbsTask);
  const updateWbsTask = useProjectStore((s) => s.updateWbsTask);
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));
  const role = useSessionStore((s) => s.role);
  const existingRows = wbs?.rows ?? [];

  // Cross-notify on Add Task ONLY (not Edit) — whichever side did NOT add
  // it gets told. Event-pushed here (repeatable, one per task, never
  // deduped) since "a task was just added" is a moment, not a recomputable
  // condition — same reasoning as tranche_created (ScheduleTrancheSlideOver
  // .tsx).
  function notifyOtherSideOfNewTask(taskTitle: string) {
    if (!project) return;
    const partner = getPartnersByProject(projectId)[0];
    const action = { label: "View WBS", route: `/projects/${projectId}/wbs` };
    if (role === "partner") {
      if (!partner) return;
      useAlertStore.getState().pushHistoryEvent({
        key: `wbs_task_added:project:${projectId}`,
        type: "wbs_task_added",
        category: "project",
        severity: "info",
        title: "New WBS task added",
        message: `${partner.name} added a new task "${taskTitle}" to the Work Breakdown Structure for ${project.name}.`,
        targetRole: "sponsor",
        entityType: "project",
        entityId: projectId,
        projectId,
        action,
      });
    } else {
      if (!partner) return;
      useAlertStore.getState().pushHistoryEvent({
        key: `wbs_task_added:project:${projectId}`,
        type: "wbs_task_added",
        category: "project",
        severity: "info",
        title: "New WBS task added",
        message: `Sponsor added a new task "${taskTitle}" to the Work Breakdown Structure for ${project.name}.`,
        targetPartnerOrgId: partner.id,
        entityType: "project",
        entityId: projectId,
        projectId,
        action,
      });
    }
  }

  const [title, setTitle] = useState("");
  const [titleError, setTitleError] = useState(false);
  const [description, setDescription] = useState("");
  const [descriptionError, setDescriptionError] = useState(false);
  const [assignee, setAssignee] = useState("");
  const [startDate, setStartDate] = useState("");
  const [startDateError, setStartDateError] = useState(false);
  const [endDate, setEndDate] = useState("");
  const [endDateError, setEndDateError] = useState(false);
  const [status, setStatus] = useState<string>(WBS_STATUS_OPTIONS[0]);
  const [completion, setCompletion] = useState(0);
  const [priority, setPriority] = useState<string>("Medium");
  const [dependencyIds, setDependencyIds] = useState<string[]>([]);
  const [remarks, setRemarks] = useState("");

  // Seeds every field from `task` (Edit) or blanks (Add) each time this
  // freshly opens, or the target Task changes while it's already open —
  // React's "adjust state during render" pattern (setState here runs
  // synchronously as part of this render, not in an effect), same
  // convention as this app's other "reset on (re)open" slide-overs. Only runs while
  // `open` is true, so closing never clobbers state mid-close-animation.
  const seedKey = open ? task?.id ?? "__add__" : null;
  const [seededFor, setSeededFor] = useState<string | null>(null);
  if (seedKey !== null && seedKey !== seededFor) {
    setSeededFor(seedKey);
    setTitle(task?.cells[WBS_COL.title] ?? "");
    setTitleError(false);
    setDescription(task?.cells[WBS_COL.description] ?? "");
    setDescriptionError(false);
    setAssignee(task?.cells[WBS_COL.assignee] ?? "");
    setStartDate(task?.cells[WBS_COL.start] ?? "");
    setStartDateError(false);
    setEndDate(task?.cells[WBS_COL.end] ?? "");
    setEndDateError(false);
    setStatus(task?.cells[WBS_COL.status] ?? WBS_STATUS_OPTIONS[0]);
    setCompletion(Number(task?.cells[WBS_COL.completion] ?? 0) || 0);
    setPriority(task?.cells[WBS_COL.priority] ?? "Medium");
    setDependencyIds(dependencyIdsFromCell(task?.cells[WBS_COL.dependency]));
    setRemarks(task?.cells[WBS_COL.remarks] ?? "");
  }

  // Live, independent of the required-field checks below (which only fire
  // on a submit attempt) — matches this app's existing date-order
  // validation convention (see CreateBudgetSlideOver.tsx).
  const dateOrderError =
    startDate && endDate && endDate < startDate ? "End date cannot be earlier than start date." : null;

  function handleCompletionChange(raw: string) {
    const n = Math.max(0, Math.min(100, Number(raw) || 0));
    const synced = syncStatusAndCompletion(status, n, "completion");
    setCompletion(synced.completion);
    setStatus(synced.status);
  }
  function handleStatusChange(next: string) {
    const synced = syncStatusAndCompletion(next, completion, "status");
    setStatus(synced.status);
    setCompletion(synced.completion);
  }

  function handleSubmit() {
    // Task Title, Task Description, Start Date, End Date, Status, and
    // Priority are compulsory (Status/Priority always carry a non-empty
    // default via their <select> — see the `*` on their labels below — so
    // they can never actually fail this check, only Title/Description/
    // dates can be left blank).
    const titleBad = !title.trim();
    const descriptionBad = !description.trim();
    const startDateBad = !startDate;
    const endDateBad = !endDate;
    setTitleError(titleBad);
    setDescriptionError(descriptionBad);
    setStartDateError(startDateBad);
    setEndDateError(endDateBad);
    if (titleBad || descriptionBad || startDateBad || endDateBad || dateOrderError) return;

    const payload = { title, description, assignee, startDate, endDate, status, completion, priority, dependencyIds, remarks };
    if (isEdit && task) {
      updateWbsTask(projectId, task.id, payload);
    } else {
      addWbsTask(projectId, payload);
      notifyOtherSideOfNewTask(title.trim());
    }
    onClose();
  }

  // A Task can never depend on itself (spec section 12) — excluded from
  // the choices, not just from whatever it already has selected.
  const dependencyChoices = existingRows.filter((r) => r.id !== task?.id);
  const dependencyOptions = dependencyChoices.map(dependencyToken);
  const dependencyValue = dependencyIds
    .map((id) => dependencyChoices.find((r) => r.id === id))
    .filter((r): r is NonNullable<typeof r> => !!r)
    .map(dependencyToken);

  return (
    <SlideOver
      open={open}
      onClose={onClose}
      title={isEdit ? "Edit Task" : "Add Task"}
      footer={
        readOnly ? (
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        ) : (
          <>
            <Button variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>{isEdit ? "Save Changes" : "Add Task"}</Button>
          </>
        )
      }
    >
      {isEdit && (
        <div className="mb-4 rounded-sm border border-border bg-surface-2 px-3 py-2">
          <span className="block text-[11px] font-bold uppercase tracking-wide text-muted-2">Task ID</span>
          <span className="font-mono text-sm font-semibold text-ink-2">{task.id}</span>
        </div>
      )}

      <label className="mb-4 block">
        <WbsFieldLabel label="Task Title" tooltip="Enter a clear and concise name that describes the task." required />
        <input
          autoFocus={!readOnly}
          disabled={readOnly}
          value={title}
          onChange={(e) => {
            setTitle(e.target.value);
            setTitleError(false);
          }}
          placeholder="Enter task title"
          className={fieldCls(titleError)}
        />
        {titleError && <span className="mt-1 block text-xs text-danger">Task title is required.</span>}
      </label>

      <label className="mb-4 block">
        <WbsFieldLabel
          label="Task Description"
          tooltip="Describe what needs to be done, including the key activities or expected outcome."
          required
        />
        <textarea
          rows={3}
          disabled={readOnly}
          value={description}
          onChange={(e) => {
            setDescription(e.target.value);
            setDescriptionError(false);
          }}
          placeholder="Describe the task..."
          className={`${fieldCls(descriptionError)} resize-none`}
        />
        {descriptionError && <span className="mt-1 block text-xs text-danger">Task description is required.</span>}
      </label>

      <label className="mb-4 block">
        <WbsFieldLabel label="Assigned To" tooltip="Enter the name of the person responsible for completing this task." />
        <input
          disabled={readOnly}
          value={assignee}
          onChange={(e) => setAssignee(e.target.value)}
          placeholder="Enter assignee name"
          className={fieldCls(false)}
        />
      </label>

      <div className="mb-4 flex gap-3">
        <label className="block flex-1">
          <WbsFieldLabel label="Start Date" tooltip="Select the date when work on this task is expected to begin." required />
          <input
            type="date"
            disabled={readOnly}
            value={startDate}
            onChange={(e) => {
              setStartDate(e.target.value);
              setStartDateError(false);
            }}
            className={fieldCls(startDateError)}
          />
          {startDateError && <span className="mt-1 block text-xs text-danger">Start date is required.</span>}
        </label>
        <label className="block flex-1">
          <WbsFieldLabel label="End Date" tooltip="Select the date by which this task is expected to be completed." required />
          <input
            type="date"
            disabled={readOnly}
            value={endDate}
            onChange={(e) => {
              setEndDate(e.target.value);
              setEndDateError(false);
            }}
            className={fieldCls(endDateError || !!dateOrderError)}
          />
          {endDateError && <span className="mt-1 block text-xs text-danger">End date is required.</span>}
        </label>
      </div>
      {dateOrderError && <span className="-mt-3 mb-4 block text-xs text-danger">{dateOrderError}</span>}

      <label className="mb-4 block">
        <WbsFieldLabel label="Status" tooltip="Select the current stage of progress for this task." required />
        <select
          disabled={readOnly}
          value={status}
          onChange={(e) => handleStatusChange(e.target.value)}
          className={fieldCls(false)}
        >
          {WBS_STATUS_OPTIONS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </label>

      <label className="mb-4 block">
        <WbsFieldLabel label="Completion Percentage" tooltip="Enter how much of the task has been completed, from 0% to 100%." />
        <div className="flex items-center gap-2">
          <input
            type="number"
            min={0}
            max={100}
            disabled={readOnly}
            value={completion}
            onChange={(e) => handleCompletionChange(e.target.value)}
            className={fieldCls(false)}
          />
          <span className="text-sm text-muted">%</span>
        </div>
      </label>

      <label className="mb-4 block">
        <WbsFieldLabel
          label="Priority"
          tooltip="Select the importance level that indicates how urgently this task should be completed."
          required
        />
        <select
          disabled={readOnly}
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
          className={fieldCls(false)}
        >
          {WBS_PRIORITY_OPTIONS.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </select>
      </label>

      <div className="mb-4">
        <WbsFieldLabel
          label="Dependency"
          tooltip="Select the task that must be completed or progressed before this task can proceed."
        />
        {readOnly ? (
          dependencyValue.length === 0 ? (
            <p className="rounded-sm border border-border bg-surface-2 px-3 py-2 text-sm text-muted-2">—</p>
          ) : (
            <div className="flex flex-wrap gap-1.5 rounded-sm border border-border bg-surface-2 px-3 py-2">
              {dependencyValue.map((t) => (
                <span key={t} className="rounded-full bg-surface px-2 py-0.5 text-xs text-ink-2">
                  {t}
                </span>
              ))}
            </div>
          )
        ) : dependencyOptions.length === 0 ? (
          <p className="rounded-sm border border-dashed border-border bg-bg px-3 py-2.5 text-center text-xs text-muted">
            No existing tasks to depend on yet.
          </p>
        ) : (
          <MultiSelect
            options={dependencyOptions}
            value={dependencyValue}
            onChange={(tokens) => setDependencyIds(tokens.map(dependencyIdFromToken))}
            placeholder="Select dependency"
          />
        )}
      </div>

      <div>
        <WbsFieldLabel label="Remarks" tooltip="Add any additional information, context, or notes related to this task." />
        <WbsRemarksField value={remarks} onChange={setRemarks} readOnly={readOnly} />
      </div>
    </SlideOver>
  );
}
