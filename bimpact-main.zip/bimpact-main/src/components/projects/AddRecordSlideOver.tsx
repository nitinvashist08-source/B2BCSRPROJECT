"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useProjectStore } from "@/store/projectStore";
import { FormField } from "@/types/project";
import { DynamicField, FieldGroup } from "./DynamicIndicatorField";
import { OfficerSignoffSection } from "./OfficerSignoffSection";

function CloseIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}
function FormIcon() {
  return (
    <svg fill="none" height="22" width="22" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
      <rect height="18" rx="2" ry="2" width="18" x="3" y="3" />
      <line x1="3" x2="21" y1="9" y2="9" />
      <line x1="9" x2="9" y1="21" y2="9" />
    </svg>
  );
}

// Add Record — dynamically driven by the project's Indicator Form (the
// single source of truth for which questions appear here), not a
// hard-coded beneficiary form. See IndicatorFormResponse's doc comment in
// types/project.ts for why this writes into a separate array from the
// older, fixed-shape beneficiaryRecords (still used by the existing
// Records table, untouched by this change).
export function AddRecordSlideOver({ projectId, open, onClose }: { projectId: string; open: boolean; onClose: () => void }) {
  const router = useRouter();
  const formState = useProjectStore((s) => s.indicatorForms[projectId]);
  const addIndicatorFormResponse = useProjectStore((s) => s.addIndicatorFormResponse);

  const flatFields: FormField[] = (formState?.sections ?? []).flatMap((sec) => sec.fields);

  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  // Officer Sign-off's acknowledgement — a system-generated section, not an
  // Indicator Form question, so it's tracked separately from `answers`/
  // `errors` above and never written into `responses`. See
  // OfficerSignoffSection.tsx and projectStore.ts's addIndicatorFormResponse
  // (which stamps the actual submittedBy/acknowledgement record metadata
  // from the current session at save time).
  const [acknowledged, setAcknowledged] = useState(false);
  const [ackError, setAckError] = useState<string | undefined>();

  function reset() {
    setAnswers({});
    setErrors({});
    setAcknowledged(false);
    setAckError(undefined);
  }
  function handleClose() {
    reset();
    onClose();
  }

  function handleSave() {
    if (!formState) return; // belt-and-suspenders — the button isn't even rendered in this case
    const nextErrors: Record<string, string> = {};
    flatFields.forEach((f) => {
      if (f.required && !answers[f.id]?.trim()) nextErrors[f.id] = "This field is required.";
    });
    setErrors(nextErrors);
    const nextAckError = acknowledged ? undefined : "Please acknowledge the declaration before submitting the record.";
    setAckError(nextAckError);
    if (Object.keys(nextErrors).length > 0 || nextAckError) return;
    addIndicatorFormResponse(projectId, answers);
    handleClose();
  }

  // Deep-links straight into the "Indicator Form" tab (IndicatorsView.tsx
  // reads this ?tab=form param to skip its default Records view) rather
  // than just landing on Beneficiary Indicators' records list one click
  // short of where the CTA promises to go.
  function goToIndicatorForm() {
    handleClose();
    router.push(`/projects/${projectId}/indicators?tab=form`);
  }

  return (
    <>
      <div
        className={`fixed inset-0 z-[400] bg-black/40 backdrop-blur-[2px] transition-opacity ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) handleClose();
        }}
      />
      <div
        className={`fixed right-0 top-0 z-[401] flex h-full w-[520px] max-w-full flex-col bg-surface shadow-[-8px_0_32px_rgba(0,0,0,0.14)] transition-transform duration-200 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center gap-3 border-b border-border px-5 py-4">
          <span className="flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-[9px] bg-primary-50 text-primary">
            <svg fill="none" height="16" width="16" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <line x1="19" x2="19" y1="8" y2="14" />
              <line x1="22" x2="16" y1="11" y2="11" />
            </svg>
          </span>
          <div>
            <div className="text-[0.95rem] font-bold text-ink">Add Beneficiary Record</div>
            <div className="mt-px text-[11.5px] text-muted">
              {formState ? "Fill in the details for a new beneficiary" : "This project has no Indicator Form yet"}
            </div>
          </div>
          <button
            onClick={handleClose}
            className="ml-auto flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-md text-muted transition-colors hover:bg-bg hover:text-ink"
          >
            <CloseIcon />
          </button>
        </div>

        {!formState ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center">
            <div className="flex h-[52px] w-[52px] items-center justify-center rounded-full border-2 border-dashed border-border-strong bg-bg text-muted-2">
              <FormIcon />
            </div>
            <div className="max-w-[320px] text-[0.95rem] font-bold text-ink">
              Please create a indicator form to capture beneficiary details.
            </div>
            <p className="max-w-[320px] text-[13px] leading-snug text-muted">
              Beneficiary information can&apos;t be captured until an Indicator Form is configured for this project.
            </p>
            <button
              onClick={goToIndicatorForm}
              className="mt-1 flex h-9 items-center gap-1.5 rounded-lg bg-primary px-4 text-sm font-semibold text-white shadow-[0_1px_3px_rgba(10,151,217,0.25)] hover:bg-primary-600"
            >
              Create Indicator Form
            </button>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-5">
            {flatFields.length === 0 ? (
              <p className="text-[13px] text-muted">This project&apos;s Indicator Form has no questions yet.</p>
            ) : (
              flatFields.map((f) => (
                <FieldGroup key={f.id} label={f.label} required={f.required} error={errors[f.id]}>
                  <DynamicField
                    field={f}
                    value={answers[f.id] ?? ""}
                    onChange={(v) => setAnswers((a) => ({ ...a, [f.id]: v }))}
                    invalid={!!errors[f.id]}
                  />
                </FieldGroup>
              ))
            )}

            {/* System-generated, always last — see OfficerSignoffSection.tsx.
                Rendered regardless of flatFields.length so the officer's
                identity/acknowledgement is still captured even for a form
                with zero questions configured yet. */}
            <OfficerSignoffSection acknowledged={acknowledged} onAcknowledgedChange={setAcknowledged} error={ackError} />
          </div>
        )}

        <div className="flex justify-end gap-2.5 border-t border-border bg-surface-2 px-5 py-3.5">
          <button
            onClick={handleClose}
            className="flex h-9 items-center rounded-lg border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 hover:border-border-strong"
          >
            Cancel
          </button>
          {formState && (
            <button
              onClick={handleSave}
              className="flex h-9 items-center rounded-lg bg-primary px-4 text-sm font-semibold text-white shadow-[0_1px_3px_rgba(10,151,217,0.25)] hover:bg-primary-600"
            >
              Save Record
            </button>
          )}
        </div>
      </div>
    </>
  );
}
