"use client";

import { useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { IndicatorFormResponse } from "@/types/project";
import { AddRecordSlideOver } from "./AddRecordSlideOver";
import { IndicatorResponseDetailSlideOver } from "./IndicatorResponseDetailSlideOver";
import { ShareIndicatorFormModal } from "./ShareIndicatorFormModal";

function EyeIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function FormIcon() {
  return (
    <svg fill="none" height="22" width="22" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
      <rect height="18" rx="2" ry="2" width="18" x="3" y="3" />
      <line x1="3" x2="21" y1="9" y2="9" />
      <line x1="9" x2="9" y1="21" y2="9" />
    </svg>
  );
}

function fmtDateShort(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

// Best-effort human-friendly label for a dynamic Indicator Form response —
// an Indicator Form's questions are project-defined, so there's no fixed
// "name" field to key off; the first non-empty answer is shown instead
// (usually whatever the Sponsor/Partner put first, e.g. a name-like
// question).
function responseLabel(r: IndicatorFormResponse): string {
  const firstAnswer = Object.values(r.responses).find((v) => v && v.trim());
  return firstAnswer || "Untitled response";
}

// Beneficiary data is captured entirely through the project's Indicator
// Form now (Add Record / Share Form) — there is no separate, fixed-column
// beneficiary table here any more. This intentionally no longer reads
// projectStore's `beneficiaryRecords` (that legacy fixed-shape array still
// exists for other consumers, e.g. dashboard datasets in useDatasetRows.ts —
// untouched — it's just no longer rendered as a blank data-entry table on
// this page).
export function BeneficiaryRecordsTable({ projectId }: { projectId: string }) {
  const allResponses = useProjectStore((s) => s.indicatorFormResponses);
  const responses = allResponses.filter((r) => r.projectId === projectId);
  const getOrCreateIndicatorFormShareLink = useProjectStore((s) => s.getOrCreateIndicatorFormShareLink);
  const [addOpen, setAddOpen] = useState(false);
  const [respDetailId, setRespDetailId] = useState<string | null>(null);
  const [shareOpen, setShareOpen] = useState(false);
  const [shareToken, setShareToken] = useState<string | null>(null);

  function openShare() {
    setShareToken(getOrCreateIndicatorFormShareLink(projectId));
    setShareOpen(true);
  }

  return (
    <>
      <div className="flex flex-wrap items-center gap-2.5 border-b border-border bg-surface px-5 py-3">
        <span className="text-[0.9rem] font-bold text-ink">Records</span>
        {/* Share Form — immediately left of Add Record, per spec. Available
            to Sponsor and Partner alike regardless of Indicator Form
            ownership mode — sharing the form is a separate capability from
            editing its question structure (see getOrCreateIndicatorFormShareLink). */}
        <button
          onClick={openShare}
          className="ml-auto flex h-[34px] shrink-0 items-center gap-1.5 rounded-lg border-[1.5px] border-border bg-surface px-3.5 text-sm font-semibold text-ink-2 hover:border-primary hover:bg-primary-50 hover:text-primary"
        >
          <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <circle cx="18" cy="5" r="3" />
            <circle cx="6" cy="12" r="3" />
            <circle cx="18" cy="19" r="3" />
            <line x1="8.59" x2="15.42" y1="10.51" y2="6.49" />
            <line x1="8.59" x2="15.42" y1="13.49" y2="17.51" />
          </svg>
          Share Form
        </button>
        <button
          onClick={() => setAddOpen(true)}
          className="flex h-[34px] shrink-0 items-center gap-1.5 rounded-lg bg-primary px-3.5 text-sm font-semibold text-white shadow-[0_1px_3px_rgba(10,151,217,0.25)] hover:bg-primary-600"
        >
          <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <line x1="12" x2="12" y1="5" y2="19" />
            <line x1="5" x2="19" y1="12" y2="12" />
          </svg>
          Add Record
        </button>
      </div>

      <div className="bg-bg px-5 pb-10 pt-4">
        {/* Submissions captured via the project's Indicator Form (Add
            Record / Share Form) — the Indicator Form is the single source
            of truth for what beneficiary information is collected, so
            there's no separate fixed-column table here any more. See
            IndicatorFormResponse's doc comment in types/project.ts. */}
        {responses.length === 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-[10px] border border-dashed border-border-strong bg-surface px-5 py-14 text-center">
            <div className="flex h-[52px] w-[52px] items-center justify-center rounded-full border-2 border-dashed border-border-strong bg-bg text-muted-2">
              <FormIcon />
            </div>
            <div className="text-[0.9rem] font-semibold text-ink-2">No beneficiary records yet.</div>
            <p className="max-w-[320px] text-[13px] leading-snug text-muted">
              Use <strong>Add Record</strong> or <strong>Share Form</strong> to start capturing beneficiary details
              through this project&apos;s Indicator Form.
            </p>
          </div>
        ) : (
          <div className="overflow-hidden rounded-[10px] border border-border bg-surface">
            <div className="flex items-center gap-2 border-b border-border bg-surface-2 px-4 py-2.5">
              <span className="text-[0.85rem] font-bold text-ink">Indicator Form Responses</span>
              <span className="text-xs text-muted">Captured via this project&apos;s Indicator Form</span>
            </div>
            <table className="w-full border-collapse text-[13px]">
              <tbody>
                {responses.map((r) => (
                  <tr key={r.id} className="border-t border-border first:border-t-0 hover:bg-surface-2">
                    <td className="px-4 py-3 font-medium text-ink">{responseLabel(r)}</td>
                    <td className="px-4 py-3 text-muted">{fmtDateShort(r.submittedAt)}</td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => setRespDetailId(r.id)}
                        className="inline-flex h-[26px] items-center gap-1 rounded-md border border-border bg-surface px-2.5 text-xs font-medium text-ink-2 transition-colors hover:border-primary hover:bg-primary-50 hover:text-primary"
                      >
                        <EyeIcon />
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <AddRecordSlideOver projectId={projectId} open={addOpen} onClose={() => setAddOpen(false)} />
      <ShareIndicatorFormModal token={shareToken} open={shareOpen} onClose={() => setShareOpen(false)} />
      <IndicatorResponseDetailSlideOver
        response={responses.find((r) => r.id === respDetailId) ?? null}
        onClose={() => setRespDetailId(null)}
      />
    </>
  );
}
