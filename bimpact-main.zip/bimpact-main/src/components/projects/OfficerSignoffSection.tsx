"use client";

import { useSessionStore } from "@/store/sessionStore";
import { resolveDisplayName } from "@/lib/userDisplay";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function pad2(n: number): string {
  return n.toString().padStart(2, "0");
}

// "08 Sep 2026 · 05:50 PM" — matches this app's existing 3-letter month
// convention (MeetingCard.tsx/financeData.ts's MONTHS), not a one-off format.
function formatOfficerTimestamp(d: Date): string {
  const day = pad2(d.getDate());
  const month = MONTHS[d.getMonth()];
  const year = d.getFullYear();
  let hours = d.getHours();
  const minutes = pad2(d.getMinutes());
  const ampm = hours >= 12 ? "PM" : "AM";
  hours = hours % 12 || 12;
  return `${day} ${month} ${year} · ${pad2(hours)}:${minutes} ${ampm}`;
}

function roBox(content: string) {
  // Same read-only box treatment as SignoffSection.tsx's roBox (Meetings'
  // own Closing & Sign-off card) — this app's one existing "system-filled,
  // not user-typed" field style.
  return (
    <div className="flex h-[38px] items-center rounded-lg border-[1.5px] border-border bg-surface-2 px-3 text-[13px] text-ink">
      {content || "—"}
    </div>
  );
}

function ShieldIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  );
}
function CalendarIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="18" rx="2" width="18" x="3" y="4" />
      <line x1="16" x2="16" y1="2" y2="6" />
      <line x1="8" x2="8" y1="2" y2="6" />
      <line x1="3" x2="21" y1="10" y2="10" />
    </svg>
  );
}

// Workplace → Beneficiary Indicators → Add Record's system-generated
// closing section — NOT an Indicator Form question, never configured
// through the form builder (see IndicatorFormState/FormField in
// types/project.ts, both untouched by this component). Establishes who
// submitted a beneficiary record, when, and that they acknowledged
// responsibility for it. Officer Name/Email are read-only, always the
// current session's identity (AddRecordSlideOver.tsx is only ever reached
// by a logged-in Sponsor/Partner) — the acknowledgement checkbox is the
// only interactive control here, owned by the caller (AddRecordSlideOver)
// since it gates that form's own Save action.
//
// Visual treatment mirrors SignoffSection.tsx (Meetings' Closing &
// Sign-off card: icon-badge header, 2-col read-only grid, checkbox
// declaration block) rather than inventing a new card style.
export function OfficerSignoffSection({
  acknowledged,
  onAcknowledgedChange,
  error,
}: {
  acknowledged: boolean;
  onAcknowledgedChange: (accepted: boolean) => void;
  error?: string;
}) {
  const sessionName = useSessionStore((s) => s.name);
  const sessionEmail = useSessionStore((s) => s.email);
  const officerName = resolveDisplayName(sessionName, sessionEmail);

  return (
    <div className="mt-5">
      <div className="mb-2 text-[11px] font-bold uppercase tracking-wide text-muted">
        Officer Signature &amp; Acknowledgement
      </div>

      <div className="overflow-hidden rounded-[14px] border border-border bg-surface shadow-sm">
        <div className="flex items-start gap-3 border-b border-border bg-primary-50 px-5 py-4">
          <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary-100 text-primary">
            <ShieldIcon />
          </span>
          <div>
            <div className="text-[13.5px] font-bold text-primary-700">Data Collection Officer Sign-off</div>
            <div className="mt-0.5 text-xs text-primary-600">
              Auto-filled from your account. Please verify and acknowledge before submission.
            </div>
          </div>
        </div>

        <div className="p-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wide text-muted">Officer Name</span>
              {roBox(officerName)}
            </div>
            <div>
              <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wide text-muted">Email Address</span>
              {roBox(sessionEmail ?? "")}
            </div>
          </div>

          <div className="mt-4">
            <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wide text-muted">
              Date &amp; Time of Submission
            </span>
            <div className="flex h-[38px] items-center gap-2 rounded-lg border-[1.5px] border-border bg-surface-2 px-3 text-[13px] text-ink">
              <CalendarIcon />
              {formatOfficerTimestamp(new Date())}
            </div>
          </div>

          <label
            className={`mt-4 flex items-start gap-3 rounded-[10px] border-[1.5px] px-[18px] py-4 text-[13px] ${
              error ? "border-danger bg-danger-50" : "border-primary-100 bg-primary-50"
            }`}
          >
            <input
              type="checkbox"
              checked={acknowledged}
              onChange={(e) => onAcknowledgedChange(e.target.checked)}
              className="mt-0.5 h-[18px] w-[18px] shrink-0 accent-primary"
            />
            <span className={`leading-relaxed ${error ? "text-danger" : "text-primary-700"}`}>
              I, <strong>{officerName}</strong>, confirm that the information above is accurate, the respondent data
              has been correctly and ethically acquired, and I take responsibility for this submission.
            </span>
          </label>
          {error && <p className="mt-1.5 text-xs text-danger">{error}</p>}
        </div>
      </div>
    </div>
  );
}
