"use client";

import { useRef, useState } from "react";
import { useClickOutside } from "@/hooks/useClickOutside";

const MAX_ROWS = 8;
const MAX_COLS = 8;

export function TablePicker({ onInsert }: { onInsert: (rows: number, cols: number) => void }) {
  const [open, setOpen] = useState(false);
  const [hover, setHover] = useState({ rows: 0, cols: 0 });
  const ref = useRef<HTMLDivElement>(null);
  useClickOutside(ref, () => setOpen(false), open);

  return (
    <div className="relative" ref={ref}>
      <button
        title="Insert table"
        onMouseDown={(e) => {
          e.preventDefault();
          setOpen((o) => !o);
        }}
        className={`flex h-7 w-[30px] items-center justify-center rounded-[5px] border transition-colors ${
          open ? "border-primary-100 bg-primary-50 text-primary-700" : "border-transparent text-ink-2 hover:border-border hover:bg-surface-2"
        }`}
      >
        <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <rect height="18" rx="2" ry="2" width="18" x="3" y="3" />
          <line x1="3" x2="21" y1="9" y2="9" />
          <line x1="3" x2="21" y1="15" y2="15" />
          <line x1="9" x2="9" y1="3" y2="21" />
          <line x1="15" x2="15" y1="3" y2="21" />
        </svg>
      </button>
      {open && (
        <div className="absolute left-0 top-[34px] z-[500] flex flex-col gap-[3px] rounded-lg border border-border bg-surface p-2.5 shadow-[0_8px_24px_rgba(0,0,0,0.12)]">
          <p className="mb-1 text-center text-[11px] font-medium text-muted">Insert table</p>
          <div
            className="flex flex-col gap-0.5"
            onMouseLeave={() => setHover({ rows: 0, cols: 0 })}
          >
            {Array.from({ length: MAX_ROWS }).map((_, rowIdx) => (
              <div key={rowIdx} className="flex gap-0.5">
                {Array.from({ length: MAX_COLS }).map((_, colIdx) => {
                  const row = rowIdx + 1;
                  const col = colIdx + 1;
                  const active = row <= hover.rows && col <= hover.cols;
                  return (
                    <button
                      key={colIdx}
                      onMouseEnter={() => setHover({ rows: row, cols: col })}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        onInsert(row, col);
                        setOpen(false);
                      }}
                      className={`h-[18px] w-[18px] rounded-sm border transition-colors ${
                        active ? "border-primary bg-primary-50" : "border-border bg-bg"
                      }`}
                    />
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
