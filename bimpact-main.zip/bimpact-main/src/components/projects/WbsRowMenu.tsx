"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

function MoreIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
      <circle cx="5" cy="12" r="1" />
    </svg>
  );
}

const MENU_WIDTH = 150;
const MENU_HEIGHT_ESTIMATE = 44; // Delete Task only, extensible later
const GAP = 6;

// Row-level "⋮" menu (Delete Task, extensible for future row actions) — same
// portal-to-document.body pattern as BudgetPeriodActionMenu.tsx,
// needed for the same reason (escapes the table's overflow-x-auto clip).
// Rendered inside the row's ID cell, visible on row hover (see WbsTable.tsx).
export function WbsRowMenu({ onDelete }: { onDelete: () => void }) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  function openMenu() {
    const rect = triggerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const spaceBelow = window.innerHeight - rect.bottom;
    const openUpward = spaceBelow < MENU_HEIGHT_ESTIMATE + GAP && rect.top > MENU_HEIGHT_ESTIMATE + GAP;
    const top = openUpward ? rect.top - MENU_HEIGHT_ESTIMATE - GAP : rect.bottom + GAP;
    const left = Math.max(8, Math.min(rect.left, window.innerWidth - MENU_WIDTH - 8));
    setPos({ top, left });
    setOpen(true);
  }

  useEffect(() => {
    if (!open) return;
    function handlePointerDown(e: MouseEvent) {
      const target = e.target as Node;
      if (triggerRef.current?.contains(target) || menuRef.current?.contains(target)) return;
      setOpen(false);
    }
    function handleDismiss() {
      setOpen(false);
    }
    document.addEventListener("mousedown", handlePointerDown);
    window.addEventListener("scroll", handleDismiss, true);
    window.addEventListener("resize", handleDismiss);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      window.removeEventListener("scroll", handleDismiss, true);
      window.removeEventListener("resize", handleDismiss);
    };
  }, [open]);

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          if (open) setOpen(false);
          else openMenu();
        }}
        title="Task options"
        className="flex h-5 w-5 shrink-0 items-center justify-center rounded text-muted-2 hover:bg-bg hover:text-ink-2"
      >
        <MoreIcon />
      </button>
      {open &&
        pos &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            ref={menuRef}
            style={{ position: "fixed", top: pos.top, left: pos.left, width: MENU_WIDTH }}
            className="z-[500] overflow-hidden rounded-md border border-border bg-surface py-1 shadow-md"
          >
            <button
              type="button"
              onClick={(e) => {
                // Portaled into document.body, but React still bubbles the
                // synthetic event through the REACT tree (this component's
                // parent, not its DOM parent) — without this, clicking
                // Delete Task would also bubble into the row's own onClick
                // and open Edit Task at the same time.
                e.stopPropagation();
                setOpen(false);
                onDelete();
              }}
              className="block w-full px-3 py-1.5 text-left text-[13px] font-medium text-danger hover:bg-surface-2"
            >
              Delete Task
            </button>
          </div>,
          document.body
        )}
    </>
  );
}
