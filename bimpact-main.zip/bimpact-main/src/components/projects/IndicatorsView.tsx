"use client";

import { ReactElement, useState } from "react";
import { useSearchParams } from "next/navigation";
import { useProjectStore } from "@/store/projectStore";
import { useSessionStore } from "@/store/sessionStore";
import { pushOwnershipAlerts } from "@/lib/ownershipAlerts";
import { canEditProjectResource } from "@/lib/permissions";
import { OwnershipMode } from "@/types/project";
import { BeneficiaryRecordsTable } from "./BeneficiaryRecordsTable";
import { FormBuilder } from "./FormBuilder";

function PersonIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

function PartnerIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

function BothIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H8" />
      <circle cx="12" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

const OPTIONS: { mode: OwnershipMode; label: string; sub: string; iconBg: string; iconColor: string; onCls: string }[] = [
  {
    mode: "self",
    label: "You (CSR Head / PM)",
    sub: "You edit  ·  Partner previews only",
    iconBg: "var(--color-primary-50)",
    iconColor: "var(--color-primary)",
    onCls: "border-primary bg-primary-50 shadow-[0_0_0_3px_rgba(10,151,217,0.1)]",
  },
  {
    mode: "partner",
    label: "Partner (Implementing Org)",
    sub: "Partner edits  ·  You preview only",
    iconBg: "var(--color-secondary-50)",
    iconColor: "var(--color-secondary)",
    onCls: "border-secondary bg-[rgba(0,166,81,0.04)] shadow-[0_0_0_3px_rgba(0,166,81,0.1)]",
  },
  {
    mode: "both",
    label: "Both (Collaborative)",
    sub: "Both can edit  ·  Full collaboration",
    iconBg: "rgba(124,58,237,0.08)",
    iconColor: "#7c3aed",
    onCls: "border-[#7c3aed] bg-[rgba(124,58,237,0.04)] shadow-[0_0_0_3px_rgba(124,58,237,0.1)]",
  },
];

const ICONS: Record<OwnershipMode, () => ReactElement> = { self: PersonIcon, partner: PartnerIcon, both: BothIcon };

function BackIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="19" x2="5" y1="12" y2="12" />
      <polyline points="12 19 5 12 12 5" />
    </svg>
  );
}

function FormIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="4" rx="1" width="6" x="9" y="2" />
      <path d="M9 6H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-4" />
      <line x1="12" x2="12" y1="11" y2="17" />
      <line x1="9" x2="15" y1="14" y2="14" />
    </svg>
  );
}

function LockIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
      <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  );
}

function ChevronRightIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="9 18 15 12 9 6" />
    </svg>
  );
}

export function IndicatorsView({ projectId }: { projectId: string }) {
  const mode = useProjectStore((s) => s.beneficiaryOwnership[projectId] ?? null);
  const setBeneficiaryOwnership = useProjectStore((s) => s.setBeneficiaryOwnership);
  const formState = useProjectStore((s) => s.indicatorForms[projectId]);
  const createIndicatorForm = useProjectStore((s) => s.createIndicatorForm);
  const lockIndicatorForm = useProjectStore((s) => s.lockIndicatorForm);
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));
  const role = useSessionStore((s) => s.role);
  const isPartner = role === "partner";

  // Shared algorithm (ownershipAlerts.ts) — see DocumentOwnershipStrip.tsx's
  // handleNotifyPartner for the full rule this defers to.
  function handleNotifyPartner(newMode: OwnershipMode, previousMode: OwnershipMode | null) {
    if (!project) return;
    pushOwnershipAlerts("indicator_form", projectId, project.name, previousMode, newMode);
  }
  // ?tab=form deep-links straight into the Indicator Form (used by Add
  // Record's "Create Indicator Form" empty-state CTA, see
  // AddRecordSlideOver.tsx) instead of always landing on Records first.
  // Navigating here via router.push from an ALREADY-MOUNTED instance of
  // this same route (e.g. that CTA, reached while already sitting on this
  // project's Beneficiary Indicators page) changes the URL/searchParams
  // without remounting the component, so a useState initializer alone would
  // silently never switch the visible tab — reproduced by Playwright
  // (URL updated correctly, visible tab did not). Fixed using React's
  // "adjust state during render" pattern (see react.dev's guidance on
  // reacting to a changed prop without useEffect) instead of a useEffect,
  // which this codebase's lint config flags as cascading-render-prone.
  const searchParams = useSearchParams();
  const tabParam = searchParams.get("tab");
  const [view, setView] = useState<"records" | "form">(tabParam === "form" ? "form" : "records");
  const [appliedTabParam, setAppliedTabParam] = useState(tabParam);
  if (tabParam !== appliedTabParam) {
    setAppliedTabParam(tabParam);
    if (tabParam === "form") setView("form");
  }

  // Single source of truth for "who may create/edit this project's
  // Indicator Form" — same canEditProjectResource() matrix as the WBS,
  // keyed off this project's ownership mode (see permissions.ts).
  const canEdit = canEditProjectResource(mode, role);
  const created = !!formState;
  const locked = formState?.locked ?? false;

  if (view === "records") {
    return (
      <div className="flex flex-col">
        <div className="flex items-start justify-between gap-4 border-b border-border bg-surface px-5 py-4">
          <div>
            <h3 className="mb-0.5 text-base font-bold text-ink">Beneficiary Indicators</h3>
            <p className="text-[12.5px] text-muted">Track and manage beneficiary data for this project</p>
          </div>
          <button
            onClick={() => setView("form")}
            className={
              locked
                ? "flex h-9 shrink-0 items-center gap-1.5 rounded-lg border-[1.5px] px-4 text-sm font-semibold transition-colors"
                : "flex h-9 shrink-0 items-center gap-1.5 rounded-lg border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 transition-colors hover:border-primary hover:bg-primary-50 hover:text-primary"
            }
            style={
              locked
                ? { borderColor: "rgba(0,166,81,0.3)", color: "#00853a", background: "rgba(0,166,81,0.06)" }
                : undefined
            }
          >
            {locked ? <LockIcon /> : <FormIcon />}
            {locked ? "Form Locked · View Form" : "Indicator Form"}
            {!locked && <ChevronRightIcon />}
          </button>
        </div>
        <BeneficiaryRecordsTable projectId={projectId} />
      </div>
    );
  }

  return (
    <div className="flex flex-col">
      <div className="flex items-start justify-between gap-4 border-b border-border bg-surface px-5 py-4">
        <div>
          <h3 className="mb-0.5 text-base font-bold text-ink">Indicator Form</h3>
          <p className="text-[12.5px] text-muted">Create and manage the beneficiary data collection form</p>
          {locked && (
            <span className="mt-1.5 inline-flex items-center gap-1.5 rounded-full border border-[rgba(0,166,81,0.2)] bg-[rgba(0,166,81,0.08)] px-2.5 py-0.5 text-[11.5px] font-bold text-[#00853a]">
              <LockIcon />
              Form Locked
            </span>
          )}
        </div>
        <button
          onClick={() => setView("records")}
          className="flex h-9 shrink-0 items-center gap-1.5 rounded-lg border-[1.5px] border-border bg-surface px-4 text-sm font-semibold text-ink-2 transition-colors hover:border-primary hover:bg-primary-50 hover:text-primary"
        >
          <BackIcon />
          Back to Records
        </button>
      </div>

      {/* Who-creates-the-form picker — same container/card classes as WBS's
          "Who creates the WBS?" (WbsTable.tsx) byte-for-byte, per spec: same
          layout, spacing, icon/dot sizing, hover/active state. Only the
          heading and OPTIONS content differ. A sponsor-only governance
          decision; an invited partner must never see or trigger it, only
          inherit whatever mode the sponsor already configured. */}
      {!isPartner && (
        <div className="border-b border-border bg-surface px-5 pb-3.5 pt-[18px]">
          <div className="mb-3.5 flex items-baseline gap-2.5">
            <h3 className="text-sm font-bold text-ink">Who will create the form?</h3>
            <p className="text-[0.8rem] text-muted">Select responsibility — the form loads immediately.</p>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {OPTIONS.map((opt) => {
              const on = mode === opt.mode;
              const Icon = ICONS[opt.mode];
              return (
                <button
                  key={opt.mode}
                  onClick={() => {
                    setBeneficiaryOwnership(projectId, opt.mode);
                    handleNotifyPartner(opt.mode, mode);
                  }}
                  className={`relative flex items-center gap-3 rounded-[10px] border-2 p-3.5 text-left transition-all ${
                    on ? opt.onCls : "border-border bg-surface hover:border-border-strong hover:shadow-[0_3px_10px_rgba(0,0,0,0.06)]"
                  }`}
                >
                  <span
                    className={`absolute right-3 top-2.5 flex h-[17px] w-[17px] items-center justify-center rounded-full border-2 ${
                      on ? "border-transparent" : "border-border-strong bg-surface"
                    }`}
                    style={on ? { background: opt.iconColor } : undefined}
                  >
                    {on && <span className="h-1.5 w-1.5 rounded-full bg-white" />}
                  </span>
                  <span
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[9px]"
                    style={{ background: opt.iconBg, color: opt.iconColor }}
                  >
                    <Icon />
                  </span>
                  <span>
                    <span className="mb-0.5 block text-sm font-bold text-ink">{opt.label}</span>
                    <span className="block text-[11px] leading-snug text-muted">{opt.sub}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Ownership not configured yet — same copy/treatment as the WBS's
          equivalent empty state. */}
      {!mode && (
        <div className="flex min-h-[280px] flex-col items-center justify-center gap-3 bg-bg px-10 py-14 text-center">
          <div className="flex h-[52px] w-[52px] items-center justify-center rounded-full border-2 border-dashed border-border-strong bg-surface text-muted-2">
            <FormIcon />
          </div>
          <div className="text-[0.9rem] font-semibold text-ink-2">
            {isPartner ? "Waiting for your Sponsor to configure who creates this form." : "Select who creates the form above"}
          </div>
          <div className="max-w-[260px] text-[0.82rem] leading-snug text-muted">
            {isPartner
              ? "Once they choose You, Partner, or Both, this form will appear here automatically."
              : "Choose You, Partner, or Both — the form loads immediately."}
          </div>
        </div>
      )}

      {/* Ownership is configured, but the owning side hasn't created the
          form yet — this is a distinct state from "no ownership chosen"
          above: only the authorized (canEdit) side gets a "Create Indicator
          Form" call to action; the other side just waits. Creating it seeds
          a small default starter set (see defaultIndicatorSections in
          projectStore.ts) rather than a blank canvas, fully editable
          afterward. */}
      {mode && !created && (
        <div className="flex min-h-[280px] flex-col items-center justify-center gap-3 bg-bg px-10 py-14 text-center">
          <div className="flex h-[52px] w-[52px] items-center justify-center rounded-full border-2 border-dashed border-border-strong bg-surface text-muted-2">
            <FormIcon />
          </div>
          <div className="text-[0.9rem] font-semibold text-ink-2">No form created yet.</div>
          <div className="max-w-[260px] text-[0.82rem] leading-snug text-muted">
            {canEdit
              ? "You're responsible for this form — create it to start adding indicators."
              : isPartner
                ? "Your Sponsor hasn't created the Indicator Form yet. It will appear here automatically once they do."
                : "Your Partner hasn't created the Indicator Form yet. It will appear here automatically once they do."}
          </div>
          {canEdit && (
            <button
              onClick={() => createIndicatorForm(projectId)}
              className="mt-1 flex h-9 items-center gap-1.5 rounded-lg bg-primary px-4 text-sm font-semibold text-white hover:bg-primary-600"
            >
              <FormIcon />
              Create Indicator Form
            </button>
          )}
        </div>
      )}

      {mode && created && (
        <FormBuilder projectId={projectId} readOnly={!canEdit} locked={locked} onActivate={() => lockIndicatorForm(projectId)} />
      )}
    </div>
  );
}
