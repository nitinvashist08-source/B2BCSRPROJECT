"use client";

import { ReactNode } from "react";
import { FormField } from "@/types/project";

export function FieldGroup({
  label,
  required,
  children,
  error,
}: {
  label: string;
  required?: boolean;
  children: ReactNode;
  error?: string;
}) {
  return (
    <div className="mb-3.5">
      <label className="mb-1.5 block text-xs font-semibold text-ink-2">
        {label}
        {required && <span className="ml-0.5 text-danger">*</span>}
      </label>
      {children}
      {error && <p className="mt-1 text-xs text-danger">{error}</p>}
    </div>
  );
}

export const inputCls =
  "box-border h-[38px] w-full rounded-lg border-[1.5px] bg-bg px-3 text-[13px] text-ink outline-none transition-colors focus:border-primary";
export const areaCls =
  "box-border min-h-[76px] w-full resize-none rounded-lg border-[1.5px] bg-bg px-3 py-2 text-[13px] text-ink outline-none transition-colors focus:border-primary";
const errCls = "border-danger";
const okCls = "border-border";

// Renders one Indicator Form question as a REAL input (not the disabled
// preview used by the Indicator Form builder's own canvas — see
// GfFieldCard.tsx's AnswerPreview, which this deliberately does not reuse
// since that one is intentionally non-interactive). Every FormFieldType the
// builder supports gets a working equivalent here. Shared by AddRecordSlideOver.tsx
// (the in-app "+ Add Record" flow) and the public /beneficiary-form/[token]
// page (the "Share Form" respondent flow) — same rendering, same Indicator
// Form definition, never a second question-type implementation. Multi-select
// (checkbox) answers are flattened to a single "||"-joined string —
// IndicatorFormResponse.responses is Record<fieldId, string>, matching the
// spec's own suggested response shape.
export function DynamicField({
  field,
  value,
  onChange,
  invalid,
}: {
  field: FormField;
  value: string;
  onChange: (v: string) => void;
  invalid: boolean;
}) {
  const cls = `${inputCls} ${invalid ? errCls : okCls}`;
  const opts = field.options ?? [];

  switch (field.type) {
    case "para":
      return <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={field.description} className={`${areaCls} ${invalid ? errCls : okCls}`} />;
    case "address":
      return (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="House No., Street, Village/Ward, City, District, State, PIN"
          className={`${areaCls} ${invalid ? errCls : okCls}`}
        />
      );
    case "number":
      return <input type="number" value={value} onChange={(e) => onChange(e.target.value)} className={cls} />;
    case "currency":
      return (
        <div className="relative">
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[13px] text-muted">₹</span>
          <input type="number" value={value} onChange={(e) => onChange(e.target.value)} className={`${cls} pl-6`} />
        </div>
      );
    case "email":
      return <input type="email" value={value} onChange={(e) => onChange(e.target.value)} placeholder="name@example.com" className={cls} />;
    case "phone":
      return <input type="tel" value={value} onChange={(e) => onChange(e.target.value)} placeholder="10-digit mobile" className={cls} />;
    case "url":
      return <input type="url" value={value} onChange={(e) => onChange(e.target.value)} placeholder="https://example.com" className={cls} />;
    case "date":
      return <input type="date" value={value} onChange={(e) => onChange(e.target.value)} className={cls} />;
    case "time":
      return <input type="time" value={value} onChange={(e) => onChange(e.target.value)} className={cls} />;
    case "dropdown":
      return (
        <select value={value} onChange={(e) => onChange(e.target.value)} className={`${cls} cursor-pointer`}>
          <option value="">Select…</option>
          {opts.map((o) => (
            <option key={o} value={o}>
              {o}
            </option>
          ))}
        </select>
      );
    case "radio":
    case "yesno": {
      const choices = field.type === "yesno" ? ["Yes", "No"] : opts;
      return (
        <div className="mt-0.5 flex flex-wrap gap-[7px]">
          {choices.map((o) => {
            const sel = value === o;
            return (
              <div
                key={o}
                onClick={() => onChange(o)}
                className={`inline-flex cursor-pointer select-none items-center gap-[7px] rounded-lg border-[1.5px] px-[13px] py-[7px] text-[12.5px] transition-all ${
                  sel ? "border-primary bg-primary-50 font-semibold text-primary-700" : "border-border bg-surface font-medium text-ink-2"
                }`}
              >
                {o}
              </div>
            );
          })}
        </div>
      );
    }
    case "checkbox": {
      const selected = new Set(value ? value.split("||") : []);
      function toggle(o: string) {
        const next = new Set(selected);
        if (next.has(o)) next.delete(o);
        else next.add(o);
        onChange(Array.from(next).join("||"));
      }
      return (
        <div className="mt-0.5 flex flex-col gap-1.5">
          {opts.map((o) => (
            <label key={o} className="flex cursor-pointer items-center gap-2 text-[13px] text-ink-2">
              <input type="checkbox" checked={selected.has(o)} onChange={() => toggle(o)} className="h-[15px] w-[15px] accent-primary" />
              {o}
            </label>
          ))}
        </div>
      );
    }
    case "rating": {
      const n = Number(value) || 0;
      return (
        <div className="mt-0.5 flex gap-1">
          {Array.from({ length: 5 }).map((_, i) => {
            const filled = i < n;
            return (
              <svg
                key={i}
                onClick={() => onChange(String(i + 1))}
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill={filled ? "#f59e0b" : "none"}
                stroke={filled ? "#f59e0b" : "#d1d5db"}
                strokeWidth="1.5"
                className="cursor-pointer"
              >
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
            );
          })}
        </div>
      );
    }
    case "scale": {
      const min = field.min ?? 1;
      const max = field.max ?? 5;
      const nums = Array.from({ length: max - min + 1 }, (_, i) => min + i);
      return (
        <div className="mt-0.5 flex flex-wrap gap-2">
          {nums.map((n) => {
            const sel = value === String(n);
            return (
              <button
                type="button"
                key={n}
                onClick={() => onChange(String(n))}
                className={`flex h-9 w-9 items-center justify-center rounded-full border-[1.5px] text-[13px] font-semibold transition-colors ${
                  sel ? "border-primary bg-primary-50 text-primary-700" : "border-border text-ink-2"
                }`}
              >
                {n}
              </button>
            );
          })}
        </div>
      );
    }
    case "signature":
      return <input type="text" value={value} onChange={(e) => onChange(e.target.value)} placeholder="Type your full name to sign" className={cls} />;
    case "file":
      return (
        <input
          type="file"
          onChange={(e) => onChange(e.target.files?.[0]?.name ?? "")}
          className={`${inputCls} h-auto cursor-pointer py-1.5 ${invalid ? errCls : okCls}`}
        />
      );
    case "text":
    default:
      return <input type="text" value={value} onChange={(e) => onChange(e.target.value)} placeholder={field.description} className={cls} />;
  }
}
