"use client";

import { useRef, useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useSessionStore } from "@/store/sessionStore";
import { canEditProjectResource } from "@/lib/permissions";
import { ProjectDoc } from "@/types/project";
import { AiGeneratePanel } from "./AiGeneratePanel";
import { AiSelectionBubble } from "./AiSelectionBubble";
import { DocEmptyIcon, SparkleIcon } from "./DocEditorIcons";
import { DocumentEditorCanvas } from "@/components/documents/DocumentEditorCanvas";

export function DocEditor({ projectId }: { projectId: string }) {
  const doc = useProjectStore((s) => s.docs[projectId]);
  const documentMode = useProjectStore((s) => s.documentOwnership[projectId] ?? null);
  const saveDoc = useProjectStore((s) => s.saveDoc);
  const role = useSessionStore((s) => s.role);
  // Same permission gate as DocSidebar.tsx — read-only here means: no
  // toolbar, no title editing, contentEditable off, no Generate with AI
  // (button hidden AND the store's saveDoc/createDoc already refuse the
  // write regardless), no AI-selection bubble. Viewing the document's
  // content is never restricted.
  const canEdit = canEditProjectResource(documentMode, role);
  const bodyRef = useRef<HTMLDivElement>(null);
  // The stable, fixed-height, non-scrolling pane (below) that both AI
  // overlays position themselves against — see the comments at each
  // overlay's render site for why this has to be a different element than
  // bodyRef.
  const paneRef = useRef<HTMLDivElement>(null);
  const [aiOpen, setAiOpen] = useState(false);

  const isUploadViewer = doc?.kind === "uploaded" && doc.fileType !== undefined;

  // Still needed for the AI overlays below, which mutate bodyRef's DOM
  // directly (selection replace / appended generated content) and then need
  // that written back to the store — separate from DocumentEditorCanvas's
  // own onChange, which covers its own toolbar/typing edits.
  function persist() {
    if (bodyRef.current) saveDoc(projectId, { contentHtml: bodyRef.current.innerHTML });
  }

  function insertAiContent(html: string) {
    if (bodyRef.current) {
      bodyRef.current.innerHTML += html;
      persist();
    }
  }

  return (
    <div
      ref={paneRef}
      className="relative flex h-[calc(100vh-260px)] min-h-[520px] max-h-full flex-1 flex-col overflow-hidden bg-[#f4f5f7]"
    >
      {!doc && (
        <div className="flex flex-1 flex-col items-center justify-center gap-3 p-12 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl border-2 border-dashed border-border-strong bg-surface text-muted-2">
            <DocEmptyIcon />
          </div>
          <div className="text-[1.05rem] font-bold text-ink-2">No document open</div>
          <div className="max-w-[280px] text-sm leading-snug text-muted">
            Create a new document or upload a PDF / Word file using the buttons in the sidebar.
          </div>
        </div>
      )}

      {doc && !isUploadViewer && (
        <>
          <DocumentEditorCanvas
            bodyRef={bodyRef}
            canEdit={canEdit}
            title={doc.title ?? ""}
            onTitleChange={(v) => saveDoc(projectId, { title: v })}
            titlePlaceholder="Untitled Document"
            contentHtml={doc.contentHtml}
            contentKey={doc.id}
            onChange={(html) => saveDoc(projectId, { contentHtml: html })}
            placeholder="Start writing, or press '/' for AI suggestions…"
            readOnlyMessage="View only — you don't have edit access to this project's documents."
            // Read-only viewers get no toolbar at all (including Generate
            // with AI) — not just a disabled one. The store's own
            // createDoc/saveDoc/etc. guards are the actual enforcement;
            // this is the UI half of "hide, and also enforce at the data
            // layer" (see projectStore.ts).
            toolbarExtra={
              <button
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => setAiOpen(true)}
                className="ml-1 flex h-7 items-center gap-1.5 rounded-md px-[11px] text-xs font-semibold text-white transition-opacity hover:opacity-90"
                style={{ background: "linear-gradient(135deg, #5b21b6, #2563eb)" }}
              >
                <SparkleIcon size={12} stroke="white" />
                Generate with AI
              </button>
            }
          />
          {canEdit && <AiSelectionBubble containerRef={bodyRef} boundsRef={paneRef} onApplied={persist} />}
          {/* Rendered as a sibling of the scrollable canvas above (NOT inside
              the tall, min-h-[1060px] paper div) so its `absolute bottom-*`
              positioning resolves against this pane's own fixed-height,
              overflow-hidden root — pinned near the visible bottom of the
              editor, like the source mockup's viewport-anchored panel —
              instead of the bottom of the full (often much taller than the
              viewport) document, where it used to render off-screen. */}
          {canEdit && <AiGeneratePanel open={aiOpen} onClose={() => setAiOpen(false)} onInsert={insertAiContent} />}
        </>
      )}

      {doc && isUploadViewer && <UploadedDocViewer doc={doc} />}
    </div>
  );
}

function UploadedDocViewer({ doc }: { doc: ProjectDoc }) {
  const isPdf = doc.fileType === "pdf";
  const isDocx = doc.fileType === "docx";

  return (
    <div className="flex h-full flex-col bg-bg">
      <div className="flex flex-shrink-0 items-center gap-[13px] border-b border-border bg-surface px-5 py-3.5">
        <div
          className={`flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-[9px] text-[10px] font-extrabold tracking-wide text-white ${
            isPdf ? "bg-[#e03b3b]" : "bg-[#2B579A]"
          }`}
        >
          {isPdf ? "PDF" : isDocx ? "DOCX" : "DOC"}
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-bold text-ink">{doc.title}</div>
          <div className="mt-0.5 text-[11.5px] text-muted">{doc.fileName ?? "Inline preview"}</div>
        </div>
      </div>
      <div className="relative min-h-0 flex-1 overflow-hidden">
        {isPdf && doc.fileUrl && (
          <iframe src={doc.fileUrl} title={doc.title} className="h-full w-full border-none bg-white" />
        )}
        {isDocx && (
          <div className="h-full overflow-y-auto overflow-x-hidden bg-[#f4f5f7]">
            <div
              className="doc-word-render mx-auto my-7 max-w-[820px] rounded bg-white px-14 pb-16 pt-12 text-[14.5px] leading-[1.8] text-[#1e293b] shadow-[0_2px_12px_rgba(15,23,42,0.08)]"
              style={{ fontFamily: "'Calibri','Georgia',-apple-system,serif" }}
              dangerouslySetInnerHTML={{ __html: doc.contentHtml }}
            />
          </div>
        )}
        {!isPdf && !isDocx && (
          <div className="flex h-full flex-col items-center justify-center gap-0 px-8 py-12 text-center">
            <div className="mb-5 flex h-[72px] w-[72px] items-center justify-center rounded-2xl bg-[#EEF2FF] text-[13px] font-extrabold tracking-wide text-[#2B579A]">
              DOC
            </div>
            <div className="mb-2 text-base font-bold text-ink">Inline preview not available</div>
            <div className="max-w-[380px] text-[13.5px] leading-relaxed text-muted">
              Legacy .doc files cannot be rendered directly in the browser. Please re-save the file as .docx to
              enable inline preview within Project Details.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
