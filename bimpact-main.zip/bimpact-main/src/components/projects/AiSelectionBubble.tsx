"use client";

import { RefObject, useEffect, useState } from "react";
import { CloseIcon, SparkleIcon } from "./DocEditorIcons";

type Action = "improve" | "shorten" | "expand" | "formalise" | "simplify" | "grammar" | "custom";

const ACTIONS: { key: Action; label: string }[] = [
  { key: "improve", label: "Improve" },
  { key: "shorten", label: "Shorten" },
  { key: "expand", label: "Expand" },
  { key: "formalise", label: "Formalise" },
  { key: "simplify", label: "Simplify" },
  { key: "grammar", label: "Fix Grammar" },
];

function transform(text: string, action: Action, custom?: string): string {
  const trimmed = text.trim();
  if (!trimmed) return trimmed;
  switch (action) {
    case "shorten": {
      const words = trimmed.split(/\s+/);
      return words.length > 12 ? `${words.slice(0, 12).join(" ")}…` : trimmed;
    }
    case "expand":
      return `${trimmed} This point is further supported by ongoing program data and community feedback.`;
    case "formalise":
      return trimmed.replace(/\bcan't\b/gi, "cannot").replace(/\bdon't\b/gi, "do not");
    case "simplify":
      return trimmed.split(/(?<=[.!?])\s+/)[0] || trimmed;
    case "grammar": {
      const sentence = trimmed.endsWith(".") ? trimmed : `${trimmed}.`;
      return `${sentence.charAt(0).toUpperCase()}${sentence.slice(1)}`;
    }
    case "custom":
      return custom ? `${trimmed} (${custom})` : trimmed;
    default: {
      const sentence = trimmed.endsWith(".") ? trimmed : `${trimmed}.`;
      return `In summary, ${sentence.charAt(0).toLowerCase()}${sentence.slice(1)}`;
    }
  }
}

export function AiSelectionBubble({
  containerRef,
  boundsRef,
  onApplied,
}: {
  // Scopes which selections count as "inside the editor" (bodyRef) — a
  // selection anchored anywhere else on the page is ignored.
  containerRef: RefObject<HTMLDivElement | null>;
  // What the bubble's own on-screen position is computed AND rendered
  // relative to. This must be the bubble's actual CSS positioned ancestor
  // (a stable, non-scrolling pane), not containerRef — containerRef sits
  // deep inside a much taller scrollable document, offset from that pane's
  // origin by the title/padding above it, so using it for both would misplace
  // the bubble by exactly that offset (it previously rendered up near the
  // page header instead of next to the selected text).
  boundsRef: RefObject<HTMLDivElement | null>;
  onApplied: () => void;
}) {
  // Rough height of the bubble (it isn't measured — matches the source
  // mockup's own fixed 180px assumption for this same flip check, just with
  // a little extra headroom) — used only to decide whether there's enough
  // room above the selection to sit above it (the normal case, translated
  // up by its own height) or whether it needs to flip below the selection
  // instead (near the top of the editor) so it never renders clipped above
  // the pane or overlapping the toolbar.
  const BUBBLE_HEIGHT_ESTIMATE = 210;

  const [pos, setPos] = useState<{ top: number; left: number; below: boolean } | null>(null);
  const [range, setRange] = useState<Range | null>(null);
  const [custom, setCustom] = useState("");

  useEffect(() => {
    function handleSelectionChange() {
      const container = containerRef.current;
      const bounds = boundsRef.current;
      const selection = window.getSelection();
      if (!container || !bounds || !selection || selection.isCollapsed || selection.rangeCount === 0) {
        setPos(null);
        setRange(null);
        return;
      }
      const anchorNode = selection.anchorNode;
      if (!anchorNode || !container.contains(anchorNode)) {
        setPos(null);
        setRange(null);
        return;
      }
      const selRange = selection.getRangeAt(0);
      const rect = selRange.getBoundingClientRect();
      const boundsRect = bounds.getBoundingClientRect();
      setRange(selRange.cloneRange());
      const left = Math.max(0, rect.left - boundsRect.left);
      const aboveTop = rect.top - boundsRect.top - 8;
      const below = aboveTop < BUBBLE_HEIGHT_ESTIMATE;
      setPos({ top: below ? rect.bottom - boundsRect.top + 8 : aboveTop, left, below });
    }
    document.addEventListener("selectionchange", handleSelectionChange);
    return () => document.removeEventListener("selectionchange", handleSelectionChange);
  }, [containerRef, boundsRef]);

  function apply(action: Action) {
    if (!range) return;
    const replaced = transform(range.toString(), action, custom);
    const selection = window.getSelection();
    if (!selection) return;
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand("insertText", false, replaced);
    setPos(null);
    setRange(null);
    setCustom("");
    onApplied();
  }

  if (!pos) return null;

  return (
    <div
      className={`absolute z-40 w-[264px] overflow-hidden rounded-[10px] bg-[#1e1e2e] shadow-[0_8px_32px_rgba(0,0,0,0.22)] ${
        pos.below ? "" : "-translate-y-full"
      }`}
      style={{ top: pos.top, left: pos.left }}
      onMouseDown={(e) => e.preventDefault()}
    >
      <div
        className="flex items-center gap-[7px] px-3 py-2 text-[11.5px] font-bold text-white"
        style={{ background: "linear-gradient(135deg, #5b21b6, #2563eb)" }}
      >
        <SparkleIcon size={13} stroke="white" />
        AI Edit
        <button
          onClick={() => {
            setPos(null);
            setRange(null);
          }}
          className="ml-auto flex h-5 w-5 items-center justify-center rounded bg-white/15 text-white hover:bg-white/25"
        >
          <CloseIcon />
        </button>
      </div>
      <div className="flex flex-wrap gap-0 bg-[#1e1e2e] p-1.5">
        {ACTIONS.map((a) => (
          <button
            key={a.key}
            onClick={() => apply(a.key)}
            className="flex w-1/2 items-center gap-[7px] rounded-md px-2.5 py-[7px] text-left text-[12.5px] text-slate-200 transition-colors hover:bg-white/10 hover:text-white"
          >
            {a.label}
          </button>
        ))}
        <div className="my-1 h-px w-full bg-white/[0.08]" />
        <div className="flex w-full items-center px-0.5">
          <input
            value={custom}
            onChange={(e) => setCustom(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") apply("custom");
            }}
            placeholder="Custom instruction…"
            className="h-8 flex-1 rounded-l-md border border-white/15 bg-white/10 px-2.5 text-xs text-white placeholder:text-white/40 outline-none focus:border-white/40"
          />
          <button
            onClick={() => apply("custom")}
            className="flex h-8 w-8 items-center justify-center rounded-r-md text-white"
            style={{ background: "linear-gradient(135deg, #5b21b6, #2563eb)" }}
          >
            <svg fill="none" height="12" width="12" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" viewBox="0 0 24 24">
              <line x1="22" x2="11" y1="2" y2="13" />
              <polygon points="22 2 15 22 11 13 2 9 22 2" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
