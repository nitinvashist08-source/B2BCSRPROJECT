import { ReactNode } from "react";

export type StatTileTone = "default" | "primary" | "secondary" | "amber" | "danger";

const VALUE_TONE: Record<StatTileTone, string> = {
  default: "text-ink",
  primary: "text-primary-700",
  secondary: "text-secondary-600",
  amber: "text-amber-600",
  danger: "text-danger",
};

// Generic KPI tile for the Reporting module — deliberately plain/static
// (no chart-kind config, no dataset wiring) unlike the Dashboard module's
// KpiCard, which is built around Visualization/dataset selection for a
// self-serve builder. Reporting renders a fixed, curated set of numbers, so
// it doesn't need that machinery.
export function StatTile({
  label,
  value,
  sublabel,
  tone = "default",
}: {
  label: string;
  value: ReactNode;
  sublabel?: ReactNode;
  tone?: StatTileTone;
}) {
  return (
    <div className="flex flex-col gap-1 rounded-lg border border-border bg-surface p-4 shadow-sm">
      <span className="text-[11px] font-semibold uppercase tracking-wide text-muted">{label}</span>
      <span className={`text-2xl font-bold ${VALUE_TONE[tone]}`}>{value}</span>
      {sublabel && <span className="text-xs text-muted">{sublabel}</span>}
    </div>
  );
}
