"use client";

import { useMemo, useState } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useFinanceStore } from "@/store/financeStore";
import { PartnerFilter } from "@/components/dashboard/PartnerFilter";
import { ProjectFilter } from "@/components/dashboard/ProjectFilter";
import { DashboardEmptyState } from "@/components/dashboard/DashboardEmptyState";
import { ALL_DASHBOARD_FILTERS, DashboardFilters } from "@/types/dashboardFilters";
import { getScopedProjectIds, getScopedPartnerIds, isFilterCombinationEmpty } from "@/lib/dashboardFilterScope";
import { computeProjectExecutionMetrics, ProjectExecution, PartnerExecutionScorecard } from "@/lib/executionReportCalcs";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { ProjectStatusBadge } from "@/components/projects/ProjectStatusBadge";
import { StatTile } from "./StatTile";

function fmtPct(n: number) {
  return `${n.toFixed(0)}%`;
}
function fmtInr(n: number) {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

// The Reporting module's second report — Project Execution Status. See
// src/lib/executionReportCalcs.ts for the metric definitions/
// simplifications this reads from. Reuses the same Partner+Project filter
// pair as Fund Utilization and the Consolidated Dashboard, so scoping
// behaves identically across the whole app.
export function ProjectExecutionReport() {
  const hydratedProjects = useProjectStore((s) => s.hydrated);
  const hydratedSettings = useSettingsStore((s) => s.hydrated);
  const hydratedFinance = useFinanceStore((s) => s.hydrated);
  const projects = useProjectStore((s) => s.projects);
  const wbs = useProjectStore((s) => s.wbs);
  const partners = useSettingsStore((s) => s.partners);
  const projectDistricts = useSettingsStore((s) => s.projectDistricts);
  const expenses = useFinanceStore((s) => s.expenses);

  const [filters, setFilters] = useState<DashboardFilters>(ALL_DASHBOARD_FILTERS);

  const noMatch = isFilterCombinationEmpty(filters);
  const partnerName = partners.find((p) => p.id === filters.partnerId)?.name;
  const projectName = projects.find((p) => p.id === filters.projectId)?.name;

  const metrics = useMemo(() => {
    if (noMatch) return null;
    const scopedProjectIds = new Set(getScopedProjectIds(filters));
    const scopedProjects = projects.filter((p) => scopedProjectIds.has(p.id));
    const scopedPartnerIds = new Set(getScopedPartnerIds(filters));
    const scopedPartners = partners.filter((p) => scopedPartnerIds.has(p.id));
    return computeProjectExecutionMetrics({
      projects: scopedProjects,
      partners: scopedPartners,
      wbs,
      projectDistricts,
      expenses,
    });
  }, [filters, noMatch, projects, partners, wbs, projectDistricts, expenses]);

  if (!hydratedProjects || !hydratedSettings || !hydratedFinance) {
    return <div className="h-40 animate-pulse rounded-lg bg-surface-2" />;
  }

  const avgCompletion =
    metrics && metrics.projects.length > 0
      ? metrics.projects.reduce((sum, p) => sum + p.completionPct, 0) / metrics.projects.length
      : 0;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-semibold text-ink">Project Execution Status</h1>
          <p className="text-xs text-muted">Delivery progress, timeline health, and partner performance across the portfolio.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <PartnerFilter value={filters.partnerId} onChange={(partnerId) => setFilters((f) => ({ ...f, partnerId }))} />
          <ProjectFilter value={filters.projectId} onChange={(projectId) => setFilters((f) => ({ ...f, projectId }))} />
        </div>
      </div>

      {noMatch || !metrics ? (
        <DashboardEmptyState
          title="No matching data"
          message={`${partnerName ?? "This partner"} is not associated with ${projectName ?? "this project"}. Try clearing one of the filters above.`}
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <StatTile label="Total Projects" value={metrics.totalProjects} />
            <StatTile label="Avg. Task Completion" value={fmtPct(avgCompletion)} tone={avgCompletion < 50 ? "danger" : avgCompletion < 75 ? "amber" : "secondary"} />
            <StatTile
              label="Needs Intervention"
              value={metrics.interventionCount}
              sublabel={`of ${metrics.totalProjects} project${metrics.totalProjects === 1 ? "" : "s"}`}
              tone={metrics.interventionCount > 0 ? "danger" : "default"}
            />
            <StatTile
              label="Underperforming Partners"
              value={metrics.underperformingPartnerCount}
              sublabel={`of ${metrics.partnerScorecards.length} scored`}
              tone={metrics.underperformingPartnerCount > 0 ? "amber" : "default"}
            />
          </div>

          <Card title="Portfolio by Status">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {metrics.byStatus.map((row) => (
                <div key={row.status} className="rounded-md border border-border bg-bg p-3">
                  <ProjectStatusBadge status={row.status} />
                  <div className="mt-2 text-lg font-bold text-ink">{row.count}</div>
                  <div className="text-xs text-muted">{fmtInr(row.budget)} allocated</div>
                </div>
              ))}
            </div>
          </Card>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {metrics.byPartner.length > 0 && (
              <Card title="Portfolio by Partner" className="overflow-x-auto">
                <RollupTable rows={metrics.byPartner.map((r) => ({ key: r.partnerId, name: r.partnerName, count: r.count }))} />
              </Card>
            )}
            {metrics.byDistrict.length > 0 && (
              <Card title="Portfolio by District" className="overflow-x-auto">
                <RollupTable
                  rows={metrics.byDistrict.map((r) => ({ key: r.district, name: r.district, sub: r.state, count: r.count }))}
                />
              </Card>
            )}
          </div>

          <Card title="Project Execution Detail" className="overflow-x-auto">
            <ProjectExecutionTable rows={metrics.projects} />
          </Card>

          {metrics.partnerScorecards.length > 0 && (
            <Card title="Partner Performance Scorecard" className="overflow-x-auto">
              <PartnerScorecardTable rows={metrics.partnerScorecards} />
            </Card>
          )}
        </>
      )}
    </div>
  );
}

function RollupTable({ rows }: { rows: { key: string; name: string; sub?: string; count: number }[] }) {
  return (
    <table className="w-full text-left text-xs">
      <thead>
        <tr className="border-b border-border text-muted">
          <th className="py-1.5 pr-3 font-semibold">Name</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Projects</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.key} className="border-b border-border last:border-0">
            <td className="py-1.5 pr-3">
              <div className="font-medium text-ink">{r.name}</div>
              {r.sub && <div className="text-[11px] text-muted">{r.sub}</div>}
            </td>
            <td className="py-1.5 pr-3 text-right font-semibold text-ink">{r.count}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function ProjectExecutionTable({ rows }: { rows: ProjectExecution[] }) {
  return (
    <table className="w-full text-left text-xs">
      <thead>
        <tr className="border-b border-border text-muted">
          <th className="py-1.5 pr-3 font-semibold">Project</th>
          <th className="py-1.5 pr-3 font-semibold">Status</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Completion</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Delayed Tasks</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Timeline</th>
          <th className="py-1.5 pr-3 font-semibold">Flag</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((p) => (
          <tr key={p.projectId} className="border-b border-border last:border-0 align-top">
            <td className="py-1.5 pr-3">
              <div className="font-medium text-ink">{p.projectName}</div>
              <div className="text-[11px] text-muted">{p.partnerNames.join(", ") || "No partner assigned"}</div>
            </td>
            <td className="py-1.5 pr-3">
              <ProjectStatusBadge status={p.status} />
            </td>
            <td className="py-1.5 pr-3 text-right font-semibold text-ink">
              {fmtPct(p.completionPct)}
              <div className="text-[11px] font-normal text-muted">
                {p.completedTasks}/{p.totalTasks} done
              </div>
            </td>
            <td className="py-1.5 pr-3 text-right text-ink-2">{p.delayedTasks || "—"}</td>
            <td className="py-1.5 pr-3 text-right text-ink-2">
              {p.slippageDays > 0 ? `${p.slippageDays}d overdue` : `${Math.abs(p.slippageDays)}d remaining`}
            </td>
            <td className="py-1.5 pr-3">
              {p.needsIntervention ? (
                <div className="flex flex-col gap-1">
                  <Badge tone="danger">Needs Intervention</Badge>
                  <ul className="list-disc pl-3 text-[11px] text-muted">
                    {p.interventionReasons.map((r) => (
                      <li key={r}>{r}</li>
                    ))}
                  </ul>
                </div>
              ) : (
                <Badge tone="secondary">On Track</Badge>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function PartnerScorecardTable({ rows }: { rows: PartnerExecutionScorecard[] }) {
  return (
    <table className="w-full text-left text-xs">
      <thead>
        <tr className="border-b border-border text-muted">
          <th className="py-1.5 pr-3 font-semibold">Partner</th>
          <th className="py-1.5 pr-3 text-right font-semibold">On-Time Tasks</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Rejected Expenses</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Stale Pending</th>
          <th className="py-1.5 pr-3 font-semibold">Compliance</th>
          <th className="py-1.5 pr-3 font-semibold">Flag</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((p) => (
          <tr key={p.partnerId} className="border-b border-border last:border-0 align-top">
            <td className="py-1.5 pr-3">
              <div className="font-medium text-ink">{p.partnerName}</div>
              <div className="text-[11px] text-muted">
                {p.projectCount} project{p.projectCount === 1 ? "" : "s"}
              </div>
            </td>
            <td className="py-1.5 pr-3 text-right font-semibold text-ink">
              {p.totalTasks > 0 ? fmtPct(p.onTimeTaskPct) : "No tasks"}
              {p.totalTasks > 0 && (
                <div className="text-[11px] font-normal text-muted">{p.delayedTasks} delayed</div>
              )}
            </td>
            <td className="py-1.5 pr-3 text-right text-ink-2">
              {p.rejectedExpenseCount}
              {p.submittedExpenseCount > 0 && (
                <div className="text-[11px] text-muted">{fmtPct(p.rejectionRatePct)} of {p.submittedExpenseCount}</div>
              )}
            </td>
            <td className="py-1.5 pr-3 text-right text-ink-2">{p.stalePendingCount || "—"}</td>
            <td className="py-1.5 pr-3">
              <Badge tone={p.complianceStatus === "Complete" ? "secondary" : p.complianceStatus === "Incomplete" ? "amber" : "muted"}>
                {p.complianceStatus}
              </Badge>
            </td>
            <td className="py-1.5 pr-3">
              {p.underperforming ? (
                <div className="flex flex-col gap-1">
                  <Badge tone="danger">Underperforming</Badge>
                  <ul className="list-disc pl-3 text-[11px] text-muted">
                    {p.underperformReasons.map((r) => (
                      <li key={r}>{r}</li>
                    ))}
                  </ul>
                </div>
              ) : (
                <Badge tone="secondary">Healthy</Badge>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
