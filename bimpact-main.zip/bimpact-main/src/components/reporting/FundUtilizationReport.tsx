"use client";

import { useEffect, useMemo, useState } from "react";
import { useFinanceStore } from "@/store/financeStore";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { PartnerFilter } from "@/components/dashboard/PartnerFilter";
import { ProjectFilter } from "@/components/dashboard/ProjectFilter";
import { DashboardEmptyState } from "@/components/dashboard/DashboardEmptyState";
import { ALL_DASHBOARD_FILTERS, DashboardFilters } from "@/types/dashboardFilters";
import { getScopedProjectIds, getScopedPartnerIds, isFilterCombinationEmpty } from "@/lib/dashboardFilterScope";
import { computeFundUtilizationMetrics } from "@/lib/reportingCalcs";
import { Card } from "@/components/ui/Card";
import { Badge, BadgeTone } from "@/components/ui/Badge";
import { StatTile } from "./StatTile";
import { Tranche, TrancheStatus } from "@/types/finance";

function fmtInr(n: number) {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}
function fmtPct(n: number) {
  return `${n.toFixed(1)}%`;
}

const TRANCHE_STATUS_LABEL: Record<TrancheStatus, string> = {
  scheduled: "Scheduled",
  upcoming: "Upcoming",
  overdue: "Overdue",
  released: "Released",
};
const TRANCHE_STATUS_TONE: Record<TrancheStatus, BadgeTone> = {
  scheduled: "muted",
  upcoming: "primary",
  overdue: "danger",
  released: "secondary",
};

// The Reporting module's first report — Fund Utilization & Financial
// Health. See src/lib/reportingCalcs.ts for the metric definitions/
// simplifications this reads from. Reuses the Consolidated Dashboard's own
// Partner+Project filter pair (src/types/dashboardFilters.ts,
// src/lib/dashboardFilterScope.ts) so scoping behaves identically to the
// rest of the app (same "All/one/both, mismatched pair = explicit empty
// state" rules) instead of a second, slightly-different filter concept.
export function FundUtilizationReport() {
  const hydratedFinance = useFinanceStore((s) => s.hydrated);
  const hydratedProjects = useProjectStore((s) => s.hydrated);
  const hydratedSettings = useSettingsStore((s) => s.hydrated);
  const projects = useProjectStore((s) => s.projects);
  const partners = useSettingsStore((s) => s.partners);
  const expenses = useFinanceStore((s) => s.expenses);
  const disbursements = useFinanceStore((s) => s.disbursements);
  const ensureExpenses = useFinanceStore((s) => s.ensureExpenses);
  const ensureDisbursements = useFinanceStore((s) => s.ensureDisbursements);

  const [filters, setFilters] = useState<DashboardFilters>(ALL_DASHBOARD_FILTERS);

  // Same lazy-seed pattern as HighLevelBudgetTable/DisbProjectList — a
  // report needs every project's data, not just whichever ones a Sponsor
  // happened to open on the Finance pages first.
  useEffect(() => {
    if (!hydratedProjects) return;
    projects.forEach((p, i) => {
      ensureExpenses(p.id);
      ensureDisbursements(p.id, i);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydratedProjects, projects.length]);

  const noMatch = isFilterCombinationEmpty(filters);
  const partnerName = partners.find((p) => p.id === filters.partnerId)?.name;
  const projectName = projects.find((p) => p.id === filters.projectId)?.name;

  const metrics = useMemo(() => {
    if (noMatch) return null;
    const scopedProjectIds = new Set(getScopedProjectIds(filters));
    const scopedProjects = projects.filter((p) => scopedProjectIds.has(p.id));
    const scopedPartnerIds = new Set(getScopedPartnerIds(filters));
    const scopedPartners = partners.filter((p) => scopedPartnerIds.has(p.id));
    return computeFundUtilizationMetrics({
      projects: scopedProjects,
      partners: scopedPartners,
      expenses,
      disbursements,
    });
  }, [filters, noMatch, projects, partners, expenses, disbursements]);

  if (!hydratedFinance || !hydratedProjects || !hydratedSettings) {
    return <div className="h-40 animate-pulse rounded-lg bg-surface-2" />;
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-semibold text-ink">Fund Utilization &amp; Financial Health</h1>
          <p className="text-xs text-muted">Allocation, spend, and disbursement status across the portfolio.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <PartnerFilter value={filters.partnerId} onChange={(partnerId) => setFilters((f) => ({ ...f, partnerId }))} />
          <ProjectFilter value={filters.projectId} onChange={(projectId) => setFilters((f) => ({ ...f, projectId }))} />
        </div>
      </div>

      {noMatch || !metrics ? (
        <DashboardEmptyState
          title="No matching data"
          message={`${partnerName ?? "This partner"} is not associated with ${projectName ?? "this project"}. Try clearing one of the filters above.`}
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
            <StatTile label="Allocated" value={fmtInr(metrics.totalAllocated)} />
            <StatTile label="Disbursed" value={fmtInr(metrics.totalDisbursed)} />
            <StatTile label="Utilized" value={fmtInr(metrics.totalUtilized)} tone="secondary" />
            <StatTile
              label="Utilization"
              value={fmtPct(metrics.utilizationPct)}
              tone={metrics.utilizationPct < 50 ? "danger" : metrics.utilizationPct < 75 ? "amber" : "secondary"}
            />
            <StatTile
              label="Float (disbursed, unspent)"
              value={fmtInr(metrics.floatGap)}
              sublabel="Cash with partners, not yet spent"
              tone={metrics.floatGap > 0 ? "amber" : "default"}
            />
            <StatTile
              label="Pending Approval"
              value={fmtInr(metrics.pendingApprovalAmount)}
              sublabel={`${metrics.pendingApprovalCount} expense${metrics.pendingApprovalCount === 1 ? "" : "s"}`}
            />
          </div>

          <Card title="Disbursement Pipeline">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {(Object.keys(metrics.trancheByStatus) as TrancheStatus[]).map((status) => (
                <div key={status} className="rounded-md border border-border bg-bg p-3">
                  <Badge tone={TRANCHE_STATUS_TONE[status]}>{TRANCHE_STATUS_LABEL[status]}</Badge>
                  <div className="mt-2 text-lg font-bold text-ink">{fmtInr(metrics.trancheByStatus[status].amount)}</div>
                  <div className="text-xs text-muted">
                    {metrics.trancheByStatus[status].count} tranche{metrics.trancheByStatus[status].count === 1 ? "" : "s"}
                  </div>
                </div>
              ))}
            </div>

            {metrics.overdueTranches.length > 0 && (
              <div className="mt-4">
                <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-danger">Overdue Tranches</h4>
                <TrancheMiniTable rows={metrics.overdueTranches} />
              </div>
            )}
            {metrics.upcomingTranches.length > 0 && (
              <div className="mt-4">
                <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted">Upcoming (next 90 days)</h4>
                <TrancheMiniTable rows={metrics.upcomingTranches} showDaysAway />
              </div>
            )}
          </Card>

          <Card title="Utilization by Project" className="overflow-x-auto">
            <UtilizationTable
              rows={metrics.byProject.map((p) => ({
                key: p.projectId,
                name: p.projectName,
                allocated: p.allocated,
                utilized: p.utilized,
                disbursed: p.disbursed,
                utilizationPct: p.utilizationPct,
                flag: p.atRisk,
              }))}
              flagLabel="At Risk"
            />
          </Card>

          {metrics.byPartner.length > 0 && (
            <Card title="Utilization by Partner" className="overflow-x-auto">
              <UtilizationTable
                rows={metrics.byPartner.map((p) => ({
                  key: p.partnerId,
                  name: p.partnerName,
                  allocated: p.allocated,
                  utilized: p.utilized,
                  disbursed: p.disbursed,
                  utilizationPct: p.utilizationPct,
                  flag: false,
                }))}
              />
            </Card>
          )}

          {metrics.rejectedCount > 0 && (
            <Card title="Rejected Expenses">
              <p className="text-sm text-ink-2">
                {metrics.rejectedCount} expense{metrics.rejectedCount === 1 ? "" : "s"} totaling{" "}
                <span className="font-semibold">{fmtInr(metrics.rejectedAmount)}</span> rejected across scoped projects.
              </p>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

function TrancheMiniTable({
  rows,
  showDaysAway,
}: {
  rows: { tranche: Tranche; projectName: string; daysAway?: number }[];
  showDaysAway?: boolean;
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-xs">
        <thead>
          <tr className="border-b border-border text-muted">
            <th className="py-1.5 pr-3 font-semibold">Tranche</th>
            <th className="py-1.5 pr-3 font-semibold">Project</th>
            <th className="py-1.5 pr-3 font-semibold">Date</th>
            {showDaysAway && <th className="py-1.5 pr-3 font-semibold">In</th>}
            <th className="py-1.5 pr-3 text-right font-semibold">Amount</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(({ tranche, projectName, daysAway }) => (
            <tr key={tranche.id} className="border-b border-border last:border-0">
              <td className="py-1.5 pr-3 text-ink-2">{tranche.name}</td>
              <td className="py-1.5 pr-3 text-ink-2">{projectName}</td>
              <td className="py-1.5 pr-3 text-muted">{tranche.date}</td>
              {showDaysAway && <td className="py-1.5 pr-3 text-muted">{daysAway}d</td>}
              <td className="py-1.5 pr-3 text-right font-medium text-ink">{fmtInr(tranche.amount)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function UtilizationTable({
  rows,
  flagLabel,
}: {
  rows: {
    key: string;
    name: string;
    allocated: number;
    utilized: number;
    disbursed: number;
    utilizationPct: number;
    flag: boolean;
  }[];
  flagLabel?: string;
}) {
  return (
    <table className="w-full text-left text-xs">
      <thead>
        <tr className="border-b border-border text-muted">
          <th className="py-1.5 pr-3 font-semibold">Name</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Allocated</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Disbursed</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Utilized</th>
          <th className="py-1.5 pr-3 text-right font-semibold">Utilization</th>
          {flagLabel && <th className="py-1.5 pr-3 font-semibold" />}
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.key} className="border-b border-border last:border-0">
            <td className="py-1.5 pr-3 font-medium text-ink">{r.name}</td>
            <td className="py-1.5 pr-3 text-right text-ink-2">{fmtInr(r.allocated)}</td>
            <td className="py-1.5 pr-3 text-right text-ink-2">{fmtInr(r.disbursed)}</td>
            <td className="py-1.5 pr-3 text-right text-ink-2">{fmtInr(r.utilized)}</td>
            <td className="py-1.5 pr-3 text-right font-semibold text-ink">{fmtPct(r.utilizationPct)}</td>
            {flagLabel && <td className="py-1.5 pr-3">{r.flag && <Badge tone="danger">{flagLabel}</Badge>}</td>}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
