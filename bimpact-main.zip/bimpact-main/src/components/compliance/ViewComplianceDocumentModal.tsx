"use client";

import { useEffect, useState } from "react";
import { ComplianceDocType, ComplianceDocument, DocumentReviewStatus } from "@/types/settings";
import { formatDateTime, formatValidityPeriod } from "@/components/partners/submission/shared";
import { getComplianceFile } from "@/lib/complianceFileStore";
import { useSettingsStore } from "@/store/settingsStore";
import { Button } from "@/components/ui/Button";
import { DocumentReasonDialog } from "./DocumentReasonDialog";

function isPreviewable(fileName: string): "pdf" | "image" | null {
  const ext = fileName.split(".").pop()?.toLowerCase();
  if (ext === "pdf") return "pdf";
  if (ext === "jpg" || ext === "jpeg" || ext === "png") return "image";
  return null;
}

const REVIEW_STATUS_STYLE: Record<DocumentReviewStatus, string> = {
  "Pending Review": "bg-amber-50 text-amber-600",
  "Changes Requested": "bg-amber-50 text-amber-600",
  Accepted: "bg-secondary-50 text-secondary-600",
  Rejected: "bg-danger-50 text-danger",
};

function DocumentReviewStatusBadge({ status }: { status: DocumentReviewStatus }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ${REVIEW_STATUS_STYLE[status]}`}
    >
      {status}
    </span>
  );
}

// Inline preview for a compliance document — stays on the Compliance page
// (a centered overlay, same pattern as CreateDocumentModal.tsx) rather than
// navigating away. Falls back to a plain download link for file types this
// app has no in-browser previewer for (doc/docx), matching how DocEditor's
// UploadedDocViewer already handles that same "no inline preview" case.
export function ViewComplianceDocumentModal({
  open,
  onClose,
  label,
  doc,
  review,
}: {
  open: boolean;
  onClose: () => void;
  label: string;
  doc: ComplianceDocument | null;
  // Presence enables the Sponsor's three document review CTAs (Reject
  // Document/Request Changes/Accept Document) plus this document's review
  // history — omitted entirely by the Partner's own read-only /compliance
  // page, which just never passes it, rather than a role check inside this
  // shared component.
  review?: { partnerId: string; documentType: ComplianceDocType };
}) {
  // The file's bytes live in IndexedDB (complianceFileStore.ts), keyed by
  // doc.fileId — fetched on demand here rather than kept in the
  // ComplianceDocument record itself (see that store's header comment for
  // why). Falls back to a legacy inline doc.fileUrl for any record saved
  // before fileId existed.
  const [resolvedUrl, setResolvedUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [reasonDialog, setReasonDialog] = useState<"reject" | "changes" | null>(null);
  const acceptComplianceDocument = useSettingsStore((s) => s.acceptComplianceDocument);
  const rejectComplianceDocument = useSettingsStore((s) => s.rejectComplianceDocument);
  const requestComplianceDocumentChanges = useSettingsStore((s) => s.requestComplianceDocumentChanges);
  const partnerHistory = useSettingsStore((s) => s.partnerHistory);

  useEffect(() => {
    if (!open || !doc) {
      setResolvedUrl(null);
      return;
    }
    if (doc.fileId) {
      let cancelled = false;
      setLoading(true);
      getComplianceFile(doc.fileId)
        .then((url) => {
          if (!cancelled) setResolvedUrl(url ?? null);
        })
        .catch(() => {
          if (!cancelled) setResolvedUrl(null);
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
      return () => {
        cancelled = true;
      };
    }
    setResolvedUrl(doc.fileUrl ?? null);
  }, [open, doc]);

  if (!open || !doc) return null;
  const kind = isPreviewable(doc.fileName);
  const reviewStatus: DocumentReviewStatus = doc.reviewStatus ?? "Pending Review";
  const validity = formatValidityPeriod(doc.validFrom, doc.validTill);
  // Every review action this document has ever received, newest first —
  // "Other" can hold several documents of the same type, so fileId
  // disambiguates which one's history this is (undefined/null fileId only
  // ever matches a legacy fileUrl-only record, itself unique enough there).
  const docHistory = review
    ? partnerHistory
        .filter(
          (h) =>
            h.partnerId === review.partnerId &&
            h.documentType === review.documentType &&
            h.activityType.startsWith("document_") &&
            (review.documentType !== "Other" || h.documentFileId === (doc.fileId ?? null))
        )
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    : [];

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center bg-ink/40 backdrop-blur-[1px]"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="flex h-[85vh] w-[720px] max-w-[92%] flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-lg">
        <div className="flex items-center justify-between border-b border-border bg-surface-2 px-6 py-4">
          <div>
            <h3 className="text-sm font-bold text-ink">{label}</h3>
            <p className="mt-0.5 text-xs text-muted">
              {doc.fileName} · Uploaded {formatDateTime(doc.uploadedAt)}
            </p>
            {/* Partner-declared validity of the certificate — null (and so
                skipped) when neither date was given; see
                ComplianceDocument.validFrom/validTill. */}
            {validity && <p className="mt-0.5 text-xs text-muted">{validity}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded p-1 text-xl leading-none text-muted hover:bg-surface"
          >
            ×
          </button>
        </div>

        {review && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-6 py-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wide text-muted">Status</span>
              <DocumentReviewStatusBadge status={reviewStatus} />
            </div>
            {/* Prominent, always-visible, not tucked behind a menu — the
                Sponsor can independently Accept/Reject/Request Changes for
                THIS document regardless of its current status (per spec, no
                extra workflow-locking rules beyond what already exists). */}
            <div className="flex flex-wrap items-center gap-2">
              <Button size="sm" variant="danger" onClick={() => setReasonDialog("reject")}>
                Reject Document
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setReasonDialog("changes")}>
                Request Changes
              </Button>
              <Button size="sm" onClick={() => acceptComplianceDocument(review.partnerId, review.documentType, doc.fileId)}>
                Accept Document
              </Button>
            </div>
          </div>
        )}

        {review && doc.review && (doc.review.action === "rejected" || doc.review.action === "changes_requested") && (
          <div className="border-b border-border bg-amber-50 px-6 py-3 text-[13px] text-amber-700">
            <span className="font-semibold">Reason: </span>
            {doc.review.reason}
            <span className="ml-2 text-amber-600">
              — {doc.review.performedBy.name || "Sponsor"}, {formatDateTime(doc.review.performedAt)}
            </span>
          </div>
        )}

        <div className="flex-1 overflow-auto bg-bg p-4">
          {loading && (
            <div className="flex h-full items-center justify-center text-sm text-muted">Loading document…</div>
          )}
          {!loading && kind === "pdf" && resolvedUrl && (
            <iframe src={resolvedUrl} title={doc.fileName} className="h-full w-full rounded border-none bg-white" />
          )}
          {!loading && kind === "image" && resolvedUrl && (
            <img src={resolvedUrl} alt={doc.fileName} className="mx-auto max-h-full rounded bg-white object-contain" />
          )}
          {!loading && !kind && (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
              <p className="text-sm font-semibold text-ink">Inline preview not available for this file type.</p>
              <p className="max-w-sm text-xs text-muted">
                {resolvedUrl
                  ? "Download the file to view it."
                  : "This document's file content isn't available to open."}
              </p>
              {resolvedUrl && (
                <a
                  href={resolvedUrl}
                  download={doc.fileName}
                  className="rounded-sm bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary-600"
                >
                  Download {doc.fileName}
                </a>
              )}
            </div>
          )}
          {!loading && kind && !resolvedUrl && (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
              <p className="text-sm font-semibold text-ink">This document's file content isn't available to open.</p>
            </div>
          )}

          {review && docHistory.length > 0 && (
            <div className="mt-4 rounded-lg border border-border bg-surface p-4">
              <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted">Review History</h4>
              <div className="flex flex-col gap-3">
                {docHistory.map((entry) => (
                  <div key={entry.id} className="border-l-2 border-border pl-3 text-[13px]">
                    <div className="font-semibold text-ink">
                      {entry.activityType === "document_accepted"
                        ? "Accepted"
                        : entry.activityType === "document_rejected"
                          ? "Rejected"
                          : "Changes Requested"}
                    </div>
                    <div className="text-xs text-muted">
                      {formatDateTime(entry.createdAt)} · By {entry.performedBy.name || "Sponsor"}
                    </div>
                    {entry.reason && <p className="mt-1 whitespace-pre-wrap break-words text-ink-2">{entry.reason}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {review && (
        <>
          <DocumentReasonDialog
            mode="reject"
            open={reasonDialog === "reject"}
            onClose={() => setReasonDialog(null)}
            onSubmit={(reason) => rejectComplianceDocument(review.partnerId, review.documentType, doc.fileId, reason)}
          />
          <DocumentReasonDialog
            mode="changes"
            open={reasonDialog === "changes"}
            onClose={() => setReasonDialog(null)}
            onSubmit={(reason) =>
              requestComplianceDocumentChanges(review.partnerId, review.documentType, doc.fileId, reason)
            }
          />
        </>
      )}
    </div>
  );
}
