"use client";

import { useRef, useState } from "react";
import { SlideOver } from "@/components/ui/SlideOver";
import { Button } from "@/components/ui/Button";
import { ACCEPTED_COMPLIANCE_ACCEPT, validateComplianceFile } from "@/lib/complianceUpload";

// Reused by every compliance document card (both "Upload" for an empty slot
// and "Replace" for an already-uploaded one) and by "Other Supporting
// Documents"' Add Document button — one upload surface, not a per-card copy.
export function UploadComplianceModal({
  open,
  onClose,
  label,
  // Only "Other Supporting Documents" asks for this — the 5 primary types
  // (12A/80G/CSR-1/GST/PAN) are unaffected, per spec.
  requireDocumentName = false,
  onUpload,
}: {
  open: boolean;
  onClose: () => void;
  // e.g. "12A Certificate" — used in the title and the confirmation copy.
  label: string;
  requireDocumentName?: boolean;
  onUpload: (
    file: File,
    documentName?: string,
    // The partner-declared validity period of the certificate. Both are
    // `YYYY-MM-DD` or undefined when left blank — optional because several
    // document types (PAN especially) never expire; see
    // ComplianceDocument.validFrom/validTill. When both are filled this
    // component has already checked validTill >= validFrom.
    validity?: { validFrom?: string; validTill?: string }
  ) => Promise<void> | void;
}) {
  const [documentName, setDocumentName] = useState("");
  const [validFrom, setValidFrom] = useState("");
  const [validTill, setValidTill] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  function reset() {
    setDocumentName("");
    setValidFrom("");
    setValidTill("");
    setFile(null);
    setError(null);
    setSubmitting(false);
    if (inputRef.current) inputRef.current.value = "";
  }
  function handleClose() {
    reset();
    onClose();
  }

  function handleFileChange(selected: File | null) {
    if (!selected) return;
    const validationError = validateComplianceFile(selected);
    if (validationError) {
      setError(validationError);
      setFile(null);
      return;
    }
    setError(null);
    setFile(selected);
  }

  async function handleUpload() {
    if (requireDocumentName && !documentName.trim()) {
      setError("Please enter document name.");
      return;
    }
    // Only meaningful when BOTH dates were given — either one alone is a
    // legitimate entry (an open-ended certificate, or an expiry the partner
    // knows without the issue date).
    if (validFrom && validTill && validTill < validFrom) {
      setError("Valid Till must be on or after Valid From.");
      return;
    }
    if (!file) {
      setError("Please select a file to upload.");
      return;
    }
    setSubmitting(true);
    try {
      await onUpload(file, requireDocumentName ? documentName.trim() : undefined, {
        validFrom: validFrom || undefined,
        validTill: validTill || undefined,
      });
      reset();
      onClose();
    } catch (err) {
      setSubmitting(false);
      setError(err instanceof Error && err.message ? err.message : "Unable to upload document. Please try again.");
    }
  }

  return (
    <SlideOver
      open={open}
      onClose={handleClose}
      title={`Upload ${label}`}
      footer={
        <>
          <Button variant="ghost" onClick={handleClose} disabled={submitting}>
            Cancel
          </Button>
          <Button onClick={handleUpload} disabled={submitting}>
            {submitting ? "Uploading…" : "Upload"}
          </Button>
        </>
      }
    >
      {requireDocumentName && (
        <div className="mb-4">
          <label className="mb-1.5 block text-[12.5px] font-semibold text-ink-2">
            Document Name <span className="text-danger">*</span>
          </label>
          <input
            value={documentName}
            onChange={(e) => setDocumentName(e.target.value)}
            placeholder="Enter document name"
            className="box-border h-10 w-full rounded-sm border-[1.5px] border-border bg-bg px-3 text-sm text-ink outline-none transition-colors focus:border-primary"
          />
        </div>
      )}

      {/* Validity period of the document itself — distinct from the upload
          timestamp the store records. Shown for EVERY compliance document
          type, including "Other Supporting Documents". Optional: a PAN card
          and similar never expire, so requiring an expiry would block a
          legitimate upload. */}
      <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <label className="mb-1.5 block text-[12.5px] font-semibold text-ink-2" htmlFor="compliance-valid-from">
            Valid From
          </label>
          <input
            id="compliance-valid-from"
            type="date"
            value={validFrom}
            // Keeps the native picker itself consistent with the check in
            // handleUpload, which still runs for typed-in dates.
            max={validTill || undefined}
            onChange={(e) => setValidFrom(e.target.value)}
            className="box-border h-10 w-full rounded-sm border-[1.5px] border-border bg-bg px-3 text-sm text-ink outline-none transition-colors focus:border-primary"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-[12.5px] font-semibold text-ink-2" htmlFor="compliance-valid-till">
            Valid Till
          </label>
          <input
            id="compliance-valid-till"
            type="date"
            value={validTill}
            min={validFrom || undefined}
            onChange={(e) => setValidTill(e.target.value)}
            className="box-border h-10 w-full rounded-sm border-[1.5px] border-border bg-bg px-3 text-sm text-ink outline-none transition-colors focus:border-primary"
          />
        </div>
      </div>
      <p className="mb-4 -mt-2 text-xs text-muted">
        Leave the validity dates blank if this document does not expire.
        <br />
        Accepted formats: PDF, DOC, DOCX, JPG, PNG.
        <br />
        Maximum file size: 1 MB per file.
      </p>

      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          handleFileChange(e.dataTransfer.files?.[0] ?? null);
        }}
        className="flex w-full flex-col items-center gap-2 rounded-lg border-2 border-dashed border-border-strong bg-bg px-4 py-8 text-center transition-colors hover:border-primary-100 hover:bg-primary-50"
      >
        <span className="text-sm font-semibold text-ink-2">Choose File</span>
        <span className="text-xs text-muted">or drag a file here</span>
      </button>
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED_COMPLIANCE_ACCEPT}
        className="hidden"
        onChange={(e) => handleFileChange(e.target.files?.[0] ?? null)}
      />

      {file && (
        <div className="mt-4 flex items-center justify-between gap-2 rounded-md border border-border bg-surface-2 px-3 py-2.5">
          <span className="min-w-0 flex-1 truncate text-sm font-medium text-ink">{file.name}</span>
          <button
            type="button"
            onClick={reset}
            className="shrink-0 text-xs font-semibold text-muted hover:text-danger"
          >
            Remove
          </button>
        </div>
      )}

      {error && <p className="mt-2 text-xs text-danger">{error}</p>}
    </SlideOver>
  );
}
