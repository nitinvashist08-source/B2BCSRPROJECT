"use client";

import { ComplianceDocument, DocumentReviewStatus } from "@/types/settings";
import { Button } from "@/components/ui/Button";
import { formatDateTime, formatValidityPeriod } from "@/components/partners/submission/shared";

// Exported so the Sponsor's Partner Compliance document list
// (ComplianceDocumentsSection.tsx) can show the same status colors inline,
// without opening this card/Document View — one status style source, not a
// second copy that could drift.
export const REVIEW_STATUS_STYLE: Record<DocumentReviewStatus, string> = {
  "Pending Review": "bg-amber-50 text-amber-600",
  "Changes Requested": "bg-amber-50 text-amber-600",
  Accepted: "bg-secondary-50 text-secondary-600",
  Rejected: "bg-danger-50 text-danger",
};

// One of the five required, single-slot compliance documents (12A/80G/
// CSR-1/GST/PAN). "Other Supporting Documents" has its own card in
// compliance/page.tsx since it holds a list, not a single doc.
export function ComplianceDocumentCard({
  label,
  doc,
  onUpload,
  onView,
}: {
  label: string;
  doc: ComplianceDocument | undefined;
  onUpload: () => void;
  onView: () => void;
}) {
  const uploaded = !!doc;
  // Undefined means "Pending Review" — every freshly uploaded/replaced
  // document starts there implicitly (see ComplianceDocument.reviewStatus's
  // own comment). Independent of the Uploaded/Pending pill above, which is
  // about whether a file exists at all, not the Sponsor's review of it.
  const reviewStatus: DocumentReviewStatus | null = uploaded ? doc.reviewStatus ?? "Pending Review" : null;
  const validity = uploaded ? formatValidityPeriod(doc.validFrom, doc.validTill) : null;

  return (
    <div className="flex flex-col gap-3 rounded-lg border border-border bg-surface p-5 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="text-sm font-bold text-ink">{label}</h3>
          <span
            className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ${
              uploaded ? "bg-secondary-50 text-secondary-600" : "bg-amber-50 text-amber-600"
            }`}
          >
            {uploaded ? "Uploaded" : "Pending"}
          </span>
          {reviewStatus && (
            <span
              className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ${REVIEW_STATUS_STYLE[reviewStatus]}`}
            >
              {reviewStatus}
            </span>
          )}
        </div>
        <p className="mt-1 text-xs text-muted">Required compliance document</p>
        {uploaded ? (
          <>
            <p className="mt-2 text-[13px] font-medium text-ink-2">
              {doc.fileName} <span className="text-muted">· {formatDateTime(doc.uploadedAt)}</span>
            </p>
            {/* Absent on documents uploaded before validity was captured,
                and on ones the partner declared as never expiring — the
                helper returns null there and the line is skipped entirely.  */}
            {validity && <p className="mt-0.5 text-[12.5px] text-muted">{validity}</p>}
          </>
        ) : (
          <p className="mt-2 text-[13px] text-muted">No document uploaded</p>
        )}
        {/* Sponsor's explanation, shown to the Partner — same "who/when"
            detail the Sponsor's own Document View shows (see
            ViewComplianceDocumentModal). */}
        {uploaded && doc.review && (doc.review.action === "rejected" || doc.review.action === "changes_requested") && (
          <p className="mt-2 max-w-md text-[13px] text-amber-700">
            <span className="font-semibold">Sponsor message: </span>
            {doc.review.reason}
          </p>
        )}
      </div>

      <div className="flex shrink-0 gap-2">
        {uploaded ? (
          <>
            <Button variant="ghost" size="sm" onClick={onView}>
              View
            </Button>
            <Button variant="ghost" size="sm" onClick={onUpload}>
              Replace
            </Button>
          </>
        ) : (
          <Button size="sm" onClick={onUpload}>
            Upload Document
          </Button>
        )}
      </div>
    </div>
  );
}
