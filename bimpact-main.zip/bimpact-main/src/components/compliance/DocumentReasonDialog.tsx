"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";

// Shared reason-entry dialog for the two document-level review decisions
// that require a mandatory explanation — Reject Document and Request
// Changes (Accept Document needs none, so it has no dialog at all, see
// ViewComplianceDocumentModal). Same single-purpose-per-mode shape as
// DeactivatePartnerDialog, just parameterized by `mode` since the two
// share an identical confirm/validate/submit flow and differ only in copy.
const COPY = {
  reject: {
    title: "Reject Document?",
    message: "Please provide a reason for rejecting this document.",
    label: "Reason for Rejection",
    placeholder: "Enter the reason for rejecting this document",
    error: "Please provide a reason for rejecting the document.",
    confirmLabel: "Reject Document",
    confirmVariant: "danger" as const,
  },
  changes: {
    title: "Request Changes",
    message: "Please provide an explanation describing what needs to be changed or resubmitted.",
    label: "Reason for Change Request",
    placeholder: "Describe what the partner needs to change or resubmit",
    error: "Please provide a reason for requesting changes.",
    confirmLabel: "Request Changes",
    confirmVariant: "primary" as const,
  },
};

export function DocumentReasonDialog({
  mode,
  open,
  onClose,
  onSubmit,
}: {
  mode: "reject" | "changes";
  open: boolean;
  onClose: () => void;
  // Called with the trimmed, already-validated reason — the caller runs the
  // actual guarded store action (rejectComplianceDocument/
  // requestComplianceDocumentChanges), which re-validates independently.
  onSubmit: (reason: string) => void;
}) {
  const [reason, setReason] = useState("");
  const [error, setError] = useState(false);
  const copy = COPY[mode];

  function handleClose() {
    onClose();
    // Deferred so the dialog doesn't visibly flip back to blank during its
    // own close transition.
    setTimeout(() => {
      setReason("");
      setError(false);
    }, 200);
  }

  function handleSubmit() {
    const trimmed = reason.trim();
    if (!trimmed) {
      setError(true);
      return;
    }
    onSubmit(trimmed);
    handleClose();
  }

  return (
    <Modal
      open={open}
      onClose={handleClose}
      title={copy.title}
      footer={
        <>
          <Button variant="ghost" onClick={handleClose}>
            Cancel
          </Button>
          <Button variant={copy.confirmVariant} onClick={handleSubmit}>
            {copy.confirmLabel}
          </Button>
        </>
      }
    >
      <p>{copy.message}</p>
      <label className="mt-3 block text-sm">
        <span className="mb-1 block font-medium text-ink-2">{copy.label}</span>
        <textarea
          value={reason}
          onChange={(e) => {
            setReason(e.target.value);
            if (error) setError(false);
          }}
          placeholder={copy.placeholder}
          rows={3}
          className={`w-full rounded-sm border px-3 py-2 text-sm outline-none focus:border-primary ${
            error ? "border-danger" : "border-border"
          }`}
        />
        {error && <p className="mt-1.5 text-xs text-danger">{copy.error}</p>}
      </label>
    </Modal>
  );
}
