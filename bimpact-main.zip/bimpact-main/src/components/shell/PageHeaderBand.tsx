import { ReactNode } from "react";

function DefaultIcon() {
  return (
    <svg fill="none" height="15" width="15" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14" />
      <path d="M12 2v2M12 20v2M2 12h2M20 12h2" />
    </svg>
  );
}

// Standardized module-level page header: icon + title + description, same
// height/padding/border wherever it's used (Settings' 5 sections, and the
// standalone Partners module). Section-specific content headers (e.g.
// "Projects & Activities") render below this, inside each page's own
// component — unchanged. Icon at bImpact_MeetingSplit_v10.html:8097-8099.
export function PageHeaderBand({
  title,
  sub,
  icon,
  right,
  className = "",
}: {
  title: string;
  sub: string;
  icon?: ReactNode;
  right?: ReactNode;
  // Per-instance background/spacing override — e.g. Partners' layout passes
  // a white, full-bleed treatment matching the source HTML's .st-topbar
  // (background: var(--surface), edge-to-edge) without changing every other
  // page that renders this same shared band (Settings' sections keep the
  // default transparent/inherited background).
  className?: string;
}) {
  return (
    <div className={`mb-6 flex items-center gap-4 border-b border-border pb-5 ${className}`}>
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-border bg-bg text-ink-2">
        {icon ?? <DefaultIcon />}
      </span>
      <div className="min-w-0">
        <div className="text-base font-bold text-ink">{title}</div>
        <div className="mt-0.5 text-xs text-muted">{sub}</div>
      </div>
      {right}
    </div>
  );
}
