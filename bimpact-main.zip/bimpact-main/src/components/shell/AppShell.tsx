"use client";

import { ReactNode, useEffect } from "react";
import { usePathname } from "next/navigation";
import { useShellStore } from "@/store/shellStore";
import { useSessionStore } from "@/store/sessionStore";
import { loadLocal } from "@/lib/localPersist";
import { AUTH_TRANSITION_PATH, getDashboardPathForRole } from "@/lib/roleRouting";
import { isPartnerOnlyPath, isSponsorOnlyPath } from "@/lib/permissions";
import { DataBootstrap } from "./DataBootstrap";
import { Brand } from "./Brand";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";

const PUBLIC_PREFIXES = [
  "/about",
  "/contact",
  "/pricing",
  "/privacy",
  "/terms",
  "/register",
  "/login",
  "/partner-onboarding",
  "/beneficiary-form",
];

function isPublicPath(pathname: string): boolean {
  if (pathname === "/") return true;
  return PUBLIC_PREFIXES.some((p) => pathname === p || pathname.startsWith(p + "/"));
}

// /partner-onboarding is public (an external partner clicking an invite
// email link has no session at all) but still needs settingsStore hydrated
// to validate the invite token against seeded/persisted partners — without
// DataBootstrap it would silently see only the store's empty initial state
// and every lookup would fail. /login needs it for the same reason: the
// unified login form's role auto-detection (sessionStore.loginWithCredentials)
// looks the entered email up against settingsStore's partner directory to
// decide sponsor vs. partner — with settingsStore still at its empty default
// (unhydrated), every partner email would silently fall through to "sponsor".
// "/beneficiary-form" needs the same treatment: an anonymous respondent has
// no session at all, but the page still has to resolve the share token
// against projectStore's indicatorFormShareLinks/indicatorForms — without
// DataBootstrap it would only ever see each store's empty pre-hydration
// default.
const PUBLIC_DATA_PREFIXES = ["/partner-onboarding", "/login", "/beneficiary-form"];

function needsPublicData(pathname: string): boolean {
  return PUBLIC_DATA_PREFIXES.some((p) => pathname === p || pathname.startsWith(p + "/"));
}

// /onboarding is intentionally NOT public — reaching it must still require
// being authenticated (and, for email signups, verified), same as any other
// protected route. It's special-cased instead: the guard's own "not yet
// onboarded -> /onboarding" redirect is suppressed while already on this
// page (avoiding a self-redirect reload loop), and once authenticated +
// verified it renders standalone (no Sidebar/Header), same as /register.
function isOnboardingPath(pathname: string): boolean {
  return pathname === "/onboarding" || pathname.startsWith("/onboarding/");
}

function FullScreenLoading() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-bg">
      <span
        className="flex h-9 w-9 items-center justify-center rounded-[9px] text-[14px] font-extrabold tracking-tight text-white"
        style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
      >
        bI
      </span>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const density = useShellStore((s) => s.density);
  const sessionHydrated = useSessionStore((s) => s.hydrated);
  const hydrateSession = useSessionStore((s) => s.hydrate);
  const authenticated = useSessionStore((s) => s.authenticated);
  const justLoggedOut = useSessionStore((s) => s.justLoggedOut);
  const clearJustLoggedOut = useSessionStore((s) => s.clearJustLoggedOut);
  const authMethod = useSessionStore((s) => s.authMethod);
  const emailVerified = useSessionStore((s) => s.emailVerified);
  const onboardingComplete = useSessionStore((s) => s.onboardingComplete);
  const role = useSessionStore((s) => s.role);

  useEffect(() => {
    hydrateSession(loadLocal("session", {}));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const publicPath = isPublicPath(pathname);
  const onboardingPath = isOnboardingPath(pathname);
  // /auth/loading is a brief post-login transition screen (owned by another
  // agent) that itself decides where to hard-navigate next once it has read
  // the freshly-set role from useSessionStore. It is NOT public — reaching
  // it still requires being authenticated — but once authenticated the
  // guard must not fight its own navigation, so every later stage below
  // (verification, onboarding, role) is skipped while on this exact path.
  const isAuthTransitionPath = pathname === AUTH_TRANSITION_PATH;

  // The single navigation authority for the protected-route guard, checked
  // in stage order: unauthenticated -> /login (or / if just logged out,
  // handling both direct/deep-link access and an explicit logout that just
  // happened); authenticated-but-unverified email signup -> /register/verify;
  // authenticated-and-verified-but-not-onboarded -> /onboarding (suppressed
  // while already there, to avoid redirecting a page to itself);
  // authenticated + verified + onboarded but on a route the session's role
  // isn't allowed on -> that role's own dashboard (getDashboardPathForRole),
  // e.g. a partner pasting /finance into the address bar is bounced back to
  // /partner-workspace, a sponsor pasting /partner-workspace is bounced back
  // to /dashboard. Hard navigation, not router.replace — Next's client-side
  // transition across these boundaries proved unreliable in testing (every
  // crossing in this app uses window.location for the same reason:
  // RoleLoginForm, register/page.tsx, app/page.tsx).
  useEffect(() => {
    if (!sessionHydrated || publicPath) return;
    if (!authenticated) {
      window.location.href = justLoggedOut ? "/" : "/login";
    } else if (isAuthTransitionPath) {
      // let it manage its own navigation
    } else if (authMethod === "email" && !emailVerified) {
      // eslint-disable-next-line @next/next/no-location-assign-relative-destination
      window.location.href = "/register/verify";
    } else if (!onboardingComplete && !onboardingPath) {
      // eslint-disable-next-line @next/next/no-location-assign-relative-destination
      window.location.href = "/onboarding";
    } else if (role === "partner" && isSponsorOnlyPath(pathname)) {
      window.location.href = getDashboardPathForRole(role);
    } else if (role === "sponsor" && isPartnerOnlyPath(pathname)) {
      window.location.href = getDashboardPathForRole(role);
    }
  }, [
    sessionHydrated,
    publicPath,
    authenticated,
    justLoggedOut,
    isAuthTransitionPath,
    authMethod,
    emailVerified,
    onboardingComplete,
    onboardingPath,
    role,
    pathname,
  ]);

  // Clears the one-shot flag once we've actually landed on a public path.
  // Harmless no-op in the logout case above (the hard navigation tears this
  // page down before it would fire), kept for any other future caller that
  // sets justLoggedOut without a hard nav.
  useEffect(() => {
    if (publicPath && justLoggedOut) clearJustLoggedOut();
  }, [publicPath, justLoggedOut, clearJustLoggedOut]);

  if (!sessionHydrated) return <FullScreenLoading />;
  if (publicPath) {
    if (needsPublicData(pathname)) return <DataBootstrap>{children}</DataBootstrap>;
    return <>{children}</>;
  }
  if (!authenticated) return <FullScreenLoading />;
  // Renders standalone (no Sidebar/Header) and skips every later guard
  // stage below — see the isAuthTransitionPath comment above the effect.
  if (isAuthTransitionPath) return <>{children}</>;
  if (authMethod === "email" && !emailVerified) return <FullScreenLoading />;
  if (!onboardingComplete) {
    // Renders standalone (no Sidebar/Header), same as a public auth page —
    // any other not-yet-onboarded protected route already redirected here.
    // Still wrapped in DataBootstrap (unlike /register/*): the onboarding
    // page reads real team/partner/committee/project counts to snapshot the
    // new workspace's checklist baseline, which needs the demo data actually
    // hydrated first, not the stores' empty pre-hydration defaults.
    if (onboardingPath) return <DataBootstrap>{children}</DataBootstrap>;
    return <FullScreenLoading />;
  }
  // Role/path mismatch: the effect above is already issuing the hard
  // redirect to this role's own dashboard — render a blank loading state
  // in the meantime instead of flashing the disallowed page's content.
  if (role === "partner" && isSponsorOnlyPath(pathname)) return <FullScreenLoading />;
  if (role === "sponsor" && isPartnerOnlyPath(pathname)) return <FullScreenLoading />;

  return (
    <DataBootstrap>
      <div
        className="grid min-h-screen max-w-[100vw] overflow-hidden"
        style={{
          gridTemplateColumns: "220px 1fr",
          gridTemplateRows: "68px 1fr",
          gridTemplateAreas: '"brand header" "sidebar main"',
        }}
        data-density={density}
      >
        <div style={{ gridArea: "brand" }}>
          <Brand />
        </div>
        <div style={{ gridArea: "header" }}>
          <Header />
        </div>
        <div style={{ gridArea: "sidebar" }} className="overflow-hidden">
          <Sidebar />
        </div>
        <main style={{ gridArea: "main" }} className="overflow-y-auto bg-bg p-6">
          {children}
        </main>
      </div>
    </DataBootstrap>
  );
}
