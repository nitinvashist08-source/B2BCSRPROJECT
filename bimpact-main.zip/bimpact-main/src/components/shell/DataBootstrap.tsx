"use client";

import { ReactNode, useEffect, useState } from "react";
import { useMeetingStore } from "@/store/meetingStore";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore } from "@/store/financeStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useDashboardStore } from "@/store/dashboardStore";
import { useDashboardLayoutStore } from "@/store/dashboardLayoutStore";
import { useWorkspaceStore } from "@/store/workspaceStore";
import { useAlertStore } from "@/store/alertStore";
import { loadLocal, subscribeToStorageChanges } from "@/lib/localPersist";
import { migrateInlineComplianceFiles } from "@/lib/complianceFileStore";
import { migrateLegacyComplianceDocumentTypes } from "@/lib/complianceLegacyMigration";
import { meetingSeedData } from "@/data/meetingData";
import { projectSeedData } from "@/data/projectData";
import { financeSeedData } from "@/data/financeData";
import { settingsSeedData } from "@/data/settingsData";
import { dashboardSeedData } from "@/data/dashboardData";
import { workspaceSeedData } from "@/data/workspaceData";

// No backend: every store hydrates from localStorage if a previous session
// already saved something there, otherwise from the bundled sample data
// (src/data/*.ts). See src/lib/localPersist.ts.
export function DataBootstrap({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const hydrateMeetings = useMeetingStore((s) => s.hydrate);
  const hydrateProjects = useProjectStore((s) => s.hydrate);
  const hydrateFinance = useFinanceStore((s) => s.hydrate);
  const hydrateSettings = useSettingsStore((s) => s.hydrate);
  const hydrateDashboard = useDashboardStore((s) => s.hydrate);
  const hydrateDashboardLayout = useDashboardLayoutStore((s) => s.hydrate);
  const hydrateWorkspace = useWorkspaceStore((s) => s.hydrate);
  const hydrateAlerts = useAlertStore((s) => s.hydrate);

  useEffect(() => {
    let cancelled = false;

    async function bootstrap() {
      hydrateMeetings(loadLocal("meetings", meetingSeedData));
      hydrateProjects(loadLocal("projects", projectSeedData));
      hydrateFinance(loadLocal("finance", financeSeedData));
      hydrateSettings(loadLocal("settings", settingsSeedData));
      hydrateDashboard(loadLocal("dashboard", dashboardSeedData));
      hydrateDashboardLayout(loadLocal("dashboardLayout", { layoutsByKey: {} }));
      hydrateWorkspace(loadLocal("workspace", workspaceSeedData));
      hydrateAlerts(loadLocal("alerts", { alerts: [] }));
      if (!cancelled) setReady(true);

      // Fire-and-forget, after the app is already showing — shrinks any
      // pre-existing compliance documents saved with an inline fileUrl
      // (from before IndexedDB storage existed) back down to a small
      // fileId reference, which is what actually stops "storage limit
      // reached" from recurring on a browser that already has old bloated
      // entries sitting in localStorage. See complianceFileStore.ts.
      migrateInlineComplianceFiles().catch((err) => {
        console.error("Compliance file migration failed", err);
      });

      // Fire-and-forget, same as above — rewrites any compliance
      // document/history saved under the old fixed 6-code type scheme to
      // the new catalog item ids. See complianceLegacyMigration.ts.
      migrateLegacyComplianceDocumentTypes().catch((err) => {
        console.error("Compliance document type migration failed", err);
      });
    }

    bootstrap();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Same-browser, cross-tab live sync (e.g. a Sponsor tab and a Partner tab
  // open side by side) — see subscribeToStorageChanges's own comment for
  // why this is needed at all. Re-runs the SAME hydrate each key already
  // uses on initial load, just fed the freshly-changed value instead of
  // loadLocal's own read, so migration/normalization never drifts between
  // the two paths. Falls back to that key's seed data on a missing/
  // unparsable value, matching loadLocal's own fallback behavior.
  useEffect(() => {
    // Same "trust the parsed JSON, no runtime schema validation" convention
    // this app already uses everywhere else it reads its own localStorage
    // (see loadLocal's `as T` cast) — each store's own hydrate is what
    // actually normalizes/tolerates shape drift.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const hydrators: Record<string, (raw: any) => void> = {
      meetings: hydrateMeetings,
      projects: hydrateProjects,
      finance: hydrateFinance,
      settings: hydrateSettings,
      dashboard: hydrateDashboard,
      dashboardLayout: hydrateDashboardLayout,
      workspace: hydrateWorkspace,
      alerts: hydrateAlerts,
    };
    const fallbacks: Record<string, unknown> = {
      meetings: meetingSeedData,
      projects: projectSeedData,
      finance: financeSeedData,
      settings: settingsSeedData,
      dashboard: dashboardSeedData,
      dashboardLayout: { layoutsByKey: {} },
      workspace: workspaceSeedData,
      alerts: { alerts: [] },
    };

    return subscribeToStorageChanges((key, raw) => {
      const hydrate = hydrators[key];
      if (!hydrate) return;
      if (raw == null) {
        hydrate(fallbacks[key]);
        return;
      }
      try {
        hydrate(JSON.parse(raw));
      } catch (err) {
        console.error(`Failed to apply cross-tab update for "${key}"`, err);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Alerts have no server/scheduler to fire them at an exact threshold
  // moment (this app has none — see alertRules.ts's header comment), so
  // evaluate() recomputes every derived rule fresh: once right after
  // hydration, then every 5 minutes while the tab stays open. This is the
  // closest this no-backend app can get to "dynamic" alerts — always
  // correct the moment someone looks, never silently stale for a session
  // that's been open a while.
  useEffect(() => {
    if (!ready) return;
    const evaluate = useAlertStore.getState().evaluate;
    evaluate();
    const interval = setInterval(evaluate, 5 * 60_000);
    return () => clearInterval(interval);
  }, [ready]);

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-bg">
        <p className="text-sm text-muted">Loading…</p>
      </div>
    );
  }

  return <>{children}</>;
}
