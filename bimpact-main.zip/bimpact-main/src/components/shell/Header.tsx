"use client";

import { useShellStore } from "@/store/shellStore";
import { useSessionStore } from "@/store/sessionStore";
import { useSettingsStore } from "@/store/settingsStore";
import { Dropdown, DropdownItem } from "@/components/ui/Dropdown";
import { resolveDisplayName } from "@/lib/userDisplay";

function initialsFor(name: string, email: string | null): string {
  const words = name.trim().split(/\s+/).filter(Boolean);
  if (words.length >= 2) return (words[0][0] + words[words.length - 1][0]).toUpperCase();
  if (words.length === 1 && words[0].length > 0) return words[0].slice(0, 2).toUpperCase();
  if (email) return email[0].toUpperCase();
  return "?";
}

function SearchIcon() {
  return (
    <svg
      className="pointer-events-none absolute left-[14px] top-1/2 -translate-y-1/2 text-muted-2"
      fill="none"
      height="18"
      width="18"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      viewBox="0 0 24 24"
    >
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.5-3.5" />
    </svg>
  );
}

function ChevronDownIcon() {
  return (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

export function Header() {
  const jobRole = useShellStore((s) => s.role);
  const logout = useSessionStore((s) => s.logout);
  const sessionRole = useSessionStore((s) => s.role);
  const sessionName = useSessionStore((s) => s.name);
  const sessionEmail = useSessionStore((s) => s.email);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const partners = useSettingsStore((s) => s.partners);

  // AppShell's redirect effect is the sole navigator after logout (it sees
  // `justLoggedOut` and sends the user to "/" instead of "/login") — no
  // router.push here, to avoid racing that effect.
  function handleLogout() {
    logout();
  }

  const isPartner = sessionRole === "partner";
  const displayName = resolveDisplayName(sessionName, sessionEmail);
  const initials = initialsFor(displayName, sessionEmail);
  const partnerOrgName = isPartner
    ? partners.find((p) => p.id === partnerOrgId)?.name
    : undefined;

  return (
    <header className="flex h-full items-center gap-5 border-b border-border bg-surface px-7">
      <form className="relative max-w-[460px] flex-1" onSubmit={(e) => e.preventDefault()} role="search">
        <SearchIcon />
        <input
          type="search"
          placeholder="Search projects, activities…"
          className="h-10 w-full rounded-[10px] border border-border bg-bg pl-[42px] pr-3.5 text-sm text-ink outline-none transition-all focus:border-primary focus:bg-surface focus:shadow-[0_0_0_4px_rgba(10,151,217,0.12)]"
        />
        <span className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 rounded-md border border-border bg-surface px-[7px] py-[3px] text-[11px] font-medium text-muted">
          ⌘K
        </span>
      </form>

      <div className="ml-auto flex items-center gap-2">
        <Dropdown
          trigger={
            <button className="flex items-center gap-2.5 rounded-[10px] py-1.5 pl-1.5 pr-3 transition-colors hover:bg-bg">
              <span
                className="flex h-9 w-9 items-center justify-center rounded-full text-[13px] font-semibold text-white"
                style={{ background: "linear-gradient(135deg, var(--color-primary), var(--color-primary-600))" }}
              >
                {initials}
              </span>
              <span className="flex flex-col text-left leading-tight">
                <span className="text-[13.5px] font-semibold text-ink">{displayName}</span>
                <span className="text-xs text-muted">
                  {isPartner ? `Invited Partner${partnerOrgName ? ` · ${partnerOrgName}` : ""}` : jobRole}
                </span>
              </span>
              <ChevronDownIcon />
            </button>
          }
        >
          <DropdownItem onClick={handleLogout}>Log out</DropdownItem>
        </Dropdown>
      </div>
    </header>
  );
}
