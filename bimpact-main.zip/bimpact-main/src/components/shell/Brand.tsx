export function Brand() {
  return (
    <div className="flex h-full items-center justify-center border-r border-b border-border bg-surface">
      <div
        className="flex h-9 w-9 items-center justify-center rounded-[9px] text-[14px] font-extrabold tracking-tight text-white"
        style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
      >
        bI
      </div>
    </div>
  );
}
