"use client";

import { ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useShellStore } from "@/store/shellStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { useProjectStore } from "@/store/projectStore";
import { useAlertStore } from "@/store/alertStore";
import { filterNavGroupsForRole } from "@/lib/permissions";
import { isAlertVisible } from "@/lib/alertVisibility";

function DashboardIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="8" rx="1" width="7" x="3" y="3" />
      <rect height="5" rx="1" width="7" x="14" y="3" />
      <rect height="5" rx="1" width="7" x="14" y="12" />
      <rect height="8" rx="1" width="7" x="3" y="13" />
    </svg>
  );
}

function WorkplaceIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="14" rx="2" width="20" x="2" y="7" />
      <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
    </svg>
  );
}

function FinanceIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="14" rx="2" width="20" x="2" y="5" />
      <line x1="2" x2="22" y1="10" y2="10" />
    </svg>
  );
}

// Partner-side-only nav icon (Compliance) — a shield with a check mark,
// same 17x17/stroke-currentColor/strokeWidth-2 visual language as every
// other icon in this file.
function ComplianceIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <path d="M9 12l2 2 4-4" />
    </svg>
  );
}

function ManagementIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="18" rx="2" width="18" x="3" y="4" />
      <line x1="16" x2="16" y1="2" y2="6" />
      <line x1="8" x2="8" y1="2" y2="6" />
      <line x1="3" x2="21" y1="10" y2="10" />
      <path d="M8 14h.01" />
      <path d="M12 14h.01" />
      <path d="M16 14h.01" />
      <path d="M8 18h.01" />
      <path d="M12 18h.01" />
    </svg>
  );
}

function AlertsIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
      <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
    </svg>
  );
}

function ReportingIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="18" y1="20" y2="10" />
      <line x1="12" x2="12" y1="20" y2="4" />
      <line x1="6" x2="6" y1="20" y2="14" />
    </svg>
  );
}

function SettingsIcon() {
  return (
    <svg fill="none" height="17" width="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}

function ExpandIcon({ open }: { open: boolean }) {
  return (
    <svg
      aria-hidden="true"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      viewBox="0 0 24 24"
      className={`ml-auto h-4 w-4 shrink-0 transition-transform duration-200 ${open ? "rotate-180" : ""}`}
    >
      <path d="M6 9l6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function PartnersIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

function UsersIcon() {
  return (
    <svg fill="none" height="13" width="13" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

type NavGroup = {
  label: string;
  items: {
    href: string;
    label: string;
    icon: ReactNode;
    dot?: boolean;
    badge?: number;
    sub?: { href: string; label: string; icon?: ReactNode; badge?: number }[];
  }[];
};

// Full sponsor nav — every item here lives under a sponsor-only path prefix
// (see src/lib/permissions.ts), i.e. an org's own team managing its CSR
// program: dashboard, workplace/projects, finance, board meetings, the
// partner directory, alerts, reporting, and settings.
const SPONSOR_NAV_GROUPS: NavGroup[] = [
  {
    label: "Main",
    items: [
      { href: "/dashboard", label: "Dashboard", icon: <DashboardIcon /> },
      { href: "/projects", label: "Workplace", icon: <WorkplaceIcon /> },
      {
        href: "/finance",
        label: "Finance",
        icon: <FinanceIcon />,
        sub: [
          { href: "/finance/hlp", label: "Budget Planning" },
          { href: "/finance/micro", label: "Micro-Budgeting" },
          { href: "/finance/expense", label: "Expense Booking" },
          { href: "/finance/disbursement", label: "Disbursement planning" },
        ],
      },
      { href: "/meetings", label: "Board Management", icon: <ManagementIcon /> },
      { href: "/partners", label: "Partners", icon: <PartnersIcon /> },
    ],
  },
  {
    label: "System",
    items: [
      { href: "/alerts", label: "Alerts", icon: <AlertsIcon /> },
      { href: "/reporting", label: "Reporting", icon: <ReportingIcon /> },
      {
        href: "/settings",
        label: "Settings",
        icon: <SettingsIcon />,
        sub: [{ href: "/settings/user", label: "Users", icon: <UsersIcon /> }],
      },
    ],
  },
];

// Reduced nav for the "partner" session role (which every external
// collaborator type — Partner / NGO / Implementing Partner / Co-Sponsor —
// maps to, per the product spec). None of the sponsor's org-management
// modules below (Board Management/Partners/Alerts/Reporting/Settings) apply
// to an external partner, so this is intentionally not a filtered-down copy
// of SPONSOR_NAV_GROUPS. Dashboard/Workplace/Finance all point at the exact
// same routes sponsors use — Dashboard is identical/unrestricted (explicit
// product direction), Workplace's ProjectsTable.tsx filters the list and
// hides Create Project for the partner role itself, and each Finance
// module filters to the partner's assigned projects and hides
// create/edit/delete/approve/release actions (see permissions.ts's comment
// for the full list of components involved).
const PARTNER_NAV_GROUPS: NavGroup[] = [
  {
    label: "Main",
    items: [
      { href: "/dashboard", label: "Dashboard", icon: <DashboardIcon /> },
      { href: "/projects", label: "Workplace", icon: <WorkplaceIcon /> },
      {
        href: "/finance",
        label: "Finance",
        icon: <FinanceIcon />,
        sub: [
          { href: "/finance/hlp", label: "Budget Planning" },
          { href: "/finance/micro", label: "Micro-Budgeting" },
          { href: "/finance/expense", label: "Expense Booking" },
          { href: "/finance/disbursement", label: "Disbursement planning" },
        ],
      },
      // Partner-only document-management workspace — see
      // src/app/compliance/page.tsx and src/lib/permissions.ts's
      // PARTNER_ONLY_PREFIXES (never added to SPONSOR_NAV_GROUPS above).
      { href: "/compliance", label: "Compliance", icon: <ComplianceIcon /> },
    ],
  },
  {
    label: "System",
    items: [
      // Same page/route as the Sponsor's own Alerts item below — content is
      // live-filtered per role/project access (see alertVisibility.ts), not
      // a separate page.
      { href: "/alerts", label: "Alerts", icon: <AlertsIcon /> },
      {
        href: "/settings",
        label: "Settings",
        icon: <SettingsIcon />,
        // Only Users for this iteration — a Partner org's own internal team
        // (settingsStore's partnerTeamMembers, scoped to partnerOrgId), not
        // a filtered-down copy of the Sponsor's Settings sub-items.
        sub: [{ href: "/settings/user", label: "Users", icon: <UsersIcon /> }],
      },
    ],
  },
];

export function Sidebar() {
  const pathname = usePathname();
  const { financeSubnavOpen, settingsSubnavOpen, toggleFinanceSubnav, toggleSettingsSubnav } =
    useShellStore();
  const partnerCount = useSettingsStore((s) => s.partners.length);
  const sponsorUserCount = useSettingsStore((s) => s.teamMembers.length);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const partnerUserCount = useSettingsStore(
    (s) => s.partnerTeamMembers.filter((m) => m.partnerOrgId === partnerOrgId).length
  );
  // "/settings/user" is a shared href between the two nav arrays above, so
  // its badge count must be sourced from the role-appropriate list — a
  // partner must never see the Sponsor's own teamMembers count (or vice
  // versa) next to their Users link.
  const userCount = role === "partner" ? partnerUserCount : sponsorUserCount;

  // Unread Alerts count (spec: "Alerts ⑤", no badge at all when zero) —
  // same visibility rule the Alerts page itself uses, so the sidebar number
  // always matches what opening the page would actually show.
  const alerts = useAlertStore((s) => s.alerts);
  const partnerName = useSettingsStore((s) => s.partners.find((p) => p.id === partnerOrgId)?.name ?? null);
  const workspaceId = useSessionStore((s) => s.workspaceId);
  const projects = useProjectStore((s) => s.projects);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const allPartners = useSettingsStore((s) => s.partners);
  const unreadAlertCount = alerts.filter(
    (a) =>
      !a.isRead &&
      isAlertVisible(a, { role, partnerOrgId, partnerName, workspaceId, projects, projectPartners, partners: allPartners })
  ).length;

  const badgeByHref: Record<string, number | undefined> = {
    "/partners": partnerCount,
    "/settings/user": userCount,
    "/alerts": unreadAlertCount > 0 ? unreadAlertCount : undefined,
  };

  // filterNavGroupsForRole is a safety net here (both arrays above already
  // only contain paths their own role is allowed on) — it guards against a
  // future edit accidentally adding a sponsor-only href to the partner nav
  // (or vice versa) without updating permissions.ts to match.
  const navGroups = filterNavGroupsForRole(
    role === "partner" ? PARTNER_NAV_GROUPS : SPONSOR_NAV_GROUPS,
    role
  );

  return (
    <nav className="flex h-full flex-col items-start gap-0.5 overflow-y-auto overflow-x-hidden border-r border-border bg-surface px-2.5 py-4">
      {navGroups.map((group, groupIdx) => (
        <div key={group.label} className="w-full">
          <div
            className={`w-full px-2.5 pb-[5px] pt-3.5 text-left text-[10px] font-bold uppercase tracking-wide text-muted-2 ${
              groupIdx > 0 ? "border-t border-border" : ""
            }`}
          >
            {group.label}
          </div>
          {group.items.map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + "/");
            const isFinance = item.href === "/finance";
            const isSettings = item.href === "/settings";
            const subOpen = isFinance ? financeSubnavOpen : settingsSubnavOpen;

            return (
              <div key={item.href} className="w-full">
                <Link
                  href={item.href}
                  onClick={() => {
                    if (isFinance) toggleFinanceSubnav();
                    if (isSettings) toggleSettingsSubnav();
                  }}
                  className={`relative flex min-h-10 w-full items-center gap-2.5 rounded-[9px] px-3 py-2 text-[13px] font-medium transition-colors ${
                    active
                      ? "bg-primary-50 font-semibold text-primary-700 [&_svg]:text-primary"
                      : "text-muted hover:bg-bg hover:text-ink-2 [&_svg]:text-muted [&:hover_svg]:text-primary"
                  }`}
                >
                  {active && (
                    <span className="absolute inset-y-[7px] left-0 w-[3px] rounded-r-[3px] bg-gradient-to-b from-primary to-primary-600" />
                  )}
                  {item.icon}
                  <span className="flex-1">{item.label}</span>
                  {item.dot && <span className="h-[7px] w-[7px] shrink-0 rounded-full border-2 border-surface bg-secondary" />}
                  {badgeByHref[item.href] !== undefined && (
                    <span
                      className={`flex h-[18px] min-w-[18px] items-center justify-center rounded-full border px-1.5 text-[10.5px] font-bold ${
                        active ? "border-primary bg-primary text-white" : "border-border bg-bg text-muted"
                      }`}
                    >
                      {badgeByHref[item.href]}
                    </span>
                  )}
                  {item.sub && <ExpandIcon open={subOpen} />}
                </Link>
                {item.sub && subOpen && (
                  <div className="flex w-full flex-col gap-px py-[3px]">
                    {item.sub.map((sub) => {
                      const subActive = pathname === sub.href;
                      const badge = badgeByHref[sub.href];
                      return (
                        <Link
                          key={sub.href}
                          href={sub.href}
                          className={`relative flex items-center gap-2 rounded-lg py-[7px] pl-8 pr-3 text-[12.5px] font-medium transition-colors ${
                            subActive
                              ? "bg-primary-50 font-semibold text-primary-700 [&_svg]:text-primary"
                              : "text-muted hover:bg-bg hover:text-ink-2 [&_svg]:text-muted-2"
                          }`}
                        >
                          {subActive && (
                            <span className="absolute inset-y-1.5 left-0 w-[3px] rounded-r-[3px] bg-primary" />
                          )}
                          {sub.icon}
                          <span>{sub.label}</span>
                          {badge !== undefined && (
                            <span
                              className={`ml-auto flex h-[18px] min-w-[18px] items-center justify-center rounded-full border px-1.5 text-[10.5px] font-bold ${
                                subActive
                                  ? "border-primary bg-primary text-white"
                                  : "border-border bg-bg text-muted"
                              }`}
                            >
                              {badge}
                            </span>
                          )}
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </nav>
  );
}
