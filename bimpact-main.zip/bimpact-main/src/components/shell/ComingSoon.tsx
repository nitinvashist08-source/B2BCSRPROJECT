export function ComingSoon({ title }: { title: string }) {
  return (
    <div className="flex h-full min-h-[400px] flex-col items-center justify-center rounded-lg border border-dashed border-border-strong bg-surface text-center">
      <h2 className="text-lg font-semibold text-ink">{title}</h2>
      <p className="mt-1 max-w-sm text-sm text-muted">
        This section is coming in a later phase of the Next.js migration.
      </p>
    </div>
  );
}
