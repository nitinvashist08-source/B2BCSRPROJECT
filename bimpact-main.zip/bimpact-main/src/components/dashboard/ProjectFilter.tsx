"use client";

import { useProjectStore } from "@/store/projectStore";
import { Dropdown } from "@/components/ui/Dropdown";
import { Project } from "@/types/project";

function ChevronDownIcon() {
  return (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

// One of the Consolidated Sponsor Dashboard's two independent narrowing
// filters (see src/types/dashboardFilters.ts). Fully controlled and fully
// independent of the Partner filter: it only knows its own selected project
// id and reports changes via onChange — it does not read or care about the
// Partner filter's current value. Whoever holds both filters' state combines
// them via src/lib/dashboardFilterScope.ts.
//
// Visual style matches DashboardSelector.tsx (same Dropdown primitive,
// chevron trigger, checkmarked active row) even though this is a plain
// value filter rather than a page-navigating switcher.
export function ProjectFilter({
  value,
  onChange,
  projects: projectsOverride,
}: {
  value: string | null; // selected Project.id, or null = "All Projects"
  onChange: (projectId: string | null) => void;
  // Optional option-list override — the Partner dashboard passes just that
  // Partner's own associated projects here (see src/lib/dashboardScope.ts's
  // getProjectsByPartner) so a Partner user can never see or pick another
  // Partner's project. Omitted (Sponsor side) keeps reading every project
  // from the store, unchanged.
  projects?: Project[];
}) {
  const allProjects = useProjectStore((s) => s.projects);
  const projects = projectsOverride ?? allProjects;

  const label = value === null ? "All Projects" : (projects.find((p) => p.id === value)?.name ?? "All Projects");

  return (
    <Dropdown
      align="right"
      trigger={
        <button
          type="button"
          className="flex h-9 items-center gap-2 rounded-sm border border-border bg-surface px-3 text-sm font-medium text-ink-2 hover:border-border-strong hover:bg-surface-2"
        >
          <span className="max-w-[220px] truncate">{label}</span>
          <ChevronDownIcon />
        </button>
      }
    >
      <div className="max-h-[360px] w-[240px] overflow-y-auto">
        <button
          type="button"
          onClick={() => onChange(null)}
          className={`flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-2 ${
            value === null ? "font-semibold text-primary-700" : "text-ink-2"
          }`}
        >
          <span className="truncate">All Projects</span>
          {value === null && <CheckIcon />}
        </button>

        {projects.map((project) => (
          <button
            key={project.id}
            type="button"
            onClick={() => onChange(project.id)}
            className={`flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-2 ${
              value === project.id ? "font-semibold text-primary-700" : "text-ink-2"
            }`}
          >
            <span className="truncate">{project.name}</span>
            {value === project.id && <CheckIcon />}
          </button>
        ))}
      </div>
    </Dropdown>
  );
}
