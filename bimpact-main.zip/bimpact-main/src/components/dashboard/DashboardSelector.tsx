"use client";

import { useRouter } from "next/navigation";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { Dropdown } from "@/components/ui/Dropdown";
import { DashboardContext, dashboardContextsEqual } from "@/types/dashboardContext";

function ChevronDownIcon() {
  return (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

function contextLabel(
  context: DashboardContext,
  partners: { id: string; name: string }[],
  projects: { id: string; name: string }[]
): string {
  if (context.scope === "partner") return partners.find((p) => p.id === context.partnerId)?.name ?? "Partner";
  if (context.scope === "project") return projects.find((p) => p.id === context.projectId)?.name ?? "Project";
  return "Overall CSR Dashboard";
}

// Single grouped switcher for the Sponsor multi-dashboard feature — one
// control instead of per-partner/per-project nav-menu items (see the sidebar,
// which stays a flat two-role list). Grouped into Overall CSR Dashboard /
// Partners / Projects, matching the dropdown-menu look already used for the
// header's account menu (Dropdown/DropdownItem) but with its own row markup
// so the active entry can be checkmarked and section labels can be rendered.
export function DashboardSelector({ current }: { current: DashboardContext }) {
  const router = useRouter();
  const partners = useSettingsStore((s) => s.partners);
  const projects = useProjectStore((s) => s.projects);

  const label = contextLabel(current, partners, projects);

  function isActive(ctx: DashboardContext): boolean {
    return dashboardContextsEqual(current, ctx);
  }

  function go(path: string) {
    router.push(path);
  }

  return (
    <Dropdown
      align="left"
      trigger={
        <button
          type="button"
          className="flex h-9 items-center gap-2 rounded-sm border border-border bg-surface px-3 text-sm font-medium text-ink-2 hover:border-border-strong hover:bg-surface-2"
        >
          <span className="max-w-[220px] truncate">{label}</span>
          <ChevronDownIcon />
        </button>
      }
    >
      <div className="max-h-[360px] w-[260px] overflow-y-auto">
        <button
          type="button"
          onClick={() => go("/dashboard/consolidated")}
          className={`flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-2 ${
            isActive({ scope: "consolidated" }) ? "font-semibold text-primary-700" : "text-ink-2"
          }`}
        >
          <span className="truncate">Overall CSR Dashboard</span>
          {isActive({ scope: "consolidated" }) && <CheckIcon />}
        </button>

        {partners.length > 0 && (
          <>
            <div className="mt-1 border-t border-border px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-wide text-muted-2">
              Partners
            </div>
            {partners.map((partner) => (
              <button
                key={partner.id}
                type="button"
                onClick={() => go(`/dashboard/partner/${partner.id}`)}
                className={`flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-2 ${
                  isActive({ scope: "partner", partnerId: partner.id }) ? "font-semibold text-primary-700" : "text-ink-2"
                }`}
              >
                <span className="truncate">{partner.name}</span>
                {isActive({ scope: "partner", partnerId: partner.id }) && <CheckIcon />}
              </button>
            ))}
          </>
        )}

        {projects.length > 0 && (
          <>
            <div className="mt-1 border-t border-border px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-wide text-muted-2">
              Projects
            </div>
            {projects.map((project) => (
              <button
                key={project.id}
                type="button"
                onClick={() => go(`/dashboard/project/${project.id}`)}
                className={`flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-2 ${
                  isActive({ scope: "project", projectId: project.id }) ? "font-semibold text-primary-700" : "text-ink-2"
                }`}
              >
                <span className="truncate">{project.name}</span>
                {isActive({ scope: "project", projectId: project.id }) && <CheckIcon />}
              </button>
            ))}
          </>
        )}
      </div>
    </Dropdown>
  );
}
