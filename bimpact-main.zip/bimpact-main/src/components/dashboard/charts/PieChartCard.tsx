"use client";

import { useMemo } from "react";
import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { SliceVizConfig, Visualization } from "@/types/dashboard";
import { useDatasetRows } from "@/hooks/useDatasetRows";
import { AggregatedRow, aggregate, getDataset, resolveColor } from "@/lib/dashboardFields";

// See BarChartCard.tsx's comment — `previewRows` is illustrative-only
// sample data for the Add Visualization chart-type library, real usage never passes it.
export function PieChartCard({ viz, previewRows }: { viz: Visualization & SliceVizConfig; previewRows?: AggregatedRow[] }) {
  const dataset = getDataset(viz.datasetId);
  const liveRows = useDatasetRows(viz.datasetId);

  const data = useMemo(() => {
    if (previewRows) return previewRows;
    if (!dataset) return [];
    return aggregate(dataset, liveRows, viz.dimensionField, viz.measureField, viz.aggregation);
  }, [previewRows, dataset, liveRows, viz.dimensionField, viz.measureField, viz.aggregation]);

  const isDonut = viz.kind === "donut";

  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Tooltip />
        {/* Legend is skipped in preview mode (see Add Visualization's
            chart-type list) — its own tight, fixed preview box has just
            enough room for the full circle with padding; real dashboard
            usage (previewRows unset) is completely unaffected. */}
        {!previewRows && <Legend />}
        <Pie
          data={data}
          dataKey="value"
          nameKey="category"
          // Percentage radii (not fixed pixels) so the pie/donut always
          // scales to whatever container it's actually rendered in and the
          // full circumference stays visible — a fixed outerRadius={95}
          // previously clipped badly in a small preview box (recharts computes
          // these as a share of the container's own smaller dimension).
          innerRadius={isDonut ? "45%" : 0}
          outerRadius="75%"
          paddingAngle={isDonut ? 2 : 0}
        >
          {data.map((slice) => (
            <Cell key={slice.category} fill={resolveColor(viz.colors, slice.category)} />
          ))}
        </Pie>
      </PieChart>
    </ResponsiveContainer>
  );
}
