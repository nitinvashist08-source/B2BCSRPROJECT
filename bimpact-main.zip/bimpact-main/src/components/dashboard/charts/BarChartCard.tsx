"use client";

import { useMemo } from "react";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CategoryVizConfig, Visualization } from "@/types/dashboard";
import { useDatasetRows } from "@/hooks/useDatasetRows";
import { AggregatedRow, aggregate, getDataset, pivotForRecharts, resolveColor } from "@/lib/dashboardFields";

// `previewRows` is illustrative-only sample data (see chartRegistry.ts's
// CHART_TYPES and ChartTypePreview.tsx) for Add Visualization's chart-type
// library row — when provided, this renders with the EXACT same recharts
// config/colors/axes as a real dashboard chart, just skipping the live
// useDatasetRows()/aggregate() pipeline in favor of generic static numbers.
// Real dashboard usage never passes this.
export function BarChartCard({ viz, previewRows }: { viz: Visualization & CategoryVizConfig; previewRows?: AggregatedRow[] }) {
  const dataset = getDataset(viz.datasetId);
  const liveRows = useDatasetRows(viz.datasetId);

  const { data, seriesKeys } = useMemo(() => {
    if (previewRows) {
      const measureLabel = dataset?.measureFields.find((f) => f.id === viz.measureField)?.label ?? viz.measureField;
      return pivotForRecharts(previewRows, measureLabel);
    }
    if (!dataset) return { data: [], seriesKeys: [] };
    const measureLabel = dataset.measureFields.find((f) => f.id === viz.measureField)?.label ?? viz.measureField;
    const aggregated = aggregate(dataset, liveRows, viz.dimensionField, viz.measureField, viz.aggregation, viz.seriesField);
    return pivotForRecharts(aggregated, measureLabel);
  }, [previewRows, dataset, liveRows, viz.dimensionField, viz.measureField, viz.aggregation, viz.seriesField]);

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
        <XAxis dataKey="category" tick={{ fontSize: 11 }} />
        <YAxis tick={{ fontSize: 11 }} />
        <Tooltip />
        {seriesKeys.length > 1 && <Legend />}
        {seriesKeys.map((key) => (
          <Bar key={key} dataKey={key} name={key} fill={resolveColor(viz.colors, key)} radius={[3, 3, 0, 0]} />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}
