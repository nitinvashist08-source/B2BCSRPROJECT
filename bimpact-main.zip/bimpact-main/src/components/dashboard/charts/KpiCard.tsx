"use client";

import { useMemo } from "react";
import { KpiVizConfig, Visualization } from "@/types/dashboard";
import { useDatasetRows } from "@/hooks/useDatasetRows";
import { getDataset } from "@/lib/dashboardFields";

// See BarChartCard.tsx's comment — `previewValue`/`previewLabel` are
// illustrative-only sample data for the Add Visualization chart-type library, real
// usage never passes them.
export function KpiCard({
  viz,
  previewValue,
  previewLabel,
}: {
  viz: Visualization & KpiVizConfig;
  previewValue?: string;
  previewLabel?: string;
}) {
  const dataset = getDataset(viz.datasetId);
  const rows = useDatasetRows(viz.datasetId);

  const value = useMemo(() => {
    if (!dataset || rows.length === 0) return 0;
    const values = rows.map((row) => dataset.getMeasure(row, viz.measureField));
    const sum = values.reduce((a, b) => a + b, 0);
    if (viz.aggregation === "count") return values.length;
    if (viz.aggregation === "avg") return sum / values.length;
    return sum;
  }, [dataset, rows, viz.measureField, viz.aggregation]);

  const measureLabel = dataset?.measureFields.find((f) => f.id === viz.measureField)?.label ?? viz.measureField;

  return (
    <div className="flex h-full min-h-[100px] flex-col items-center justify-center gap-2">
      <span className="text-4xl font-bold" style={{ color: viz.valueColor }}>
        {previewValue ?? (Number.isInteger(value) ? value.toLocaleString("en-IN") : value.toFixed(1))}
      </span>
      <span className="text-sm font-medium" style={{ color: viz.labelColor }}>
        {previewLabel ?? measureLabel}
      </span>
    </div>
  );
}
