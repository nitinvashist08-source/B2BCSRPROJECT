"use client";

import { useMemo } from "react";
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CategoryVizConfig, Visualization } from "@/types/dashboard";
import { useDatasetRows } from "@/hooks/useDatasetRows";
import { AggregatedRow, aggregate, getDataset, pivotForRecharts, resolveColor } from "@/lib/dashboardFields";

// See BarChartCard.tsx's comment — `previewRows` is illustrative-only
// sample data for the Add Visualization chart-type library, real usage never passes it.
export function LineChartCard({ viz, previewRows }: { viz: Visualization & CategoryVizConfig; previewRows?: AggregatedRow[] }) {
  const dataset = getDataset(viz.datasetId);
  const liveRows = useDatasetRows(viz.datasetId);

  const { data, seriesKeys } = useMemo(() => {
    if (previewRows) {
      const measureLabel = dataset?.measureFields.find((f) => f.id === viz.measureField)?.label ?? viz.measureField;
      return pivotForRecharts(previewRows, measureLabel);
    }
    if (!dataset) return { data: [], seriesKeys: [] };
    const measureLabel = dataset.measureFields.find((f) => f.id === viz.measureField)?.label ?? viz.measureField;
    const aggregated = aggregate(dataset, liveRows, viz.dimensionField, viz.measureField, viz.aggregation, viz.seriesField);
    return pivotForRecharts(aggregated, measureLabel);
  }, [previewRows, dataset, liveRows, viz.dimensionField, viz.measureField, viz.aggregation, viz.seriesField]);

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
        <XAxis dataKey="category" tick={{ fontSize: 11 }} />
        <YAxis tick={{ fontSize: 11 }} />
        <Tooltip />
        {seriesKeys.length > 1 && <Legend />}
        {seriesKeys.map((key) => (
          <Line
            key={key}
            type="monotone"
            dataKey={key}
            name={key}
            stroke={resolveColor(viz.colors, key)}
            strokeWidth={2}
            dot={{ r: 3 }}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}
