"use client";

import { TableVizConfig, Visualization } from "@/types/dashboard";
import { useDatasetRows } from "@/hooks/useDatasetRows";
import { aggregate, getDataset } from "@/lib/dashboardFields";

// See BarChartCard.tsx's comment — `previewRows`/`previewColumns` are
// illustrative-only sample data for the Add Visualization chart-type library, real
// usage never passes them.
export function TableCard({
  viz,
  previewColumns,
  previewRows,
}: {
  viz: Visualization & TableVizConfig;
  previewColumns?: string[];
  previewRows?: (string | number)[][];
}) {
  const dataset = getDataset(viz.datasetId);
  const liveRows = useDatasetRows(viz.datasetId);

  const measureLabels = viz.measureFields.map(
    (fieldId) => dataset?.measureFields.find((f) => f.id === fieldId)?.label ?? fieldId
  );

  const tableRows = (() => {
    if (!dataset) return [];
    const perMeasure = viz.measureFields.map((measureField) =>
      aggregate(dataset, liveRows, viz.dimensionField, measureField, viz.aggregation)
    );
    const categories = perMeasure[0]?.map((r) => r.category) ?? [];
    return categories.map((category, i) => ({
      category,
      values: perMeasure.map((agg) => agg[i]?.value ?? 0),
    }));
  })();

  const dimensionLabel = dataset?.dimensionFields.find((f) => f.id === viz.dimensionField)?.label ?? viz.dimensionField;

  if (previewRows && previewColumns) {
    return (
      <div className="h-full overflow-y-auto">
        <table className="w-full text-left text-[13px]">
          <thead>
            <tr className="border-b border-border bg-surface-2">
              {previewColumns.map((label) => (
                <th key={label} className="px-3 py-2 font-semibold text-ink-2 first:text-left last:text-right">
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {previewRows.map((row, i) => (
              <tr key={i} className="border-b border-border last:border-0">
                {row.map((cell, j) => (
                  <td key={j} className={`px-3 py-2 text-ink ${j === 0 ? "text-left" : "text-right"}`}>
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto">
      <table className="w-full text-left text-[13px]">
        <thead>
          <tr className="border-b border-border bg-surface-2">
            <th className="px-3 py-2 font-semibold text-ink-2">{dimensionLabel}</th>
            {measureLabels.map((label) => (
              <th key={label} className="px-3 py-2 text-right font-semibold text-ink-2">
                {label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {tableRows.map((row) => (
            <tr key={row.category} className="border-b border-border last:border-0">
              <td className="px-3 py-2 text-ink">{row.category}</td>
              {row.values.map((value, i) => (
                <td key={i} className="px-3 py-2 text-right text-ink">
                  {Number.isInteger(value) ? value.toLocaleString("en-IN") : value.toFixed(1)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
