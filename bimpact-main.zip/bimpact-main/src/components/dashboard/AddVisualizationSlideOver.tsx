"use client";

import { useMemo, useState } from "react";
import { SlideOver } from "@/components/ui/SlideOver";
import { Button } from "@/components/ui/Button";
import { MultiSelect } from "@/components/ui/MultiSelect";
import { useDashboardStore } from "@/store/dashboardStore";
import { useDatasetRows } from "@/hooks/useDatasetRows";
import { AggregationOp, ChartKind, DistributiveOmit, TableVizConfig, Visualization } from "@/types/dashboard";
import { CHART_TYPES, getChartType } from "@/lib/chartRegistry";
import { DATASETS, aggregate, distinctSeriesKeys, getDataset, resolveColor } from "@/lib/dashboardFields";
import { VisualizationCard } from "./VisualizationCard";
import { ChartTypeRow } from "./ChartTypeRow";

const inputCls =
  "box-border h-[38px] w-full rounded-lg border-[1.5px] border-border bg-bg px-3 text-[13px] text-ink outline-none transition-colors focus:border-primary";
const selCls =
  "box-border h-[38px] w-full cursor-pointer rounded-lg border-[1.5px] border-border bg-bg px-2.5 text-[13px] text-ink outline-none transition-colors focus:border-primary";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-3.5">
      <label className="mb-1.5 block text-xs font-semibold text-ink-2">{label}</label>
      {children}
    </div>
  );
}

const AGGREGATION_OPTIONS: { value: AggregationOp; label: string }[] = [
  { value: "count", label: "Count" },
  { value: "sum", label: "Sum" },
  { value: "avg", label: "Average" },
];

type FormState = {
  kind: ChartKind;
  datasetId: string;
  title: string;
  dimensionField: string;
  measureField: string;
  seriesField: string;
  measureFieldLabels: string[];
  aggregation: AggregationOp;
  colors: Record<string, string>;
  valueColor: string;
  labelColor: string;
};

function initialState(editing?: Visualization | null): FormState {
  const defaultDataset = DATASETS[0];
  if (!editing) {
    return {
      kind: "bar",
      datasetId: defaultDataset.id,
      title: "",
      dimensionField: defaultDataset.dimensionFields[0]?.id ?? "",
      measureField: "__count__",
      seriesField: "",
      measureFieldLabels: [defaultDataset.measureFields[0]?.label ?? ""],
      aggregation: "count",
      colors: {},
      valueColor: "#0A97D9",
      labelColor: "#64748B",
    };
  }
  const dataset = getDataset(editing.datasetId) ?? defaultDataset;
  const base: FormState = {
    kind: editing.kind,
    datasetId: editing.datasetId,
    title: editing.title,
    dimensionField: "",
    measureField: "__count__",
    seriesField: "",
    measureFieldLabels: [dataset.measureFields[0]?.label ?? ""],
    aggregation: "count",
    colors: {},
    valueColor: "#0A97D9",
    labelColor: "#64748B",
  };
  if (editing.kind === "bar" || editing.kind === "line" || editing.kind === "area") {
    return {
      ...base,
      dimensionField: editing.dimensionField,
      measureField: editing.measureField,
      seriesField: editing.seriesField ?? "",
      aggregation: editing.aggregation,
      colors: editing.colors,
    };
  }
  if (editing.kind === "pie" || editing.kind === "donut") {
    return {
      ...base,
      dimensionField: editing.dimensionField,
      measureField: editing.measureField,
      aggregation: editing.aggregation,
      colors: editing.colors,
    };
  }
  if (editing.kind === "kpi") {
    return {
      ...base,
      measureField: editing.measureField,
      aggregation: editing.aggregation,
      valueColor: editing.valueColor,
      labelColor: editing.labelColor,
    };
  }
  // table (the only remaining variant)
  const tableEditing = editing as Visualization & TableVizConfig;
  return {
    ...base,
    dimensionField: tableEditing.dimensionField,
    aggregation: tableEditing.aggregation,
    measureFieldLabels: tableEditing.measureFields
      .map((id: string) => dataset.measureFields.find((f) => f.id === id)?.label)
      .filter((l: string | undefined): l is string => !!l),
  };
}

function buildVisualization(pageId: string, form: FormState): DistributiveOmit<Visualization, "id" | "order"> {
  const dataset = getDataset(form.datasetId)!;
  const base = { pageId, title: form.title || "Untitled Visualization", datasetId: form.datasetId };
  if (form.kind === "bar" || form.kind === "line" || form.kind === "area") {
    return {
      ...base,
      kind: form.kind,
      dimensionField: form.dimensionField,
      measureField: form.measureField,
      aggregation: form.aggregation,
      seriesField: form.seriesField || undefined,
      colors: form.colors,
    };
  }
  if (form.kind === "pie" || form.kind === "donut") {
    return {
      ...base,
      kind: form.kind,
      dimensionField: form.dimensionField,
      measureField: form.measureField,
      aggregation: form.aggregation,
      colors: form.colors,
    };
  }
  if (form.kind === "kpi") {
    return {
      ...base,
      kind: "kpi",
      measureField: form.measureField,
      aggregation: form.aggregation,
      valueColor: form.valueColor,
      labelColor: form.labelColor,
    };
  }
  // table
  const measureFields = form.measureFieldLabels
    .map((label) => dataset.measureFields.find((f) => f.label === label)?.id)
    .filter((id): id is string => !!id);
  return {
    ...base,
    kind: "table",
    dimensionField: form.dimensionField,
    measureFields: measureFields.length > 0 ? measureFields : [dataset.measureFields[0].id],
    aggregation: form.aggregation,
  };
}

export function AddVisualizationSlideOver({
  open,
  onClose,
  pageId,
  editing = null,
}: {
  open: boolean;
  onClose: () => void;
  pageId: string;
  editing?: Visualization | null;
}) {
  const addVisualization = useDashboardStore((s) => s.addVisualization);
  const updateVisualization = useDashboardStore((s) => s.updateVisualization);
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [form, setForm] = useState<FormState>(() => initialState(editing));

  const dataset = getDataset(form.datasetId) ?? DATASETS[0];
  const chartType = getChartType(form.kind);
  const rows = useDatasetRows(form.datasetId);

  function patch(update: Partial<FormState>) {
    setForm((f) => ({ ...f, ...update }));
  }

  // Step 1 is purely "how should the data be displayed" — selecting a
  // chart TYPE never binds a dataset/dimension/measure (that's step 2,
  // unchanged). Clicking a row selects the kind AND advances, per spec's
  // "clicking anywhere should select it... then proceed to the existing
  // configuration flow."
  function selectKind(kind: ChartKind) {
    const type = getChartType(kind);
    patch({
      kind,
      measureField: type.axisModel === "tabular" ? form.measureField : form.measureField || "__count__",
      aggregation: type.defaultAggregation,
    });
    setStep(2);
  }

  function selectDataset(datasetId: string) {
    const nextDataset = getDataset(datasetId);
    if (!nextDataset) return;
    patch({
      datasetId,
      dimensionField: nextDataset.dimensionFields[0]?.id ?? "",
      measureField: "__count__",
      seriesField: "",
      measureFieldLabels: [nextDataset.measureFields[0]?.label ?? ""],
      colors: {},
    });
  }

  // Distinct series/slice identities the CURRENT selection resolves to —
  // this is what makes the color list grow/shrink with the real data
  // instead of a hardcoded count.
  const colorKeys = useMemo(() => {
    if (chartType.colorMode === "series") {
      const measureLabel = dataset.measureFields.find((f) => f.id === form.measureField)?.label ?? form.measureField;
      const aggregated = aggregate(dataset, rows, form.dimensionField, form.measureField, form.aggregation, form.seriesField || undefined);
      return distinctSeriesKeys(aggregated, measureLabel);
    }
    if (chartType.colorMode === "slice") {
      const aggregated = aggregate(dataset, rows, form.dimensionField, form.measureField, form.aggregation);
      return Array.from(new Set(aggregated.map((r) => r.category)));
    }
    return [];
  }, [chartType.colorMode, dataset, rows, form.dimensionField, form.measureField, form.aggregation, form.seriesField]);

  function handleSave() {
    const input = buildVisualization(pageId, form);
    if (editing) {
      updateVisualization(editing.id, input as Partial<Visualization>);
    } else {
      addVisualization(pageId, input);
    }
    onClose();
  }

  function handleClose() {
    setStep(1);
    setForm(initialState(null));
    onClose();
  }

  const previewViz: Visualization = { id: "preview", order: 0, ...buildVisualization(pageId, form) } as Visualization;

  return (
    <SlideOver
      open={open}
      onClose={handleClose}
      title={editing ? "Edit Visualization" : "Add Visualization"}
      // Step 1's width was 620 — cut to ~60% of that (spec: "reduce by
      // approximately 40%") now that each row stacks preview-above-text
      // instead of side-by-side, so a narrower card no longer squeezes the
      // preview or the guiding text.
      width={step === 1 ? 380 : 480}
      footer={
        <>
          {step > 1 && (
            <Button variant="ghost" onClick={() => setStep((s) => (s - 1) as 1 | 2 | 3)}>
              Back
            </Button>
          )}
          {step < 3 ? (
            <Button onClick={() => setStep((s) => (s + 1) as 1 | 2 | 3)}>Next</Button>
          ) : (
            <Button onClick={handleSave}>Save Visualization</Button>
          )}
        </>
      }
    >
      {step === 1 && (
        <div>
          <div className="mb-3.5">
            <h3 className="text-[13px] font-bold text-ink">Choose a Visualization Type</h3>
            <p className="mt-0.5 text-xs text-muted">
              Pick how you want to display your data — you&apos;ll choose the metric and category next.
            </p>
          </div>
          <div className="flex flex-col gap-2.5">
            {CHART_TYPES.map((type) => (
              <ChartTypeRow key={type.kind} type={type} selected={form.kind === type.kind} onSelect={() => selectKind(type.kind)} />
            ))}
          </div>
        </div>
      )}

      {step === 2 && (
        <>
          <Field label="Title">
            <input
              className={inputCls}
              value={form.title}
              onChange={(e) => patch({ title: e.target.value })}
              placeholder={`e.g. "${chartType.label} — ${dataset.label}"`}
            />
          </Field>
          <Field label="Data Source">
            <select className={selCls} value={form.datasetId} onChange={(e) => selectDataset(e.target.value)}>
              {DATASETS.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.label}
                </option>
              ))}
            </select>
          </Field>

          {chartType.axisModel === "series-category-measure" && (
            <>
              <Field label="X-Axis">
                <select className={selCls} value={form.dimensionField} onChange={(e) => patch({ dimensionField: e.target.value })}>
                  {dataset.dimensionFields.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Y-Axis">
                <select className={selCls} value={form.measureField} onChange={(e) => patch({ measureField: e.target.value })}>
                  {dataset.measureFields.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Group By (optional)">
                <select className={selCls} value={form.seriesField} onChange={(e) => patch({ seriesField: e.target.value })}>
                  <option value="">None</option>
                  {dataset.dimensionFields
                    .filter((f) => f.id !== form.dimensionField)
                    .map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.label}
                      </option>
                    ))}
                </select>
              </Field>
            </>
          )}

          {chartType.axisModel === "category-value" && (
            <>
              <Field label="Category">
                <select className={selCls} value={form.dimensionField} onChange={(e) => patch({ dimensionField: e.target.value })}>
                  {dataset.dimensionFields.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Value">
                <select className={selCls} value={form.measureField} onChange={(e) => patch({ measureField: e.target.value })}>
                  {dataset.measureFields.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </Field>
            </>
          )}

          {chartType.axisModel === "metric-only" && (
            <Field label="Metric">
              <select className={selCls} value={form.measureField} onChange={(e) => patch({ measureField: e.target.value })}>
                {dataset.measureFields.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.label}
                  </option>
                ))}
              </select>
            </Field>
          )}

          {chartType.axisModel === "tabular" && (
            <>
              <Field label="Group By">
                <select className={selCls} value={form.dimensionField} onChange={(e) => patch({ dimensionField: e.target.value })}>
                  {dataset.dimensionFields.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Columns">
                <MultiSelect
                  options={dataset.measureFields.map((f) => f.label)}
                  value={form.measureFieldLabels}
                  onChange={(labels) => patch({ measureFieldLabels: labels })}
                  placeholder="Select columns…"
                />
              </Field>
            </>
          )}

          <Field label="Aggregation">
            <select className={selCls} value={form.aggregation} onChange={(e) => patch({ aggregation: e.target.value as AggregationOp })}>
              {AGGREGATION_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </Field>
        </>
      )}

      {step === 3 && (
        <>
          <div className="mb-4 h-[320px] rounded-lg border border-border bg-bg p-2">
            <VisualizationCard viz={previewViz} onEdit={() => {}} onRemove={() => {}} />
          </div>

          {chartType.colorMode === "series" && colorKeys.length > 0 && (
            <Field label={colorKeys.length > 1 ? "Series Colors" : "Color"}>
              <div className="flex flex-col gap-2">
                {colorKeys.map((key) => (
                  <div key={key} className="flex items-center justify-between gap-2">
                    <span className="text-[13px] text-ink-2">{key}</span>
                    <input
                      type="color"
                      value={resolveColor(form.colors, key)}
                      onChange={(e) => patch({ colors: { ...form.colors, [key]: e.target.value } })}
                      className="h-8 w-14 cursor-pointer rounded border border-border"
                    />
                  </div>
                ))}
              </div>
            </Field>
          )}

          {chartType.colorMode === "slice" && colorKeys.length > 0 && (
            <Field label="Slice Colors">
              <div className="flex flex-col gap-2">
                {colorKeys.map((key) => (
                  <div key={key} className="flex items-center justify-between gap-2">
                    <span className="text-[13px] text-ink-2">{key}</span>
                    <input
                      type="color"
                      value={resolveColor(form.colors, key)}
                      onChange={(e) => patch({ colors: { ...form.colors, [key]: e.target.value } })}
                      className="h-8 w-14 cursor-pointer rounded border border-border"
                    />
                  </div>
                ))}
              </div>
            </Field>
          )}

          {chartType.colorMode === "single" && (
            <>
              <Field label="Value Color">
                <input
                  type="color"
                  value={form.valueColor}
                  onChange={(e) => patch({ valueColor: e.target.value })}
                  className="h-8 w-14 cursor-pointer rounded border border-border"
                />
              </Field>
              <Field label="Label Color">
                <input
                  type="color"
                  value={form.labelColor}
                  onChange={(e) => patch({ labelColor: e.target.value })}
                  className="h-8 w-14 cursor-pointer rounded border border-border"
                />
              </Field>
            </>
          )}

          {chartType.colorMode === "none" && (
            <p className="text-[13px] text-muted">This visualization has no color customization.</p>
          )}
        </>
      )}
    </SlideOver>
  );
}
