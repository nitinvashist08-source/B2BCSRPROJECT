"use client";

import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { Badge } from "@/components/ui/Badge";
import { DashboardContext } from "@/types/dashboardContext";

// Small, always-visible "where am I" strip for the Sponsor multi-dashboard
// feature — sits above DashboardSelector on every consolidated/partner/
// project dashboard route so the current context (type + name) is never
// ambiguous, even if the selector itself is collapsed.
export function DashboardContextHeader({ context }: { context: DashboardContext }) {
  const partnerName = useSettingsStore((s) =>
    context.scope === "partner" ? s.partners.find((p) => p.id === context.partnerId)?.name : undefined
  );
  const projectName = useProjectStore((s) =>
    context.scope === "project" ? s.projects.find((p) => p.id === context.projectId)?.name : undefined
  );

  if (context.scope === "partner") {
    return (
      <div className="flex items-center gap-2.5">
        <h1 className="text-lg font-semibold text-ink">{partnerName ?? "Partner"}</h1>
        <Badge tone="primary" dot={false}>
          Partner
        </Badge>
      </div>
    );
  }

  if (context.scope === "project") {
    return (
      <div className="flex items-center gap-2.5">
        <h1 className="text-lg font-semibold text-ink">{projectName ?? "Project"}</h1>
        <Badge tone="secondary" dot={false}>
          Project
        </Badge>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2.5">
      <h1 className="text-lg font-semibold text-ink">Overall CSR Dashboard</h1>
    </div>
  );
}
