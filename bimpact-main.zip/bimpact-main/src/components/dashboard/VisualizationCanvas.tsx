"use client";

import { useMemo, useState } from "react";
import { Responsive, WidthProvider } from "react-grid-layout/legacy";
import { Button } from "@/components/ui/Button";
import { Modal } from "@/components/ui/Modal";
import { useDashboardStore } from "@/store/dashboardStore";
import { useDashboardLayoutStore, getPageLayout } from "@/store/dashboardLayoutStore";
import { useSessionStore } from "@/store/sessionStore";
import { CardLayout, Visualization } from "@/types/dashboard";
import { DashboardContext, dashboardScopeKey } from "@/types/dashboardContext";
import { GRID_MARGIN, reconcileLayout, ROW_HEIGHT } from "@/lib/dashboardLayout";
import { DatasetScopeFilter, DatasetScopeProvider } from "@/hooks/useDatasetRows";
import { VisualizationCard } from "./VisualizationCard";
import { AddVisualizationSlideOver } from "./AddVisualizationSlideOver";

// Sub-Agent 2's dashboardScope.ts (getScopedProjectIds/getScopedPartnerIds)
// lives outside this slice's ownership and may not exist yet while all three
// dashboard workstreams are being built in parallel — imported here by the
// exact signature specified in the shared plan.
import { getScopedProjectIds, getScopedPartnerIds } from "@/lib/dashboardScope";

// Independent Partner/Project filter bar (Consolidated dashboard only, see
// src/types/dashboardFilters.ts) — a separate, later feature from the
// context-based scoping above. buildDashboardFilterScopeFilter follows the
// exact same DatasetScopeFilter convention as buildDatasetScopeFilter below,
// so the two are simply ANDed together when both are present.
import { DashboardFilters } from "@/types/dashboardFilters";
import { buildDashboardFilterScopeFilter } from "@/lib/dashboardFilterScope";

const CONSOLIDATED_SCOPE_KEY = "consolidated::global";

// Which dataset rows carry a project or partner linkage, and how to test a
// row against the scoped id sets — kept in one place so adding a new
// dataset with project/partner linkage later only needs one line here.
// Datasets not listed (meetings, policies, teamMembers) are Sponsor-wide
// records with no project/partner ownership field, so they're never
// filtered by scope.
function buildDatasetScopeFilter(context: DashboardContext): DatasetScopeFilter | null {
  if (context.scope === "consolidated") return null;
  const projectIds = new Set(getScopedProjectIds(context));
  const partnerIds = new Set(getScopedPartnerIds(context));
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- row shape depends on datasetId, same as DatasetScopeFilter's own signature
  return (datasetId: string, row: any) => {
    switch (datasetId) {
      case "projects":
        return projectIds.has(row?.id);
      case "expenses":
      case "tranches":
      case "beneficiaries":
        return projectIds.has(row?.projectId);
      case "partners":
        return partnerIds.has(row?.id);
      default:
        return true;
    }
  };
}

// WidthProvider(Responsive) must be created once, not per render, or every
// render would remount the whole grid (losing drag/resize interaction
// state).
const ResponsiveGridLayout = WidthProvider(Responsive);

type Breakpoint = "lg" | "md" | "sm" | "xs";
const BREAKPOINTS: Record<Breakpoint, number> = { lg: 996, md: 768, sm: 480, xs: 0 };
// xs collapses to a single column so small screens stack cards full-width
// instead of shrinking them into unreadable slivers.
const COLS: Record<Breakpoint, number> = { lg: 12, md: 12, sm: 4, xs: 1 };

type RglItem = { i: string; x: number; y: number; w: number; h: number; minW?: number; minH?: number; maxW?: number; maxH?: number };

function toCardLayouts(layout: readonly RglItem[]): CardLayout[] {
  return layout.map((l) => ({ i: l.i, x: l.x, y: l.y, w: l.w, h: l.h, minW: l.minW, minH: l.minH, maxW: l.maxW, maxH: l.maxH }));
}

export function VisualizationCanvas({
  pageId,
  context,
  filters,
}: {
  pageId: string;
  context?: DashboardContext;
  // Independent Partner/Project filter bar's current value (Consolidated
  // dashboard only) — narrows data on top of (never instead of) whatever
  // `context` already scopes. Omitted everywhere else, same as `context`.
  filters?: DashboardFilters;
}) {
  // Omitted `context` (today's one unscoped /dashboard route) behaves
  // exactly as before this feature: scopeKey resolves to the same
  // "consolidated::global" value pre-scoping layouts were migrated under,
  // and scopeFilter stays null so useDatasetRows returns fully unfiltered
  // rows.
  const scopeKey = context ? dashboardScopeKey(context) : CONSOLIDATED_SCOPE_KEY;
  const contextFilter = useMemo(() => (context ? buildDatasetScopeFilter(context) : null), [context]);
  const filterBarFilter = useMemo(() => (filters ? buildDashboardFilterScopeFilter(filters) : null), [filters]);
  // Both are optional and independent — AND them together when both are
  // present so a dedicated Partner/Project dashboard route could one day also
  // carry the filter bar without the two scoping mechanisms fighting.
  const scopeFilter = useMemo(() => {
    if (contextFilter && filterBarFilter) {
      return (datasetId: string, row: unknown) => contextFilter(datasetId, row) && filterBarFilter(datasetId, row);
    }
    return contextFilter ?? filterBarFilter;
  }, [contextFilter, filterBarFilter]);

  const visualizations = useDashboardStore((s) => s.visualizations);
  const removeVisualization = useDashboardStore((s) => s.removeVisualization);
  const userId = useSessionStore((s) => s.userId);
  const layoutsByKey = useDashboardLayoutStore((s) => s.layoutsByKey);
  const setPageLayout = useDashboardLayoutStore((s) => s.setPageLayout);
  const resetPageLayout = useDashboardLayoutStore((s) => s.resetPageLayout);
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Visualization | null>(null);
  const [confirmingReset, setConfirmingReset] = useState(false);
  // Free-form drag/resize is a desktop feature — below the `lg` breakpoint
  // cards just stack full-width (see COLS.xs) so the dashboard never breaks
  // on a small screen, and so a phone/tablet viewport can never overwrite a
  // user's desktop arrangement.
  const [breakpoint, setBreakpoint] = useState<Breakpoint>("lg");
  const isDesktop = breakpoint === "lg";

  const pageVisualizations = visualizations.filter((v) => v.pageId === pageId).sort((a, b) => a.order - b.order);
  const vizIdsKey = pageVisualizations.map((v) => v.id).join(",");
  const vizIds = useMemo(() => vizIdsKey.split(",").filter(Boolean), [vizIdsKey]);

  // Every card's arrangement resolves independently per logged-in user AND
  // per dashboard (see dashboardLayoutStore) — a Sponsor dragging/resizing a
  // card never affects a Partner's view of the same visualization, another
  // Sponsor user's, or another dashboard's (Consolidated vs. Partner A vs.
  // Partner B vs. any Project) layout for the same page id.
  const savedLayout = userId ? getPageLayout(layoutsByKey, userId, scopeKey, pageId) : undefined;
  const layout = useMemo(() => reconcileLayout(savedLayout, vizIds), [savedLayout, vizIds]);
  const hasCustomLayout = !!savedLayout && savedLayout.length > 0;

  function persistIfDesktop(nextLayout: readonly RglItem[]) {
    if (!userId || !isDesktop) return;
    setPageLayout(userId, scopeKey, pageId, toCardLayouts(nextLayout));
  }

  function requestReset() {
    if (hasCustomLayout) setConfirmingReset(true);
  }

  function confirmReset() {
    if (userId) resetPageLayout(userId, scopeKey, pageId);
    setConfirmingReset(false);
  }

  if (pageVisualizations.length === 0) {
    return (
      <DatasetScopeProvider filter={scopeFilter}>
        <div className="flex min-h-[360px] flex-col items-center justify-center rounded-lg border border-dashed border-border-strong bg-surface text-center">
          <h2 className="text-lg font-semibold text-ink">Build your dashboard</h2>
          <p className="mt-1 max-w-sm text-sm text-muted">
            Add visualizations to turn your survey data into actionable insights.
          </p>
          <Button className="mt-4" onClick={() => setAdding(true)}>
            + Add Visualization
          </Button>
        </div>
        <AddVisualizationSlideOver open={adding} onClose={() => setAdding(false)} pageId={pageId} />
      </DatasetScopeProvider>
    );
  }

  return (
    <DatasetScopeProvider filter={scopeFilter}>
      <div className="flex flex-col gap-4">
        <div className="flex justify-end gap-2.5">
          {hasCustomLayout && (
            <Button variant="ghost" onClick={requestReset}>
              Reset Dashboard Layout
            </Button>
          )}
          <Button onClick={() => setAdding(true)}>+ Add Visualization</Button>
        </div>
        <ResponsiveGridLayout
          className="layout"
          layouts={{ lg: layout }}
          breakpoints={BREAKPOINTS}
          cols={COLS}
          rowHeight={ROW_HEIGHT}
          margin={GRID_MARGIN}
          containerPadding={[0, 0]}
          compactType="vertical"
          preventCollision={false}
          isBounded
          draggableHandle=".viz-drag-handle"
          draggableCancel="button"
          resizeHandles={["se"]}
          isDraggable={isDesktop}
          isResizable={isDesktop}
          onBreakpointChange={(bp: string) => setBreakpoint(bp as Breakpoint)}
          onDragStop={(l: readonly RglItem[]) => persistIfDesktop(l)}
          onResizeStop={(l: readonly RglItem[]) => persistIfDesktop(l)}
        >
          {pageVisualizations.map((viz) => (
            <div key={viz.id}>
              <VisualizationCard viz={viz} onEdit={() => setEditing(viz)} onRemove={() => removeVisualization(viz.id)} />
            </div>
          ))}
        </ResponsiveGridLayout>
        <AddVisualizationSlideOver open={adding} onClose={() => setAdding(false)} pageId={pageId} />
        {editing && (
          <AddVisualizationSlideOver
            open={!!editing}
            onClose={() => setEditing(null)}
            pageId={pageId}
            editing={editing}
          />
        )}

        <Modal
          open={confirmingReset}
          onClose={() => setConfirmingReset(false)}
          title="Reset dashboard layout?"
          footer={
            <>
              <Button variant="ghost" onClick={() => setConfirmingReset(false)}>
                Cancel
              </Button>
              <Button onClick={confirmReset}>Reset Layout</Button>
            </>
          }
        >
          This will restore the original dashboard layout and remove your custom card arrangement.
        </Modal>
      </div>
    </DatasetScopeProvider>
  );
}
