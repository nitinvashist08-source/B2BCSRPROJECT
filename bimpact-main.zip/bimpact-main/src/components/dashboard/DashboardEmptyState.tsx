"use client";

// Shared "nothing to show" panel for dashboard filter states with no data
// to display (e.g. a selected Partner/Project pair with no real
// association — see src/lib/dashboardFilterScope.ts's
// isFilterCombinationEmpty). Used by both the Consolidated Sponsor
// Dashboard and the Partner Dashboard's Project filter so there is exactly
// one empty-state design, not a per-page reinvention. Same look as
// VisualizationCanvas's own "Build your dashboard" placeholder.
export function DashboardEmptyState({ title, message }: { title: string; message: string }) {
  return (
    <div className="flex min-h-[360px] flex-col items-center justify-center rounded-lg border border-dashed border-border-strong bg-surface text-center">
      <h2 className="text-lg font-semibold text-ink">{title}</h2>
      <p className="mt-1 max-w-sm text-sm text-muted">{message}</p>
    </div>
  );
}
