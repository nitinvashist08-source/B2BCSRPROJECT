"use client";

import { CategoryVizConfig, KpiVizConfig, SliceVizConfig, TableVizConfig, Visualization } from "@/types/dashboard";
import { ChartTypeDef } from "@/lib/chartRegistry";
import { BarChartCard } from "./charts/BarChartCard";
import { LineChartCard } from "./charts/LineChartCard";
import { AreaChartCard } from "./charts/AreaChartCard";
import { PieChartCard } from "./charts/PieChartCard";
import { KpiCard } from "./charts/KpiCard";
import { TableCard } from "./charts/TableCard";

// Renders one chart TYPE's generic illustrative sample (Category A/B/C/D —
// see chartRegistry.ts's CHART_TYPES) using the SAME chart card components
// (and the same recharts config/colors) the real dashboard uses — see each
// card's `preview*` prop. The throwaway `Visualization` built here is
// deliberately NOT bound to any real dataset/dimension/measure (datasetId
// is a placeholder id that resolves to nothing in the dataset registry) —
// selecting a chart TYPE must never imply a specific metric; every card's
// `preview*` override makes the real (nonexistent) dataset lookup moot
// anyway, since the illustrative numbers are used directly.
export function ChartTypePreview({ type }: { type: ChartTypeDef }) {
  const base = { id: "preview", pageId: "preview", order: 0, title: type.label, datasetId: "__preview__" };

  if (type.kind === "bar" || type.kind === "line" || type.kind === "area") {
    const viz: Visualization & CategoryVizConfig = {
      ...base,
      kind: type.kind,
      dimensionField: "category",
      measureField: "value",
      aggregation: type.defaultAggregation,
      colors: {},
    };
    if (type.kind === "bar") return <BarChartCard viz={viz} previewRows={type.previewData} />;
    if (type.kind === "line") return <LineChartCard viz={viz} previewRows={type.previewData} />;
    return <AreaChartCard viz={viz} previewRows={type.previewData} />;
  }

  if (type.kind === "pie" || type.kind === "donut") {
    const viz: Visualization & SliceVizConfig = {
      ...base,
      kind: type.kind,
      dimensionField: "category",
      measureField: "value",
      aggregation: type.defaultAggregation,
      colors: {},
    };
    return <PieChartCard viz={viz} previewRows={type.previewData} />;
  }

  if (type.kind === "kpi") {
    const viz: Visualization & KpiVizConfig = {
      ...base,
      kind: "kpi",
      measureField: "value",
      aggregation: type.defaultAggregation,
      valueColor: "#0A97D9",
      labelColor: "#64748B",
    };
    return <KpiCard viz={viz} previewValue={type.previewKpiValue} previewLabel={type.previewKpiLabel} />;
  }

  // table (the only remaining kind)
  const viz: Visualization & TableVizConfig = {
    ...base,
    kind: "table",
    dimensionField: "category",
    measureFields: ["value"],
    aggregation: type.defaultAggregation,
  };
  return <TableCard viz={viz} previewColumns={type.previewTable?.columns} previewRows={type.previewTable?.rows} />;
}
