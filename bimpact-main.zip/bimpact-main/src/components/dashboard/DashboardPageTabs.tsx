"use client";

import { useState } from "react";
import { DndContext, DragEndEvent, PointerSensor, closestCenter, useSensor, useSensors } from "@dnd-kit/core";
import { SortableContext, arrayMove, horizontalListSortingStrategy, useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useDashboardStore } from "@/store/dashboardStore";
import { DashboardPage } from "@/types/dashboard";

function PlusIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeLinecap="round" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" x2="12" y1="5" y2="19" />
      <line x1="5" x2="19" y1="12" y2="12" />
    </svg>
  );
}
function CloseIcon() {
  return (
    <svg fill="none" height="10" width="10" stroke="currentColor" strokeLinecap="round" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="18" x2="6" y1="6" y2="18" />
      <line x1="6" x2="18" y1="6" y2="18" />
    </svg>
  );
}
function DragHandleIcon() {
  return (
    <svg fill="currentColor" height="12" width="12" viewBox="0 0 24 24">
      <circle cx="9" cy="6" r="1.5" />
      <circle cx="9" cy="12" r="1.5" />
      <circle cx="9" cy="18" r="1.5" />
      <circle cx="15" cy="6" r="1.5" />
      <circle cx="15" cy="12" r="1.5" />
      <circle cx="15" cy="18" r="1.5" />
    </svg>
  );
}

function PageTab({
  page,
  active,
  draggable,
  onSelect,
}: {
  page: DashboardPage;
  active: boolean;
  draggable: boolean;
  onSelect: () => void;
}) {
  const renamePage = useDashboardStore((s) => s.renamePage);
  const deletePage = useDashboardStore((s) => s.deletePage);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(page.name);

  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: page.id,
    disabled: !draggable,
  });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.6 : 1,
  };

  function commitRename() {
    const trimmed = draft.trim();
    if (trimmed && trimmed !== page.name) renamePage(page.id, trimmed);
    else setDraft(page.name);
    setEditing(false);
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`group flex shrink-0 items-center gap-1.5 border-b-[2.5px] px-3 py-2.5 text-[13px] ${
        active ? "border-primary font-semibold text-primary" : "border-transparent font-medium text-muted hover:text-ink"
      }`}
    >
      {draggable && (
        <button
          type="button"
          className="cursor-grab text-muted-2 opacity-0 group-hover:opacity-100 active:cursor-grabbing"
          aria-label="Reorder page"
          {...attributes}
          {...listeners}
        >
          <DragHandleIcon />
        </button>
      )}
      {editing ? (
        <input
          autoFocus
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={commitRename}
          onKeyDown={(e) => {
            if (e.key === "Enter") commitRename();
            if (e.key === "Escape") {
              setDraft(page.name);
              setEditing(false);
            }
          }}
          className="h-6 w-32 rounded border border-primary bg-bg px-1.5 text-[13px] text-ink outline-none"
        />
      ) : (
        <button type="button" onClick={onSelect} onDoubleClick={() => setEditing(true)}>
          {page.name}
        </button>
      )}
      {page.deletable && (
        <button
          type="button"
          onClick={() => deletePage(page.id)}
          className="text-muted-2 opacity-0 hover:text-danger group-hover:opacity-100"
          aria-label={`Delete ${page.name}`}
        >
          <CloseIcon />
        </button>
      )}
    </div>
  );
}

// scopeKey identifies which dashboard's pages to list/add/reorder (see
// src/types/dashboardContext.ts's dashboardScopeKey()). Omitted (today's one
// unscoped /dashboard route) keeps prior behavior exactly: every page
// without a scopeKey is treated as belonging to "consolidated::global" and
// listed/added/reordered together, same as before this prop existed.
const CONSOLIDATED_SCOPE_KEY = "consolidated::global";

export function DashboardPageTabs({
  activePageId,
  onSelect,
  scopeKey,
}: {
  activePageId: string;
  onSelect: (pageId: string) => void;
  scopeKey?: string;
}) {
  const pages = useDashboardStore((s) => s.pages);
  const addPage = useDashboardStore((s) => s.addPage);
  const reorderPages = useDashboardStore((s) => s.reorderPages);
  const [addingPage, setAddingPage] = useState(false);
  const [newPageName, setNewPageName] = useState("");

  const effectiveScopeKey = scopeKey ?? CONSOLIDATED_SCOPE_KEY;
  const scopedPages = pages.filter((p) => (p.scopeKey ?? CONSOLIDATED_SCOPE_KEY) === effectiveScopeKey);
  const sorted = [...scopedPages].sort((a, b) => a.order - b.order);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));

  if (sorted.length === 0) return null;
  const [firstPage, ...reorderablePages] = sorted;

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const ids = reorderablePages.map((p) => p.id);
    const oldIndex = ids.indexOf(String(active.id));
    const newIndex = ids.indexOf(String(over.id));
    if (oldIndex === -1 || newIndex === -1) return;
    reorderPages([firstPage.id, ...arrayMove(ids, oldIndex, newIndex)]);
  }

  function commitAddPage() {
    const name = newPageName.trim() || "Untitled Page";
    const id = addPage(name, scopeKey);
    onSelect(id);
    setNewPageName("");
    setAddingPage(false);
  }

  return (
    <div className="flex flex-wrap items-center gap-0.5 border-b border-border">
      <PageTab page={firstPage} active={firstPage.id === activePageId} draggable={false} onSelect={() => onSelect(firstPage.id)} />
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={reorderablePages.map((p) => p.id)} strategy={horizontalListSortingStrategy}>
          {reorderablePages.map((page) => (
            <PageTab key={page.id} page={page} active={page.id === activePageId} draggable onSelect={() => onSelect(page.id)} />
          ))}
        </SortableContext>
      </DndContext>
      {addingPage ? (
        <input
          autoFocus
          value={newPageName}
          onChange={(e) => setNewPageName(e.target.value)}
          onBlur={commitAddPage}
          onKeyDown={(e) => {
            if (e.key === "Enter") commitAddPage();
            if (e.key === "Escape") {
              setAddingPage(false);
              setNewPageName("");
            }
          }}
          placeholder="Page name"
          className="ml-2 h-7 w-32 rounded border border-primary bg-bg px-1.5 text-[13px] text-ink outline-none"
        />
      ) : (
        <button
          type="button"
          onClick={() => setAddingPage(true)}
          className="ml-2 flex shrink-0 items-center gap-1 rounded-md px-2.5 py-1.5 text-[13px] font-medium text-muted hover:bg-bg hover:text-ink"
        >
          <PlusIcon /> Add Page
        </button>
      )}
    </div>
  );
}
