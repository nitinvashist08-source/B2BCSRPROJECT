"use client";

import { useSettingsStore } from "@/store/settingsStore";
import { Dropdown } from "@/components/ui/Dropdown";

function ChevronDownIcon() {
  return (
    <svg fill="none" height="16" width="16" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" viewBox="0 0 24 24">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

// Independent Partner filter for the Consolidated Sponsor Dashboard (see
// src/types/dashboardFilters.ts). Deliberately mirrors DashboardSelector.tsx's
// dropdown look (trigger button classes, chevron/check icons, row markup) so
// it reads as part of the same control family, but this component only ever
// narrows data on the current page — it never navigates, and it knows
// nothing about the Project filter sitting next to it.
export function PartnerFilter({
  value,
  onChange,
}: {
  value: string | null; // selected PartnerOrg.id, or null = "All Partners"
  onChange: (partnerId: string | null) => void;
}) {
  const partners = useSettingsStore((s) => s.partners);

  const label = value === null ? "All Partners" : partners.find((p) => p.id === value)?.name ?? "All Partners";

  return (
    <Dropdown
      align="right"
      trigger={
        <button
          type="button"
          className="flex h-9 items-center gap-2 rounded-sm border border-border bg-surface px-3 text-sm font-medium text-ink-2 hover:border-border-strong hover:bg-surface-2"
        >
          <span className="max-w-[220px] truncate">{label}</span>
          <ChevronDownIcon />
        </button>
      }
    >
      <div className="max-h-[360px] w-[240px] overflow-y-auto">
        <button
          type="button"
          onClick={() => onChange(null)}
          className={`flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-2 ${
            value === null ? "font-semibold text-primary-700" : "text-ink-2"
          }`}
        >
          <span className="truncate">All Partners</span>
          {value === null && <CheckIcon />}
        </button>

        {partners.map((partner) => (
          <button
            key={partner.id}
            type="button"
            onClick={() => onChange(partner.id)}
            className={`flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-2 ${
              value === partner.id ? "font-semibold text-primary-700" : "text-ink-2"
            }`}
          >
            <span className="truncate">{partner.name}</span>
            {value === partner.id && <CheckIcon />}
          </button>
        ))}
      </div>
    </Dropdown>
  );
}
