"use client";

import { Card } from "@/components/ui/Card";
import { Visualization } from "@/types/dashboard";
import { BarChartCard } from "./charts/BarChartCard";
import { LineChartCard } from "./charts/LineChartCard";
import { AreaChartCard } from "./charts/AreaChartCard";
import { PieChartCard } from "./charts/PieChartCard";
import { KpiCard } from "./charts/KpiCard";
import { TableCard } from "./charts/TableCard";

function DragHandleIcon() {
  return (
    <svg fill="currentColor" height="14" width="14" viewBox="0 0 24 24" className="shrink-0">
      <circle cx="9" cy="6" r="1.5" />
      <circle cx="9" cy="12" r="1.5" />
      <circle cx="9" cy="18" r="1.5" />
      <circle cx="15" cy="6" r="1.5" />
      <circle cx="15" cy="12" r="1.5" />
      <circle cx="15" cy="18" r="1.5" />
    </svg>
  );
}
function EditIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4Z" />
    </svg>
  );
}
function TrashIcon() {
  return (
    <svg fill="none" height="14" width="14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M3 6h18" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}

function renderChart(viz: Visualization) {
  switch (viz.kind) {
    case "bar":
      return <BarChartCard viz={viz} />;
    case "line":
      return <LineChartCard viz={viz} />;
    case "area":
      return <AreaChartCard viz={viz} />;
    case "pie":
    case "donut":
      return <PieChartCard viz={viz} />;
    case "kpi":
      return <KpiCard viz={viz} />;
    case "table":
      return <TableCard viz={viz} />;
  }
}

// No size-menu here on purpose — free-form width/height comes from dragging
// the resize handle react-grid-layout renders at the card's bottom-right
// corner (see VisualizationCanvas.tsx). The header below is the *drag*
// handle (react-grid-layout's `draggableHandle`/`draggableCancel`), scoped
// so moving a card never fights with clicking Edit/Remove or interacting
// with the chart itself (tooltips, legends).
export function VisualizationCard({
  viz,
  onEdit,
  onRemove,
}: {
  viz: Visualization;
  onEdit: () => void;
  onRemove: () => void;
}) {
  return (
    <Card className="flex h-full flex-col overflow-hidden">
      <div className="viz-drag-handle mb-3 flex cursor-grab items-center justify-between gap-2 active:cursor-grabbing">
        <div className="flex min-w-0 items-center gap-1.5 text-muted-2">
          <DragHandleIcon />
          <h3 className="truncate text-sm font-semibold text-ink">{viz.title}</h3>
        </div>
        <div className="flex shrink-0 items-center gap-1 text-muted-2">
          <button type="button" onClick={onEdit} className="p-1 hover:text-primary" aria-label="Edit visualization">
            <EditIcon />
          </button>
          <button type="button" onClick={onRemove} className="p-1 hover:text-danger" aria-label="Remove visualization">
            <TrashIcon />
          </button>
        </div>
      </div>
      <div className="min-h-0 flex-1">{renderChart(viz)}</div>
    </Card>
  );
}
