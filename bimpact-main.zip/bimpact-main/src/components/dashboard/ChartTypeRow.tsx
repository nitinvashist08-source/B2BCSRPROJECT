"use client";

import { ChartTypeDef } from "@/lib/chartRegistry";
import { ChartTypePreview } from "./ChartTypePreview";

// One row of Add Visualization's chart-TYPE library (step 1) — full overlay
// width, one per row (never a grid). Preview sits on top with its own
// dedicated, generously-sized box (name/description never sit beside it —
// per spec, content order is strictly Preview → Name → Description), so
// circular charts have enough room to render their full circumference
// (see PieChartCard.tsx's percentage-radius fix) without clipping.
// Clicking anywhere on the row selects it. This answers "how should the
// data be displayed" only — it never binds to a dataset/metric, that's the
// existing configuration step's job (see AddVisualizationSlideOver.tsx).
export function ChartTypeRow({ type, selected, onSelect }: { type: ChartTypeDef; selected: boolean; onSelect: () => void }) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={`flex w-full flex-col overflow-hidden rounded-lg border-[1.5px] text-left transition-colors ${
        selected ? "border-primary bg-primary-50" : "border-border bg-surface hover:border-border-strong hover:bg-surface-2"
      }`}
    >
      <div className="h-[160px] w-full shrink-0 border-b border-border bg-bg p-3">
        <ChartTypePreview type={type} />
      </div>
      <div className="p-3.5">
        <h4 className={`text-[13.5px] font-bold ${selected ? "text-primary-700" : "text-ink"}`}>{type.label}</h4>
        <p className="mt-1 text-[12.5px] leading-snug text-muted">{type.description}</p>
      </div>
    </button>
  );
}
