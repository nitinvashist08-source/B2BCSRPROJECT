import { MarketingLayout } from "./MarketingLayout";
import { Hero } from "./Hero";
import { Capabilities } from "./Capabilities";
import { HowItWorks } from "./HowItWorks";
import { TrustSignals } from "./TrustSignals";

export function LandingPage() {
  return (
    <MarketingLayout>
      <Hero />
      <Capabilities />
      <HowItWorks />
      <TrustSignals />
    </MarketingLayout>
  );
}
