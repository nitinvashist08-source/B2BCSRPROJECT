function ArrowIcon() {
  return (
    <svg
      className="hidden shrink-0 text-border-strong sm:block"
      fill="none"
      width="20"
      height="20"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      viewBox="0 0 24 24"
    >
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </svg>
  );
}

function StepRow({ steps, tint }: { steps: string[]; tint: string }) {
  return (
    <div className="flex flex-wrap items-center gap-2.5">
      {steps.map((step, i) => (
        <div key={step} className="flex items-center gap-2.5">
          <span className={`rounded-full border px-3.5 py-1.5 text-[13px] font-semibold ${tint}`}>{step}</span>
          {i < steps.length - 1 && <ArrowIcon />}
        </div>
      ))}
    </div>
  );
}

export function HowItWorks() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-20">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="text-3xl font-bold tracking-tight text-ink">How it works</h2>
        <p className="mt-3 text-base text-muted">Two journeys, one shared platform.</p>
      </div>

      <div className="mt-14 flex flex-col gap-10">
        <div className="rounded-lg border border-border bg-surface p-7 shadow-sm">
          <h3 className="text-[15px] font-semibold text-ink">For Sponsors</h3>
          <div className="mt-5">
            <StepRow
              steps={["Plan", "Fund", "Collaborate", "Monitor", "Measure Impact"]}
              tint="border-primary-100 bg-primary-50 text-primary-700"
            />
          </div>
        </div>

        <div className="rounded-lg border border-border bg-surface p-7 shadow-sm">
          <h3 className="text-[15px] font-semibold text-ink">For Implementing Partners</h3>
          <div className="mt-5">
            <StepRow
              steps={["Onboard", "Execute Projects", "Collect Data", "Report Progress", "Demonstrate Impact"]}
              tint="border-secondary-100 bg-secondary-50 text-secondary-600"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
