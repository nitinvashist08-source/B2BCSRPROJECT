"use client";

import { useState } from "react";
import { useSessionStore } from "@/store/sessionStore";
import { Button } from "@/components/ui/Button";
import { Field, inputCls } from "@/components/marketing/AuthCard";
import { AUTH_TRANSITION_PATH } from "@/lib/roleRouting";

// Single unified login form — no Sponsor/Partner choice. Role is
// auto-detected by loginWithCredentials (sessionStore) from the entered
// email against settingsStore's partner directory; this component doesn't
// need to know which role it ended up logging in as.
export function LoginForm() {
  const loginWithCredentials = useSessionStore((s) => s.loginWithCredentials);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(false);

  // Hard navigation, not router.push — this codebase deliberately avoids
  // client-side transitions across the auth boundary (see AppShell.tsx's
  // comment). loginWithCredentials persists synchronously via the
  // login/loginAsPartner action it calls, so it's safe to navigate
  // immediately after a successful result.
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    const result = loginWithCredentials(email, password);
    if (!result.ok) {
      setError(true);
      setSubmitting(false);
      return;
    }
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination
    window.location.href = AUTH_TRANSITION_PATH;
  }

  return (
    <form onSubmit={handleSubmit}>
      <Field label="Email">
        <input
          required
          type="email"
          className={inputCls}
          placeholder="you@company.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </Field>
      <Field label="Password">
        <input
          required
          type="password"
          className={inputCls}
          placeholder="••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </Field>

      <Button type="submit" variant="primary" size="md" className="mt-1 w-full" disabled={submitting}>
        {submitting ? "Signing in..." : "Log In"}
      </Button>

      {error && (
        <div className="mt-3 rounded-lg border border-border bg-surface p-3 text-[13px] text-ink-2">
          Enter your email and password to continue.
        </div>
      )}
    </form>
  );
}
