import Link from "next/link";
import { Button } from "@/components/ui/Button";

export function MarketingNav() {
  return (
    <header className="sticky top-0 z-10 border-b border-border bg-surface/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
        <Link href="/" className="flex items-center gap-2.5">
          <span
            className="flex h-8 w-8 items-center justify-center rounded-[9px] text-[13px] font-extrabold tracking-tight text-white"
            style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
          >
            bI
          </span>
          <span className="text-[15px] font-semibold tracking-tight text-ink">bImpact</span>
        </Link>

        <div className="flex items-center gap-3">
          <Link href="/login">
            <Button variant="ghost" size="md">
              Log In
            </Button>
          </Link>
          <Link href="/register">
            <Button variant="primary" size="md">
              Get Started
            </Button>
          </Link>
        </div>
      </div>
    </header>
  );
}
