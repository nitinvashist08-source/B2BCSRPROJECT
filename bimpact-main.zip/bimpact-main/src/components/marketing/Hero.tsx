import Link from "next/link";
import { Button } from "@/components/ui/Button";

function BuildingIcon() {
  return (
    <svg fill="none" width="22" height="22" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="14" rx="2" width="20" x="2" y="7" />
      <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
    </svg>
  );
}

function HandshakeIcon() {
  return (
    <svg fill="none" width="22" height="22" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

export function Hero() {
  return (
    <section className="mx-auto max-w-6xl px-6 pb-20 pt-20 sm:pt-28">
      <div className="mx-auto max-w-3xl text-center">
        <span className="inline-flex items-center rounded-full border border-border bg-surface px-3.5 py-1 text-xs font-semibold uppercase tracking-wide text-primary-700">
          CSR &amp; Social Impact Management
        </span>
        <h1 className="mt-6 text-4xl font-extrabold leading-tight tracking-tight text-ink sm:text-5xl">
          One platform to fund, manage, and measure social impact
        </h1>
        <p className="mt-5 text-lg leading-relaxed text-muted">
          bImpact brings corporate sponsors and implementing partners together on a single
          system — for budgeting, collaboration, compliance, and monitoring across every CSR
          initiative.
        </p>
        <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link href="/register">
            <Button variant="primary" size="md" className="h-12 px-8 text-base">
              Get Started
            </Button>
          </Link>
          <Link href="/login">
            <Button variant="ghost" size="md" className="h-12 px-8 text-base">
              Log In
            </Button>
          </Link>
        </div>
      </div>

      <div className="mx-auto mt-16 grid max-w-4xl grid-cols-1 gap-5 sm:grid-cols-2">
        <div className="rounded-lg border border-border bg-surface p-7 shadow-sm">
          <div className="flex h-11 w-11 items-center justify-center rounded-[10px] bg-primary-50 text-primary">
            <BuildingIcon />
          </div>
          <h3 className="mt-4 text-base font-semibold text-ink">Sponsors &amp; Corporates</h3>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Fund, manage, monitor, and govern CSR initiatives — with full visibility into
            budgets, disbursements, and compliance across every partner and project.
          </p>
        </div>
        <div className="rounded-lg border border-border bg-surface p-7 shadow-sm">
          <div className="flex h-11 w-11 items-center justify-center rounded-[10px] bg-secondary-50 text-secondary">
            <HandshakeIcon />
          </div>
          <h3 className="mt-4 text-base font-semibold text-ink">Implementing Partners &amp; NGOs</h3>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Implement projects, manage field execution, and run impact activities — with a
            single place to report progress and demonstrate outcomes to sponsors.
          </p>
        </div>
      </div>
    </section>
  );
}
