const PLACEHOLDER_LOGOS = ["Acme Foundation", "Northstar Group", "Bluepeak CSR", "Meridian Trust", "Civica Partners"];

const TESTIMONIALS: { quote: string; name: string; role: string }[] = [
  {
    quote: "Illustrative quote — bImpact gave our CSR team one place to track every partner's budget and progress.",
    name: "Sample Sponsor",
    role: "Head of CSR, placeholder company",
  },
  {
    quote: "Illustrative quote — reporting to our sponsor used to take days; now it's continuous and effortless.",
    name: "Sample Partner",
    role: "Program Director, placeholder NGO",
  },
  {
    quote: "Illustrative quote — compliance and disbursement tracking finally live in the same system.",
    name: "Sample Sponsor",
    role: "Finance Controller, placeholder company",
  },
];

const STATS: { value: string; label: string }[] = [
  { value: "50+", label: "Programs Managed" },
  { value: "₹100Cr+", label: "Disbursed" },
  { value: "200+", label: "Implementing Partners" },
];

export function TrustSignals() {
  return (
    <section className="border-t border-border bg-surface-2 py-20">
      <div className="mx-auto max-w-6xl px-6">
        <p className="text-center text-xs font-semibold uppercase tracking-wide text-muted-2">
          Illustrative example — not real customer data
        </p>

        <div className="mt-7 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
          {PLACEHOLDER_LOGOS.map((logo) => (
            <span key={logo} className="text-sm font-semibold tracking-wide text-muted-2 grayscale">
              {logo}
            </span>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-3">
          {STATS.map((stat) => (
            <div key={stat.label} className="rounded-lg border border-border bg-surface p-7 text-center shadow-sm">
              <div className="text-3xl font-extrabold tracking-tight text-primary">{stat.value}</div>
              <div className="mt-1.5 text-sm text-muted">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="mt-10 grid grid-cols-1 gap-5 md:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <div key={i} className="rounded-lg border border-border bg-surface p-6 shadow-sm">
              <p className="text-sm italic leading-relaxed text-ink-2">&ldquo;{t.quote}&rdquo;</p>
              <p className="mt-4 text-[13px] font-semibold text-ink">{t.name}</p>
              <p className="text-xs text-muted">{t.role}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
