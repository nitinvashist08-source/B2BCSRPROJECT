import { ReactNode } from "react";

function CollaborationIcon() {
  return (
    <svg fill="none" width="24" height="24" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

function BudgetIcon() {
  return (
    <svg fill="none" width="24" height="24" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <rect height="14" rx="2" width="20" x="2" y="5" />
      <line x1="2" x2="22" y1="10" y2="10" />
    </svg>
  );
}

function ComplianceIcon() {
  return (
    <svg fill="none" width="24" height="24" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M12 2 4 5v6c0 5 3.4 9.4 8 11 4.6-1.6 8-6 8-11V5l-8-3Z" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}

function MonitoringIcon() {
  return (
    <svg fill="none" width="24" height="24" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24">
      <line x1="18" x2="18" y1="20" y2="10" />
      <line x1="12" x2="12" y1="20" y2="4" />
      <line x1="6" x2="6" y1="20" y2="14" />
    </svg>
  );
}

const CAPABILITIES: { icon: ReactNode; title: string; description: string; tint: string }[] = [
  {
    icon: <CollaborationIcon />,
    title: "Project Collaboration",
    description: "Sponsors and partners work from a shared project workspace, from proposal through closure.",
    tint: "bg-primary-50 text-primary",
  },
  {
    icon: <BudgetIcon />,
    title: "Budgeting & Finance",
    description: "Plan budgets, track disbursements, and book expenses with a single financial thread per project.",
    tint: "bg-secondary-50 text-secondary",
  },
  {
    icon: <ComplianceIcon />,
    title: "Compliance",
    description: "Keep documentation, approvals, and governance records aligned with CSR regulatory requirements.",
    tint: "bg-amber-50 text-amber-600",
  },
  {
    icon: <MonitoringIcon />,
    title: "Monitoring & Evaluation",
    description: "Track indicators and outcomes as they happen, so impact is measured, not just reported.",
    tint: "bg-purple-50 text-purple",
  },
];

export function Capabilities() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-20">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="text-3xl font-bold tracking-tight text-ink">Everything CSR management needs, in one place</h2>
        <p className="mt-3 text-base text-muted">
          Purpose-built modules for the full lifecycle of a social-impact initiative.
        </p>
      </div>

      <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {CAPABILITIES.map((cap) => (
          <div key={cap.title} className="rounded-lg border border-border bg-surface p-6 shadow-sm">
            <div className={`flex h-11 w-11 items-center justify-center rounded-[10px] ${cap.tint}`}>{cap.icon}</div>
            <h3 className="mt-4 text-[15px] font-semibold text-ink">{cap.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{cap.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
