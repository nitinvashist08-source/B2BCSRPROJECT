import Link from "next/link";
import { ReactNode } from "react";

// Shared centered-card shell for the auth screens (register, login chooser,
// login/sponsor, login/partner). Reuses the old LoginGate's visual language:
// a bImpact "bI" mark, a centered white card on a full-height bg-bg screen.
// Deliberately NOT wrapped in MarketingLayout/MarketingNav — these are
// minimal auth screens, not marketing pages.
export function AuthCard({
  title,
  subtitle,
  children,
  footer,
  width = "380px",
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  width?: string;
}) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-bg px-4">
      <Link href="/" className="flex items-center gap-2.5">
        <span
          className="flex h-9 w-9 items-center justify-center rounded-[9px] text-[14px] font-extrabold tracking-tight text-white"
          style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
        >
          bI
        </span>
        <span className="text-[15px] font-semibold tracking-tight text-ink">bImpact</span>
      </Link>

      <div
        className="w-full rounded-xl border border-border bg-surface p-7 shadow-sm"
        style={{ maxWidth: width }}
      >
        <h2 className="text-lg font-bold text-ink">{title}</h2>
        {subtitle && <p className="mt-1 text-[13px] text-muted">{subtitle}</p>}
        <div className="mt-5">{children}</div>
      </div>

      {footer && <div className="text-[13px] text-muted">{footer}</div>}
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-3.5">
      <label className="mb-1.5 block text-xs font-semibold text-ink-2">{label}</label>
      {children}
    </div>
  );
}

export const inputCls =
  "box-border h-[38px] w-full rounded-lg border-[1.5px] border-border bg-bg px-3 text-[13px] text-ink outline-none transition-colors focus:border-primary";
