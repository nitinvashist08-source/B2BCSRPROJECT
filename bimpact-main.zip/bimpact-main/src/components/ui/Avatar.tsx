const PALETTE = [
  "#0A97D9",
  "#00A651",
  "#F59E0B",
  "#8B5CF6",
  "#EF4444",
  "#0881BB",
  "#008C45",
];

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function colorForName(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  }
  return PALETTE[hash % PALETTE.length];
}

const sizeMap = {
  sm: { box: 24, font: 10 },
  md: { box: 32, font: 12 },
  lg: { box: 44, font: 15 },
};

export function Avatar({
  name,
  size = "md",
  color,
}: {
  name: string;
  size?: keyof typeof sizeMap;
  color?: string;
}) {
  const { box, font } = sizeMap[size];
  return (
    <span
      className="inline-flex shrink-0 items-center justify-center rounded-full font-semibold text-white"
      style={{
        width: box,
        height: box,
        fontSize: font,
        background: color ?? colorForName(name),
      }}
      title={name}
    >
      {initials(name)}
    </span>
  );
}
