"use client";

import { useEffect, useRef } from "react";

const INLINE_COMMANDS = [
  { cmd: "bold", label: "Bold", icon: "B" },
  { cmd: "italic", label: "Italic", icon: "I" },
  { cmd: "underline", label: "Underline", icon: "U" },
];
const LIST_COMMANDS = [
  { cmd: "insertUnorderedList", label: "Bullet", icon: "•" },
  { cmd: "insertOrderedList", label: "Numbered", icon: "1." },
];
// mgmt-rte-tb / csrp-ed toolbar, bImpact_MeetingSplit_v10.html:10703-10714
// (meeting agenda/notes) and :12239-12248 (CSR policy — same base commands
// plus H2/H3/paragraph formatBlock buttons).
const HEADING_COMMANDS = [
  { block: "h2", label: "Heading", icon: "H2" },
  { block: "h3", label: "Sub-heading", icon: "H3" },
  { block: "p", label: "Paragraph", icon: "¶" },
];

function Separator() {
  return <span className="mx-1 h-4 w-px shrink-0 bg-border" />;
}

export function RichTextEditor({
  value,
  onChange,
  placeholder,
  minHeight = 160,
  headings = false,
  bare = false,
  autoFocus = false,
}: {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  minHeight?: number;
  headings?: boolean;
  // Drops the outer border/radius (source's inline `style="border:none;
  // border-radius:0"` override on the Execute & MoM notes editor, which
  // already sits inside its own bordered card — see MeetingExecutionSection.
  // Every other caller is unaffected (defaults to the existing bordered look).
  bare?: boolean;
  // Places the caret in the editor as soon as it mounts — used by
  // WbsRemarksField.tsx's click-to-activate Remarks field, which swaps this
  // in only once the user has already clicked, matching the Jira-style "you
  // clicked, so you can type immediately" expectation. Every other caller
  // is unaffected (defaults to false, unchanged behavior).
  autoFocus?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const initialized = useRef(false);

  useEffect(() => {
    // contentEditable is uncontrolled after mount (re-setting innerHTML on every
    // keystroke would reset the caret), so only seed it once.
    if (!initialized.current && ref.current) {
      ref.current.innerHTML = value;
      initialized.current = true;
      if (autoFocus) ref.current.focus();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  return (
    <div className={bare ? "" : "rounded-sm border border-border"}>
      <div className="flex items-center gap-1 border-b border-border bg-surface-2 px-2 py-1.5">
        {INLINE_COMMANDS.map((c) => (
          <button
            key={c.cmd}
            type="button"
            title={c.label}
            onMouseDown={(e) => {
              e.preventDefault();
              document.execCommand(c.cmd);
              if (ref.current) onChange(ref.current.innerHTML);
            }}
            className="flex h-7 w-7 items-center justify-center rounded-sm text-sm font-semibold text-ink-2 hover:bg-white"
          >
            {c.icon}
          </button>
        ))}
        <Separator />
        {LIST_COMMANDS.map((c) => (
          <button
            key={c.cmd}
            type="button"
            title={c.label}
            onMouseDown={(e) => {
              e.preventDefault();
              document.execCommand(c.cmd);
              if (ref.current) onChange(ref.current.innerHTML);
            }}
            className="flex h-7 w-7 items-center justify-center rounded-sm text-sm font-semibold text-ink-2 hover:bg-white"
          >
            {c.icon}
          </button>
        ))}
        {headings && (
          <>
            <Separator />
            {HEADING_COMMANDS.map((c) => (
              <button
                key={c.block}
                type="button"
                title={c.label}
                onMouseDown={(e) => {
                  e.preventDefault();
                  document.execCommand("formatBlock", false, c.block);
                  if (ref.current) onChange(ref.current.innerHTML);
                }}
                className="flex h-7 min-w-7 items-center justify-center rounded-sm px-1 text-[11px] font-bold text-ink-2 hover:bg-white"
              >
                {c.icon}
              </button>
            ))}
          </>
        )}
      </div>
      <div
        ref={ref}
        contentEditable
        suppressContentEditableWarning
        data-placeholder={placeholder}
        onInput={(e) => onChange(e.currentTarget.innerHTML)}
        className={`empty:before:content-[attr(data-placeholder)] empty:before:text-muted-2 text-sm text-ink outline-none ${
          bare ? "bg-[#FDFCFB] px-4 py-3.5" : "px-3 py-2"
        }`}
        style={{ minHeight }}
      />
    </div>
  );
}
