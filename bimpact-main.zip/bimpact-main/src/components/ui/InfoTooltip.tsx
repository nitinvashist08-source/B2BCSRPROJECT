// Small "ⓘ" info icon shown next to a form field's label, with the
// explanatory one-liner as a native title tooltip (no popover/portal
// needed — a plain title attribute is never clipped by a scrollable
// slide-over container, unlike the app's other floating menus). Used by
// TaskFormSlideOver.tsx/WbsRemarksField.tsx per the Add Task spec's
// "every configurable field needs a concise one-line tooltip" requirement.
export function InfoTooltip({ text }: { text: string }) {
  return (
    <span
      tabIndex={0}
      title={text}
      aria-label={text}
      className="inline-flex h-3.5 w-3.5 shrink-0 cursor-help items-center justify-center rounded-full border border-border-strong text-[9px] font-bold leading-none text-muted-2 outline-none focus-visible:ring-2 focus-visible:ring-primary-500"
    >
      i
    </span>
  );
}

// Field label + required-star + InfoTooltip, in the exact spacing this
// app's slide-over forms already use (see CreateProjectSlideOver.tsx).
export function WbsFieldLabel({ label, tooltip, required }: { label: string; tooltip: string; required?: boolean }) {
  return (
    <span className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-ink-2">
      {label} {required && <span className="text-danger">*</span>}
      <InfoTooltip text={tooltip} />
    </span>
  );
}
