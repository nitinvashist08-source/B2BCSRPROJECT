import { ReactNode } from "react";

export type BadgeTone =
  | "primary"
  | "secondary"
  | "amber"
  | "danger"
  | "purple"
  | "muted";

const toneClasses: Record<BadgeTone, string> = {
  primary: "bg-primary-50 text-primary-700",
  secondary: "bg-secondary-50 text-secondary-600",
  amber: "bg-amber-50 text-amber-600",
  danger: "bg-danger-50 text-danger",
  purple: "bg-purple-50 text-purple",
  muted: "bg-surface-2 text-muted border border-border",
};

export function Badge({
  tone = "muted",
  dot = true,
  children,
}: {
  tone?: BadgeTone;
  dot?: boolean;
  children: ReactNode;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${toneClasses[tone]}`}
    >
      {dot && (
        <span
          className="h-1.5 w-1.5 rounded-full bg-current opacity-70"
          aria-hidden
        />
      )}
      {children}
    </span>
  );
}
