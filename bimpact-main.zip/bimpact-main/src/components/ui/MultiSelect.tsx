"use client";

import { useEffect, useRef, useState } from "react";
import { useClickOutside } from "@/hooks/useClickOutside";

export function MultiSelect({
  options,
  value,
  onChange,
  placeholder = "Select…",
  openUpward = false,
  showSelectAll = false,
}: {
  options: string[];
  value: string[];
  onChange: (value: string[]) => void;
  placeholder?: string;
  // Set true when this MultiSelect sits near the bottom of a scrollable
  // container (e.g. the last field in a slide-over form) so its panel
  // doesn't get clipped by the container's edge. Default unchanged for
  // every existing caller.
  openUpward?: boolean;
  // Adds a "Select All" row above the option list, pinned outside the
  // scrollable/search-filtered area so it always applies to every option,
  // not just currently-matching search results. Default unchanged for
  // every existing caller.
  showSelectAll?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef<HTMLDivElement>(null);
  useClickOutside(ref, () => setOpen(false), open);

  const filtered = options.filter((o) => o.toLowerCase().includes(search.toLowerCase()));

  const allSelected = options.length > 0 && options.every((o) => value.includes(o));
  const someSelected = value.length > 0 && !allSelected;
  const selectAllRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (selectAllRef.current) selectAllRef.current.indeterminate = someSelected;
  }, [someSelected]);

  function toggle(option: string) {
    onChange(value.includes(option) ? value.filter((v) => v !== option) : [...value, option]);
  }
  function toggleSelectAll() {
    onChange(allSelected ? [] : options);
  }

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex min-h-9 w-full flex-wrap items-center gap-1 rounded-sm border border-border px-2 py-1.5 text-left text-sm"
      >
        {value.length === 0 && <span className="text-muted-2">{placeholder}</span>}
        {value.map((v) => (
          <span
            key={v}
            className="flex items-center gap-1 rounded-full bg-primary-50 px-2 py-0.5 text-xs text-primary-700"
          >
            {v}
            <span
              role="button"
              tabIndex={-1}
              onClick={(e) => {
                e.stopPropagation();
                toggle(v);
              }}
              className="cursor-pointer"
            >
              ✕
            </span>
          </span>
        ))}
      </button>
      {open && (
        <div className={`absolute z-50 w-full rounded-sm border border-border bg-surface shadow-md ${openUpward ? "bottom-full mb-1" : "mt-1"}`}>
          <input
            autoFocus
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search…"
            className="w-full border-b border-border px-2 py-1.5 text-sm outline-none"
          />
          {showSelectAll && options.length > 0 && (
            <label className="flex cursor-pointer items-center gap-2 border-b border-border bg-surface-2 px-2 py-1.5 text-sm font-semibold text-ink-2">
              <input ref={selectAllRef} type="checkbox" checked={allSelected} onChange={toggleSelectAll} />
              Select All
            </label>
          )}
          <div className="max-h-48 overflow-y-auto py-1">
            {filtered.map((o) => (
              <label
                key={o}
                className="flex cursor-pointer items-center gap-2 px-2 py-1.5 text-sm hover:bg-surface-2"
              >
                <input type="checkbox" checked={value.includes(o)} onChange={() => toggle(o)} />
                {o}
              </label>
            ))}
            {filtered.length === 0 && <p className="px-2 py-2 text-xs text-muted">No matches.</p>}
          </div>
        </div>
      )}
    </div>
  );
}
