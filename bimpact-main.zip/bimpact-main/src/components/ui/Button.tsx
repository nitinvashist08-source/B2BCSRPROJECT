import { ButtonHTMLAttributes, forwardRef } from "react";

type Variant = "primary" | "ghost" | "danger" | "secondary";
type Size = "md" | "sm";

const variantClasses: Record<Variant, string> = {
  primary: "bg-primary text-white hover:bg-primary-600 border border-transparent",
  ghost:
    "bg-white text-ink-2 border border-border hover:bg-surface-2 hover:border-border-strong",
  danger: "bg-danger text-white hover:opacity-90 border border-transparent",
  secondary: "bg-secondary text-white hover:opacity-90 border border-transparent",
};

const sizeClasses: Record<Size, string> = {
  md: "h-9 px-4 text-sm",
  sm: "h-7 px-2.5 text-xs",
};

export const Button = forwardRef<
  HTMLButtonElement,
  ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: Size }
>(function Button(
  { variant = "primary", size = "md", className = "", ...props },
  ref
) {
  return (
    <button
      ref={ref}
      className={`inline-flex items-center justify-center gap-1.5 rounded-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      {...props}
    />
  );
});
