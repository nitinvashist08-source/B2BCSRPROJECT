import { HTMLAttributes, ReactNode } from "react";

export function Card({
  title,
  action,
  children,
  className = "",
  ...props
}: Omit<HTMLAttributes<HTMLDivElement>, "title"> & { title?: ReactNode; action?: ReactNode }) {
  return (
    <div
      className={`rounded-lg border border-border bg-surface shadow-sm ${className}`}
      style={{ padding: "var(--pad-card)" }}
      {...props}
    >
      {(title || action) && (
        <div className="mb-3 flex items-center justify-between">
          {title && <h3 className="text-sm font-semibold text-ink">{title}</h3>}
          {action}
        </div>
      )}
      {children}
    </div>
  );
}
