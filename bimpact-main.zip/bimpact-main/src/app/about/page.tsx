import { MarketingLayout } from "@/components/marketing/MarketingLayout";

export default function AboutPage() {
  return (
    <MarketingLayout>
      <section className="mx-auto max-w-3xl px-6 py-20">
        <h1 className="text-3xl font-bold tracking-tight text-ink">About bImpact</h1>
        <p className="mt-4 text-base leading-relaxed text-muted">
          bImpact is a platform for managing and collaborating on CSR and social-impact
          initiatives, connecting corporate sponsors with the implementing partners who
          deliver programs on the ground.
        </p>
      </section>
    </MarketingLayout>
  );
}
