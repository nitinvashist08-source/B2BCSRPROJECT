import Link from "next/link";
import { AuthCard } from "@/components/marketing/AuthCard";
import { LoginForm } from "@/components/marketing/LoginForm";

// Single unified login screen — role (sponsor vs. partner) is auto-detected
// from the entered email (see sessionStore's loginWithCredentials), so there
// is no Sponsor/Partner choice here.
export default function LoginPage() {
  return (
    <AuthCard
      title="Log In"
      footer={
        <>
          New here?{" "}
          <Link href="/register" className="font-semibold text-primary hover:underline">
            Get Started
          </Link>
        </>
      }
    >
      <LoginForm />
    </AuthCard>
  );
}
