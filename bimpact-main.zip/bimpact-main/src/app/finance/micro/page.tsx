import { MicroBudgetView } from "@/components/finance/MicroBudgetView";

export default function FinanceMicroPage() {
  return <MicroBudgetView />;
}
