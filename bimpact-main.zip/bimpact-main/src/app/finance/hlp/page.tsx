import { PeriodBudgetsPanel } from "@/components/finance/PeriodBudgetsPanel";
import { HighLevelBudgetTable } from "@/components/finance/HighLevelBudgetTable";

export default function FinanceHlpPage() {
  return (
    <div>
      <PeriodBudgetsPanel />
      <HighLevelBudgetTable />
    </div>
  );
}
