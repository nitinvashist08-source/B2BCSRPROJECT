"use client";

import { use, useEffect } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";
import { TranchePipeline } from "@/components/finance/TranchePipeline";

export default function FinanceDisbursementDetailPage({ params }: { params: Promise<{ projectId: string }> }) {
  const { projectId } = use(params);
  const projects = useProjectStore((s) => s.projects);
  const project = projects.find((p) => p.id === projectId);
  const seedIndex = projects.findIndex((p) => p.id === projectId);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const partners = useSettingsStore((s) => s.partners);

  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const allowedForPartner =
    role !== "partner" || (!!project && isProjectAssignedToPartner(project, projectPartners, partnerName));

  // Per-project access boundary for the "partner" role, mirroring
  // /projects/[id]/layout.tsx: a direct URL to a project outside the
  // partner's assignment must hard-redirect to the Disbursement Planning
  // list, not render that project's tranches. `window.location.href` matches
  // this app's established hard-navigation convention (see AppShell.tsx).
  useEffect(() => {
    if (role === "partner" && !allowedForPartner) {
      window.location.href = "/finance/disbursement";
    }
  }, [role, allowedForPartner]);

  if (role === "partner" && !allowedForPartner) {
    // Redirect is firing (see effect above) — render nothing so the
    // disallowed project's tranches never flash on screen first.
    return null;
  }

  return <TranchePipeline projectId={projectId} seedIndex={Math.max(seedIndex, 0)} />;
}
