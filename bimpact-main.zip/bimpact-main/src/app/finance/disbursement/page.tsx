import { DisbProjectList } from "@/components/finance/DisbProjectList";

export default function FinanceDisbursementPage() {
  return <DisbProjectList />;
}
