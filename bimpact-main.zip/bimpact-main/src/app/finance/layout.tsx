import { ReactNode } from "react";
import { FinanceTopBar } from "@/components/finance/FinanceTopBar";

// AppShell's <main> (src/components/shell/AppShell.tsx) is the scrolling
// container for every section and gives itself p-6 (24px) padding — but the
// source's .fin-topbar spans the full content width and sticks flush to the
// top of its scroll area (bImpact_MeetingSplit_v10.html:6379-6396). -m-6
// reclaims that 24px inset on every side so this subtree bleeds to main's
// true edges; each page's own content re-applies matching padding itself
// (e.g. HighLevelBudgetTable.tsx's p-[22px], mirroring .fin-body's own
// padding:22px 22px 40px in the source) instead of inheriting main's.
//
// `top-0` alone isn't enough on the sticky bar: sticky offsets are resolved
// against the scrolling ancestor's PADDING edge, not its border edge, so
// with main's 24px padding still in play a plain `top-0` bar would sit
// flush only until the first scroll, then snap down 24px and expose a gap
// of main's bg-bg color. `-top-6` (i.e. -24px, matching the padding being
// escaped) is what keeps it flush against the true top the whole time.
export default function FinanceLayout({ children }: { children: ReactNode }) {
  return (
    <div className="-m-6 flex flex-col" style={{ height: "calc(100% + 48px)" }}>
      <div className="sticky -top-6 z-10">
        <FinanceTopBar />
      </div>
      <div className="flex-1">{children}</div>
    </div>
  );
}
