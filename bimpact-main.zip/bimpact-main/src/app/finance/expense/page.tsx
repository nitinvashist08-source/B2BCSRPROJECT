import { ExpenseProjectList } from "@/components/finance/ExpenseProjectList";

export default function FinanceExpensePage() {
  return <ExpenseProjectList />;
}
