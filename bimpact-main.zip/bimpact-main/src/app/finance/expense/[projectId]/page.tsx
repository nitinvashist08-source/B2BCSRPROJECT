"use client";

import { use, useEffect } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";
import { ExpenseTable } from "@/components/finance/ExpenseTable";

export default function FinanceExpenseDetailPage({ params }: { params: Promise<{ projectId: string }> }) {
  const { projectId } = use(params);
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const partners = useSettingsStore((s) => s.partners);

  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const allowedForPartner =
    role !== "partner" || (!!project && isProjectAssignedToPartner(project, projectPartners, partnerName));

  // Per-project access boundary for the "partner" role, mirroring
  // /projects/[id]/layout.tsx: a direct URL to a project outside the
  // partner's assignment must hard-redirect to the Expense Booking list,
  // not render that project's expenses. `window.location.href` matches this
  // app's established hard-navigation convention (see AppShell.tsx).
  useEffect(() => {
    if (role === "partner" && !allowedForPartner) {
      window.location.href = "/finance/expense";
    }
  }, [role, allowedForPartner]);

  if (role === "partner" && !allowedForPartner) {
    // Redirect is firing (see effect above) — render nothing so the
    // disallowed project's expenses never flash on screen first.
    return null;
  }

  return <ExpenseTable projectId={projectId} />;
}
