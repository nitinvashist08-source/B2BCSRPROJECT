import { ReactNode } from "react";
import { SettingsPageHeader } from "@/components/settings/SettingsPageHeader";

export default function SettingsLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-full flex-col">
      <SettingsPageHeader />
      <div className="flex-1">{children}</div>
    </div>
  );
}
