"use client";

import { useSessionStore } from "@/store/sessionStore";
import { TeamMembersTable } from "@/components/settings/TeamMembersTable";
import { PartnerTeamMembersTable } from "@/components/settings/PartnerTeamMembersTable";

export default function SettingsUserPage() {
  const role = useSessionStore((s) => s.role);
  // Sponsor's render path is unchanged (still just <TeamMembersTable />);
  // a partner gets its own scoped table instead.
  return role === "partner" ? <PartnerTeamMembersTable /> : <TeamMembersTable />;
}
