"use client";

import { Suspense, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useSettingsStore } from "@/store/settingsStore";
import { validateInviteToken } from "@/lib/partnerInvite";
import { AuthCard } from "@/components/marketing/AuthCard";
import { PartnerOnboardingForm } from "@/components/partners/PartnerOnboardingForm";

// Entry point for a new partner reaching /partner-onboarding, in two ways —
// both converge on the exact same PartnerOnboardingForm (see that file's own
// header comment: one canonical wizard, entry-context-driven, no separate
// self-serve implementation):
// (1) a Sponsor-generated invite link (?token=...) — validated against
// seeded/persisted partners; every invalid-token reason (not found, already
// consumed, expired) collapses to the same "Invite not valid" message per
// spec, see src/lib/partnerInvite.ts. Constructs entry={type:"invited",
// partner}.
// (2) no token at all — reached from the simulated invite screen
// (src/app/partner-onboarding/invite), itself reached from the register
// page's "Partner Onboarding" link — no Sponsor invite exists at all.
// Constructs entry={type:"self_served"}.
// Unauthenticated + public route (see AppShell's
// PUBLIC_PREFIXES/PUBLIC_DATA_PREFIXES) but still needs settingsStore
// hydrated for the token lookup / duplicate-email check.
function PartnerOnboardingContent() {
  const token = useSearchParams().get("token");
  const partners = useSettingsStore((s) => s.partners);

  // Validated ONCE (lazy initializer), not re-derived on every `partners`
  // change. Completing the wizard itself nulls out inviteToken (a
  // deliberate one-time-use consumption — see activatePartner's own
  // comment), which would otherwise make THIS SAME re-render see the token
  // as newly "invalid" and yank the success screen out from under the
  // partner who just finished, replacing it with "Invite not valid" — the
  // wizard's own `submitted` state, not a continuously-re-checked token,
  // is what should govern what's shown from here on.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const [validation] = useState(() => (token ? validateInviteToken(partners, token) : null));

  if (!token) return <PartnerOnboardingForm entry={{ type: "self_served" }} />;

  if (!validation || !validation.ok) {
    return (
      <AuthCard title="Invite not valid">
        <p className="text-sm text-ink-2">
          This invite has expired — please contact the Sponsor Admin to request a new one.
        </p>
        <Link href="/" className="mt-4 inline-block text-[13px] font-semibold text-primary hover:underline">
          Back to home
        </Link>
      </AuthCard>
    );
  }

  return <PartnerOnboardingForm entry={{ type: "invited", partner: validation.partner }} />;
}

export default function PartnerOnboardingPage() {
  return (
    <Suspense fallback={null}>
      <PartnerOnboardingContent />
    </Suspense>
  );
}
