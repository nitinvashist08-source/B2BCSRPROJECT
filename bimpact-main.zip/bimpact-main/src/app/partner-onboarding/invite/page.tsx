"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { useWorkspaceStore } from "@/store/workspaceStore";
import { getLastPartnerInvite } from "@/lib/lastPartnerInvite";

// Simulated "you've received an invitation email" entry step, reached only
// from the self-serve path (Landing → Get Started → /register's "Partner
// Onboarding" link → here). A real Sponsor-issued invite link
// (/partner-onboarding?token=...) already IS a real invitation — it skips
// this screen entirely and goes straight to the existing Welcome step
// (see /partner-onboarding/page.tsx), unchanged. This page exists purely to
// make the self-serve entry point feel like the same "open an invite email,
// click the link" journey, without inventing a second onboarding
// implementation or any real email delivery — "Start Partner Onboarding"
// below just navigates to the existing, unmodified self-serve wizard.
//
// A real <Link> (not a state toggle) so the browser's back button works
// exactly as the product spec requires: Welcome → Back lands here, and
// Back again lands on /register.
//
// Partner Name / Inviter Company Name below come from the SAME
// lastPartnerInvite cache the Welcome step's self-serve entry seeds itself
// from (PartnerOnboardingForm.tsx's `lastInvite` lazy initializer) — no
// second data source. Inviter Company Name is resolved via the invite's
// workspaceId through useWorkspaceStore's existing getWorkspace, which is
// the same PartnerOrg.workspaceId → Workspace.name link invitePartner
// already sets (settingsStore.ts) — not a new mapping.
export default function PartnerOnboardingInvitePage() {
  const router = useRouter();
  const getWorkspace = useWorkspaceStore((s) => s.getWorkspace);

  // Lazy initializer: read once at mount, same convention as
  // PartnerOnboardingForm's own `lastInvite` state.
  const [lastInvite] = useState(() => getLastPartnerInvite());

  // No fabricated names when this browser has no recorded invite yet —
  // generic fallbacks only, matching this app's existing "Hello Partner" /
  // "Your Sponsor" wording used elsewhere for the same no-data case (e.g.
  // ProjectsTable.tsx's Sponsor change-request banner).
  const partnerName = lastInvite?.name.trim() || "Partner";
  const inviterCompanyName = (lastInvite?.workspaceId ? getWorkspace(lastInvite.workspaceId)?.name : undefined) || "Your Sponsor";

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-bg px-4 py-10">
      <Link href="/" className="flex items-center gap-2.5">
        <span
          className="flex h-9 w-9 items-center justify-center rounded-[9px] text-[14px] font-extrabold tracking-tight text-white"
          style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
        >
          bI
        </span>
        <span className="text-[15px] font-semibold tracking-tight text-ink">bImpact</span>
      </Link>

      <div className="w-full rounded-xl border border-border bg-surface p-7 shadow-sm" style={{ maxWidth: "520px" }}>
        <button
          type="button"
          onClick={() => router.back()}
          className="mb-4 flex items-center gap-1 text-xs font-semibold text-muted hover:text-ink-2"
        >
          ← Back
        </button>

        <h1 className="text-lg font-bold text-ink">You&apos;re Invited to Complete Partner Onboarding</h1>
        <p className="mt-1.5 text-[13px] leading-relaxed text-muted">
          Your organization has been invited to join the bImpact CSR platform. Open the invitation below to begin
          your Partner onboarding.
        </p>

        {/* Simulated invitation email */}
        <div className="mt-6 rounded-lg border border-border bg-surface-2 p-5">
          <div className="flex items-center gap-2">
            <span
              className="flex h-6 w-6 items-center justify-center rounded-[6px] text-[10px] font-extrabold text-white"
              style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
            >
              bI
            </span>
            <span className="text-[13px] font-semibold text-ink">bImpact</span>
          </div>

          <p className="mt-4 break-words text-[11px] font-semibold uppercase tracking-wide text-muted-2">
            Subject: {inviterCompanyName} Invites You to Join Its CSR Initiative
          </p>

          <p className="mt-3 break-words text-sm font-semibold text-ink">
            You&apos;re Invited to Collaborate with {inviterCompanyName}
          </p>

          <p className="mt-3 break-words text-[13px] leading-relaxed text-ink-2">Hello {partnerName},</p>
          <p className="mt-2 break-words text-[13px] leading-relaxed text-ink-2">
            <span className="font-semibold text-ink">{inviterCompanyName}</span> has invited your organization to
            join its CSR initiative and collaborate on upcoming CSR projects through <span className="font-semibold text-ink">bImpact</span>.
          </p>
          <p className="mt-2 text-[13px] leading-relaxed text-ink-2">
            Complete your Partner Onboarding to get started.
          </p>

          <div className="mt-5 flex justify-center">
            {/* A Button INSIDE the Link, not classes on the <a> directly —
                globals.css's plain `a { color: inherit }` rule sits outside
                any @layer, so it beats a Tailwind text-color utility applied
                straight to the anchor regardless of specificity. Same
                workaround already used elsewhere in this app (e.g.
                register/page.tsx's "Log In" link). */}
            <Link href="/partner-onboarding">
              <Button variant="primary" size="md" className="px-6">
                Start Partner Onboarding
              </Button>
            </Link>
          </div>

          <p className="mt-4 break-words text-[13px] leading-relaxed text-ink-2">
            Regards,
            <br />
            <span className="font-semibold text-ink">{inviterCompanyName}</span>
          </p>

          <p className="mt-4 text-center text-[11px] italic text-muted-2">
            This is a simulated invitation for the demo.
          </p>
        </div>

        <p className="mt-4 text-center text-xs text-muted">
          Demo: Click the invitation link above to continue with Partner onboarding.
        </p>
      </div>
    </div>
  );
}
