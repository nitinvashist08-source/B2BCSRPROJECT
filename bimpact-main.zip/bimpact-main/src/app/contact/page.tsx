import { MarketingLayout } from "@/components/marketing/MarketingLayout";

export default function ContactPage() {
  return (
    <MarketingLayout>
      <section className="mx-auto max-w-3xl px-6 py-20">
        <h1 className="text-3xl font-bold tracking-tight text-ink">Contact Us</h1>
        <p className="mt-4 text-base leading-relaxed text-muted">
          Have a question about bImpact for your organization? Reach out to our team and
          we&rsquo;ll get back to you shortly.
        </p>
      </section>
    </MarketingLayout>
  );
}
