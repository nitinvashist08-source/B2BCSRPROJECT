"use client";

import { useEffect, useState } from "react";
import { useSessionStore } from "@/store/sessionStore";
import { Button } from "@/components/ui/Button";
import { AuthCard } from "@/components/marketing/AuthCard";

// Email verification waiting room. There's no real mail server behind this
// app, so `verificationStatus` is driven entirely by mock actions — the
// "Demo controls" box below simulates the outcomes a real inbox click would
// otherwise produce. Reachable both by the /register hard-navigation on
// signup and by AppShell's guard resuming a mid-flow direct URL visit.
export default function VerifyEmailPage() {
  const email = useSessionStore((s) => s.email);
  const verificationStatus = useSessionStore((s) => s.verificationStatus);
  const resendVerification = useSessionStore((s) => s.resendVerification);
  const verifyEmail = useSessionStore((s) => s.verifyEmail);
  const markVerificationExpired = useSessionStore((s) => s.markVerificationExpired);
  const logout = useSessionStore((s) => s.logout);

  const [resent, setResent] = useState(false);

  // Auto-advance the instant verification succeeds — no click required.
  useEffect(() => {
    if (verificationStatus === "verified") {
      // eslint-disable-next-line @next/next/no-location-assign-relative-destination
      window.location.href = "/onboarding";
    }
  }, [verificationStatus]);

  function handleResend() {
    resendVerification();
    setResent(true);
  }

  function handleChangeEmail() {
    // Sign the half-registered account out so they can register fresh with
    // a different email, rather than getting stuck bouncing back here.
    logout();
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination
    window.location.href = "/register";
  }

  if (verificationStatus === "verified") return null;

  return (
    <AuthCard title={verificationStatus === "expired" ? "Verification link expired" : "Check your email"}>
      {verificationStatus === "expired" ? (
        <p className="text-[13px] text-ink-2">
          This verification link has expired. Request a new link to continue.
        </p>
      ) : (
        <p className="text-[13px] text-ink-2">
          We sent a verification link to <span className="font-semibold text-ink">{email}</span>.
        </p>
      )}

      <div className="mt-4 flex flex-col gap-2.5">
        <Button type="button" variant="primary" size="md" className="w-full" onClick={handleResend}>
          Resend Verification Email
        </Button>
        <Button type="button" variant="ghost" size="md" className="w-full" onClick={handleChangeEmail}>
          Change Email
        </Button>
      </div>

      {resent && verificationStatus === "pending" && (
        <p className="mt-3 text-xs font-medium text-secondary">Verification email resent.</p>
      )}

      <div className="mt-6 rounded-lg border border-dashed border-border-strong bg-surface-2 p-3.5">
        <p className="mb-2.5 text-xs font-semibold text-muted">Demo controls (no real email is sent)</p>
        <div className="flex flex-col gap-2">
          <Button type="button" variant="ghost" size="sm" className="w-full" onClick={() => verifyEmail()}>
            Simulate: link clicked (verify)
          </Button>
          <Button type="button" variant="ghost" size="sm" className="w-full" onClick={() => markVerificationExpired()}>
            Simulate: link expired
          </Button>
        </div>
      </div>
    </AuthCard>
  );
}
