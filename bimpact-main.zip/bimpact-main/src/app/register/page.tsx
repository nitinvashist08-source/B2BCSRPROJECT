"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSessionStore } from "@/store/sessionStore";
import { Button } from "@/components/ui/Button";
import { AuthCard, Field, inputCls } from "@/components/marketing/AuthCard";

// Registration — sponsor / corporate sign-up. Organization/company name is
// collected later during onboarding, not here (built by a different agent).
// Email + password only (goes through /register/verify) — no OAuth/social
// sign-up in this product.
export default function RegisterPage() {
  const registerWithEmail = useSessionStore((s) => s.registerWithEmail);
  const findAccountByEmail = useSessionStore((s) => s.findAccountByEmail);

  // Captured once at mount (lazy initializer, not a reactive subscription) —
  // an "already logged in" redirect must not react to `authenticated`
  // flipping true mid-flow when this very page calls registerWithEmail
  // (which navigates on its own).
  const [alreadyAuthenticated] = useState(() => useSessionStore.getState().authenticated);

  useEffect(() => {
    if (alreadyAuthenticated) {
      // eslint-disable-next-line @next/next/no-location-assign-relative-destination
      window.location.href = "/projects";
    }
  }, [alreadyAuthenticated]);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [debouncedEmail, setDebouncedEmail] = useState("");
  const [formDuplicate, setFormDuplicate] = useState(false);

  // Inline (debounced) "already registered?" feedback as the user types.
  useEffect(() => {
    const t = setTimeout(() => setDebouncedEmail(email), 400);
    return () => clearTimeout(t);
  }, [email]);

  const duplicateHint = debouncedEmail ? !!findAccountByEmail(debouncedEmail) : false;

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const result = registerWithEmail(name, email, password);
    if (!result.ok) {
      setFormDuplicate(true);
      return;
    }
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination
    window.location.href = "/register/verify";
  }

  if (alreadyAuthenticated) return null;

  return (
    <AuthCard
      title="Create your bImpact account"
      subtitle="Set up your account to manage CSR initiatives, projects, partners, budgets, and impact."
      width="420px"
      footer={
        <>
          Already have an account?{" "}
          <Link href="/login" className="font-semibold text-primary hover:underline">
            Log in
          </Link>
          <div className="mt-2 text-[12px] text-muted-2">
            {/* The self-serve entry point now shows a simulated "you've
                received an invitation email" step first — a real
                Sponsor-issued invite link (?token=...) still skips straight
                to the Welcome step, unaffected. */}
            <Link href="/partner-onboarding/invite" className="hover:underline">
              Partner Onboarding
            </Link>
          </div>
        </>
      }
    >
      <form onSubmit={handleSubmit}>
        <Field label="Name">
          <input
            required
            className={inputCls}
            placeholder="Your full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Field>
        <Field label="Email">
          <input
            required
            type="email"
            className={inputCls}
            placeholder="you@company.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onBlur={() => setDebouncedEmail(email)}
          />
          {duplicateHint && !formDuplicate && (
            <p className="mt-1.5 text-xs text-danger">
              This email is already registered.{" "}
              <Link href="/login" className="font-semibold underline">
                Log in instead
              </Link>
              .
            </p>
          )}
        </Field>
        <Field label="Password">
          <input
            required
            type="password"
            className={inputCls}
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>

        <Button type="submit" variant="primary" size="md" className="mt-1 w-full">
          Create Account
        </Button>

        {formDuplicate && (
          <div className="mt-3 rounded-lg border border-border bg-surface-2 p-3 text-[13px] text-ink-2">
            Already registered? Log in instead.{" "}
            <Link href="/login">
              <Button type="button" variant="ghost" size="sm" className="ml-1">
                Log In
              </Button>
            </Link>
          </div>
        )}
      </form>

      <p className="mt-5 text-center text-xs text-muted">
        By continuing, you accept the{" "}
        <Link href="/terms" className="font-semibold text-primary hover:underline">
          Terms of Service
        </Link>{" "}
        and{" "}
        <Link href="/privacy" className="font-semibold text-primary hover:underline">
          Privacy Policy
        </Link>
        .
      </p>
    </AuthCard>
  );
}
