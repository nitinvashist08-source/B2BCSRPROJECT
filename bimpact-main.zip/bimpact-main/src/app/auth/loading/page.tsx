"use client";

import { useEffect, useState } from "react";
import { useSessionStore } from "@/store/sessionStore";
import { getDashboardPathForRole } from "@/lib/roleRouting";

// Brief branded transition shown right after a successful login, before
// landing on the role's dashboard. Reached only via the hard navigation the
// unified login form does on success (window.location.href = AUTH_TRANSITION_PATH,
// see roleRouting.ts) — never a client-side route the user is expected to
// linger on or revisit, so total time on screen is kept short (~1s) per the
// product spec ("avoid longer than necessary").
const TRANSITION_MS = 1000;

// Rotates through a couple of non-technical alternates purely for visual
// interest during the short delay — not tied to any real loading progress
// (there's nothing to actually await: DataBootstrap hydrates the demo data
// synchronously from localStorage/sample JSON once the dashboard mounts).
const MESSAGES = [
  "Setting up your workspace...",
  "Loading your dashboard...",
  "Preparing your personalized experience...",
];

export default function AuthLoadingPage() {
  const authenticated = useSessionStore((s) => s.authenticated);
  const role = useSessionStore((s) => s.role);
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    // Someone hit this URL directly with no session (bookmarked link, back
    // button, etc.) — nothing to transition into, bounce straight to login
    // instead of showing a branded loader for a navigation that goes nowhere.
    if (!authenticated) {
      window.location.href = "/login";
      return;
    }

    const rotate = setInterval(() => {
      setMessageIndex((i) => (i + 1) % MESSAGES.length);
    }, 400);
    const redirect = setTimeout(() => {
      window.location.href = getDashboardPathForRole(role);
    }, TRANSITION_MS);

    return () => {
      clearInterval(rotate);
      clearTimeout(redirect);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!authenticated) return null;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-bg px-4">
      <span
        className="flex h-11 w-11 animate-pulse items-center justify-center rounded-[11px] text-[16px] font-extrabold tracking-tight text-white"
        style={{ background: "linear-gradient(135deg, var(--color-primary), #0565a0)" }}
      >
        bI
      </span>

      <div className="flex flex-col items-center gap-3 text-center">
        <p className="text-[15px] font-semibold text-ink">Preparing your workspace</p>
        <p className="max-w-xs text-[13px] text-muted">
          We&apos;re setting up your dashboard and loading the information you need.
        </p>
      </div>

      <div className="flex items-center gap-2 text-[12.5px] text-muted-2">
        <span
          className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-border-strong border-t-primary"
          aria-hidden="true"
        />
        <span aria-live="polite">{MESSAGES[messageIndex]}</span>
      </div>
    </div>
  );
}
