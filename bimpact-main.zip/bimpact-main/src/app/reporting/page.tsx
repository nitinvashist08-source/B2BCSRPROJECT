"use client";

import { useState } from "react";
import { FundUtilizationReport } from "@/components/reporting/FundUtilizationReport";
import { ProjectExecutionReport } from "@/components/reporting/ProjectExecutionReport";

const TABS = [
  { id: "fund-utilization", label: "Fund Utilization & Financial Health" },
  { id: "project-execution", label: "Project Execution Status" },
] as const;

type TabId = (typeof TABS)[number]["id"];

export default function ReportingPage() {
  const [tab, setTab] = useState<TabId>("fund-utilization");

  return (
    <div className="flex flex-col gap-4">
      <div className="flex gap-1 border-b border-border">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`border-b-2 px-3 py-2 text-sm font-semibold transition-colors ${
              tab === t.id ? "border-primary text-primary" : "border-transparent text-muted hover:text-ink-2"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "fund-utilization" ? <FundUtilizationReport /> : <ProjectExecutionReport />}
    </div>
  );
}
