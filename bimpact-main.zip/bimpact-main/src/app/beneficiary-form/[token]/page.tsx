"use client";

import { use } from "react";
import { BeneficiaryShareRespond } from "@/components/projects/BeneficiaryShareRespond";

// Public, unauthenticated route — see AppShell.tsx's PUBLIC_PREFIXES /
// PUBLIC_DATA_PREFIXES for "/beneficiary-form". Reached only via a Share
// Form link (BeneficiaryRecordsTable.tsx); never linked to from inside the
// authenticated app itself.
export default function BeneficiaryFormPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = use(params);
  return <BeneficiaryShareRespond token={token} />;
}
