"use client";

import { useEffect } from "react";
import { useSessionStore } from "@/store/sessionStore";
import { LandingPage } from "@/components/marketing/LandingPage";
import { getDashboardPathForRole } from "@/lib/roleRouting";

export default function Home() {
  const authenticated = useSessionStore((s) => s.authenticated);
  const role = useSessionStore((s) => s.role);

  // Hard navigation, not router.replace — Next's client-side transition
  // between this public route and the protected workspace has proven
  // unreliable here (see AppShell.tsx), so every auth-boundary crossing in
  // this app uses window.location instead. Routed by role (not a hardcoded
  // "/projects") so an already-authenticated partner landing on "/" goes
  // straight to /partner-workspace instead of bouncing through a sponsor
  // path AppShell's guard would immediately redirect away from anyway.
  useEffect(() => {
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination
    if (authenticated) window.location.href = getDashboardPathForRole(role);
  }, [authenticated, role]);

  if (authenticated) return null;
  return <LandingPage />;
}
