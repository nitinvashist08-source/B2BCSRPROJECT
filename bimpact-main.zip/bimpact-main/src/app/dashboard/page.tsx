"use client";

import { useEffect, useState } from "react";
import { useDashboardStore } from "@/store/dashboardStore";
import { useProjectStore } from "@/store/projectStore";
import { useSessionStore } from "@/store/sessionStore";
import { DashboardPageTabs } from "@/components/dashboard/DashboardPageTabs";
import { VisualizationCanvas } from "@/components/dashboard/VisualizationCanvas";
import { ProjectFilter } from "@/components/dashboard/ProjectFilter";
import { DashboardEmptyState } from "@/components/dashboard/DashboardEmptyState";
import { getProjectsByPartner } from "@/lib/dashboardScope";
import { isFilterCombinationEmpty } from "@/lib/dashboardFilterScope";

// Mirrors the tab bar + chart-card grid this page renders once
// useDashboardStore is hydrated, so there's no layout shift when the real
// content swaps in.
function DashboardSkeleton() {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-4 border-b border-border pb-2.5">
        <div className="h-4 w-20 animate-pulse rounded bg-surface-2" />
        <div className="h-4 w-24 animate-pulse rounded bg-surface-2" />
        <div className="h-4 w-16 animate-pulse rounded bg-surface-2" />
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-[220px] animate-pulse rounded-lg border border-border bg-surface-2" />
        ))}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const hydrated = useDashboardStore((s) => s.hydrated);
  const pages = useDashboardStore((s) => s.pages);
  const sorted = [...pages].sort((a, b) => a.order - b.order);
  const [activePageId, setActivePageId] = useState<string | null>(null);
  const sessionHydrated = useSessionStore((s) => s.hydrated);
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  // Independent Project filter for this Partner's own "Overall CSR
  // Dashboard" — same component/behaviour as the Sponsor-side Consolidated
  // dashboard's Project filter (src/components/dashboard/ProjectFilter.tsx),
  // just handed only this Partner's own projects as its option list. There
  // is deliberately NO Partner filter here — the Partner context is fixed
  // to the logged-in account (session.partnerOrgId), never a user choice.
  const [projectId, setProjectId] = useState<string | null>(null);
  const allProjects = useProjectStore((s) => s.projects);
  const partnerProjects = partnerOrgId ? getProjectsByPartner(partnerOrgId) : [];
  const projectName = allProjects.find((p) => p.id === projectId)?.name;
  // Reuses the exact same combination/empty-state rule the Sponsor-side
  // filters use (src/lib/dashboardFilterScope.ts), with partnerId locked to
  // this session's own partner — a selected project that somehow isn't
  // (any longer) associated with this Partner shows the shared empty
  // state instead of silently falling back to unrelated data.
  const noMatch = role === "partner" ? isFilterCombinationEmpty({ partnerId: partnerOrgId, projectId }) : false;

  // Sponsors now land on the multi-dashboard system's default context
  // (Consolidated) — plain /dashboard is only ever the sponsor's landing
  // spot for a moment before this fires. Partner users are untouched: this
  // route still renders their existing shared dashboard content exactly as
  // before (per explicit product direction — see permissions.ts), now with
  // its own Project filter (see above).
  useEffect(() => {
    if (sessionHydrated && role === "sponsor") {
      window.location.href = "/dashboard/consolidated";
    }
  }, [sessionHydrated, role]);

  if (!sessionHydrated || role === "sponsor") return <DashboardSkeleton />;

  if (!hydrated) return <DashboardSkeleton />;

  const currentPageId = activePageId && sorted.some((p) => p.id === activePageId) ? activePageId : sorted[0]?.id;

  if (!currentPageId) return null;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-lg font-semibold text-ink">Overall CSR Dashboard</h1>
        <ProjectFilter value={projectId} onChange={setProjectId} projects={partnerProjects} />
      </div>
      <DashboardPageTabs activePageId={currentPageId} onSelect={setActivePageId} />
      {noMatch ? (
        <DashboardEmptyState
          title="No matching data"
          message={`You are no longer associated with ${projectName ?? "this project"}. Try selecting All Projects.`}
        />
      ) : (
        <VisualizationCanvas pageId={currentPageId} filters={{ partnerId: partnerOrgId, projectId }} />
      )}
    </div>
  );
}
