"use client";

import { useState } from "react";
import { useDashboardStore } from "@/store/dashboardStore";
import { DashboardPageTabs } from "@/components/dashboard/DashboardPageTabs";
import { VisualizationCanvas } from "@/components/dashboard/VisualizationCanvas";
import { DashboardContextHeader } from "@/components/dashboard/DashboardContextHeader";
import { PartnerFilter } from "@/components/dashboard/PartnerFilter";
import { ProjectFilter } from "@/components/dashboard/ProjectFilter";
import { DashboardEmptyState } from "@/components/dashboard/DashboardEmptyState";
import { DashboardContext, dashboardScopeKey } from "@/types/dashboardContext";
import { ALL_DASHBOARD_FILTERS, DashboardFilters } from "@/types/dashboardFilters";
import { isFilterCombinationEmpty } from "@/lib/dashboardFilterScope";
import { useSettingsStore } from "@/store/settingsStore";
import { useProjectStore } from "@/store/projectStore";

// Mirrors the tab bar + chart-card grid this page renders once
// useDashboardStore is hydrated, so there's no layout shift when the real
// content swaps in. Same skeleton shape as the legacy /dashboard route.
function DashboardSkeleton() {
  return (
    <div className="flex flex-col gap-4">
      <div className="h-6 w-56 animate-pulse rounded bg-surface-2" />
      <div className="flex items-center gap-4 border-b border-border pb-2.5">
        <div className="h-4 w-20 animate-pulse rounded bg-surface-2" />
        <div className="h-4 w-24 animate-pulse rounded bg-surface-2" />
        <div className="h-4 w-16 animate-pulse rounded bg-surface-2" />
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-[220px] animate-pulse rounded-lg border border-border bg-surface-2" />
        ))}
      </div>
    </div>
  );
}

const context: DashboardContext = { scope: "consolidated" };
const scopeKey = dashboardScopeKey(context);

// The Sponsor's default portfolio-wide dashboard — /dashboard redirects here
// for the sponsor role (see src/app/dashboard/page.tsx). Partner users never
// reach this route (sponsor-only, see src/lib/permissions.ts). Only pages
// belonging to the consolidated scope (scopeKey undefined, i.e. today's
// pre-existing pages, or explicitly "consolidated::global") are shown here —
// Partner/Project dashboards keep their own independent page sets.
export default function ConsolidatedDashboardPage() {
  const hydrated = useDashboardStore((s) => s.hydrated);
  const pages = useDashboardStore((s) => s.pages);
  const scopedPages = pages.filter((p) => (p.scopeKey ?? scopeKey) === scopeKey);
  const sorted = [...scopedPages].sort((a, b) => a.order - b.order);
  const [activePageId, setActivePageId] = useState<string | null>(null);
  // Independent Partner/Project narrowing filters (see
  // src/types/dashboardFilters.ts) — separate from `context` above, which
  // only ever picks between the whole Consolidated/Partner/Project
  // dashboards. Either, neither, or both may be set at once; clearing one
  // never touches the other (each filter's "All ..." row just sets its own
  // field back to null).
  const [filters, setFilters] = useState<DashboardFilters>(ALL_DASHBOARD_FILTERS);
  const partnerName = useSettingsStore((s) => s.partners.find((p) => p.id === filters.partnerId)?.name);
  const projectName = useProjectStore((s) => s.projects.find((p) => p.id === filters.projectId)?.name);

  if (!hydrated) return <DashboardSkeleton />;

  const currentPageId = activePageId && sorted.some((p) => p.id === activePageId) ? activePageId : sorted[0]?.id;
  // A selected Partner + Project pair with no real assignment between them
  // must show an explicit empty state, never unrelated data (see
  // dashboardFilterScope.ts's isFilterCombinationEmpty).
  const noMatch = isFilterCombinationEmpty(filters);

  return (
    <div className="flex flex-col gap-4">
      {/* Title on the left, the two independent Partner/Project filters
          pinned to the right of the SAME header row. This replaces the old
          DashboardSelector here (a single dropdown that mixed Partner and
          Project entries together to navigate to a whole separate
          dashboard) — that control duplicated what these two filters now do
          and has been removed from this page. DashboardSelector itself is
          untouched and still used as-is by the dedicated
          /dashboard/partner/[id] and /dashboard/project/[id] pages. */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <DashboardContextHeader context={context} />
        <div className="flex flex-wrap items-center gap-2">
          <PartnerFilter
            value={filters.partnerId}
            onChange={(partnerId) => setFilters((f) => ({ ...f, partnerId }))}
          />
          <ProjectFilter
            value={filters.projectId}
            onChange={(projectId) => setFilters((f) => ({ ...f, projectId }))}
          />
        </div>
      </div>
      {currentPageId && (
        <>
          <DashboardPageTabs activePageId={currentPageId} onSelect={setActivePageId} scopeKey={scopeKey} />
          {noMatch ? (
            <DashboardEmptyState
              title="No matching data"
              message={`${partnerName ?? "This partner"} is not associated with ${projectName ?? "this project"}. Try clearing one of the filters above.`}
            />
          ) : (
            <VisualizationCanvas pageId={currentPageId} context={context} filters={filters} />
          )}
        </>
      )}
    </div>
  );
}
