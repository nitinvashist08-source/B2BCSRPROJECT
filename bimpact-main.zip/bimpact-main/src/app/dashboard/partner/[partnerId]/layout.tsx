"use client";

import { ReactNode, use, useEffect } from "react";
import { useSettingsStore } from "@/store/settingsStore";

// Mirrors src/app/projects/[id]/layout.tsx's access-boundary pattern: if
// partnerId doesn't resolve to a real PartnerOrg, bounce away rather than
// rendering a dashboard for a partner that doesn't exist. This route is
// sponsor-only (see src/lib/permissions.ts) — the role check itself is
// AppShell's job, not this layout's; this only validates the :partnerId
// param.
export default function PartnerDashboardLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ partnerId: string }>;
}) {
  const { partnerId } = use(params);
  const partnersHydrated = useSettingsStore((s) => s.hydrated);
  const partner = useSettingsStore((s) => s.partners.find((p) => p.id === partnerId));

  useEffect(() => {
    if (partnersHydrated && !partner) {
      window.location.href = "/dashboard/consolidated";
    }
  }, [partnersHydrated, partner]);

  if (!partnersHydrated) return null;

  if (!partner) {
    // Redirect is firing (see effect above) — render nothing so an invalid
    // partner id never flashes a dashboard shell on screen first.
    return null;
  }

  return <>{children}</>;
}
