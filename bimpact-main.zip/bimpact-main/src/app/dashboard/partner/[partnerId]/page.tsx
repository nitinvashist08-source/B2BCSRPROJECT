"use client";

import { use, useEffect, useState } from "react";
import { useDashboardStore } from "@/store/dashboardStore";
import { DashboardPageTabs } from "@/components/dashboard/DashboardPageTabs";
import { VisualizationCanvas } from "@/components/dashboard/VisualizationCanvas";
import { DashboardContextHeader } from "@/components/dashboard/DashboardContextHeader";
import { DashboardSelector } from "@/components/dashboard/DashboardSelector";
import { DashboardContext, dashboardScopeKey } from "@/types/dashboardContext";
import { partnerDashboardPages, partnerDashboardVisualizations } from "@/data/dashboardData";

// Same skeleton shape as the legacy /dashboard route and the consolidated
// dashboard, so switching contexts never causes a layout jump while
// useDashboardStore (re)hydrates.
function DashboardSkeleton() {
  return (
    <div className="flex flex-col gap-4">
      <div className="h-6 w-56 animate-pulse rounded bg-surface-2" />
      <div className="flex items-center gap-4 border-b border-border pb-2.5">
        <div className="h-4 w-20 animate-pulse rounded bg-surface-2" />
        <div className="h-4 w-24 animate-pulse rounded bg-surface-2" />
        <div className="h-4 w-16 animate-pulse rounded bg-surface-2" />
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-[220px] animate-pulse rounded-lg border border-border bg-surface-2" />
        ))}
      </div>
    </div>
  );
}

// One implementing partner's dashboard across all of its projects (a partner
// may be assigned to many projects — see src/lib/dashboardScope.ts's
// getProjectsByPartner, owned by Sub-Agent 2). The layout.tsx alongside this
// file already validated :partnerId resolves to a real PartnerOrg before
// this renders.
export default function PartnerDashboardPage({ params }: { params: Promise<{ partnerId: string }> }) {
  const { partnerId } = use(params);
  const context: DashboardContext = { scope: "partner", partnerId };
  const scopeKey = dashboardScopeKey(context);

  const hydrated = useDashboardStore((s) => s.hydrated);
  const pages = useDashboardStore((s) => s.pages);
  const ensureScopeSeeded = useDashboardStore((s) => s.ensureScopeSeeded);
  const [activePageId, setActivePageId] = useState<string | null>(null);

  // Seed this partner's default page/card composition the first time their
  // dashboard is opened — a no-op once pages for this scopeKey already
  // exist, so it never overwrites a partner's own customization on repeat
  // visits.
  useEffect(() => {
    if (!hydrated) return;
    ensureScopeSeeded(scopeKey, partnerDashboardPages, partnerDashboardVisualizations);
  }, [hydrated, scopeKey, ensureScopeSeeded]);

  const scopedPages = pages.filter((p) => p.scopeKey === scopeKey);
  const sorted = [...scopedPages].sort((a, b) => a.order - b.order);

  if (!hydrated || sorted.length === 0) return <DashboardSkeleton />;

  const currentPageId = activePageId && sorted.some((p) => p.id === activePageId) ? activePageId : sorted[0]?.id;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <DashboardContextHeader context={context} />
        <DashboardSelector current={context} />
      </div>
      {currentPageId && (
        <>
          <DashboardPageTabs activePageId={currentPageId} onSelect={setActivePageId} scopeKey={scopeKey} />
          <VisualizationCanvas pageId={currentPageId} context={context} />
        </>
      )}
    </div>
  );
}
