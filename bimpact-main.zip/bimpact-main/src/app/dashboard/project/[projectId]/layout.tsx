"use client";

import { ReactNode, use, useEffect } from "react";
import { useProjectStore } from "@/store/projectStore";

// Mirrors src/app/projects/[id]/layout.tsx's access-boundary pattern: if
// projectId doesn't resolve to a real Project, bounce away rather than
// rendering a dashboard for a project that doesn't exist. This route is
// sponsor-only (see src/lib/permissions.ts) — the role check itself is
// AppShell's job, not this layout's; this only validates the :projectId
// param.
export default function ProjectDashboardLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ projectId: string }>;
}) {
  const { projectId } = use(params);
  const projectsHydrated = useProjectStore((s) => s.hydrated);
  const project = useProjectStore((s) => s.projects.find((p) => p.id === projectId));

  useEffect(() => {
    if (projectsHydrated && !project) {
      window.location.href = "/dashboard/consolidated";
    }
  }, [projectsHydrated, project]);

  if (!projectsHydrated) return null;

  if (!project) {
    // Redirect is firing (see effect above) — render nothing so an invalid
    // project id never flashes a dashboard shell on screen first.
    return null;
  }

  return <>{children}</>;
}
