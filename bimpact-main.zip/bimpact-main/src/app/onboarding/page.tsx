"use client";

import { useState, type FormEvent } from "react";
import { useSessionStore } from "@/store/sessionStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useMeetingStore } from "@/store/meetingStore";
import { useProjectStore } from "@/store/projectStore";
import { useWorkspaceStore } from "@/store/workspaceStore";
import { Button } from "@/components/ui/Button";
import { Field, inputCls } from "@/components/marketing/AuthCard";
import { OnboardingShell } from "@/components/onboarding/OnboardingShell";
import { SelectionCard } from "@/components/onboarding/SelectionCard";
import { GettingStartedStep } from "@/components/onboarding/GettingStartedStep";

type UserType = "sponsor" | "partner" | "";
type StepKey = "userType" | "partnerNotice" | "role" | "company" | "gettingStarted";

const JOB_ROLES = [
  "CSR Head",
  "Program Manager",
  "Finance",
  "Compliance",
  "CSR Committee Member",
  "Management",
  "Other",
] as const;

// Progressive, single-page onboarding flow reached only via AppShell's
// redirect for an authenticated-but-not-yet-onboarded session (Q1 user type,
// Q2 role, Q3 company name), ending in a one-time "getting started" step
// once workspace provisioning (sessionStore.completeOnboarding) succeeds.
//
// `step`'s initial value is derived from onboardingComplete, not hardcoded
// to "userType": the moment completeOnboarding() flips onboardingComplete
// to true, AppShell swaps from this page's standalone layout to the full
// Sidebar/Header shell, which changes the surrounding JSX enough that React
// can't preserve this component's identity across it — it remounts fresh.
// So "show the getting-started step after creating a workspace" can't be
// local state; it has to be re-derivable from session/workspace state alone
// every time this component mounts.
export default function OnboardingPage() {
  const completeOnboarding = useSessionStore((s) => s.completeOnboarding);
  const onboardingComplete = useSessionStore((s) => s.onboardingComplete);
  const workspaceId = useSessionStore((s) => s.workspaceId);
  const getWorkspace = useWorkspaceStore((s) => s.getWorkspace);
  const workspace = workspaceId ? getWorkspace(workspaceId) : undefined;

  const teamMembersCount = useSettingsStore((s) => s.teamMembers).length;
  const partnersCount = useSettingsStore((s) => s.partners).length;
  const committeeMembersCount = useMeetingStore((s) => s.committee).length;
  const projectsCount = useProjectStore((s) => s.projects).length;

  const [step, setStep] = useState<StepKey>(() => (onboardingComplete ? "gettingStarted" : "userType"));
  const [userType, setUserType] = useState<UserType>("");
  const [jobRole, setJobRole] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [companyError, setCompanyError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  function goToRoleOrPartnerNotice(type: UserType) {
    setUserType(type);
    setStep(type === "partner" ? "partnerNotice" : "role");
  }

  function handleCreateWorkspace(e: FormEvent) {
    e.preventDefault();
    const trimmed = companyName.trim();
    if (!trimmed) {
      setCompanyError("Company name is required to create your workspace.");
      return;
    }
    setCompanyError("");
    setSubmitting(true);

    // Snapshot current counts as the "getting started" baseline for this
    // brand-new workspace — stored on the workspace record itself (see
    // workspaceStore.ts) so it survives the remount below.
    completeOnboarding({
      userType,
      jobRole,
      companyName: trimmed,
      baseline: {
        teamMembers: teamMembersCount,
        partners: partnersCount,
        committeeMembers: committeeMembersCount,
        projects: projectsCount,
      },
    });
    // No setStep() here — completeOnboarding's onboardingComplete flip
    // triggers the remount described above; the fresh instance's lazy
    // useState initializer picks "gettingStarted" up on its own.
  }

  function goToDashboard() {
    // Hard navigation, not router.push — router.push/replace has proven
    // unreliable for auth-flow-stage transitions in this app; every other
    // auth transition (AppShell's guard, /register, /register/verify) uses
    // window.location.href too.
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination
    window.location.href = "/projects";
  }

  if (step === "userType") {
    return (
      <OnboardingShell
        title="Are you a Sponsor or an Implementing Partner?"
        subtitle="This helps us set up the right workspace for you. You can change this later in Settings."
      >
        <div className="flex flex-col gap-3 sm:flex-row">
          <SelectionCard
            title="Sponsor"
            description="Organizations that fund, manage, and oversee CSR/social-impact initiatives."
            selected={userType === "sponsor"}
            onClick={() => setUserType("sponsor")}
          />
          <SelectionCard
            title="Implementing Partner"
            description="Organizations that execute projects and collect/manage field-level information."
            selected={userType === "partner"}
            onClick={() => setUserType("partner")}
          />
        </div>

        <div className="mt-5 flex items-center gap-2">
          <Button
            type="button"
            variant="primary"
            className="flex-1"
            disabled={!userType}
            onClick={() => goToRoleOrPartnerNotice(userType)}
          >
            Continue
          </Button>
          <Button type="button" variant="ghost" onClick={() => goToRoleOrPartnerNotice("")}>
            Skip for now
          </Button>
        </div>
      </OnboardingShell>
    );
  }

  if (step === "partnerNotice") {
    return (
      <OnboardingShell title="Partner access is invitation-based" width="420px">
        <p className="text-[13px] leading-relaxed text-ink-2">
          bImpact Partner access is currently invitation-based. Ask a Sponsor organization to
          invite you to join their workspace.
        </p>

        <div className="mt-5 flex items-center gap-2">
          <Button type="button" variant="ghost" onClick={() => setStep("userType")}>
            Back
          </Button>
          <Button
            type="button"
            variant="primary"
            className="flex-1"
            onClick={() => goToRoleOrPartnerNotice("sponsor")}
          >
            Continue as Sponsor
          </Button>
        </div>
      </OnboardingShell>
    );
  }

  if (step === "role") {
    return (
      <OnboardingShell
        title="What is your role?"
        subtitle="You can change this later in Settings."
      >
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          {JOB_ROLES.map((role) => (
            <SelectionCard
              key={role}
              title={role}
              selected={jobRole === role}
              onClick={() => setJobRole(role)}
            />
          ))}
        </div>

        <div className="mt-5 flex items-center gap-2">
          <Button type="button" variant="ghost" onClick={() => setStep("userType")}>
            Back
          </Button>
          <Button
            type="button"
            variant="primary"
            className="flex-1"
            disabled={!jobRole}
            onClick={() => setStep("company")}
          >
            Continue
          </Button>
          <Button
            type="button"
            variant="ghost"
            onClick={() => {
              setJobRole("");
              setStep("company");
            }}
          >
            Skip for now
          </Button>
        </div>
      </OnboardingShell>
    );
  }

  if (step === "gettingStarted" && workspace) {
    return <GettingStartedStep baseline={workspace.checklistBaseline} onContinue={goToDashboard} />;
  }

  // step === "company"
  return (
    <OnboardingShell
      title="What is your company name?"
      subtitle="We'll use this to set up your workspace."
      width="420px"
    >
      <form onSubmit={handleCreateWorkspace} noValidate>
        <Field label="Company name">
          <input
            className={inputCls}
            placeholder="Your company name"
            value={companyName}
            onChange={(e) => {
              setCompanyName(e.target.value);
              if (companyError) setCompanyError("");
            }}
            aria-invalid={!!companyError}
            aria-describedby={companyError ? "company-name-error" : undefined}
          />
          {companyError && (
            <p id="company-name-error" className="mt-1.5 text-[12px] text-danger">
              {companyError}
            </p>
          )}
        </Field>

        <div className="mt-4 flex items-center gap-2">
          <Button
            type="button"
            variant="ghost"
            onClick={() => setStep("role")}
            disabled={submitting}
          >
            Back
          </Button>
          <Button type="submit" variant="primary" className="flex-1" disabled={submitting}>
            {submitting ? "Creating workspace..." : "Create Workspace"}
          </Button>
        </div>
      </form>
    </OnboardingShell>
  );
}
