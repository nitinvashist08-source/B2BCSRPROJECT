import { ReactNode } from "react";
import { MeetingsTabs } from "@/components/meetings/MeetingsTabs";

export default function MeetingsLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-full flex-col">
      <MeetingsTabs />
      <div className="flex-1 pt-4">{children}</div>
    </div>
  );
}
