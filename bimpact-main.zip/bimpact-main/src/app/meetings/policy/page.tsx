import { CsrPolicyList } from "@/components/meetings/CsrPolicyList";

export default function CsrPolicyPage() {
  return <CsrPolicyList />;
}
