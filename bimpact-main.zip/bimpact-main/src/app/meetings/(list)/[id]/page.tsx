"use client";

import { use } from "react";
import { useMeetingStore } from "@/store/meetingStore";
import { MOMPanel } from "@/components/meetings/MOMPanel";

export default function MeetingDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const meeting = useMeetingStore((s) => s.meetings.find((m) => m.id === id));

  if (!meeting) {
    return (
      <div className="flex h-full min-h-[300px] flex-col items-center justify-center text-center">
        <p className="text-sm text-muted">This meeting no longer exists.</p>
      </div>
    );
  }

  return <MOMPanel key={meeting.id} meeting={meeting} />;
}
