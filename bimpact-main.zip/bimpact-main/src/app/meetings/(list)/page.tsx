export default function MeetingsIndexPage() {
  return (
    <div className="flex h-full min-h-[300px] flex-col items-center justify-center text-center">
      <p className="text-sm text-muted">Select a meeting from the list, or create a new one.</p>
    </div>
  );
}
