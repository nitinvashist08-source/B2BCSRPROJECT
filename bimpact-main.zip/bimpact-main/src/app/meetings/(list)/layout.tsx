import { ReactNode } from "react";
import { MeetingList } from "@/components/meetings/MeetingList";

export default function MeetingsListLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-full gap-4 bg-surface">
      <MeetingList />
      {/* min-w-0 is load-bearing: a flex child with only flex-1 refuses to
          shrink below its content's intrinsic width, so any normal-width
          content here (the meeting form, its rich-text editor, etc.) was
          forcing this whole row — and the page with it — wider than the
          viewport, producing a page-level horizontal scrollbar next to the
          320px MeetingList sidebar. min-w-0 lets it actually respect the
          remaining space instead. */}
      <div className="min-w-0 flex-1 overflow-y-auto">{children}</div>
    </div>
  );
}
