"use client";

import { useState } from "react";
import { useMeetingStore } from "@/store/meetingStore";
import { CommitteePeriodsTable, periodLabel } from "@/components/meetings/CommitteePeriodsTable";
import { NewPeriodSlideOver } from "@/components/meetings/NewPeriodSlideOver";
import { OrgChart } from "@/components/meetings/OrgChart";
import { MemberFormSlideOver } from "@/components/meetings/MemberFormSlideOver";
import { RemoveMemberModal } from "@/components/meetings/RemoveMemberModal";
import { CommitteeMember } from "@/types/meeting";

function PlusIcon() {
  return (
    <svg fill="none" height="12" width="12" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
function BackIcon() {
  return (
    <svg fill="none" height="11" width="11" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  );
}

// Management → CSR Committee: committees are managed by period. The list
// page creates periods; View opens that period's committee as an org-chart
// (reporting hierarchy), not a flat list/table — see OrgChart.tsx.
export default function CommitteePage() {
  const periods = useMeetingStore((s) => s.periods);
  const setActivePeriod = useMeetingStore((s) => s.setActivePeriod);

  const [viewingPeriodId, setViewingPeriodId] = useState<string | null>(null);
  const [periodFormOpen, setPeriodFormOpen] = useState(false);

  const [memberFormOpen, setMemberFormOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<CommitteeMember | null>(null);
  const [addParentId, setAddParentId] = useState<string | null>(null);
  const [removingMember, setRemovingMember] = useState<CommitteeMember | null>(null);

  const viewingPeriod = viewingPeriodId ? periods.find((p) => p.id === viewingPeriodId) ?? null : null;

  function openView(id: string) {
    setActivePeriod(id);
    setViewingPeriodId(id);
  }
  function openAddRoot() {
    setEditingMember(null);
    setAddParentId(null);
    setMemberFormOpen(true);
  }
  function openAddChild(parentId: string) {
    setEditingMember(null);
    setAddParentId(parentId);
    setMemberFormOpen(true);
  }
  function openEdit(member: CommitteeMember) {
    setEditingMember(member);
    setAddParentId(null);
    setMemberFormOpen(true);
  }

  if (viewingPeriod) {
    return (
      <div>
        <button
          onClick={() => setViewingPeriodId(null)}
          className="mb-3 inline-flex h-7 items-center gap-[5px] rounded-sm border-[1.5px] border-border bg-surface px-2.5 text-xs font-semibold text-ink-2 hover:border-border-strong"
        >
          <BackIcon />
          Back to CSR Committee
        </button>

        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <div className="text-[1.1rem] font-extrabold tracking-[-0.02em] text-ink">CSR Committee</div>
            <div className="mt-0.5 text-[13.5px] font-semibold text-ink-2">{periodLabel(viewingPeriod)}</div>
            <p className="mt-0.5 text-[13px] text-muted">Manage committee members and their reporting structure.</p>
          </div>
          <button
            onClick={openAddRoot}
            className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-sm bg-primary px-3.5 text-[13px] font-semibold text-white hover:bg-primary-600"
          >
            <PlusIcon />
            Add Member
          </button>
        </div>

        <OrgChart onAddRoot={openAddRoot} onAddChild={openAddChild} onEdit={openEdit} onRemove={setRemovingMember} />

        <MemberFormSlideOver
          key={memberFormOpen ? (editingMember?.id ?? addParentId ?? "new") : "closed"}
          open={memberFormOpen}
          onClose={() => setMemberFormOpen(false)}
          editing={editingMember}
          defaultParentId={addParentId}
        />
        <RemoveMemberModal member={removingMember} onClose={() => setRemovingMember(null)} />
      </div>
    );
  }

  return (
    <div>
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <div className="text-[1.1rem] font-extrabold tracking-[-0.02em] text-ink">CSR Committee</div>
          <p className="mt-0.5 max-w-[560px] text-[13px] text-muted">
            Create and manage CSR Committees for different periods and define the reporting structure of committee members.
          </p>
        </div>
        <button
          onClick={() => setPeriodFormOpen(true)}
          className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-sm bg-primary px-3.5 text-[13px] font-semibold text-white hover:bg-primary-600"
        >
          <PlusIcon />
          New Period
        </button>
      </div>

      <CommitteePeriodsTable onView={openView} />

      <NewPeriodSlideOver key={periodFormOpen ? "open" : "closed"} open={periodFormOpen} onClose={() => setPeriodFormOpen(false)} />
    </div>
  );
}
