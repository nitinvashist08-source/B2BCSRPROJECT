import { PartnerOrgsTable } from "@/components/settings/PartnerOrgsTable";

export default function PartnersPage() {
  return <PartnerOrgsTable />;
}
