import { ReactNode } from "react";
import { PageHeaderBand } from "@/components/shell/PageHeaderBand";

export default function PartnersLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-full flex-col">
      <PageHeaderBand
        title="Partner Management"
        sub="Onboard NGOs, align implementing agencies & manage collaborators"
        className="-mx-6 -mt-6 bg-surface px-6 pt-6"
      />
      <div className="flex-1">{children}</div>
    </div>
  );
}
