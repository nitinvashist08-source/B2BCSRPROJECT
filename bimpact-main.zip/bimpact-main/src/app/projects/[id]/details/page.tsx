"use client";

import { use } from "react";
import { DocSidebar } from "@/components/projects/DocSidebar";
import { DocEditor } from "@/components/projects/DocEditor";
import { DocumentOwnershipStrip } from "@/components/projects/DocumentOwnershipStrip";

export default function DetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return (
    <div className="flex flex-col">
      <DocumentOwnershipStrip projectId={id} />
      <div className="flex">
        <DocEditor projectId={id} />
        <DocSidebar projectId={id} />
      </div>
    </div>
  );
}
