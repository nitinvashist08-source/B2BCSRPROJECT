"use client";

import { Suspense, use } from "react";
import { IndicatorsView } from "@/components/projects/IndicatorsView";

// Suspense boundary required for IndicatorsView's useSearchParams() call
// (?tab=form deep-link — see its own comment), same pattern already used by
// src/app/partner-onboarding/page.tsx for the same reason.
export default function IndicatorsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return (
    <Suspense fallback={null}>
      <IndicatorsView projectId={id} />
    </Suspense>
  );
}
