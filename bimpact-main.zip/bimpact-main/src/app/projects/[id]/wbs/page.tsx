"use client";

import { use } from "react";
import { WbsTable } from "@/components/projects/WbsTable";

export default function WbsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return <WbsTable projectId={id} />;
}
