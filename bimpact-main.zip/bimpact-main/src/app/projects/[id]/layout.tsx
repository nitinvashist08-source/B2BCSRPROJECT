"use client";

import { ReactNode, use, useEffect } from "react";
import { useProjectStore } from "@/store/projectStore";
import { useSettingsStore } from "@/store/settingsStore";
import { useSessionStore } from "@/store/sessionStore";
import { WorkspaceHeader } from "@/components/projects/WorkspaceHeader";
import { WorkspaceTabs } from "@/components/projects/WorkspaceTabs";
import { isProjectAssignedToPartner } from "@/lib/projectAccess";

export default function ProjectWorkspaceLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const project = useProjectStore((s) => s.projects.find((p) => p.id === id));
  const role = useSessionStore((s) => s.role);
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const projectPartners = useSettingsStore((s) => s.projectPartners);
  const partners = useSettingsStore((s) => s.partners);

  const partnerName = partners.find((p) => p.id === partnerOrgId)?.name;
  const allowedForPartner =
    role !== "partner" || (!!project && isProjectAssignedToPartner(project, projectPartners, partnerName));

  // Per-project access boundary for the "partner" role: a partner may only
  // ever open a project assigned to their own org. This is the actual
  // enforcement (not just hiding the row in ProjectsTable) — it stops the
  // tabs/content below from ever rendering for a disallowed project, even
  // when reached by direct URL. Matches this app's established hard-
  // navigation convention for auth/access boundaries (see AppShell.tsx) —
  // `window.location.href`, not `router.push`.
  useEffect(() => {
    if (role === "partner" && project && !allowedForPartner) {
      window.location.href = "/projects";
    }
  }, [role, project, allowedForPartner]);

  if (!project) {
    return (
      <div className="flex h-full min-h-[300px] flex-col items-center justify-center text-center">
        <p className="text-sm text-muted">This project no longer exists.</p>
      </div>
    );
  }

  if (role === "partner" && !allowedForPartner) {
    // Redirect is firing (see effect above) — render nothing so the
    // disallowed project's details never flash on screen first.
    return null;
  }

  return (
    <div className="flex flex-col">
      <WorkspaceHeader project={project} />
      <WorkspaceTabs projectId={id} />
      <div className="min-w-0 rounded-b-lg border border-border bg-surface">{children}</div>
    </div>
  );
}
