import { MarketingLayout } from "@/components/marketing/MarketingLayout";

export default function PrivacyPage() {
  return (
    <MarketingLayout>
      <section className="mx-auto max-w-3xl px-6 py-20">
        <h1 className="text-3xl font-bold tracking-tight text-ink">Privacy Policy</h1>
        <p className="mt-4 text-base leading-relaxed text-muted">
          This placeholder page will host bImpact&rsquo;s full privacy policy, describing how
          data submitted by sponsors and implementing partners is handled.
        </p>
      </section>
    </MarketingLayout>
  );
}
