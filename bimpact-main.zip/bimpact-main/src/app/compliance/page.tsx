"use client";

import { useEffect, useState } from "react";
import { useSessionStore } from "@/store/sessionStore";
import { useSettingsStore } from "@/store/settingsStore";
import { ComplianceDocType, ComplianceDocument } from "@/types/settings";
import { getComplianceDocLabel, getRequiredComplianceGroups } from "@/lib/partnerComplianceRequirements";
import { readFileAsDataUrl } from "@/lib/complianceUpload";
import { deleteComplianceFile, newComplianceFileId, saveComplianceFile } from "@/lib/complianceFileStore";
import { ALL_STATES, districtsFor, PIN_CODE_REGEX } from "@/lib/geography";
import { ComplianceDocumentCard } from "@/components/compliance/ComplianceDocumentCard";
import { UploadComplianceModal } from "@/components/compliance/UploadComplianceModal";
import { ViewComplianceDocumentModal } from "@/components/compliance/ViewComplianceDocumentModal";
import { Button } from "@/components/ui/Button";

type Feedback = { tone: "success" | "error"; message: string };

// Partner-side document-management workspace — /compliance (see
// src/lib/permissions.ts's PARTNER_ONLY_PREFIXES; Sponsor-side already has
// its own read-only compliance view under Partner Onboarding review,
// untouched by this page). Reads/writes the SAME PartnerOrg.
// complianceDocuments the onboarding wizard and Sponsor review already use
// (src/store/settingsStore.ts's uploadComplianceDocument) — no parallel
// data model, no separate status system.
export default function CompliancePage() {
  const partnerOrgId = useSessionStore((s) => s.partnerOrgId);
  const partner = useSettingsStore((s) => s.partners.find((p) => p.id === partnerOrgId));
  // Same Sponsor change-request state the Workplace banner reads
  // (PartnerOrg.reviewStatus/changeRequestMessage in ProjectsTable.tsx) —
  // no separate change-request model for this page.
  const hasChangeRequest = partner?.reviewStatus === "Changes Requested";
  const uploadComplianceDocument = useSettingsStore((s) => s.uploadComplianceDocument);
  const updatePartner = useSettingsStore((s) => s.updatePartner);
  const partnerForms = useSettingsStore((s) => s.partnerForms);

  const [uploadType, setUploadType] = useState<ComplianceDocType | null>(null);
  const [viewing, setViewing] = useState<{ label: string; doc: ComplianceDocument } | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);

  // Registered Address — a complete postal address for the organization
  // (see types/settings.ts's RegisteredOfficeAddress; `addressLine1` is
  // shown as "Address" and `addressLine2` stays unused/unedited here — this
  // page only ever asks for the 5 fields in this section's spec). Reuses the
  // SAME geography.ts State/District list this app already uses for
  // Organization Location/CreateProjectSlideOver, not a second data source.
  const savedAddress = partner?.registeredOfficeAddress;
  const [addrLine1, setAddrLine1] = useState(savedAddress?.addressLine1 ?? "");
  const [addrState, setAddrState] = useState(savedAddress?.state ?? "");
  const [addrDistrict, setAddrDistrict] = useState(savedAddress?.district ?? "");
  const [addrCity, setAddrCity] = useState(savedAddress?.city ?? "");
  const [addrPin, setAddrPin] = useState(savedAddress?.pinCode ?? "");
  const [addrErrors, setAddrErrors] = useState<Record<string, string>>({});
  const [addrSaved, setAddrSaved] = useState(false);
  useEffect(() => {
    setAddrLine1(savedAddress?.addressLine1 ?? "");
    setAddrState(savedAddress?.state ?? "");
    setAddrDistrict(savedAddress?.district ?? "");
    setAddrCity(savedAddress?.city ?? "");
    setAddrPin(savedAddress?.pinCode ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [savedAddress?.addressLine1, savedAddress?.state, savedAddress?.district, savedAddress?.city, savedAddress?.pinCode]);

  const availableAddrDistricts = districtsFor(addrState);
  const addrDirty =
    addrLine1 !== (savedAddress?.addressLine1 ?? "") ||
    addrState !== (savedAddress?.state ?? "") ||
    addrDistrict !== (savedAddress?.district ?? "") ||
    addrCity !== (savedAddress?.city ?? "") ||
    addrPin !== (savedAddress?.pinCode ?? "");

  // Changing State clears whatever District was selected — a District from
  // the previous State is never valid, and must never remain selected (same
  // convention as CreateProjectSlideOver/the old Organization Location
  // picker).
  function handleAddrStateChange(next: string) {
    setAddrState(next);
    setAddrDistrict("");
  }

  function validateAddress() {
    const errs: Record<string, string> = {};
    if (!addrLine1.trim()) errs.addressLine1 = "Address is required.";
    if (!addrState) errs.state = "State is required.";
    if (!addrDistrict) errs.district = "District is required.";
    if (!addrCity.trim()) errs.city = "City is required.";
    // Numeric-only + exactly 6 digits — never silently truncated: a longer
    // value is rejected here (blocking Save), not cut down to 6 and saved.
    if (!PIN_CODE_REGEX.test(addrPin.trim())) errs.pinCode = "PIN Code must be exactly 6 digits.";
    return errs;
  }

  function saveAddress() {
    if (!partner) return;
    const errs = validateAddress();
    setAddrErrors(errs);
    if (Object.keys(errs).length > 0) return;
    updatePartner(partner.id, {
      registeredOfficeAddress: {
        // addressLine2 isn't collected on this page — carried over untouched
        // from whatever was already saved, never reset, per spec ("preserve
        // existing saved address data where possible").
        addressLine2: savedAddress?.addressLine2,
        addressLine1: addrLine1.trim(),
        state: addrState,
        district: addrDistrict,
        city: addrCity.trim(),
        pinCode: addrPin.trim(),
      },
    });
    setAddrSaved(true);
    setTimeout(() => setAddrSaved(false), 3000);
  }

  function announce(next: Feedback) {
    setFeedback(next);
    // Lightweight, page-local confirmation banner — this app has no global
    // toast system to hook into (see AGENTS.md-adjacent conventions: prefer
    // reusing what exists), so this mirrors the inline confirmation style
    // already used elsewhere (e.g. the onboarding wizard's own success
    // panel) rather than inventing a new notification framework.
    setTimeout(() => setFeedback((f) => (f === next ? null : f)), 4000);
  }

  if (!partner) {
    return (
      <div className="flex flex-col gap-4">
        <h1 className="text-lg font-semibold text-ink">Compliance</h1>
        <p className="text-sm text-muted">
          We couldn&apos;t find your organization&apos;s record. Please contact your Sponsor Admin.
        </p>
      </div>
    );
  }

  const docs = partner.complianceDocuments ?? [];
  // Required documents are whatever the Sponsor selected for this partner's
  // TYPE in the Partner Compliance Form — never a fixed list. `configured`
  // is false only when the Sponsor hasn't set up (activated) a checklist for
  // this partner type at all yet, distinct from one that's active but empty.
  const { configured, groups: requiredGroups } = getRequiredComplianceGroups(partner, partnerForms);
  const requiredItems = requiredGroups.flatMap((g) => g.items);
  const uploadedRequiredCount = requiredItems.filter((item) => docs.some((d) => d.type === item.id)).length;

  async function handleUpload(
    type: ComplianceDocType,
    file: File,
    documentName?: string,
    validity?: { validFrom?: string; validTill?: string }
  ) {
    if (!partner) return;
    // The file's bytes go to IndexedDB (complianceFileStore.ts), not into
    // the localStorage-backed settingsStore — that's what actually fixes
    // "storage limit reached" at normal, within-1MB-per-file usage; only a
    // small {type, fileName, uploadedAt, fileId} record below ever reaches
    // uploadComplianceDocument/localStorage.
    const dataUrl = await readFileAsDataUrl(file);
    const fileId = newComplianceFileId();
    try {
      await saveComplianceFile(fileId, dataUrl);
    } catch {
      throw new Error("Unable to upload document. Please try again.");
    }

    const result = uploadComplianceDocument(partner.id, {
      type,
      documentName: documentName || undefined,
      fileName: file.name,
      uploadedAt: new Date().toISOString(),
      // Partner-declared validity of the certificate — blank fields arrive
      // as undefined and stay absent on the record (see
      // ComplianceDocument.validFrom/validTill).
      validFrom: validity?.validFrom,
      validTill: validity?.validTill,
      fileId,
    });
    if (!result.ok) {
      // The metadata write failed (or the partner vanished) — don't leave
      // an orphaned blob behind for a document that was never recorded.
      void deleteComplianceFile(fileId);
      // Thrown (not just announced) so UploadComplianceModal's own error
      // state shows this and keeps the modal open for a retry with a
      // smaller file — a failed upload must never report success.
      throw new Error(
        result.reason === "quota"
          ? "Unable to upload document — storage limit reached. Try a smaller file, or remove an existing document first."
          : "Unable to upload document. Please try again."
      );
    }
    // A successful Replace leaves the old file orphaned in IndexedDB —
    // clean it up now that the new one is the recorded document.
    if (result.replacedFileId) void deleteComplianceFile(result.replacedFileId);

    announce({ tone: "success", message: `${getComplianceDocLabel(type)} uploaded successfully.` });
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-lg font-semibold text-ink">Compliance</h1>
        <p className="mt-1 text-sm text-muted">
          Manage your organization&apos;s compliance documents and supporting certificates.
        </p>
      </div>

      <div className="flex flex-col gap-3 rounded-lg border border-border bg-surface p-5">
        <div>
          <h3 className="text-sm font-bold text-ink">Registered Address</h3>
          <p className="mt-1 text-xs text-muted">Enter your organization&apos;s complete registered address.</p>
        </div>
        <div className="grid gap-4">
          <label className="block text-sm">
            <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">Address</span>
            <input
              value={addrLine1}
              onChange={(e) => setAddrLine1(e.target.value)}
              placeholder="Building, street"
              className="w-full rounded-sm border border-border px-3 py-2 text-sm outline-none focus:border-primary"
            />
            {addrErrors.addressLine1 && <p className="mt-1.5 text-xs text-danger">{addrErrors.addressLine1}</p>}
          </label>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <label className="block text-sm">
              <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">State</span>
              <select
                value={addrState}
                onChange={(e) => handleAddrStateChange(e.target.value)}
                className="w-full rounded-sm border border-border px-3 py-2 text-sm outline-none focus:border-primary"
              >
                <option value="">Select State</option>
                {ALL_STATES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              {addrErrors.state && <p className="mt-1.5 text-xs text-danger">{addrErrors.state}</p>}
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">District</span>
              <select
                value={addrDistrict}
                onChange={(e) => setAddrDistrict(e.target.value)}
                disabled={!addrState}
                className="w-full rounded-sm border border-border px-3 py-2 text-sm outline-none focus:border-primary disabled:bg-bg disabled:text-muted"
              >
                <option value="">{addrState ? "Select District" : "Select a state first"}</option>
                {availableAddrDistricts.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
              {addrErrors.district && <p className="mt-1.5 text-xs text-danger">{addrErrors.district}</p>}
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">City</span>
              <input
                value={addrCity}
                onChange={(e) => setAddrCity(e.target.value)}
                className="w-full rounded-sm border border-border px-3 py-2 text-sm outline-none focus:border-primary"
              />
              {addrErrors.city && <p className="mt-1.5 text-xs text-danger">{addrErrors.city}</p>}
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted">PIN Code</span>
              <input
                value={addrPin}
                onChange={(e) => setAddrPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                inputMode="numeric"
                maxLength={6}
                placeholder="411001"
                className="w-full rounded-sm border border-border px-3 py-2 text-sm outline-none focus:border-primary"
              />
              {addrErrors.pinCode && <p className="mt-1.5 text-xs text-danger">{addrErrors.pinCode}</p>}
            </label>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button size="sm" onClick={saveAddress} disabled={!addrDirty}>
            Save Address
          </Button>
          {addrSaved && <span className="text-xs font-medium text-secondary-700">Saved.</span>}
        </div>
      </div>

      {hasChangeRequest && (
        <div className="rounded-lg border border-amber-100 bg-amber-50 px-4 py-3 text-[13px] leading-relaxed text-amber-600">
          Our Sponsor has requested changes: upload the remaining documents
        </div>
      )}

      {configured && (
        <div className="flex items-center justify-between rounded-lg border border-border bg-surface-2 px-4 py-3">
          <span className="text-sm font-semibold text-ink">Required Documents</span>
          <span className="text-sm font-medium text-ink-2">
            {uploadedRequiredCount} of {requiredItems.length} required documents uploaded
          </span>
        </div>
      )}

      {feedback && (
        <div
          className={`rounded-md border px-4 py-2.5 text-sm font-medium ${
            feedback.tone === "success"
              ? "border-secondary-100 bg-secondary-50 text-secondary-700"
              : "border-danger-100 bg-danger-50 text-danger"
          }`}
        >
          {feedback.message}
        </div>
      )}

      {!configured && (
        <div className="rounded-lg border border-dashed border-border-strong bg-surface p-6 text-center">
          <h2 className="text-sm font-bold text-ink">Compliance requirements not configured yet</h2>
          <p className="mx-auto mt-1 max-w-md text-xs text-muted">
            Your Sponsor hasn&apos;t set up compliance requirements for your partner type yet. Check back once they
            have.
          </p>
        </div>
      )}

      <div className="flex flex-col gap-4">
        {requiredGroups.map((group) => (
          <div key={group.category.id} className="flex flex-col gap-2.5">
            <h3 className="text-[13px] font-bold text-ink">{group.category.title}</h3>
            <div className="flex flex-col gap-3">
              {group.items.map((item) => (
                <ComplianceDocumentCard
                  key={item.id}
                  label={item.name}
                  doc={docs.find((d) => d.type === item.id)}
                  onUpload={() => setUploadType(item.id)}
                  onView={() => {
                    const doc = docs.find((d) => d.type === item.id);
                    if (doc) setViewing({ label: item.name, doc });
                  }}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      <UploadComplianceModal
        open={uploadType !== null}
        onClose={() => setUploadType(null)}
        label={uploadType ? getComplianceDocLabel(uploadType) : ""}
        onUpload={async (file, documentName, validity) => {
          if (uploadType) await handleUpload(uploadType, file, documentName, validity);
        }}
      />

      <ViewComplianceDocumentModal
        open={viewing !== null}
        onClose={() => setViewing(null)}
        label={viewing?.label ?? ""}
        doc={viewing?.doc ?? null}
      />
    </div>
  );
}
