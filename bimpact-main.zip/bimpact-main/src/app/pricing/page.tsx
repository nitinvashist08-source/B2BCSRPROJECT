import { MarketingLayout } from "@/components/marketing/MarketingLayout";

export default function PricingPage() {
  return (
    <MarketingLayout>
      <section className="mx-auto max-w-3xl px-6 py-20">
        <h1 className="text-3xl font-bold tracking-tight text-ink">Pricing</h1>
        <p className="mt-4 text-base leading-relaxed text-muted">
          Pricing details for sponsor and implementing-partner plans will be published here.
          Contact our team in the meantime for more information.
        </p>
      </section>
    </MarketingLayout>
  );
}
