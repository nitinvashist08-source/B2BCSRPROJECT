"use client";

import { useEffect } from "react";

// Legacy route — partners now land in the real Workplace (/projects, filtered
// to their own assignments) instead of this separate simplified page, see
// src/lib/roleRouting.ts's getDashboardPathForRole. Kept as a redirect so any
// stale link/bookmark to /partner-workspace still goes somewhere real instead
// of a broken page.
export default function PartnerWorkspacePage() {
  useEffect(() => {
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination
    window.location.href = "/projects";
  }, []);
  return null;
}
