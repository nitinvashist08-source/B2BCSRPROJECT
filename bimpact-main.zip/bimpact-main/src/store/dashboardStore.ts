import { create } from "zustand";
import { DashboardPage, DistributiveOmit, Visualization } from "@/types/dashboard";
import { persistLocal } from "@/lib/localPersist";

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

// Template shapes for ensureScopeSeeded — a page/visualization "recipe" for a
// brand-new Partner/Project dashboard, not a persisted record yet. `key`/
// `pageKey` are local-only identifiers used just to wire a seed
// visualization to its seed page; real `id`/`pageId` values are generated
// fresh (via uid()) every time a dashboard is seeded so that, e.g., Partner
// A's and Partner B's seeded "Overview" pages never collide on id even
// though both dashboards are seeded from the same preset in
// src/data/dashboardData.ts.
export type ScopeSeedPage = Pick<DashboardPage, "name" | "deletable"> & { key: string };
export type ScopeSeedVisualization = DistributiveOmit<Visualization, "id" | "pageId" | "order"> & { pageKey: string };

type DashboardState = {
  pages: DashboardPage[];
  visualizations: Visualization[];
  hydrated: boolean;
  hydrate: (state: { pages: DashboardPage[]; visualizations: Visualization[] }) => void;

  addPage: (name: string, scopeKey?: string) => string;
  renamePage: (id: string, name: string) => void;
  deletePage: (id: string) => void;
  reorderPages: (orderedIds: string[]) => void;

  addVisualization: (pageId: string, input: DistributiveOmit<Visualization, "id" | "pageId" | "order">) => string;
  updateVisualization: (id: string, patch: Partial<Visualization>) => void;
  removeVisualization: (id: string) => void;
  reorderVisualizations: (pageId: string, orderedIds: string[]) => void;

  // Seeds a brand-new Partner/Project dashboard with its default
  // pages/visualizations the first time it's opened — a no-op if any page
  // already carries this scopeKey (so revisiting a dashboard, or calling
  // this more than once, never duplicates pages/visualizations). Does not
  // touch/reseed Consolidated ("consolidated::global") or any other scope.
  ensureScopeSeeded: (scopeKey: string, defaultPages: ScopeSeedPage[], defaultVisualizations: ScopeSeedVisualization[]) => void;
};

export const useDashboardStore = create<DashboardState>((set) => ({
  pages: [],
  visualizations: [],
  hydrated: false,
  hydrate: (state) => set({ ...state, hydrated: true }),

  addPage: (name, scopeKey) => {
    const id = uid("page");
    set((s) => ({ pages: [...s.pages, { id, name, order: s.pages.length, deletable: true, scopeKey }] }));
    return id;
  },
  renamePage: (id, name) =>
    set((s) => ({ pages: s.pages.map((p) => (p.id === id ? { ...p, name } : p)) })),
  deletePage: (id) =>
    set((s) => {
      const page = s.pages.find((p) => p.id === id);
      if (!page || !page.deletable) return s;
      return {
        pages: s.pages.filter((p) => p.id !== id),
        visualizations: s.visualizations.filter((v) => v.pageId !== id),
      };
    }),
  reorderPages: (orderedIds) =>
    set((s) => ({
      pages: orderedIds
        .map((id, index) => {
          const page = s.pages.find((p) => p.id === id);
          return page ? { ...page, order: index } : null;
        })
        .filter((p): p is DashboardPage => p !== null),
    })),

  addVisualization: (pageId, input) => {
    const id = uid("viz");
    set((s) => {
      const order = s.visualizations.filter((v) => v.pageId === pageId).length;
      return { visualizations: [...s.visualizations, { ...input, id, pageId, order } as Visualization] };
    });
    return id;
  },
  updateVisualization: (id, patch) =>
    set((s) => ({
      visualizations: s.visualizations.map((v) => (v.id === id ? ({ ...v, ...patch } as Visualization) : v)),
    })),
  removeVisualization: (id) =>
    set((s) => ({ visualizations: s.visualizations.filter((v) => v.id !== id) })),
  reorderVisualizations: (pageId, orderedIds) =>
    set((s) => ({
      visualizations: s.visualizations.map((v) => {
        if (v.pageId !== pageId) return v;
        const index = orderedIds.indexOf(v.id);
        return index === -1 ? v : { ...v, order: index };
      }),
    })),

  ensureScopeSeeded: (scopeKey, defaultPages, defaultVisualizations) =>
    set((s) => {
      if (s.pages.some((p) => p.scopeKey === scopeKey)) return s;

      const pageIdByKey = new Map<string, string>();
      const newPages: DashboardPage[] = defaultPages.map((tpl, index) => {
        const id = uid("page");
        pageIdByKey.set(tpl.key, id);
        return { id, name: tpl.name, order: index, deletable: tpl.deletable, scopeKey };
      });

      const orderByPageId = new Map<string, number>();
      const newVisualizations: Visualization[] = [];
      for (const tpl of defaultVisualizations) {
        const pageId = pageIdByKey.get(tpl.pageKey);
        if (!pageId) continue; // seed data bug (unknown pageKey) — skip rather than crash
        const order = orderByPageId.get(pageId) ?? 0;
        orderByPageId.set(pageId, order + 1);
        // eslint-disable-next-line @typescript-eslint/no-unused-vars -- destructured only to exclude it from `rest`
        const { pageKey: _pageKey, ...rest } = tpl;
        newVisualizations.push({ ...rest, id: uid("viz"), pageId, order } as Visualization);
      }

      return {
        pages: [...s.pages, ...newPages],
        visualizations: [...s.visualizations, ...newVisualizations],
      };
    }),
}));

persistLocal("dashboard", useDashboardStore, (s) => ({
  pages: s.pages,
  visualizations: s.visualizations,
}));
