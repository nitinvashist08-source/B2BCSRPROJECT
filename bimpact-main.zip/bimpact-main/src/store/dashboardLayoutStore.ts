import { create } from "zustand";
import { CardLayout } from "@/types/dashboard";
import { persistLocal } from "@/lib/localPersist";

// Per-user, per-dashboard, per-page arrangement (drag position + free-form
// resize for every card) — deliberately a separate store from dashboardStore
// (which owns the shared visualizations/pages everyone with dashboard access
// sees). Keys are `${userId}::${scopeKey}::${pageId}` so one Sponsor user's
// dragging/resizing never affects another Sponsor user, a Partner user, a
// different dashboard's scope (Consolidated vs. Partner A vs. Partner B vs.
// any Project), or the visualization's own data/config. `userId` comes from
// sessionStore (stable per account within a browser's localStorage lifetime
// — see sessionStore.ts's `login`, which preserves an existing userId across
// relogins rather than regenerating one). `scopeKey` comes from
// dashboardScopeKey() in src/types/dashboardContext.ts (e.g.
// "consolidated::global", "partner::<id>", "project::<id>").
export function pageLayoutKey(userId: string, scopeKey: string, pageId: string): string {
  return `${userId}::${scopeKey}::${pageId}`;
}

// Pre-scoping, keys were `${userId}::${pageId}` (exactly one "::"). Every
// scopeKey contains exactly one "::" itself (e.g. "consolidated::global",
// "partner::<id>"), so a fully-qualified new-format key always has exactly
// three "::" separators (userId :: scope-segment :: id-segment :: pageId),
// while an old-format key has exactly one. That makes old vs. new keys
// unambiguous to tell apart by splitting on "::".
//
// Backward-compat choice: migrate old keys in place, once, during hydrate()
// (rather than making getPageLayout fall back to checking the old key on
// every read). Migrating once keeps every other method (get/set/reset)
// simple and only ever dealing with the new 3-part shape, and a user's
// pre-scoping layout is exactly their Consolidated dashboard's layout today
// (the only dashboard that existed), so it's remapped under
// "consolidated::global" — nobody loses their existing customized layout.
const LEGACY_CONSOLIDATED_SCOPE_KEY = "consolidated::global";

function migrateLayoutsByKey(layoutsByKey: Record<string, CardLayout[]>): Record<string, CardLayout[]> {
  const migrated: Record<string, CardLayout[]> = {};
  for (const [key, value] of Object.entries(layoutsByKey)) {
    const parts = key.split("::");
    if (parts.length === 2) {
      const [userId, pageId] = parts;
      migrated[pageLayoutKey(userId, LEGACY_CONSOLIDATED_SCOPE_KEY, pageId)] = value;
    } else {
      migrated[key] = value;
    }
  }
  return migrated;
}

type DashboardLayoutState = {
  layoutsByKey: Record<string, CardLayout[]>;
  hydrated: boolean;
  hydrate: (state: { layoutsByKey?: Record<string, CardLayout[]> }) => void;

  setPageLayout: (userId: string, scopeKey: string, pageId: string, layout: CardLayout[]) => void;
  // Removes this user's saved arrangement for one (scopeKey, pageId) pair —
  // used by "Reset Dashboard Layout". Scoped to the one
  // (userId, scopeKey, pageId) key, never a blanket wipe, so resetting a
  // Partner or Project dashboard's layout never touches Consolidated,
  // another Partner/Project's layout, or another user's saved layout.
  resetPageLayout: (userId: string, scopeKey: string, pageId: string) => void;
};

export const useDashboardLayoutStore = create<DashboardLayoutState>((set) => ({
  layoutsByKey: {},
  hydrated: false,
  // Defensively tolerant of the older `{ sizeByKey: {...} }` shape this key
  // used to persist (predefined-size era) — that data no longer means
  // anything under the free-form layout model, so it's dropped rather than
  // crashing on load. Also migrates pre-scoping `${userId}::${pageId}` keys
  // (see migrateLayoutsByKey above).
  hydrate: (state) => set({ layoutsByKey: migrateLayoutsByKey(state.layoutsByKey ?? {}), hydrated: true }),

  setPageLayout: (userId, scopeKey, pageId, layout) =>
    set((s) => ({
      layoutsByKey: { ...s.layoutsByKey, [pageLayoutKey(userId, scopeKey, pageId)]: layout },
    })),

  resetPageLayout: (userId, scopeKey, pageId) =>
    set((s) => {
      const next = { ...s.layoutsByKey };
      delete next[pageLayoutKey(userId, scopeKey, pageId)];
      return { layoutsByKey: next };
    }),
}));

persistLocal("dashboardLayout", useDashboardLayoutStore, (s) => ({ layoutsByKey: s.layoutsByKey }));

// Resolves a page's saved layout for this user+dashboard, if any. Returns
// undefined (not a default) when there's no logged-in userId or no saved
// entry, so callers can tell "never customized" apart from "customized to X"
// and fall back to `defaultLayoutForVisualizations` themselves.
export function getPageLayout(
  layoutsByKey: Record<string, CardLayout[]>,
  userId: string | null,
  scopeKey: string,
  pageId: string
): CardLayout[] | undefined {
  if (!userId) return undefined;
  return layoutsByKey[pageLayoutKey(userId, scopeKey, pageId)];
}
