﻿import { create } from "zustand";
import {
  BeneficiaryRecord,
  FormField,
  FormFieldType,
  FormSection,
  IndicatorFormResponse,
  IndicatorFormShareLink,
  IndicatorFormState,
  OwnershipMode,
  Project,
  ProjectDoc,
  WbsRow,
  WbsState,
  WbsTaskInput,
} from "@/types/project";
import { persistLocal } from "@/lib/localPersist";
import { useSessionStore } from "@/store/sessionStore";
import { canEditProjectResource } from "@/lib/permissions";
import { resolveDisplayName } from "@/lib/userDisplay";
import { WBS_COL, dependencyCellFromIds, syncStatusAndCompletion, taskColumns } from "@/lib/wbsColumns";

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

// WBS row IDs are a visible, user-facing 4-character code (per spec) — NOT
// the internal store key of past sessions ("row-xxxxxxxx"). Generated once
// at row creation, never regenerated on reorder/sort/delete of other rows,
// unique within the project's own WBS (retried on collision, astronomically
// rare at this alphabet/length but checked anyway rather than assumed).
const WBS_ROW_ID_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I — avoids visually-ambiguous codes
const WBS_ROW_ID_PATTERN = new RegExp(`^[${WBS_ROW_ID_CHARS}]{4}$`);
function genWbsRowId(existingIds: Set<string>): string {
  let id = "";
  do {
    id = Array.from({ length: 4 }, () => WBS_ROW_ID_CHARS[Math.floor(Math.random() * WBS_ROW_ID_CHARS.length)]).join("");
  } while (existingIds.has(id));
  return id;
}

// One-time migration for any row whose id predates the 4-character-code
// format (e.g. an already-persisted "row-xxxxxxxx" id from before this
// existed) — same "tolerate historical shapes on load" convention this app
// already uses elsewhere (meetingStore's normalizeMember()). Only replaces
// ids that don't already match the exact 4-char uppercase pattern; cell
// data and everything else about the row is untouched. Returns the same
// object reference when nothing needed fixing, so it's a no-op for anyone
// whose data is already clean.
function normalizeWbsRowIds(wbs: Record<string, WbsState>): Record<string, WbsState> {
  let anyChanged = false;
  const next: Record<string, WbsState> = {};
  for (const [projectId, state] of Object.entries(wbs)) {
    let projectChanged = false;
    const seen = new Set(state.rows.map((r) => r.id).filter((id) => WBS_ROW_ID_PATTERN.test(id)));
    const rows = state.rows.map((r) => {
      if (WBS_ROW_ID_PATTERN.test(r.id)) return r;
      projectChanged = true;
      const id = genWbsRowId(seen);
      seen.add(id);
      return { ...r, id };
    });
    if (projectChanged) {
      anyChanged = true;
      next[projectId] = { ...state, rows };
    } else {
      next[projectId] = state;
    }
  }
  return anyChanged ? next : wbs;
}

// One-time migration onto the fixed Task column schema (see
// lib/wbsColumns.ts's taskColumns()) for any project whose WBS still has
// the old freeform Add Column/Add Row shape — same "tolerate historical
// shapes on load" convention as normalizeWbsRowIds above. Preserves every
// cell value keyed under a surviving column id (col-task, col-assigned,
// col-start, col-end, col-status all kept their ids across the old->new
// schema, just re-labeled/re-typed); a legacy Status value's old casing
// ("To Do"/"In Progress") is remapped to the new one so the select still
// shows it selected instead of going blank. Any truly custom column a user
// had added via the old Add Column button has no equivalent in the fixed
// schema and is dropped along with its cell values — there is no more UI
// to manage such a column going forward. `mode` and row ids/order are
// never touched.
const LEGACY_STATUS_VALUES: Record<string, string> = {
  "To Do": "To-do",
  "In Progress": "In-progress",
};
function normalizeWbsColumns(wbs: Record<string, WbsState>): Record<string, WbsState> {
  const fixed = taskColumns();
  const fixedIds = fixed.map((c) => c.id);
  let anyChanged = false;
  const next: Record<string, WbsState> = {};
  for (const [projectId, state] of Object.entries(wbs)) {
    const currentIds = state.columns.map((c) => c.id);
    const sameShape = currentIds.length === fixedIds.length && currentIds.every((id, i) => id === fixedIds[i]);
    if (sameShape) {
      next[projectId] = state;
      continue;
    }
    anyChanged = true;
    const rows = state.rows.map((r) => {
      const cells: Record<string, string> = {};
      for (const col of fixed) {
        const raw = r.cells[col.id] ?? "";
        cells[col.id] = col.id === WBS_COL.status ? (LEGACY_STATUS_VALUES[raw] ?? raw) : raw;
      }
      return { ...r, cells };
    });
    next[projectId] = { ...state, columns: fixed, rows };
  }
  return anyChanged ? next : wbs;
}

type ProjectState = {
  projects: Project[];
  docs: Record<string, ProjectDoc | null>;
  wbs: Record<string, WbsState>;
  beneficiaryOwnership: Record<string, OwnershipMode | null>;
  beneficiaryRecords: BeneficiaryRecord[];
  // Project-scoped Indicator Form — absence of a projectId key means "not
  // created yet" (see IndicatorFormState's doc comment in types/project.ts).
  indicatorForms: Record<string, IndicatorFormState>;
  // Submissions captured via the Indicator Form itself (Add Record, once a
  // form exists, AND the public Share Form link below) — see
  // IndicatorFormResponse's doc comment for why this is a separate array
  // from beneficiaryRecords, not a replacement of it. Both entry points push
  // into this SAME array/collection — there is no second, Share-Form-only
  // response list.
  indicatorFormResponses: IndicatorFormResponse[];
  // Workplace → Beneficiary Indicators → "Share Form" — see
  // IndicatorFormShareLink's doc comment in types/project.ts. Keyed by
  // token (not projectId): the public /beneficiary-form/[token] route only
  // ever has the token, and resolves everything else (project, sharer
  // identity) from this record, so the URL itself can't be edited to reach
  // another project's form.
  indicatorFormShareLinks: Record<string, IndicatorFormShareLink>;
  // Project-scoped Document ownership (Workplace → Project Details →
  // Documents → "Who will create the documents?") — deliberately reuses the
  // exact same OwnershipMode ("self"/"partner"/"both") type and
  // canEditProjectResource() permission function WBS/Indicator Form already
  // use, rather than a parallel "sponsor"/"partner"/"collaborative" type with
  // its own resolution logic — same 3-way governance model, one shared
  // implementation. Absence of a projectId key (or an explicit null) means
  // "not configured yet" — nobody can create/edit until the Sponsor picks
  // one, but EXISTING documents (from before this feature, or on any
  // project that never gets configured) always stay visible/read-only
  // regardless, never hidden or deleted.
  documentOwnership: Record<string, OwnershipMode | null>;
  hydrated: boolean;
  hydrate: (state: {
    projects: Project[];
    docs: Record<string, ProjectDoc | null>;
    wbs: Record<string, WbsState>;
    beneficiaryOwnership: Record<string, OwnershipMode | null>;
    beneficiaryRecords: BeneficiaryRecord[];
    indicatorForms: Record<string, IndicatorFormState>;
    indicatorFormResponses: IndicatorFormResponse[];
    indicatorFormShareLinks: Record<string, IndicatorFormShareLink>;
    documentOwnership: Record<string, OwnershipMode | null>;
  }) => void;

  // Finds this project's existing Share Form link for the CURRENTLY logged-in
  // Sponsor/Partner, or creates one — re-clicking Share Form always returns
  // the SAME link/token for the same sharer instead of minting a new one
  // every time. Returns null (and creates nothing) when the project has no
  // Indicator Form yet — matches the existing "Please create a indicator
  // form to capture beneficiary details." empty state; a link must never be
  // generated for a form that doesn't exist. Available to Sponsor and
  // Partner alike regardless of the form's ownership mode — sharing the
  // form is a separate capability from editing its question structure (see
  // canEditProjectResource, which still gates the latter).
  getOrCreateIndicatorFormShareLink: (projectId: string) => string | null;
  // The ONE write path for the public /beneficiary-form/[token] page —
  // resolves the token back to its project/sharer, then pushes into the
  // SAME indicatorFormResponses array addIndicatorFormResponse (Add Record)
  // already writes into. Fails closed: an unknown token, or a token whose
  // project no longer has an Indicator Form, is refused rather than
  // fabricating a response against nothing.
  submitIndicatorFormResponseViaShareLink: (
    token: string,
    responses: Record<string, string>
  ) => { ok: true } | { ok: false; reason: "invalid-link" | "no-form" };

  setDocumentOwnership: (projectId: string, mode: OwnershipMode) => void;
  // Every action below is guarded by canEditProjectResource(documentOwnership[projectId], role) —
  // same enforcement point WBS/Indicator Form actions already use, refusing
  // (no-op) the mutation for a read-only role even if called directly,
  // bypassing the UI. Viewing (reading docs[projectId]) is never gated.
  createDoc: (projectId: string, title: string) => void;
  uploadDoc: (projectId: string, doc: Omit<ProjectDoc, "id" | "created" | "modified" | "kind">) => void;
  saveDoc: (projectId: string, patch: Partial<ProjectDoc>) => void;
  deleteDoc: (projectId: string) => void;

  setWbsMode: (projectId: string, mode: OwnershipMode) => void;
  // Task creation — the only way a WBS row is ever created (see
  // TaskFormSlideOver.tsx's "add" mode). Columns are a fixed schema
  // (lib/wbsColumns.ts) with no more Add Column/Add Row/rename/retype
  // actions, and the table itself is read-only — see updateWbsTask below.
  addWbsTask: (projectId: string, input: WbsTaskInput) => void;
  // Task editing — the only way an existing WBS row is ever changed (see
  // TaskFormSlideOver.tsx's "edit" mode, opened by clicking any cell of a
  // Task row in WbsTable.tsx). There is no more per-cell inline editing.
  updateWbsTask: (projectId: string, rowId: string, input: WbsTaskInput) => void;
  removeWbsRow: (projectId: string, rowId: string) => void;
  // Row drag-and-drop (see WbsTable.tsx's dnd-kit usage) — reindexes `rows`
  // to the given id order; row ids themselves are never touched.
  reorderWbsRows: (projectId: string, orderedIds: string[]) => void;

  setBeneficiaryOwnership: (projectId: string, mode: OwnershipMode) => void;
  addRecord: (record: Omit<BeneficiaryRecord, "id">) => void;
  updateRecord: (id: string, patch: Partial<BeneficiaryRecord>) => void;
  removeRecord: (id: string) => void;

  // Add Record, driven by the project's Indicator Form (see
  // AddRecordSlideOver.tsx) — not gated by canEditProjectResource: like the
  // pre-existing addRecord above, submitting beneficiary DATA has never been
  // restricted by WBS/Indicator-Form OWNERSHIP (that only ever gated who can
  // edit the form's QUESTION structure, a different permission axis). Only
  // ever writes when the project actually has an Indicator Form.
  addIndicatorFormResponse: (projectId: string, responses: Record<string, string>) => void;

  // Every Indicator Form action below is guarded by the same
  // canEditProjectResource() check as the WBS actions above, keyed off
  // beneficiaryOwnership[projectId] (this record already IS the Indicator
  // Form's per-project ownership mode — see IndicatorsView.tsx's "Who will
  // create the form?" picker, which writes to it via setBeneficiaryOwnership).
  createIndicatorForm: (projectId: string) => void;
  updateIndicatorFormMeta: (projectId: string, patch: { title?: string; description?: string }) => void;
  lockIndicatorForm: (projectId: string) => void;
  addField: (projectId: string, sectionId: string, field: Omit<FormField, "id">, afterFieldId?: string) => void;
  updateField: (projectId: string, sectionId: string, fieldId: string, patch: Partial<FormField>) => void;
  duplicateField: (projectId: string, sectionId: string, fieldId: string) => void;
  removeField: (projectId: string, sectionId: string, fieldId: string) => void;
  changeFieldType: (projectId: string, sectionId: string, fieldId: string, type: FormFieldType) => void;

  addProject: (project: Omit<Project, "id" | "statusChangedAt">) => string;
  updateProject: (id: string, patch: Partial<Project>) => void;
};

function emptyWbs(): WbsState {
  return {
    mode: null,
    // Fixed Task schema — see lib/wbsColumns.ts (single source of truth,
    // also used by data/projectData.ts's sample-data emptyWbs and this
    // file's own normalizeWbsColumns migration).
    columns: taskColumns(),
    // No default WBS items — a Project's WBS starts empty until an
    // authorized user (per the configured ownership mode) creates the first
    // row, per spec.
    rows: [],
  };
}

// Starter content for a brand-new Indicator Form — a small, generic
// beneficiary-intake set (not the full 44-field legacy form kept on
// prj-1, see data/projectData.ts) so the sponsor/partner creating the form
// isn't starting from a completely blank canvas. Fully editable/removable —
// never re-applied once a form exists (see createIndicatorForm's no-op
// guard when a projectId key is already present).
function defaultIndicatorSections(): FormSection[] {
  return [
    {
      id: uid("sec"),
      title: "Beneficiary Details",
      description: "Core details collected for every beneficiary",
      fields: [
        { id: uid("f"), type: "text", label: "Full Name", required: true },
        { id: uid("f"), type: "radio", label: "Gender", required: true, options: ["Female", "Male", "Other"] },
        { id: uid("f"), type: "number", label: "Age", required: false },
        { id: uid("f"), type: "text", label: "Village / Location", required: false },
        { id: uid("f"), type: "phone", label: "Contact Number", required: false },
      ],
    },
  ];
}

export const useProjectStore = create<ProjectState>((set, get) => ({
  projects: [],
  docs: {},
  wbs: {},
  beneficiaryOwnership: {},
  beneficiaryRecords: [],
  indicatorForms: {},
  indicatorFormResponses: [],
  indicatorFormShareLinks: {},
  documentOwnership: {},
  hydrated: false,
  hydrate: (state) =>
    set({ ...state, wbs: normalizeWbsColumns(normalizeWbsRowIds(state.wbs)), hydrated: true }),

  // Same sponsor-only governance rule as setWbsMode/setBeneficiaryOwnership
  // below — refuse the change (no-op) for an active partner session,
  // regardless of whether the call came through the (hidden, for partners)
  // picker UI.
  setDocumentOwnership: (projectId, mode) => {
    if (useSessionStore.getState().role === "partner") return;
    set((s) => ({ documentOwnership: { ...s.documentOwnership, [projectId]: mode } }));
  },
  createDoc: (projectId, title) =>
    set((s) => {
      if (!canEditProjectResource(s.documentOwnership[projectId] ?? null, useSessionStore.getState().role)) return {};
      return {
        docs: {
          ...s.docs,
          [projectId]: {
            id: uid("doc"),
            title,
            contentHtml: "",
            created: new Date().toISOString().slice(0, 10),
            modified: new Date().toISOString().slice(0, 10),
            kind: "created",
          },
        },
      };
    }),
  uploadDoc: (projectId, doc) =>
    set((s) => {
      if (!canEditProjectResource(s.documentOwnership[projectId] ?? null, useSessionStore.getState().role)) return {};
      return {
        docs: {
          ...s.docs,
          [projectId]: {
            ...doc,
            id: uid("doc"),
            created: new Date().toISOString().slice(0, 10),
            modified: new Date().toISOString().slice(0, 10),
            kind: "uploaded",
          },
        },
      };
    }),
  saveDoc: (projectId, patch) =>
    set((s) => {
      const existing = s.docs[projectId];
      if (!existing) return s;
      if (!canEditProjectResource(s.documentOwnership[projectId] ?? null, useSessionStore.getState().role)) return {};
      return {
        docs: {
          ...s.docs,
          [projectId]: { ...existing, ...patch, modified: new Date().toISOString().slice(0, 10) },
        },
      };
    }),
  deleteDoc: (projectId) =>
    set((s) => {
      if (!canEditProjectResource(s.documentOwnership[projectId] ?? null, useSessionStore.getState().role)) return {};
      return { docs: { ...s.docs, [projectId]: null } };
    }),

  // "Who creates the WBS?" is a sponsor-only governance decision — an
  // invited partner must never be able to set it, even by a direct store
  // call bypassing the (already-hidden) picker UI. Mirrors the lazy
  // `useSessionStore.getState()`-inside-action-body pattern settingsStore
  // already uses (see invitePartner) rather than importing at module scope
  // in a way that could create a real circular dependency.
  setWbsMode: (projectId, mode) => {
    if (useSessionStore.getState().role === "partner") return;
    set((s) => ({
      wbs: { ...s.wbs, [projectId]: { ...(s.wbs[projectId] ?? emptyWbs()), mode } },
    }));
  },
  // Every WBS mutation below is guarded by the same canEditProjectResource() check used
  // by WbsTable's UI (see permissions.ts) — a read-only user (per the
  // project's configured ownership mode) is refused here as a no-op even if
  // the action is invoked directly, not only when the button is hidden.
  //
  // The only way a Task/row is created (Add Column/Add Row are gone — see
  // lib/wbsColumns.ts's fixed taskColumns()). Builds cells straight from the
  // Add Task slide-over's input, running it through the same
  // syncStatusAndCompletion() rule updateWbsTask uses below so a task
  // created as "Done" (or at 100%) always lands correctly synced.
  addWbsTask: (projectId, input) =>
    set((s) => {
      const current = s.wbs[projectId] ?? emptyWbs();
      if (!canEditProjectResource(current.mode, useSessionStore.getState().role)) return {};
      const id = genWbsRowId(new Set(current.rows.map((r) => r.id)));
      const synced = syncStatusAndCompletion(
        input.status,
        input.completion,
        input.status === "Done" ? "status" : "completion"
      );
      const row: WbsRow = {
        id,
        cells: {
          [WBS_COL.title]: input.title.trim(),
          [WBS_COL.description]: input.description.trim(),
          [WBS_COL.assignee]: input.assignee,
          [WBS_COL.start]: input.startDate,
          [WBS_COL.end]: input.endDate,
          [WBS_COL.status]: synced.status,
          [WBS_COL.completion]: String(synced.completion),
          [WBS_COL.priority]: input.priority,
          [WBS_COL.dependency]: dependencyCellFromIds(input.dependencyIds),
          [WBS_COL.remarks]: input.remarks.trim(),
        },
      };
      return { wbs: { ...s.wbs, [projectId]: { ...current, rows: [...current.rows, row] } } };
    }),
  // Task editing now happens only through the Edit Task slide-over (the WBS
  // table itself is a read-only list — see WbsTable.tsx) — this replaces
  // the old per-cell updateWbsCell with one full-row update, built exactly
  // like addWbsTask above (same syncStatusAndCompletion() rule, so a task
  // saved as "Done"/100% always lands correctly synced either way). The
  // row's id and its position in `rows` are never touched — this can only
  // ever update the one Task that already exists, never create or reorder.
  updateWbsTask: (projectId, rowId, input) =>
    set((s) => {
      const current = s.wbs[projectId] ?? emptyWbs();
      if (!canEditProjectResource(current.mode, useSessionStore.getState().role)) return {};
      const synced = syncStatusAndCompletion(
        input.status,
        input.completion,
        input.status === "Done" ? "status" : "completion"
      );
      return {
        wbs: {
          ...s.wbs,
          [projectId]: {
            ...current,
            rows: current.rows.map((r) =>
              r.id !== rowId
                ? r
                : {
                    ...r,
                    cells: {
                      [WBS_COL.title]: input.title.trim(),
                      [WBS_COL.description]: input.description.trim(),
                      [WBS_COL.assignee]: input.assignee,
                      [WBS_COL.start]: input.startDate,
                      [WBS_COL.end]: input.endDate,
                      [WBS_COL.status]: synced.status,
                      [WBS_COL.completion]: String(synced.completion),
                      [WBS_COL.priority]: input.priority,
                      [WBS_COL.dependency]: dependencyCellFromIds(input.dependencyIds),
                      [WBS_COL.remarks]: input.remarks.trim(),
                    },
                  }
            ),
          },
        },
      };
    }),
  removeWbsRow: (projectId, rowId) =>
    set((s) => {
      const current = s.wbs[projectId] ?? emptyWbs();
      if (!canEditProjectResource(current.mode, useSessionStore.getState().role)) return {};
      return {
        wbs: { ...s.wbs, [projectId]: { ...current, rows: current.rows.filter((r) => r.id !== rowId) } },
      };
    }),
  reorderWbsRows: (projectId, orderedIds) =>
    set((s) => {
      const current = s.wbs[projectId] ?? emptyWbs();
      if (!canEditProjectResource(current.mode, useSessionStore.getState().role)) return {};
      const byId = new Map(current.rows.map((r) => [r.id, r]));
      const reordered = orderedIds.map((id) => byId.get(id)).filter((r): r is WbsRow => !!r);
      // Defensive: never silently drop a row that (for whatever reason)
      // wasn't in the given id list — append it rather than lose data.
      const missing = current.rows.filter((r) => !orderedIds.includes(r.id));
      return { wbs: { ...s.wbs, [projectId]: { ...current, rows: [...reordered, ...missing] } } };
    }),

  // Same sponsor-only governance rule as setWbsMode above — refuse the
  // change (no-op) when called with an active partner session, regardless
  // of whether the call came through the (hidden, for partners) picker UI.
  setBeneficiaryOwnership: (projectId, mode) => {
    if (useSessionStore.getState().role === "partner") return;
    set((s) => ({ beneficiaryOwnership: { ...s.beneficiaryOwnership, [projectId]: mode } }));
  },
  addRecord: (record) =>
    set((s) => ({ beneficiaryRecords: [...s.beneficiaryRecords, { ...record, id: uid("ben") }] })),
  updateRecord: (id, patch) =>
    set((s) => ({
      beneficiaryRecords: s.beneficiaryRecords.map((r) => (r.id === id ? { ...r, ...patch } : r)),
    })),
  removeRecord: (id) =>
    set((s) => ({ beneficiaryRecords: s.beneficiaryRecords.filter((r) => r.id !== id) })),

  // The in-app "+ Add Record" path (AddRecordSlideOver.tsx) — always called
  // by a logged-in Sponsor/Partner, so this is the one place that stamps
  // submittedBy + acknowledgement from the current session. Contrast with
  // submitIndicatorFormResponseViaShareLink below, whose submittedBy is the
  // link's SHARER (captured at share-time), not a live acknowledger — that
  // flow has no acknowledgement step and none is added here.
  addIndicatorFormResponse: (projectId, responses) =>
    set((s) => {
      if (!s.indicatorForms[projectId]) return {}; // no form yet — nothing to submit against
      const session = useSessionStore.getState();
      const now = new Date().toISOString();
      const entry: IndicatorFormResponse = {
        id: uid("resp"),
        projectId,
        indicatorFormId: projectId,
        responses,
        submittedAt: now,
        submittedBy: session.role
          ? {
              userId: session.userId ?? "",
              name: resolveDisplayName(session.name, session.email),
              email: session.email ?? "",
              role: session.role,
            }
          : undefined,
        acknowledgement: { accepted: true, acceptedAt: now },
      };
      return { indicatorFormResponses: [...s.indicatorFormResponses, entry] };
    }),

  getOrCreateIndicatorFormShareLink: (projectId) => {
    const s = get();
    if (!s.indicatorForms[projectId]) return null; // no form yet — nothing to share
    const session = useSessionStore.getState();
    if (!session.role) return null;
    // Share Form is available to Sponsor and Partner alike regardless of
    // the Indicator Form's ownership mode (unlike editing the form itself,
    // which stays gated by canEditProjectResource) — sharing/distributing
    // the form is a separate capability from managing its question
    // structure, per product decision.
    const existing = Object.values(s.indicatorFormShareLinks).find(
      (l) => l.projectId === projectId && l.sharedByUserId === session.userId
    );
    if (existing) return existing.token;
    const token = uid("share");
    const link: IndicatorFormShareLink = {
      token,
      projectId,
      sharedByUserId: session.userId ?? "",
      sharedByName: session.name ?? "",
      sharedByEmail: session.email ?? "",
      sharedByRole: session.role,
      createdAt: new Date().toISOString(),
    };
    set((state) => ({ indicatorFormShareLinks: { ...state.indicatorFormShareLinks, [token]: link } }));
    return token;
  },

  submitIndicatorFormResponseViaShareLink: (token, responses) => {
    const s = get();
    const link = s.indicatorFormShareLinks[token];
    if (!link) return { ok: false, reason: "invalid-link" };
    if (!s.indicatorForms[link.projectId]) return { ok: false, reason: "no-form" };
    const entry: IndicatorFormResponse = {
      id: uid("resp"),
      projectId: link.projectId,
      indicatorFormId: link.projectId,
      responses,
      submittedAt: new Date().toISOString(),
      sharedLinkToken: token,
      submittedBy: {
        userId: link.sharedByUserId,
        name: link.sharedByName,
        email: link.sharedByEmail,
        role: link.sharedByRole,
      },
    };
    set((state) => ({ indicatorFormResponses: [...state.indicatorFormResponses, entry] }));
    return { ok: true };
  },

  // "Not created yet" is represented by the absence of a projectId key in
  // indicatorForms (see IndicatorFormState's doc comment) — createIndicatorForm
  // is the only action allowed to add that key, and it never overwrites an
  // existing entry, so it can never delete/reset/duplicate an already-created
  // form (matches "changing ownership must not recreate the form" — this
  // action isn't even reachable from an ownership change, only from the
  // explicit "Create Indicator Form" button in the empty state).
  createIndicatorForm: (projectId) =>
    set((s) => {
      if (s.indicatorForms[projectId]) return {};
      const mode = s.beneficiaryOwnership[projectId] ?? null;
      if (!canEditProjectResource(mode, useSessionStore.getState().role)) return {};
      const form: IndicatorFormState = {
        title: "Beneficiary Registration & Assessment Form",
        description: "Beneficiary data collection form for this project.",
        // A small default starter set (see defaultIndicatorSections) rather
        // than a blank canvas — fully editable/removable from here, and
        // never re-applied once the projectId key exists (this action no-ops
        // if it does, see the guard above).
        sections: defaultIndicatorSections(),
        locked: false,
        createdAt: new Date().toISOString(),
      };
      return { indicatorForms: { ...s.indicatorForms, [projectId]: form } };
    }),
  updateIndicatorFormMeta: (projectId, patch) =>
    set((s) => {
      const current = s.indicatorForms[projectId];
      if (!current) return {};
      const mode = s.beneficiaryOwnership[projectId] ?? null;
      if (!canEditProjectResource(mode, useSessionStore.getState().role)) return {};
      return { indicatorForms: { ...s.indicatorForms, [projectId]: { ...current, ...patch } } };
    }),
  lockIndicatorForm: (projectId) =>
    set((s) => {
      const current = s.indicatorForms[projectId];
      if (!current) return {};
      const mode = s.beneficiaryOwnership[projectId] ?? null;
      if (!canEditProjectResource(mode, useSessionStore.getState().role)) return {};
      return { indicatorForms: { ...s.indicatorForms, [projectId]: { ...current, locked: true } } };
    }),
  addField: (projectId, sectionId, field, afterFieldId) =>
    set((s) => {
      const current = s.indicatorForms[projectId];
      if (!current) return {};
      const mode = s.beneficiaryOwnership[projectId] ?? null;
      if (!canEditProjectResource(mode, useSessionStore.getState().role)) return {};
      const sections = current.sections.map((sec) => {
        if (sec.id !== sectionId) return sec;
        const newField = { ...field, id: uid("f") };
        const afterIdx = afterFieldId ? sec.fields.findIndex((f) => f.id === afterFieldId) : -1;
        if (afterIdx === -1) return { ...sec, fields: [...sec.fields, newField] };
        const fields = [...sec.fields];
        fields.splice(afterIdx + 1, 0, newField);
        return { ...sec, fields };
      });
      return { indicatorForms: { ...s.indicatorForms, [projectId]: { ...current, sections } } };
    }),
  updateField: (projectId, sectionId, fieldId, patch) =>
    set((s) => {
      const current = s.indicatorForms[projectId];
      if (!current) return {};
      const mode = s.beneficiaryOwnership[projectId] ?? null;
      if (!canEditProjectResource(mode, useSessionStore.getState().role)) return {};
      const sections = current.sections.map((sec) =>
        sec.id === sectionId
          ? { ...sec, fields: sec.fields.map((f) => (f.id === fieldId ? { ...f, ...patch } : f)) }
          : sec
      );
      return { indicatorForms: { ...s.indicatorForms, [projectId]: { ...current, sections } } };
    }),
  duplicateField: (projectId, sectionId, fieldId) =>
    set((s) => {
      const current = s.indicatorForms[projectId];
      if (!current) return {};
      const mode = s.beneficiaryOwnership[projectId] ?? null;
      if (!canEditProjectResource(mode, useSessionStore.getState().role)) return {};
      const sections = current.sections.map((sec) => {
        if (sec.id !== sectionId) return sec;
        const idx = sec.fields.findIndex((f) => f.id === fieldId);
        if (idx === -1) return sec;
        const copy = { ...sec.fields[idx], id: uid("f"), label: `${sec.fields[idx].label} (Copy)` };
        const fields = [...sec.fields];
        fields.splice(idx + 1, 0, copy);
        return { ...sec, fields };
      });
      return { indicatorForms: { ...s.indicatorForms, [projectId]: { ...current, sections } } };
    }),
  removeField: (projectId, sectionId, fieldId) =>
    set((s) => {
      const current = s.indicatorForms[projectId];
      if (!current) return {};
      const mode = s.beneficiaryOwnership[projectId] ?? null;
      if (!canEditProjectResource(mode, useSessionStore.getState().role)) return {};
      const sections = current.sections.map((sec) =>
        sec.id === sectionId ? { ...sec, fields: sec.fields.filter((f) => f.id !== fieldId) } : sec
      );
      return { indicatorForms: { ...s.indicatorForms, [projectId]: { ...current, sections } } };
    }),
  changeFieldType: (projectId, sectionId, fieldId, type) =>
    set((s) => {
      const current = s.indicatorForms[projectId];
      if (!current) return {};
      const mode = s.beneficiaryOwnership[projectId] ?? null;
      if (!canEditProjectResource(mode, useSessionStore.getState().role)) return {};
      const sections = current.sections.map((sec) =>
        sec.id === sectionId
          ? {
              ...sec,
              fields: sec.fields.map((f) =>
                f.id === fieldId
                  ? {
                      ...f,
                      type,
                      options: ["radio", "checkbox", "dropdown"].includes(type)
                        ? f.options ?? ["Option 1", "Option 2", "Option 3"]
                        : undefined,
                    }
                  : f
              ),
            }
          : sec
      );
      return { indicatorForms: { ...s.indicatorForms, [projectId]: { ...current, sections } } };
    }),

  addProject: (project) => {
    const id = uid("prj");
    set((s) => ({ projects: [...s.projects, { ...project, id, statusChangedAt: new Date().toISOString() }] }));
    return id;
  },
  // Re-stamps statusChangedAt only when `patch` actually changes `status`
  // (not on every generic field edit, e.g. budget sync writes from
  // financeStore's syncProjectBudget) — the one place this ever happens, so
  // the "Project progress is stalled" alert (alertRules.ts) always measures
  // from the real last-transition moment.
  updateProject: (id, patch) =>
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === id
          ? { ...p, ...patch, statusChangedAt: patch.status && patch.status !== p.status ? new Date().toISOString() : p.statusChangedAt }
          : p
      ),
    })),
}));

persistLocal("projects", useProjectStore, (s) => ({
  projects: s.projects,
  docs: s.docs,
  wbs: s.wbs,
  beneficiaryOwnership: s.beneficiaryOwnership,
  beneficiaryRecords: s.beneficiaryRecords,
  indicatorForms: s.indicatorForms,
  indicatorFormResponses: s.indicatorFormResponses,
  indicatorFormShareLinks: s.indicatorFormShareLinks,
  documentOwnership: s.documentOwnership,
}));
