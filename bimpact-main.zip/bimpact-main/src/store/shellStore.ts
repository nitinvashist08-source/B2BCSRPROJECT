import { create } from "zustand";

export type Density = "comfortable" | "compact";

type ShellState = {
  density: Density;
  role: string;
  financeSubnavOpen: boolean;
  settingsSubnavOpen: boolean;
  setDensity: (density: Density) => void;
  setRole: (role: string) => void;
  toggleFinanceSubnav: () => void;
  toggleSettingsSubnav: () => void;
};

export const useShellStore = create<ShellState>((set) => ({
  density: "comfortable",
  role: "Program Manager",
  financeSubnavOpen: false,
  settingsSubnavOpen: false,
  setDensity: (density) => set({ density }),
  setRole: (role) => set({ role }),
  toggleFinanceSubnav: () =>
    set((s) => ({ financeSubnavOpen: !s.financeSubnavOpen })),
  toggleSettingsSubnav: () =>
    set((s) => ({ settingsSubnavOpen: !s.settingsSubnavOpen })),
}));
