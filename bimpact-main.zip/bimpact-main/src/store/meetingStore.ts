import { create } from "zustand";
import {
  ActionItem,
  ActionStatus,
  CommitteeMember,
  CommitteePeriod,
  CsrPolicy,
  Guest,
  Meeting,
  MeetingStatus,
} from "@/types/meeting";
import { persistLocal } from "@/lib/localPersist";

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

// mtgNewMeeting's `'MOM-' + String(seq).padStart(3,'0')`,
// bImpact_MeetingSplit_v10.html:10551 — sequential, human-readable ids for
// every newly created meeting (seed/demo meetings keep their own mtg-N ids
// unchanged). Derived from the highest existing MOM-### number rather than
// meetings.length so a deleted-then-recreated meeting never collides with
// one still in the list.
function nextMeetingId(meetings: Meeting[]): string {
  const nums = meetings
    .map((m) => /^MOM-(\d+)$/.exec(m.id))
    .filter((match): match is RegExpExecArray => !!match)
    .map((match) => parseInt(match[1], 10));
  const next = (nums.length ? Math.max(...nums) : 0) + 1;
  return `MOM-${String(next).padStart(3, "0")}`;
}

// csrpGetLatest, bImpact_MeetingSplit_v10.html:12104-12109 — a new policy's
// content is prefilled from the most recently updated Published policy, or
// (if none is published yet) the most recently updated policy overall.
export function latestPolicy(policies: CsrPolicy[]): CsrPolicy | null {
  const byUpdated = (a: CsrPolicy, b: CsrPolicy) => (a.updatedAt > b.updatedAt ? -1 : 1);
  const published = policies.filter((p) => p.status === "Published").sort(byUpdated);
  if (published.length > 0) return published[0];
  const all = [...policies].sort(byUpdated);
  return all[0] ?? null;
}

type MeetingState = {
  committee: CommitteeMember[];
  // stcPeriods/stcActivePeriodId, bImpact_MeetingSplit_v10.html:12339-12340 —
  // `committee` always mirrors periods.find(p => p.id === activePeriodId)'s
  // members; every mutating action below keeps both in sync atomically
  // (the source instead reassigns `mtgCommittee = p.members` then later
  // does `mtgCommittee = mtgCommittee.filter(...)` on removal, which
  // silently decouples the two and loses the removal on next period
  // switch — a real bug, fixed here rather than replicated).
  periods: CommitteePeriod[];
  activePeriodId: string | null;
  meetings: Meeting[];
  policies: CsrPolicy[];
  hydrated: boolean;
  hydrate: (state: {
    committee: CommitteeMember[];
    periods: CommitteePeriod[];
    activePeriodId: string | null;
    meetings: Meeting[];
    policies: CsrPolicy[];
  }) => void;

  createPeriod: (startDate: string, endDate: string) => string;
  setActivePeriod: (id: string) => void;

  addMember: (m: Omit<CommitteeMember, "id">) => void;
  editMember: (id: string, patch: Partial<CommitteeMember>) => void;
  removeMember: (id: string) => void;

  // mtgNewMeeting, bImpact_MeetingSplit_v10.html:10548-10561 — no
  // creation form: a blank Draft is created instantly (today's date, a
  // default 10:00-12:00 slot, empty title/location) and the caller
  // navigates straight into its Setup form to fill in the details.
  createMeeting: () => string;
  saveDraft: (id: string, patch: Partial<Meeting>) => void;
  sendInvite: (id: string) => void;
  startMeeting: (id: string) => void;
  markComplete: (id: string) => void;
  shareMoM: (id: string) => void;
  deleteMeeting: (id: string) => void;

  addAction: (meetingId: string, action: Omit<ActionItem, "id">) => void;
  updateAction: (meetingId: string, actionId: string, patch: Partial<ActionItem>) => void;
  removeAction: (meetingId: string, actionId: string) => void;
  setActionStatus: (meetingId: string, actionId: string, status: ActionStatus) => void;

  setPresent: (meetingId: string, memberId: string) => void;
  setAbsent: (meetingId: string, memberId: string) => void;
  // Setup-time-only: toggles whether a committee member is invited at all
  // (added to/removed from `present`) — distinct from setPresent/setAbsent
  // above, which are the live Execute & MoM attendance toggle.
  toggleAttendeeInvite: (meetingId: string, memberId: string) => void;
  addGuest: (meetingId: string, guest: Omit<Guest, "id">) => void;
  removeGuest: (meetingId: string, guestId: string) => void;

  savePolicy: (
    policy: Omit<CsrPolicy, "id" | "createdAt" | "updatedAt" | "status">,
    publish?: boolean
  ) => void;
  updatePolicy: (id: string, patch: Partial<CsrPolicy>) => void;
  publishPolicy: (id: string) => void;
  unpublishPolicy: (id: string) => void;
  deletePolicy: (id: string) => void;
};

function updateMeeting(
  meetings: Meeting[],
  id: string,
  fn: (m: Meeting) => Meeting
): Meeting[] {
  return meetings.map((m) => (m.id === id ? fn(m) : m));
}

function moveAttendee(
  attendees: Meeting["attendees"],
  memberId: string,
  target: "present" | "absent"
): Meeting["attendees"] {
  const strip = (list: string[]) => list.filter((id) => id !== memberId);
  const next = {
    present: strip(attendees.present),
    absent: strip(attendees.absent),
    guests: attendees.guests,
  };
  next[target] = [...next[target], memberId];
  return next;
}

// Every committee mutation below writes `committee` and the active period's
// stored `members` together in one atomic set() call.
function withActivePeriod(
  periods: CommitteePeriod[],
  activePeriodId: string | null,
  nextCommittee: CommitteeMember[]
): CommitteePeriod[] {
  return periods.map((p) => (p.id === activePeriodId ? { ...p, members: nextCommittee } : p));
}

export const useMeetingStore = create<MeetingState>((set, get) => ({
  committee: [],
  periods: [],
  activePeriodId: null,
  meetings: [],
  policies: [],
  hydrated: false,
  hydrate: (state) => set({ ...state, hydrated: true }),

  // stcCreatePeriod, bImpact_MeetingSplit_v10.html:12415-12429 — periods
  // sort newest-start-first; creating one immediately activates it.
  createPeriod: (startDate, endDate) => {
    const id = uid("period");
    set((s) => {
      const period: CommitteePeriod = { id, startDate, endDate, members: [] };
      const periods = [...s.periods, period].sort((a, b) => (a.startDate > b.startDate ? -1 : 1));
      return { periods, activePeriodId: id, committee: [] };
    });
    return id;
  },
  // stcSetPeriod, bImpact_MeetingSplit_v10.html:12380-12389
  setActivePeriod: (id) =>
    set((s) => {
      const period = s.periods.find((p) => p.id === id);
      if (!period) return s;
      return { activePeriodId: id, committee: period.members };
    }),
  addMember: (m) =>
    set((s) => {
      const committee = [...s.committee, { ...m, id: uid("mem") }];
      return { committee, periods: withActivePeriod(s.periods, s.activePeriodId, committee) };
    }),
  editMember: (id, patch) =>
    set((s) => {
      const committee = s.committee.map((m) => (m.id === id ? { ...m, ...patch } : m));
      return { committee, periods: withActivePeriod(s.periods, s.activePeriodId, committee) };
    }),
  // stcRemoveMem, bImpact_MeetingSplit_v10.html:12622-12635 — removes the
  // member AND all descendants (cascading), not just re-parenting orphans.
  removeMember: (id) =>
    set((s) => {
      const toRemove = new Set<string>([id]);
      let grew = true;
      while (grew) {
        grew = false;
        for (const m of s.committee) {
          if (m.reportsToId && toRemove.has(m.reportsToId) && !toRemove.has(m.id)) {
            toRemove.add(m.id);
            grew = true;
          }
        }
      }
      const committee = s.committee.filter((m) => !toRemove.has(m.id));
      return { committee, periods: withActivePeriod(s.periods, s.activePeriodId, committee) };
    }),

  createMeeting: () => {
    const id = nextMeetingId(get().meetings);
    const today = new Date().toISOString().slice(0, 10);
    set((s) => ({
      meetings: [
        ...s.meetings,
        {
          id,
          title: "",
          date: today,
          startTime: "10:00",
          endTime: "12:00",
          location: "",
          status: "Draft",
          agendaHtml: "",
          notesHtml: "",
          attendees: { present: [], absent: [], guests: [] },
          signoff: { chairIds: [], minutesPreparedBy: "", confirmed: false },
          actions: [],
        },
      ],
    }));
    return id;
  },
  saveDraft: (id, patch) =>
    set((s) => ({ meetings: updateMeeting(s.meetings, id, (m) => ({ ...m, ...patch })) })),
  sendInvite: (id) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, id, (m) => ({
        ...m,
        status: "Upcoming" as MeetingStatus,
      })),
    })),
  startMeeting: (id) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, id, (m) => ({
        ...m,
        status: "InProgress" as MeetingStatus,
      })),
    })),
  markComplete: (id) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, id, (m) => ({
        ...m,
        status: "Completed" as MeetingStatus,
        signoff: { ...m.signoff, closedAt: new Date().toISOString().slice(0, 10) },
      })),
    })),
  shareMoM: (id) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, id, (m) => ({
        ...m,
        signoff: { ...m.signoff, confirmed: true },
      })),
    })),
  deleteMeeting: (id) =>
    set((s) => ({ meetings: s.meetings.filter((m) => m.id !== id) })),

  addAction: (meetingId, action) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, meetingId, (m) => ({
        ...m,
        actions: [...m.actions, { ...action, id: uid("act") }],
      })),
    })),
  updateAction: (meetingId, actionId, patch) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, meetingId, (m) => ({
        ...m,
        actions: m.actions.map((a) => (a.id === actionId ? { ...a, ...patch } : a)),
      })),
    })),
  removeAction: (meetingId, actionId) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, meetingId, (m) => ({
        ...m,
        actions: m.actions.filter((a) => a.id !== actionId),
      })),
    })),
  setActionStatus: (meetingId, actionId, status) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, meetingId, (m) => ({
        ...m,
        actions: m.actions.map((a) => (a.id === actionId ? { ...a, status } : a)),
      })),
    })),

  setPresent: (meetingId, memberId) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, meetingId, (m) => ({
        ...m,
        attendees: moveAttendee(m.attendees, memberId, "present"),
      })),
    })),
  setAbsent: (meetingId, memberId) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, meetingId, (m) => ({
        ...m,
        attendees: moveAttendee(m.attendees, memberId, "absent"),
      })),
    })),
  toggleAttendeeInvite: (meetingId, memberId) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, meetingId, (m) => {
        const invited = m.attendees.present.includes(memberId) || m.attendees.absent.includes(memberId);
        return {
          ...m,
          attendees: invited
            ? {
                ...m.attendees,
                present: m.attendees.present.filter((id) => id !== memberId),
                absent: m.attendees.absent.filter((id) => id !== memberId),
              }
            : { ...m.attendees, present: [...m.attendees.present, memberId] },
        };
      }),
    })),
  addGuest: (meetingId, guest) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, meetingId, (m) => ({
        ...m,
        attendees: {
          ...m.attendees,
          guests: [...m.attendees.guests, { ...guest, id: uid("guest") }],
        },
      })),
    })),
  removeGuest: (meetingId, guestId) =>
    set((s) => ({
      meetings: updateMeeting(s.meetings, meetingId, (m) => ({
        ...m,
        attendees: {
          ...m.attendees,
          guests: m.attendees.guests.filter((g) => g.id !== guestId),
        },
      })),
    })),

  savePolicy: (policy, publish) =>
    set((s) => ({
      policies: [
        ...s.policies,
        {
          ...policy,
          id: uid("pol"),
          status: publish ? "Published" : "Draft",
          createdAt: new Date().toISOString().slice(0, 10),
          updatedAt: new Date().toISOString().slice(0, 10),
        },
      ],
    })),
  updatePolicy: (id, patch) =>
    set((s) => ({
      policies: s.policies.map((p) =>
        p.id === id
          ? { ...p, ...patch, updatedAt: new Date().toISOString().slice(0, 10) }
          : p
      ),
    })),
  publishPolicy: (id) =>
    set((s) => ({
      policies: s.policies.map((p) => (p.id === id ? { ...p, status: "Published" } : p)),
    })),
  unpublishPolicy: (id) =>
    set((s) => ({
      policies: s.policies.map((p) => (p.id === id ? { ...p, status: "Draft" } : p)),
    })),
  // Available regardless of status (Draft or Published) — deleting a
  // Published policy removes its Published state along with the record
  // itself; no separate Unpublish step is required first.
  deletePolicy: (id) =>
    set((s) => ({
      policies: s.policies.filter((p) => p.id !== id),
    })),
}));

persistLocal("meetings", useMeetingStore, (s) => ({
  committee: s.committee,
  periods: s.periods,
  activePeriodId: s.activePeriodId,
  meetings: s.meetings,
  policies: s.policies,
}));
