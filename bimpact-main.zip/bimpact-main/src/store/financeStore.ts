import { create } from "zustand";
import {
  Expense,
  ExpenseStatus,
  GstSlab,
  FundingType,
  MicroCategory,
  MicroLineItem,
  MonthlyPlan,
  PeriodBudget,
  Tranche,
  TrancheStatus,
} from "@/types/finance";
import { persistLocal } from "@/lib/localPersist";
import { projects as SEED_PROJECTS } from "@/data/projectData";
import { useProjectStore } from "@/store/projectStore";
import { useSessionStore } from "@/store/sessionStore";
import { canEditProjectResource } from "@/lib/permissions";
import { OwnershipMode } from "@/types/project";

// The app's fixed, hand-authored demo projects (prj-1..prj-5, see
// data/projectData.ts) — the ONLY projects allowed to get the canned
// fixture Finance data below (seedExpenses/seedTranches/seedMicroCategories).
// Every other project — anything created later via projectStore's
// addProject, which always mints a fresh uid("prj") id that can never
// collide with these — must start with genuinely blank Finance data
// instead: no auto-generated expenses, tranches, or micro-budget line
// items. See each ensure* action below.
const SEED_PROJECT_IDS = new Set(SEED_PROJECTS.map((p) => p.id));

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

function emptyMonthlyPlan(): MonthlyPlan {
  return { ds: Array(12).fill(0), bs: Array(12).fill(0), as: Array(12).fill(0) };
}

function monthlyPlan(dsMonths: [number, number][]): MonthlyPlan {
  const plan = emptyMonthlyPlan();
  for (const [i, v] of dsMonths) plan.ds[i] = v;
  return plan;
}

// addMicroCat, bImpact_MeetingSplit_v10.html:14551-14558 — categories are
// never user-typed; the "category name" is silently auto-filled with the
// project's location string. Replicated verbatim rather than "fixed" into a
// free-text field, per this session's fidelity mandate. microData seeds
// every project with cats:[] (:14121-14146) — the port seeds one starter
// line item per project instead purely so the wide monthly-grid table isn't
// empty on first load; same minor seed-flavor liberty already taken
// elsewhere (e.g. Beneficiary Indicators keeps the verbatim empty-until-
// created pattern, but Finance's other tabs all ship non-empty fixtures).
function seedMicroCategories(location: string): MicroCategory[] {
  return [
    {
      id: uid("mcat"),
      name: location,
      items: [
        {
          id: uid("mit"),
          name: "Scholarships",
          monthly: monthlyPlan([
            [0, 50000],
            [3, 75000],
          ]),
          subItems: [],
        },
        {
          id: uid("mit"),
          name: "Learning kits",
          monthly: monthlyPlan([[1, 40000]]),
          subItems: [],
        },
      ],
    },
  ];
}

// _expDescPool, bImpact_MeetingSplit_v10.html:13794-13820 (a representative
// slice — the original has 25, a smaller fixture is an intentional size
// simplification per the project plan, same as elsewhere in Finance).
const EXPENSE_DESCRIPTIONS = [
  "Purchased stationery and learning kits for beneficiaries",
  "Field officer travel and accommodation expenses",
  "Training facilitator fees and venue charges",
  "Laptop and tablet procurement for community centre",
  "Monthly honorarium for frontline field workers",
  "Medical supplies for health screening camp",
  "Classroom renovation and infrastructure repair",
  "Monitoring and evaluation visit expenses",
];
const EXPENSE_GST_SLABS: GstSlab[] = [5, 5, 12, 18, 18, 28];
const EXPENSE_STATUS_POOL: ExpenseStatus[] = ["approved", "approved", "approved", "pending", "pendingfc", "rejected"];

function seedExpenses(projectId: string): Expense[] {
  return EXPENSE_STATUS_POOL.map((status, i) => {
    const gstSlab = EXPENSE_GST_SLABS[i % EXPENSE_GST_SLABS.length];
    const base = (((i * 37) % 80) + 1) * 5000;
    const amount = Math.round(base * (1 + gstSlab / 100));
    // Pending/pendingfc seed rows are backdated 5 days so the "Expense
    // awaiting approval > 3 days" alert has something real to demonstrate
    // on first load, instead of every seed expense looking freshly
    // submitted (which would never trip that threshold).
    const submittedDaysAgo = status === "pending" || status === "pendingfc" ? 5 : 0;
    const submittedAt = new Date(Date.now() - submittedDaysAgo * 86_400_000).toISOString();
    return {
      id: uid("exp"),
      projectId,
      date: `1${i} Jan 2026`,
      submittedAt,
      type: i % 2 === 0 ? "CAPEX" : "OPEX",
      description: EXPENSE_DESCRIPTIONS[i % EXPENSE_DESCRIPTIONS.length],
      amount,
      gstSlab,
      docFileName: `Bill_${projectId.slice(-3)}_${String(i + 1).padStart(3, "0")}.pdf`,
      status,
      rejectReason: status === "rejected" ? "Missing supporting invoice." : undefined,
    };
  });
}

// Verbatim tranche sets from the original's _disbTranches (:13298-13349),
// mapped in order onto our own (smaller) seeded project list rather than the
// original's separate 10-project _disbProjects — same "one shared project
// list" simplification already approved for the rest of Finance.
const SEED_TRANCHE_SETS: { name: string; condition: string; date: string; amount: number; status: TrancheStatus; remarks?: string }[][] = [
  [
    { name: "Initial Mobilization", condition: "Signed MoU + Board Approval", date: "01 Apr 2024", amount: 4000000, status: "released", remarks: "MoU signed 28 Mar 2024. Onboarding documents verified by program team." },
    { name: "Mid-Term Release", condition: "50% utilization of Tranche 1 confirmed", date: "15 Oct 2024", amount: 1100000, status: "overdue" },
    { name: "Final Release", condition: "Project completion report approved", date: "31 Mar 2025", amount: 400000, status: "scheduled", remarks: "CA-certified utilization certificate and final impact report required before release." },
  ],
  [
    { name: "Kickoff Tranche", condition: "MoU signed + setup confirmation", date: "15 Jun 2024", amount: 800000, status: "released" },
    { name: "Progress Release", condition: "50 teachers trained — validated", date: "15 Dec 2024", amount: 1200000, status: "upcoming", remarks: "Training completion certificates from the partner mandatory prior to this release." },
    { name: "Completion Release", condition: "Final evaluation report submitted", date: "30 Jun 2025", amount: 750000, status: "scheduled" },
  ],
  [
    { name: "Tranche 1 — Seed Fund", condition: "SHG group formation verified", date: "01 May 2024", amount: 1500000, status: "released", remarks: "Group registration certificates and bank account details required." },
    { name: "Tranche 2 — Scale-up", condition: "80% fund utilization from T1", date: "01 Nov 2024", amount: 1500000, status: "overdue" },
    { name: "Tranche 3 — Final", condition: "Impact assessment report approved", date: "30 Apr 2025", amount: 750000, status: "scheduled", remarks: "Final social audit report to be submitted jointly with the field team." },
  ],
  [
    { name: "Phase 1 — Infrastructure", condition: "Device procurement completed", date: "01 Jun 2024", amount: 3000000, status: "released" },
    { name: "Phase 2 — Training", condition: "Trainer onboarding batch 1 complete", date: "01 Feb 2025", amount: 2000000, status: "upcoming", remarks: "Trainer certification records must be submitted before disbursement." },
    { name: "Phase 3 — Closure", condition: "Certification rate ≥75%", date: "30 Sep 2025", amount: 1200000, status: "scheduled" },
  ],
  [
    { name: "Tranche 1 — Survey", condition: "Baseline study completed", date: "15 Apr 2024", amount: 960000, status: "released", remarks: "Baseline report approved by the relevant authority." },
    { name: "Tranche 2 — Install", condition: "Field installation completed — 30 sites", date: "15 Sep 2024", amount: 2400000, status: "overdue", remarks: "Site inspection report from third-party agency required." },
    { name: "Tranche 3 — Ops", condition: "Operations validated for 6 months", date: "31 Mar 2025", amount: 1440000, status: "scheduled" },
  ],
];

function seedTranches(projectId: string, seedIndex: number): Tranche[] {
  const set = SEED_TRANCHE_SETS[seedIndex % SEED_TRANCHE_SETS.length];
  return set.map((t) => ({ id: uid("trn"), projectId, ...t }));
}

type FinanceState = {
  expenses: Expense[];
  disbursements: Record<string, Tranche[]>;
  microBudgets: Record<string, MicroCategory[]>;
  // Project-scoped Micro-Budgeting ownership (Finance → Micro Budgeting →
  // "Who will create the Micro Budget?") — reuses the exact same
  // OwnershipMode ("self"/"partner"/"both") type and canEditProjectResource()
  // permission function WBS/Documents/Indicator Form already use, rather
  // than a parallel framework. Absence of a projectId key (or an explicit
  // null) means "not configured yet" — nobody can create/edit line items
  // until the Sponsor picks one, but EXISTING line items always stay
  // visible/read-only regardless, never hidden or deleted.
  microBudgetOwnership: Record<string, OwnershipMode | null>;
  periodBudgets: PeriodBudget[];
  hydrated: boolean;
  hydrate: (state: {
    expenses: Expense[];
    disbursements: Record<string, Tranche[]>;
    microBudgets: Record<string, MicroCategory[]>;
    microBudgetOwnership: Record<string, OwnershipMode | null>;
    periodBudgets: PeriodBudget[];
  }) => void;

  // Budget Planning → Create Budget creates ONLY the overall sanctioned
  // budget (Planning Duration + Total Sanctioned Amount) — never a Project
  // allocation. Project allocation is a fully separate action ("Assign
  // Project", see AssignProjectSlideOver.tsx) via `addAllocation`/
  // `updateAllocation` below, each validated against that budget's own
  // remaining balance — see periodBudgetBalance below, the single source of
  // truth for that math (never stored/edited directly). Every allocation
  // mutation also write-through syncs Project.budget (Project Finance's
  // existing "Allocated Budget" figure — see HighLevelBudgetTable.tsx,
  // already Partner-visible via its existing permission filtering, so this
  // reuses that surface rather than inventing a new one).
  addPeriodBudget: (input: { startDate: string; endDate: string; totalSanctionedAmount: number }) => string;
  // Period-level fields only (dates + sanctioned amount) — never touches
  // `allocations`. Refuses (no-op) to lower the sanctioned amount below
  // what's already allocated, so a budget can never end up with a negative
  // balance purely from editing its own period fields.
  updatePeriodBudgetPeriod: (
    id: string,
    input: { startDate: string; endDate: string; totalSanctionedAmount: number }
  ) => void;
  removePeriodBudget: (id: string) => void;
  addAllocation: (budgetId: string, projectId: string, allocatedAmount: number) => void;
  updateAllocation: (budgetId: string, projectId: string, allocatedAmount: number) => void;
  removeAllocation: (budgetId: string, projectId: string) => void;

  ensureExpenses: (projectId: string) => void;
  addExpense: (expense: Omit<Expense, "id" | "status" | "submittedAt">) => void;
  approveAsPM: (id: string) => void;
  approveAsFC: (id: string) => void;
  rejectExpense: (id: string, reason: string) => void;

  ensureDisbursements: (projectId: string, seedIndex: number) => void;
  addTranche: (projectId: string, tranche: Omit<Tranche, "id" | "projectId" | "status">) => void;
  releaseTranche: (projectId: string, trancheId: string) => void;

  // "Who creates the Micro Budget?" is a sponsor-only governance decision —
  // an invited partner must never be able to set it, even by a direct store
  // call bypassing the (already-hidden, for partners) picker UI. Mirrors
  // setWbsMode/setDocumentOwnership's exact same guard in projectStore.ts.
  setMicroBudgetOwnership: (projectId: string, mode: OwnershipMode) => void;
  ensureMicroBudget: (projectId: string, location: string) => void;
  // saveMicroCat, bImpact_MeetingSplit_v10.html:14569-14716 — the one
  // reachable add/edit entry point for micro-budget line items (see the
  // MicroLineItemSlideOver comment for why the two other slide-overs in the
  // source aren't ported). `editing` absent = add mode, which replicates the
  // original's match-by-name dedup: an existing category/item with the same
  // name is reused rather than creating a duplicate, EXCEPT adding a bare
  // line item (no sub-line-item name) onto an already-existing item name
  // does push a second, same-named item — that quirk is intentional, not a
  // bug in the port. Guarded by canEditProjectResource(microBudgetOwnership[projectId], role) —
  // same enforcement point WBS/Documents/Indicator Form actions already use,
  // refusing (no-op) the mutation for a read-only role even if called
  // directly, bypassing the UI. Viewing (reading microBudgets[projectId]) is
  // never gated.
  saveMicroLineItem: (
    projectId: string,
    input: {
      editing?: { categoryId: string; itemId: string; subItemId?: string };
      locationName: string;
      lineItemName: string;
      subLineItemName: string;
      monthly: MonthlyPlan;
    }
  ) => void;
};

// Write-through sync into Project.budget (this app's existing, already
// Partner-visible "Allocated Budget" field — see HighLevelBudgetTable.tsx,
// FinanceTopBar.tsx, TranchePipeline.tsx, dashboards, all untouched and
// already reading it). Deliberately last-write-wins, not summed across
// PeriodBudgets — a Project only ever has one currently-synced allocated
// figure, matching this feature's own stated scope (limited to the Budget
// Planning Create Budget flow, not a rebuild of Project Finance itself).
function syncProjectBudget(projectId: string, amount: number) {
  useProjectStore.getState().updateProject(projectId, { budget: amount });
}

export const useFinanceStore = create<FinanceState>((set) => ({
  expenses: [],
  disbursements: {},
  microBudgets: {},
  microBudgetOwnership: {},
  periodBudgets: [],
  hydrated: false,
  hydrate: (state) => set({ ...state, hydrated: true }),

  addPeriodBudget: (input) => {
    const id = uid("bud");
    const today = new Date().toISOString().slice(0, 10);
    set((s) => ({
      periodBudgets: [
        ...s.periodBudgets,
        {
          id,
          startDate: input.startDate,
          endDate: input.endDate,
          totalSanctionedAmount: input.totalSanctionedAmount,
          allocations: [],
          createdAt: today,
          updatedAt: today,
        },
      ],
    }));
    return id;
  },
  updatePeriodBudgetPeriod: (id, input) =>
    set((s) => {
      const budget = s.periodBudgets.find((b) => b.id === id);
      if (!budget) return {};
      if (input.totalSanctionedAmount < periodBudgetAllocated(budget)) return {};
      return {
        periodBudgets: s.periodBudgets.map((b) => (b.id === id ? { ...b, ...input, updatedAt: new Date().toISOString().slice(0, 10) } : b)),
      };
    }),
  removePeriodBudget: (id) =>
    set((s) => {
      const budget = s.periodBudgets.find((b) => b.id === id);
      budget?.allocations.forEach((a) => syncProjectBudget(a.projectId, 0));
      return { periodBudgets: s.periodBudgets.filter((b) => b.id !== id) };
    }),
  // Guarded against the budget's own remaining balance even though the
  // Create/Allocate UI already validates this — "even if the UI state
  // becomes stale" per spec, the data layer is the actual last line of
  // defense, same convention as this app's other ownership/permission
  // guards (see canEditProjectResource in permissions.ts).
  addAllocation: (budgetId, projectId, allocatedAmount) =>
    set((s) => {
      const budget = s.periodBudgets.find((b) => b.id === budgetId);
      if (!budget || allocatedAmount <= 0) return {};
      const alreadyAllocated = budget.allocations.reduce((sum, a) => sum + a.allocatedAmount, 0);
      if (budget.allocations.some((a) => a.projectId === projectId)) return {}; // use updateAllocation instead
      if (alreadyAllocated + allocatedAmount > budget.totalSanctionedAmount) return {};
      syncProjectBudget(projectId, allocatedAmount);
      return {
        periodBudgets: s.periodBudgets.map((b) =>
          b.id === budgetId
            ? {
                ...b,
                allocations: [...b.allocations, { projectId, allocatedAmount }],
                updatedAt: new Date().toISOString().slice(0, 10),
              }
            : b
        ),
      };
    }),
  updateAllocation: (budgetId, projectId, allocatedAmount) =>
    set((s) => {
      const budget = s.periodBudgets.find((b) => b.id === budgetId);
      if (!budget || allocatedAmount <= 0) return {};
      // Exclude this allocation's OWN current amount from "already
      // allocated" — the balance available to it is the sanctioned amount
      // minus every OTHER project's allocation, not minus itself too
      // (spec section 15's "do not subtract the current record twice").
      const otherAllocated = budget.allocations
        .filter((a) => a.projectId !== projectId)
        .reduce((sum, a) => sum + a.allocatedAmount, 0);
      if (otherAllocated + allocatedAmount > budget.totalSanctionedAmount) return {};
      syncProjectBudget(projectId, allocatedAmount);
      return {
        periodBudgets: s.periodBudgets.map((b) =>
          b.id === budgetId
            ? {
                ...b,
                allocations: b.allocations.map((a) => (a.projectId === projectId ? { ...a, allocatedAmount } : a)),
                updatedAt: new Date().toISOString().slice(0, 10),
              }
            : b
        ),
      };
    }),
  removeAllocation: (budgetId, projectId) =>
    set((s) => {
      const budget = s.periodBudgets.find((b) => b.id === budgetId);
      if (!budget) return {};
      syncProjectBudget(projectId, 0);
      return {
        periodBudgets: s.periodBudgets.map((b) =>
          b.id === budgetId
            ? { ...b, allocations: b.allocations.filter((a) => a.projectId !== projectId), updatedAt: new Date().toISOString().slice(0, 10) }
            : b
        ),
      };
    }),

  // Real projects never get fabricated expenses — a real project's expenses
  // array simply stays empty (ExpenseTable/ExpenseProjectList already render
  // "No expenses" for that) until the user books one via addExpense.
  ensureExpenses: (projectId) =>
    set((s) =>
      !SEED_PROJECT_IDS.has(projectId) || s.expenses.some((e) => e.projectId === projectId)
        ? s
        : { expenses: [...s.expenses, ...seedExpenses(projectId)] }
    ),
  // saveExpense, bImpact_MeetingSplit_v10.html:14060-14071 — new bookings
  // always start "pending" (Pending PM).
  addExpense: (expense) =>
    set((s) => ({
      expenses: [...s.expenses, { ...expense, id: uid("exp"), submittedAt: new Date().toISOString(), status: "pending" }],
    })),
  approveAsPM: (id) =>
    set((s) => ({
      expenses: s.expenses.map((e) => (e.id === id && e.status === "pending" ? { ...e, status: "pendingfc" } : e)),
    })),
  approveAsFC: (id) =>
    set((s) => ({
      expenses: s.expenses.map((e) => (e.id === id && e.status === "pendingfc" ? { ...e, status: "approved" } : e)),
    })),
  rejectExpense: (id, reason) =>
    set((s) => ({
      expenses: s.expenses.map((e) => (e.id === id ? { ...e, status: "rejected", rejectReason: reason } : e)),
    })),

  // A real project starts with zero tranches — Allocation must never imply
  // Disbursement (see HighLevelBudgetTable's already-independent
  // `disbursed = sum of released tranches` calculation, which naturally
  // reads 0 for an empty array here).
  ensureDisbursements: (projectId, seedIndex) =>
    set((s) =>
      s.disbursements[projectId]
        ? s
        : {
            disbursements: {
              ...s.disbursements,
              [projectId]: SEED_PROJECT_IDS.has(projectId) ? seedTranches(projectId, seedIndex) : [],
            },
          }
    ),
  // disbAddTranche/saveTranche, bImpact_MeetingSplit_v10.html:13607-13664 —
  // new tranches always start "scheduled"; the caller (ScheduleTrancheSlideOver)
  // computes the display condition/date text from the chosen milestone type.
  addTranche: (projectId, tranche) =>
    set((s) => ({
      disbursements: {
        ...s.disbursements,
        [projectId]: [
          ...(s.disbursements[projectId] ?? []),
          { ...tranche, id: uid("trn"), projectId, status: "scheduled" },
        ],
      },
    })),
  // The only place a Tranche's status is ever set to "released" — a
  // deliberate, manual, explicit Sponsor action (see ReleaseTrancheModal.tsx
  // and canManuallyRelease below), never inferred from creating/planning/
  // allocating/saving. Records `releasedAt` at the moment of release.
  releaseTranche: (projectId, trancheId) =>
    set((s) => ({
      disbursements: {
        ...s.disbursements,
        [projectId]: (s.disbursements[projectId] ?? []).map((t) =>
          t.id === trancheId ? { ...t, status: "released", releasedAt: new Date().toISOString().slice(0, 10) } : t
        ),
      },
    })),

  // A real project's Micro Budgeting starts fully blank — every category/
  // line item must come from the user via saveMicroLineItem, matching
  // MicroBudgetView's existing "No budget lines allocated" empty state.
  setMicroBudgetOwnership: (projectId, mode) => {
    if (useSessionStore.getState().role === "partner") return;
    set((s) => ({ microBudgetOwnership: { ...s.microBudgetOwnership, [projectId]: mode } }));
  },

  ensureMicroBudget: (projectId, location) =>
    set((s) =>
      s.microBudgets[projectId]
        ? s
        : {
            microBudgets: {
              ...s.microBudgets,
              [projectId]: SEED_PROJECT_IDS.has(projectId) ? seedMicroCategories(location) : [],
            },
          }
    ),

  saveMicroLineItem: (projectId, input) =>
    set((s) => {
      if (!canEditProjectResource(s.microBudgetOwnership[projectId] ?? null, useSessionStore.getState().role)) return {};
      const categories = s.microBudgets[projectId] ?? [];
      const { editing, locationName, lineItemName, subLineItemName, monthly } = input;

      if (editing) {
        const next = categories.map((cat) => {
          if (cat.id !== editing.categoryId) return cat;
          return {
            ...cat,
            name: locationName,
            items: cat.items.map((item) => {
              if (item.id !== editing.itemId) return item;
              if (editing.subItemId) {
                // Editing a specific sub line item — saveMicroCat's
                // sIdx!=="" branch, :14641-14650.
                return {
                  ...item,
                  name: lineItemName,
                  subItems: item.subItems.map((sub) =>
                    sub.id === editing.subItemId ? { ...sub, name: subLineItemName || "Unnamed Sub Item", monthly } : sub
                  ),
                };
              }
              // Editing the line item itself — :14651-14666.
              if (subLineItemName) {
                const subItems = item.subItems.length
                  ? item.subItems.map((sub, i) => (i === 0 ? { ...sub, name: subLineItemName, monthly } : sub))
                  : [{ id: uid("mit"), name: subLineItemName, monthly, subItems: [] }];
                return { ...item, name: lineItemName, subItems };
              }
              return { ...item, name: lineItemName, monthly, subItems: [] };
            }),
          };
        });
        return { microBudgets: { ...s.microBudgets, [projectId]: next } };
      }

      // Add mode — match-by-name dedup, saveMicroCat's else branch, :14668-14695.
      const newSubItems = subLineItemName ? [{ id: uid("mit"), name: subLineItemName, monthly, subItems: [] }] : [];
      const newItem: MicroLineItem = { id: uid("mit"), name: lineItemName, monthly, subItems: newSubItems };

      const existingCat = categories.find((c) => c.name === locationName);
      if (!existingCat) {
        return {
          microBudgets: {
            ...s.microBudgets,
            [projectId]: [...categories, { id: uid("mcat"), name: locationName, items: [newItem] }],
          },
        };
      }
      const existingItem = existingCat.items.find((i) => i.name === lineItemName);
      const nextItems = !existingItem
        ? [...existingCat.items, newItem]
        : subLineItemName
          ? existingCat.items.map((i) =>
              i.id === existingItem.id ? { ...i, subItems: [...i.subItems, { id: uid("mit"), name: subLineItemName, monthly, subItems: [] }] } : i
            )
          : [...existingCat.items, newItem];
      return {
        microBudgets: {
          ...s.microBudgets,
          [projectId]: categories.map((c) => (c.id === existingCat.id ? { ...c, items: nextItems } : c)),
        },
      };
    }),
}));

persistLocal("finance", useFinanceStore, (s) => ({
  expenses: s.expenses,
  disbursements: s.disbursements,
  microBudgets: s.microBudgets,
  microBudgetOwnership: s.microBudgetOwnership,
  periodBudgets: s.periodBudgets,
}));

export function periodBudgetAllocated(budget: PeriodBudget): number {
  return budget.allocations.reduce((sum, a) => sum + a.allocatedAmount, 0);
}

// "Balance Budget" per spec — always derived, never stored/edited directly.
export function periodBudgetBalance(budget: PeriodBudget): number {
  return budget.totalSanctionedAmount - periodBudgetAllocated(budget);
}

export function monthlyPlanTotal(plan: MonthlyPlan): number {
  return (Object.keys(plan) as FundingType[]).reduce(
    (sum, type) => sum + plan[type].reduce((a, b) => a + b, 0),
    0
  );
}

// calcMicroTotals, bImpact_MeetingSplit_v10.html:14150-14173 — either/or, not
// additive: an item with sub-items ignores its own monthly plan entirely and
// totals only its sub-items; a leaf item's total is its own monthly plan.
export function microLineTotal(item: MicroLineItem): number {
  if (item.subItems.length) return item.subItems.reduce((sum, child) => sum + microLineTotal(child), 0);
  return monthlyPlanTotal(item.monthly);
}

// _disbPipeItemHTML's canRelease (bImpact_MeetingSplit_v10.html:13366): a
// tranche can be released if it's upcoming/overdue, OR immediately follows a
// tranche that's already released (the original's "unlock the next one" step
// inside _disbDoRelease, :13468-13487) — derived fresh from status each
// render instead of a one-off DOM mutation, since our state is persisted.
export function canReleaseTranche(tranches: Tranche[], index: number): boolean {
  const t = tranches[index];
  if (t.status === "released") return false;
  if (t.status === "upcoming" || t.status === "overdue") return true;
  return index > 0 && tranches[index - 1].status === "released";
}

// Real gap canReleaseTranche alone left unfixed: every tranche created via
// "Add Tranche" starts life as status "scheduled" (see addTranche above),
// and nothing in this app ever transitions a tranche INTO "upcoming"/
// "overdue" at runtime — those only ever come from seed data. Combined with
// canReleaseTranche's own sequential rule (a "scheduled" tranche is only
// releasable if the one before it is already released), a Sponsor-created
// tranche could never reach a Release button at all, UNLESS it happened to
// land right after an already-released one. A "Custom Condition" tranche
// (see TrancheMilestoneType) is exempted from that sequential gate
// entirely — it's always manually releasable while unreleased, per spec —
// while every other milestone type keeps canReleaseTranche's existing
// pipeline behavior completely unchanged (this is additive, not a
// replacement).
export function canManuallyRelease(tranches: Tranche[], index: number): boolean {
  const t = tranches[index];
  if (t.status === "released") return false;
  if (t.milestoneType === "custom") return true;
  return canReleaseTranche(tranches, index);
}

// _disbListStatus, bImpact_MeetingSplit_v10.html:13412-13421
export function disbListStatus(tranches: Tranche[]): { label: string; tone: "attention" | "ontrack" | "noplan" } {
  if (!tranches.length) return { label: "No Plan", tone: "noplan" };
  if (tranches.some((t) => t.status === "overdue")) return { label: "⚠ Attention", tone: "attention" };
  if (tranches.some((t) => t.status === "upcoming")) return { label: "✓ On Track", tone: "ontrack" };
  if (tranches.every((t) => t.status === "released")) return { label: "✓ Completed", tone: "ontrack" };
  return { label: "✓ On Track", tone: "ontrack" };
}

export function microCategoryTotal(category: MicroCategory): number {
  return category.items.reduce((sum, item) => sum + microLineTotal(item), 0);
}
