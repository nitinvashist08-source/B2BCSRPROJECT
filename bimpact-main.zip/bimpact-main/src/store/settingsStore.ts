import { create } from "zustand";
import { ComplianceDocType, ComplianceDocument, ComplianceStatus, PartnerOrg, PartnerTeamMember, PartnerType, TeamMember } from "@/types/settings";
import { PartnerComplianceChecklist } from "@/types/partnerForm";
import { PartnerActivityType, PartnerHistoryEntry } from "@/types/partnerHistory";
import { persistLocal } from "@/lib/localPersist";
import { useSessionStore } from "@/store/sessionStore";
import { useAlertStore } from "@/store/alertStore";
import { DEFAULT_DEMO_WORKSPACE_ID } from "@/store/workspaceStore";
import { isPartnerEligibleForAssignment } from "@/lib/partnerEligibility";
import { saveLastPartnerInvite } from "@/lib/lastPartnerInvite";
import { getActiveChecklistForPartnerType, getComplianceDocLabel, getRequiredItemIdsForPartner } from "@/lib/partnerComplianceRequirements";

// "Complete" iff every currently-required item (per the partner's type's
// Active PartnerComplianceChecklist — see partnerComplianceRequirements.ts)
// has a document; trivially "Complete" when nothing is required at all
// (either no checklist configured yet, or one configured with zero items),
// since there's nothing to nag the partner about in that case.
function complianceStatusFor(documents: ComplianceDocument[], requiredItemIds: string[]): ComplianceStatus {
  return requiredItemIds.every((id) => documents.some((d) => d.type === id)) ? "Complete" : "Incomplete";
}

// Locates the ComplianceDocument a document-level review action targets.
// The 5 required types are single-slot — `type` alone is already
// unambiguous, `fileId` is ignored. "Other" can hold several documents of
// the same type, so `fileId` disambiguates; if the caller didn't have one
// handy (a legacy fileUrl-only record predates fileId), this falls back to
// the first "Other" doc, which is only actually ambiguous when more than
// one exists.
function findComplianceDocIndex(docs: ComplianceDocument[], type: ComplianceDocType, fileId?: string | null): number {
  if (type !== "Other") return docs.findIndex((d) => d.type === type);
  if (fileId) return docs.findIndex((d) => d.type === "Other" && d.fileId === fileId);
  return docs.findIndex((d) => d.type === "Other");
}

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

// Normalizes a partner record read from localStorage (or the bundled seed)
// to the current PartnerOrg shape. An earlier pass replaced a single
// `district: string` field with `districts: string[]` — a browser that
// saved partner data before that change still has partners missing
// `districts` entirely (or carrying the old singular field), which crashed
// PartnerSubmissionReview's location section on `.map()`. Same "normalize
// whatever shape actually comes out of storage" pattern already used by
// meetingStore for its own historical committee-member shape drift — run on
// every hydrate, not just once, since localStorage can hold data saved by
// an older build at any time.
function normalizePartner(raw: PartnerOrg & { district?: string }): PartnerOrg {
  const { district, ...partner } = raw;
  return {
    ...partner,
    state: partner.state ?? "",
    districts: Array.isArray(partner.districts) ? partner.districts : district ? [district] : [],
  };
}

// Builds one immutable Change Request & Activity History entry — every
// caller (requestPartnerChanges/deactivatePartner/reactivatePartner) APPENDS
// this to the existing partnerHistory array, never replaces or prunes it
// (see PartnerHistoryEntry's own header comment for why). `performedBy`
// always reads the CURRENT Sponsor session, same as deactivatePartner's
// existing session lookup — there's only ever one acting role ("sponsor")
// in this app's Partner-management flows.
function buildHistoryEntry(
  partnerId: string,
  activityType: PartnerActivityType,
  previousStatus: string,
  newStatus: string,
  reason?: string | null,
  // Only the three document_* activity types pass this — identifies which
  // uploaded document the entry is about (see PartnerHistoryEntry's own
  // documentType/documentLabel/documentFileId comments).
  docInfo?: { documentType: ComplianceDocType; documentLabel: string; documentFileId?: string | null }
): PartnerHistoryEntry {
  const session = useSessionStore.getState();
  return {
    id: uid("hist"),
    partnerId,
    activityType,
    reason: reason ?? null,
    previousStatus,
    newStatus,
    performedBy: { userId: session.userId ?? "", name: session.name ?? "", role: "sponsor" },
    createdAt: new Date().toISOString(),
    ...(docInfo
      ? { documentType: docInfo.documentType, documentLabel: docInfo.documentLabel, documentFileId: docInfo.documentFileId ?? null }
      : {}),
  };
}

// activatePartner persists synchronously (not through the debounced
// subscriber below) because its only caller (PartnerOnboardingForm) follows
// it immediately with loginAsPartner() + a hard `window.location` navigation
// — a debounced write's timer can get cancelled by the page unloading
// first, silently dropping the activation (the partner would stay Invited
// with its token still valid, forever, even though the user just onboarded
// and the new page shows them in the workspace). Same reasoning/pattern as
// sessionStore's login/logout and workspaceStore's createWorkspace.
// Exported as persistSettingsNow (aliased on import to avoid colliding with
// each store's own identically-named local persistNow) so callers OUTSIDE
// this store — currently only sessionStore's loginAsPartner, stamping
// PartnerOrg.firstLoginAt — can force the same synchronous write when their
// own action is about to be followed by a hard `window.location`
// navigation. The debounced subscriber below would otherwise get cancelled
// by the page unloading before its timer fires, silently dropping the
// update — same reasoning as every other persistNow(get()) call site in
// this file.
export function persistNow(state: {
  teamMembers: TeamMember[];
  partners: PartnerOrg[];
  allocationCeiling: number;
  projectStates: Record<string, string[]>;
  projectPartners: Record<string, string[]>;
  projectDistricts: Record<string, string[]>;
  partnerForms: PartnerComplianceChecklist[];
  partnerTeamMembers: PartnerTeamMember[];
  partnerHistory: PartnerHistoryEntry[];
}) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem("bimpact:settings", JSON.stringify(state));
  } catch {
    // best-effort — matches localPersist.ts's own swallow-and-log approach
  }
}

type SettingsState = {
  teamMembers: TeamMember[];
  partners: PartnerOrg[];
  allocationCeiling: number;
  projectStates: Record<string, string[]>;
  projectPartners: Record<string, string[]>;
  projectDistricts: Record<string, string[]>;
  partnerForms: PartnerComplianceChecklist[];
  // A Partner organization's own internal team — kept as its own list (not
  // folded into `teamMembers`, which is the Sponsor's) so every read/write
  // is structurally scoped by `partnerOrgId`; see PartnerTeamMember's
  // comment in src/types/settings.ts.
  partnerTeamMembers: PartnerTeamMember[];
  // Permanent Change Request & Activity History log — append-only, never
  // filtered/derived from PartnerOrg's current fields (see
  // src/types/partnerHistory.ts). Not scoped by workspaceId here (same as
  // `partners` itself isn't) — PartnerSubmissionReview filters by
  // partnerId, which is already workspace-scoped via the partner it's
  // showing.
  partnerHistory: PartnerHistoryEntry[];
  hydrated: boolean;
  hydrate: (state: {
    teamMembers: TeamMember[];
    partners: PartnerOrg[];
    allocationCeiling: number;
    projectStates: Record<string, string[]>;
    projectPartners: Record<string, string[]>;
    projectDistricts: Record<string, string[]>;
    partnerForms: PartnerComplianceChecklist[];
    partnerTeamMembers: PartnerTeamMember[];
    partnerHistory?: PartnerHistoryEntry[];
  }) => void;

  inviteMember: (member: Omit<TeamMember, "id" | "status">) => void;
  updateMember: (id: string, patch: Partial<TeamMember>) => void;
  removeMember: (id: string) => void;

  // Partner-side counterpart to inviteMember/updateMember/removeMember —
  // every action is scoped by partnerOrgId so one Partner org can never see
  // or mutate another's team. Duplicate check is per-organization (the same
  // email could legitimately belong to different people at two different
  // Partner orgs), matching registerPartner's own per-scope dedup style.
  invitePartnerTeamMember: (
    member: Omit<PartnerTeamMember, "id" | "status">
  ) => { ok: true } | { ok: false; reason: "duplicate" };
  updatePartnerTeamMember: (id: string, patch: Partial<PartnerTeamMember>) => void;
  removePartnerTeamMember: (id: string) => void;

  // Sponsor-side invite no longer collects location ("state"/"districts") —
  // per spec, that's the partner's own information to provide during
  // onboarding (Step 3: Organization Location), not something a Sponsor
  // guesses on their behalf at invite time.
  //
  // Re-invite handling: this is the single source of truth for "the latest
  // invitation" — there's no separate Invitation record (see the Partner
  // Onboarding Welcome step, which just reads the matched PartnerOrg
  // directly, per src/lib/partnerInvite.ts). If contactEmail already
  // matches an existing partner who is still pre-onboarding (status
  // "Invited" and reviewStatus not yet set — i.e. the invite link was never
  // used to submit anything), this UPDATES that same record in place
  // (refreshed name/contactName/type, a new inviteToken/invitedAt) instead
  // of creating a duplicate row, so the same org's latest details replace
  // the old ones and the old invite link stops validating (see
  // validateInviteToken). If that email belongs to a partner who has
  // already submitted onboarding (reviewStatus set) or is Active/Inactive,
  // this refuses instead of clobbering their real data — the Sponsor should
  // manage that partner via Edit/the review actions, not another invite.
  invitePartner: (
    partner: Omit<
      PartnerOrg,
      | "id"
      | "status"
      | "workspaceId"
      | "inviteToken"
      | "invitedAt"
      | "complianceStatus"
      | "complianceDocuments"
      | "state"
      | "districts"
    >
  ) => { ok: true; partner: PartnerOrg } | { ok: false; reason: "duplicate" };
  updatePartner: (id: string, patch: Partial<PartnerOrg>) => void;
  // Sponsor-side "Edit Partner" form save (InvitePartnerSlideOver's editing
  // path) — unlike the generic updatePartner above (used internally for
  // status-only flips like Deactivate/Activate/Approve), this is the
  // user-facing edit action, so it re-checks eligibility itself rather than
  // trusting the menu item that opened the form: only a partner still
  // "Invited" with no reviewStatus (never submitted onboarding) may be
  // edited this way. Refuses instead of applying the patch for anyone else
  // (Active, Inactive, or Invited-but-submitted/Pending Review/Changes
  // Requested/Rejected), so stale UI (a second tab, a menu opened just
  // before an Approve/Reject elsewhere) can't sneak an edit through even if
  // the menu item itself somehow rendered.
  editPartner: (
    id: string,
    patch: { name: string; contactName: string; contactEmail: string; type: PartnerType }
  ) => { ok: true; partner: PartnerOrg } | { ok: false; reason: "not-found" | "not-editable" };
  removePartner: (id: string) => void;
  // Sponsor-side "Deactivate Partner" (see DeactivatePartnerDialog) — only
  // valid from status "Active", and only with a non-blank reason, checked
  // here (not just in the dialog's own form validation) so a stale menu/
  // direct call can never deactivate without one or deactivate a partner
  // that isn't Active. Stamps who/when alongside the reason rather than
  // just flipping status, so there's an audit trail (see
  // PartnerDeactivation in src/types/settings.ts).
  deactivatePartner: (
    id: string,
    reason: string
  ) => { ok: true; partner: PartnerOrg } | { ok: false; reason: "not-found" | "not-active" | "invalid-reason" };
  // Sponsor-side "Activate Partner" (see PartnerStatusMenuItems) — from
  // either an Inactive/Deactivated partner (manual Deactivate, or a
  // reviewStatus "Rejected" outcome) back to Active. Same status flip the
  // old inline `updatePartner(id, { status: "Active" })` call did, just
  // re-checked here so it can't fire on a partner that isn't Inactive.
  // Deliberately does NOT touch reviewStatus/complianceDocuments/anything
  // else — no new onboarding submission, no data loss, per spec.
  reactivatePartner: (id: string) => { ok: true; partner: PartnerOrg } | { ok: false; reason: "not-found" | "not-inactive" };
  // Sponsor-side "Cancel Invitation" (see CancelInvitationDialog) — same
  // removal the old inline `removePartner(id)` call did for this one case,
  // now re-checked so it only ever removes a still-pending, never-submitted
  // invite (status "Invited", no reviewStatus) rather than any partner row.
  // removePartner itself stays a generic, ungated primitive — this is the
  // Cancel-Invitation-specific, guarded entry point for it.
  cancelPartnerInvitation: (id: string) => { ok: true } | { ok: false; reason: "not-found" | "not-invited" };
  // Sponsor-initiated "Re-invite" on an Invited-status partner row (see
  // PartnerOrgsTable/ReinvitePartnerDialog) — same in-place refresh
  // invitePartner already does when re-invited by matching email, but keyed
  // by id (no email/name re-entry needed) since the Sponsor already has the
  // record open. Only valid pre-submission (status "Invited", no
  // reviewStatus yet — matches the existing inviteToken-gated Copy Invite
  // Link/Cancel Invitation actions): once onboarding is submitted there's a
  // real review workflow for it instead, and re-inviting must never touch
  // that submitted data.
  reinvitePartner: (id: string) => { ok: true; partner: PartnerOrg } | { ok: false; reason: "not-found" | "not-invited" };
  findPartnerByInviteToken: (token: string) => PartnerOrg | undefined;
  // Completes an invited partner's onboarding wizard. Organization Email and
  // Partner Type are invitation-controlled and never change here; Name and
  // Primary Contact Person are editable on the Welcome step (the partner may
  // legitimately need to correct/formalize what the Sponsor typed at invite
  // time), so this is where those, plus location and compliance documents,
  // finally land on the record.
  activatePartner: (
    id: string,
    input: {
      name: string;
      contactName: string;
      state: string;
      districts: string[];
      complianceDocuments: ComplianceDocument[];
    }
  ) => void;
  // Partner-side Compliance module (src/app/compliance/page.tsx) — adds or
  // replaces a compliance document for the given partner. Every doc type
  // except "Other" is a single slot: uploading again for the same type
  // replaces that one entry (matches the "Replace" UX — old file is no
  // longer the active document, no duplicate active record). "Other
  // Supporting Documents" is the one category allowed to hold multiple
  // files, so it always appends instead. complianceStatus is recomputed
  // through the same complianceStatusFor used by activatePartner/
  // registerPartner — one status model, not a second one.
  uploadComplianceDocument: (
    partnerId: string,
    doc: ComplianceDocument
    // `replacedFileId` is the old entry's fileId when this REPLACED a
    // same-type single-slot document (undefined for a fresh upload or an
    // "Other" append) — the caller uses it to delete the now-orphaned blob
    // from complianceFileStore.ts's IndexedDB.
  ) => { ok: true; replacedFileId?: string } | { ok: false; reason: "quota" | "not-found" };
  // Sponsor-side document-level review (Partner Details → Document View) —
  // INDEPENDENT of the overall Partner onboarding review workflow above
  // (approvePartnerReview/requestPartnerChanges/rejectPartnerReview): never
  // touches PartnerOrg.status/reviewStatus, only the one ComplianceDocument
  // record's own reviewStatus/review fields, matched by `type` (+ `fileId`
  // to disambiguate one of possibly-several "Other" documents of the same
  // type — undefined for the 5 single-slot required types, where `type`
  // alone is already unambiguous). Every call also appends a
  // document_accepted/document_rejected/document_changes_requested entry to
  // partnerHistory — see buildHistoryEntry — so the decision is never lost
  // even if the document is later re-uploaded/replaced.
  acceptComplianceDocument: (
    partnerId: string,
    type: ComplianceDocType,
    fileId?: string | null
  ) => { ok: true } | { ok: false; reason: "not-found" };
  rejectComplianceDocument: (
    partnerId: string,
    type: ComplianceDocType,
    fileId: string | null | undefined,
    reason: string
  ) => { ok: true } | { ok: false; reason: "not-found" | "invalid-reason" };
  requestComplianceDocumentChanges: (
    partnerId: string,
    type: ComplianceDocType,
    fileId: string | null | undefined,
    reason: string
  ) => { ok: true } | { ok: false; reason: "not-found" | "invalid-reason" };
  // Self-serve partner sign-up (no Sponsor-generated invite token) — reached
  // via /partner-onboarding with no ?token= in the URL. Creates an already-
  // Active PartnerOrg directly (there's no invite to consume), landing in
  // the app's one shared demo workspace since there's no inviting Sponsor to
  // inherit a workspaceId from.
  registerPartner: (input: {
    name: string;
    contactName: string;
    contactEmail: string;
    state: string;
    districts: string[];
    type: PartnerType;
    complianceDocuments: ComplianceDocument[];
  }) => { ok: true; partner: PartnerOrg } | { ok: false; reason: "duplicate" };

  // Sponsor review decisions on a submitted partner onboarding — see
  // src/types/settings.ts's PartnerReviewStatus. All three clear whichever
  // of changeRequestMessage/rejectionReason doesn't apply to the new
  // decision, so a partner never sees a stale message from a prior round.
  approvePartnerReview: (id: string) => void;
  requestPartnerChanges: (id: string, message: string) => void;
  rejectPartnerReview: (id: string, reason: string) => void;

  // Clears the "NEW" tag on one compliance document once the Sponsor opens
  // it (see ComplianceDocumentsSection.tsx). Independent of reviewStatus/the
  // Alerts module — viewing a document never touches the review decision or
  // the consolidated compliance-upload alert (see alertStore's markRead for
  // that). Matches
  // by type, which only works for the 5 single-slot document types — "Other"
  // can hold several documents of the same type, so it has its own
  // fileId-matched variant below instead of reusing this one.
  markComplianceDocumentViewed: (partnerId: string, type: ComplianceDocType) => void;
  // Same "NEW" tag clear as above, but for one specific "Other Supporting
  // Document" — matched by fileId (unique per upload) since "Other" holds a
  // list, not a single slot, so type alone can't identify which entry the
  // Sponsor actually opened.
  markOtherComplianceDocumentViewed: (partnerId: string, fileId: string) => void;

  setCeiling: (amount: number) => void;

  setProjectStates: (projectId: string, states: string[]) => void;
  setProjectPartners: (projectId: string, partners: string[]) => void;
  setProjectDistricts: (projectId: string, districts: string[]) => void;

  // Only one compliance checklist per partner type — createPartnerForm
  // no-ops (returns null) if one already exists, enforcing the rule
  // in-store too, not just at the DB's unique-column layer.
  createPartnerForm: (input: { partnerType: PartnerType; name: string; selectedItemIds: string[]; status: "Draft" | "Active" }) => string | null;
  updatePartnerForm: (id: string, patch: { name?: string; selectedItemIds?: string[]; status?: "Draft" | "Active" }) => void;
};

export const useSettingsStore = create<SettingsState>((set, get) => ({
  teamMembers: [],
  partners: [],
  allocationCeiling: 0,
  projectStates: {},
  projectPartners: {},
  projectDistricts: {},
  partnerForms: [],
  partnerTeamMembers: [],
  partnerHistory: [],
  hydrated: false,
  hydrate: (state) =>
    set({
      ...state,
      partners: state.partners.map(normalizePartner),
      // Same "normalize whatever shape actually comes out of storage"
      // reasoning as normalizePartner above — a browser that saved settings
      // before this field existed has no partnerHistory key at all.
      partnerHistory: Array.isArray(state.partnerHistory) ? state.partnerHistory : [],
      hydrated: true,
    }),

  inviteMember: (member) =>
    set((s) => ({
      teamMembers: [...s.teamMembers, { ...member, id: uid("mem"), status: "Invited", invitedAt: new Date().toISOString() }],
    })),
  updateMember: (id, patch) =>
    set((s) => ({ teamMembers: s.teamMembers.map((m) => (m.id === id ? { ...m, ...patch } : m)) })),
  removeMember: (id) => set((s) => ({ teamMembers: s.teamMembers.filter((m) => m.id !== id) })),

  invitePartnerTeamMember: (member) => {
    const s = get();
    const dup = s.partnerTeamMembers.some(
      (m) => m.partnerOrgId === member.partnerOrgId && m.email.toLowerCase() === member.email.toLowerCase()
    );
    if (dup) return { ok: false, reason: "duplicate" };
    set((s) => ({
      partnerTeamMembers: [...s.partnerTeamMembers, { ...member, id: uid("ptm"), status: "Invited" }],
    }));
    return { ok: true };
  },
  updatePartnerTeamMember: (id, patch) =>
    set((s) => ({ partnerTeamMembers: s.partnerTeamMembers.map((m) => (m.id === id ? { ...m, ...patch } : m)) })),
  removePartnerTeamMember: (id) =>
    set((s) => ({ partnerTeamMembers: s.partnerTeamMembers.filter((m) => m.id !== id) })),

  invitePartner: (partner) => {
    const s = get();
    const existing = s.partners.find((p) => p.contactEmail.toLowerCase() === partner.contactEmail.toLowerCase());
    // Only a still-pre-onboarding invite (never submitted) is safe to
    // refresh in place — anything further along has real data a re-invite
    // must not touch.
    const reInvitable = !!existing && existing.status === "Invited" && !existing.reviewStatus;
    if (existing && !reInvitable) return { ok: false, reason: "duplicate" };

    if (existing) {
      const updated: PartnerOrg = {
        ...existing,
        name: partner.name,
        contactName: partner.contactName,
        contactEmail: partner.contactEmail,
        type: partner.type,
        inviteToken: uid("invite"),
        invitedAt: new Date().toISOString(),
        invitationCount: (existing.invitationCount ?? 1) + 1,
      };
      set((state) => ({ partners: state.partners.map((p) => (p.id === existing.id ? updated : p)) }));
      saveLastPartnerInvite({
        name: updated.name,
        contactName: updated.contactName,
        contactEmail: updated.contactEmail,
        type: updated.type,
        invitedAt: updated.invitedAt as string,
        workspaceId: updated.workspaceId,
      });
      return { ok: true, partner: updated };
    }

    const created: PartnerOrg = {
      ...partner,
      id: uid("ptn"),
      state: "",
      districts: [],
      status: "Invited",
      workspaceId: useSessionStore.getState().workspaceId ?? "",
      inviteToken: uid("invite"),
      invitedAt: new Date().toISOString(),
      invitationCount: 1,
    };
    set((state) => ({ partners: [...state.partners, created] }));
    saveLastPartnerInvite({
      name: created.name,
      contactName: created.contactName,
      contactEmail: created.contactEmail,
      type: created.type,
      invitedAt: created.invitedAt as string,
      workspaceId: created.workspaceId,
    });
    return { ok: true, partner: created };
  },
  updatePartner: (id, patch) =>
    set((s) => ({ partners: s.partners.map((p) => (p.id === id ? { ...p, ...patch } : p)) })),
  editPartner: (id, patch) => {
    const s = get();
    const existing = s.partners.find((p) => p.id === id);
    if (!existing) return { ok: false, reason: "not-found" };
    if (existing.status !== "Invited" || existing.reviewStatus) return { ok: false, reason: "not-editable" };
    const updated: PartnerOrg = { ...existing, ...patch };
    set((state) => ({ partners: state.partners.map((p) => (p.id === id ? updated : p)) }));
    persistNow(get());
    return { ok: true, partner: updated };
  },
  removePartner: (id) => set((s) => ({ partners: s.partners.filter((p) => p.id !== id) })),
  deactivatePartner: (id, reason) => {
    const trimmed = reason.trim();
    if (!trimmed) return { ok: false, reason: "invalid-reason" };
    const s = get();
    const existing = s.partners.find((p) => p.id === id);
    if (!existing) return { ok: false, reason: "not-found" };
    if (existing.status !== "Active") return { ok: false, reason: "not-active" };
    const session = useSessionStore.getState();
    const updated: PartnerOrg = {
      ...existing,
      status: "Inactive",
      deactivation: {
        reason: trimmed,
        deactivatedBy: { userId: session.userId ?? "", name: session.name ?? "", role: "sponsor" },
        deactivatedAt: new Date().toISOString(),
      },
    };
    const entry = buildHistoryEntry(id, "partner_deactivated", "Active", "Inactive", trimmed);
    set((state) => ({
      partners: state.partners.map((p) => (p.id === id ? updated : p)),
      partnerHistory: [entry, ...state.partnerHistory],
    }));
    persistNow(get());
    return { ok: true, partner: updated };
  },
  reactivatePartner: (id) => {
    const s = get();
    const existing = s.partners.find((p) => p.id === id);
    if (!existing) return { ok: false, reason: "not-found" };
    if (existing.status !== "Inactive") return { ok: false, reason: "not-inactive" };
    const updated: PartnerOrg = { ...existing, status: "Active" };
    // A Rejected-review outcome never actually WAS Active before — this is
    // that partner's first time becoming Active ("Partner Activated"). A
    // manual prior Deactivate means they WERE Active before and are
    // returning to it ("Partner Reactivated"). Both land on the same
    // "Activate Partner" button/status bucket, but the history log keeps
    // the distinction the ticket calls for.
    const wasRejected = existing.reviewStatus === "Rejected";
    const entry = buildHistoryEntry(
      id,
      wasRejected ? "partner_activated" : "partner_reactivated",
      wasRejected ? "Rejected" : "Inactive",
      "Active"
    );
    set((state) => ({
      partners: state.partners.map((p) => (p.id === id ? updated : p)),
      partnerHistory: [entry, ...state.partnerHistory],
    }));
    persistNow(get());
    return { ok: true, partner: updated };
  },
  cancelPartnerInvitation: (id) => {
    const s = get();
    const existing = s.partners.find((p) => p.id === id);
    if (!existing) return { ok: false, reason: "not-found" };
    if (existing.status !== "Invited" || existing.reviewStatus) return { ok: false, reason: "not-invited" };
    set((state) => ({ partners: state.partners.filter((p) => p.id !== id) }));
    persistNow(get());
    return { ok: true };
  },
  reinvitePartner: (id) => {
    const s = get();
    const existing = s.partners.find((p) => p.id === id);
    if (!existing) return { ok: false, reason: "not-found" };
    // Same guard as the Copy Invite Link/Cancel Invitation actions: only a
    // still-pre-submission invite (status "Invited", never submitted) has a
    // live invite to resend. Name/contactName/type/contactEmail are left
    // untouched — unlike invitePartner's email-matched branch, this never
    // takes fresh values from a form, so there's nothing to update but the
    // invite itself.
    if (existing.status !== "Invited" || existing.reviewStatus) return { ok: false, reason: "not-invited" };
    const updated: PartnerOrg = {
      ...existing,
      inviteToken: uid("invite"),
      invitedAt: new Date().toISOString(),
      invitationCount: (existing.invitationCount ?? 1) + 1,
    };
    set((state) => ({ partners: state.partners.map((p) => (p.id === id ? updated : p)) }));
    saveLastPartnerInvite({
      name: updated.name,
      contactName: updated.contactName,
      contactEmail: updated.contactEmail,
      type: updated.type,
      invitedAt: updated.invitedAt as string,
      workspaceId: updated.workspaceId,
    });
    persistNow(get());
    return { ok: true, partner: updated };
  },
  findPartnerByInviteToken: (token) => get().partners.find((p) => p.inviteToken === token),
  activatePartner: (id, input) => {
    set((s) => ({
      partners: s.partners.map((p) =>
        p.id === id
          ? {
              ...p,
              name: input.name,
              contactName: input.contactName,
              state: input.state,
              districts: input.districts,
              // Submitting onboarding no longer activates the account
              // directly — it now goes to the Sponsor for review (see
              // approvePartnerReview/requestPartnerChanges/rejectPartnerReview
              // below). `status` stays "Invited" (repurposed to also mean
              // "submitted, awaiting review") until the Sponsor approves.
              inviteToken: null,
              complianceDocuments: input.complianceDocuments,
              complianceStatus: complianceStatusFor(input.complianceDocuments, getRequiredItemIdsForPartner(p, s.partnerForms)),
              reviewStatus: "Pending Review",
              submittedAt: new Date().toISOString(),
              changeRequestMessage: null,
              rejectionReason: null,
            }
          : p
      ),
    }));
    persistNow(get());
  },

  uploadComplianceDocument: (partnerId, doc) => {
    const s = get();
    const partner = s.partners.find((p) => p.id === partnerId);
    if (!partner) return { ok: false, reason: "not-found" };

    const existingDocs = partner.complianceDocuments ?? [];
    // The doc this one replaces (same non-"Other" type) — its fileId, if
    // any, is now orphaned in complianceFileStore.ts's IndexedDB once we
    // commit below; the caller deletes it there.
    const replaced = doc.type === "Other" ? undefined : existingDocs.find((d) => d.type === doc.type);
    const nextDocs =
      doc.type === "Other" ? [...existingDocs, doc] : [...existingDocs.filter((d) => d.type !== doc.type), doc];
    // A successful upload/replace always sends the submission back to
    // Pending Review — same PartnerReviewStatus enum the onboarding
    // review workflow already uses, not a new status — so the Sponsor knows
    // there's an updated document to look at (e.g. after Request Changes),
    // and gets a matching alert below. Only for a partner that has actually
    // submitted onboarding (reviewStatus set) — a partner with none yet has
    // no Sponsor review to reset.
    const nextPartners = s.partners.map((p) =>
      p.id === partnerId
        ? {
            ...p,
            complianceDocuments: nextDocs,
            complianceStatus: complianceStatusFor(nextDocs, getRequiredItemIdsForPartner(p, s.partnerForms)),
            ...(p.reviewStatus
              ? { reviewStatus: "Pending Review" as const, changeRequestMessage: null, rejectionReason: null }
              : {}),
          }
        : p
    );
    // One consolidated Alert per (Sponsor, Partner) compliance update, not
    // one per document — pushIfNoUnread piggybacks a second/third/...
    // document upload/replace in the same round onto the existing unread
    // alert instead of creating another; once the Sponsor reads/dismisses
    // it, the next successful upload/replace is free to create a fresh one.
    // Only for a partner that has actually submitted onboarding
    // (reviewStatus set) — a partner with none yet has no Sponsor review to
    // alert about. This is the ONE alert type that genuinely can't be
    // derived from a state snapshot (see alertRules.ts's
    // DERIVED_ALERT_TYPES comment) — settingsStore is the sole place that
    // pushes it.
    if (partner.reviewStatus) {
      useAlertStore.getState().pushIfNoUnread({
        key: `compliance_document_uploaded:partner:${partner.id}`,
        type: "compliance_document_uploaded",
        category: "partner",
        severity: "high",
        title: "Compliance document requires review",
        message: `${partner.name} has uploaded a new document in compliances. Review the document and update its status.`,
        targetRole: "sponsor",
        entityType: "partner",
        entityId: partner.id,
        action: { label: "Review Compliance", route: "/partners" },
      });
    }

    // A ComplianceDocument now only carries a small `fileId` reference (the
    // actual bytes live in IndexedDB — see complianceFileStore.ts's header
    // comment for why), so this write is tiny regardless of how many
    // documents exist or how large the underlying files are. Still persisted
    // eagerly with our OWN try/catch (not persistNow's, which swallows the
    // error and only logs it) as a safety net against the surrounding
    // settingsStore data (many partners/forms/team members) somehow being
    // large for unrelated reasons — a quota failure is caught and reported
    // immediately, with the in-memory state left untouched, rather than the
    // debounced subscriber below silently failing later.
    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem("bimpact:settings", JSON.stringify({ ...s, partners: nextPartners }));
      } catch {
        return { ok: false, reason: "quota" };
      }
    }

    set(() => ({ partners: nextPartners }));
    return { ok: true, replacedFileId: replaced?.fileId };
  },

  acceptComplianceDocument: (partnerId, type, fileId) => {
    const s = get();
    const partner = s.partners.find((p) => p.id === partnerId);
    if (!partner) return { ok: false, reason: "not-found" };
    const docs = partner.complianceDocuments ?? [];
    const idx = findComplianceDocIndex(docs, type, fileId);
    if (idx === -1) return { ok: false, reason: "not-found" };
    const doc = docs[idx];
    const session = useSessionStore.getState();
    const performedBy = { userId: session.userId ?? "", name: session.name ?? "", role: "sponsor" as const };
    const updatedDoc: ComplianceDocument = {
      ...doc,
      reviewStatus: "Accepted",
      review: { action: "accepted", reason: null, performedBy, performedAt: new Date().toISOString() },
    };
    const nextDocs = docs.map((d, i) => (i === idx ? updatedDoc : d));
    const label = doc.documentName || getComplianceDocLabel(type);
    const entry = buildHistoryEntry(partnerId, "document_accepted", doc.reviewStatus ?? "Pending Review", "Accepted", null, {
      documentType: type,
      documentLabel: label,
      documentFileId: doc.fileId ?? null,
    });
    set((state) => ({
      partners: state.partners.map((p) => (p.id === partnerId ? { ...p, complianceDocuments: nextDocs } : p)),
      partnerHistory: [entry, ...state.partnerHistory],
    }));
    persistNow(get());
    return { ok: true };
  },

  rejectComplianceDocument: (partnerId, type, fileId, reason) => {
    const trimmed = reason.trim();
    if (!trimmed) return { ok: false, reason: "invalid-reason" };
    const s = get();
    const partner = s.partners.find((p) => p.id === partnerId);
    if (!partner) return { ok: false, reason: "not-found" };
    const docs = partner.complianceDocuments ?? [];
    const idx = findComplianceDocIndex(docs, type, fileId);
    if (idx === -1) return { ok: false, reason: "not-found" };
    const doc = docs[idx];
    const session = useSessionStore.getState();
    const performedBy = { userId: session.userId ?? "", name: session.name ?? "", role: "sponsor" as const };
    const updatedDoc: ComplianceDocument = {
      ...doc,
      reviewStatus: "Rejected",
      review: { action: "rejected", reason: trimmed, performedBy, performedAt: new Date().toISOString() },
    };
    const nextDocs = docs.map((d, i) => (i === idx ? updatedDoc : d));
    const label = doc.documentName || getComplianceDocLabel(type);
    const entry = buildHistoryEntry(partnerId, "document_rejected", doc.reviewStatus ?? "Pending Review", "Rejected", trimmed, {
      documentType: type,
      documentLabel: label,
      documentFileId: doc.fileId ?? null,
    });
    set((state) => ({
      partners: state.partners.map((p) => (p.id === partnerId ? { ...p, complianceDocuments: nextDocs } : p)),
      partnerHistory: [entry, ...state.partnerHistory],
    }));
    // Document-level notification, not a Partner-level alert — the Partner
    // needs to know THIS specific document was rejected (see spec section
    // 11). One-shot/repeatable event (pushHistoryEvent, same pattern as
    // "ownership changed"), never collapsed into an earlier unread alert —
    // every rejection is its own distinct fact.
    useAlertStore.getState().pushHistoryEvent({
      key: `document_rejected:partner:${partnerId}:${doc.fileId ?? type}`,
      type: "document_rejected",
      category: "partner",
      severity: "high",
      title: "Document Rejected",
      message: `Your ${label} has been rejected. Reason: ${trimmed}`,
      targetRole: "partner",
      targetPartnerOrgId: partnerId,
      entityType: "partner",
      entityId: partnerId,
      action: { label: "View Compliance", route: "/compliance" },
    });
    persistNow(get());
    return { ok: true };
  },

  requestComplianceDocumentChanges: (partnerId, type, fileId, reason) => {
    const trimmed = reason.trim();
    if (!trimmed) return { ok: false, reason: "invalid-reason" };
    const s = get();
    const partner = s.partners.find((p) => p.id === partnerId);
    if (!partner) return { ok: false, reason: "not-found" };
    const docs = partner.complianceDocuments ?? [];
    const idx = findComplianceDocIndex(docs, type, fileId);
    if (idx === -1) return { ok: false, reason: "not-found" };
    const doc = docs[idx];
    const session = useSessionStore.getState();
    const performedBy = { userId: session.userId ?? "", name: session.name ?? "", role: "sponsor" as const };
    const updatedDoc: ComplianceDocument = {
      ...doc,
      reviewStatus: "Changes Requested",
      review: { action: "changes_requested", reason: trimmed, performedBy, performedAt: new Date().toISOString() },
    };
    const nextDocs = docs.map((d, i) => (i === idx ? updatedDoc : d));
    const label = doc.documentName || getComplianceDocLabel(type);
    const entry = buildHistoryEntry(
      partnerId,
      "document_changes_requested",
      doc.reviewStatus ?? "Pending Review",
      "Changes Requested",
      trimmed,
      { documentType: type, documentLabel: label, documentFileId: doc.fileId ?? null }
    );
    set((state) => ({
      partners: state.partners.map((p) => (p.id === partnerId ? { ...p, complianceDocuments: nextDocs } : p)),
      partnerHistory: [entry, ...state.partnerHistory],
    }));
    useAlertStore.getState().pushHistoryEvent({
      key: `document_changes_requested:partner:${partnerId}:${doc.fileId ?? type}`,
      type: "document_changes_requested",
      category: "partner",
      severity: "high",
      title: "Document Changes Requested",
      message: `Changes have been requested for your ${label}. Please review the Sponsor's comments and upload an updated document. Sponsor's comments: ${trimmed}`,
      targetRole: "partner",
      targetPartnerOrgId: partnerId,
      entityType: "partner",
      entityId: partnerId,
      action: { label: "View Compliance", route: "/compliance" },
    });
    persistNow(get());
    return { ok: true };
  },

  registerPartner: (input) => {
    const s = get();
    const existing = s.partners.find((p) => p.contactEmail.toLowerCase() === input.contactEmail.toLowerCase());
    // A still-pending Sponsor invite (never submitted — see invitePartner's
    // own identical "reInvitable" check) is NOT a real duplicate here: it's
    // exactly the case the user asked for — an invited partner completing
    // their registration through the self-serve portal instead of using
    // their actual invite link. Only a partner who has already submitted
    // (reviewStatus set) or is Active/Inactive is a genuine duplicate.
    const pendingInvite = !!existing && existing.status === "Invited" && !existing.reviewStatus;
    if (existing && !pendingInvite) return { ok: false, reason: "duplicate" };

    if (existing) {
      // Complete that SAME invite record in place — same fields
      // activatePartner sets for the invite-token path, so both routes to
      // "finish onboarding" land in the identical state. Keeps the
      // existing id/workspaceId (the real Sponsor relationship the invite
      // already established) rather than creating a second, disconnected
      // partner row for the same organization.
      const completed: PartnerOrg = {
        ...existing,
        name: input.name,
        contactName: input.contactName,
        contactEmail: input.contactEmail,
        type: input.type,
        state: input.state,
        districts: input.districts,
        inviteToken: null,
        complianceDocuments: input.complianceDocuments,
        complianceStatus: complianceStatusFor(input.complianceDocuments, getActiveChecklistForPartnerType(s.partnerForms, input.type)?.selectedItemIds ?? []),
        reviewStatus: "Pending Review",
        submittedAt: new Date().toISOString(),
        changeRequestMessage: null,
        rejectionReason: null,
      };
      set((state) => ({ partners: state.partners.map((p) => (p.id === existing.id ? completed : p)) }));
      persistNow(get());
      return { ok: true, partner: completed };
    }

    const partner: PartnerOrg = {
      id: uid("ptn"),
      name: input.name,
      contactName: input.contactName,
      contactEmail: input.contactEmail,
      state: input.state,
      districts: input.districts,
      type: input.type,
      // Self-serve sign-up also goes to the Sponsor for review now, same as
      // the invite flow — not activated directly. "Invited" here just means
      // "not yet operationally active", there being no real invite in this path.
      status: "Invited",
      workspaceId: DEFAULT_DEMO_WORKSPACE_ID,
      inviteToken: null,
      invitedAt: null,
      complianceDocuments: input.complianceDocuments,
      complianceStatus: complianceStatusFor(input.complianceDocuments, getActiveChecklistForPartnerType(s.partnerForms, input.type)?.selectedItemIds ?? []),
      reviewStatus: "Pending Review",
      submittedAt: new Date().toISOString(),
      reviewedAt: null,
      changeRequestMessage: null,
      rejectionReason: null,
    };
    set((s) => ({ partners: [...s.partners, partner] }));
    persistNow(get());
    return { ok: true, partner };
  },

  approvePartnerReview: (id) => {
    const previous = get().partners.find((p) => p.id === id);
    const entry = buildHistoryEntry(id, "partner_approved", previous?.reviewStatus ?? "Pending Review", "Active");
    set((s) => ({
      partners: s.partners.map((p) =>
        p.id === id
          ? {
              ...p,
              reviewStatus: "Approved",
              status: "Active",
              reviewedAt: new Date().toISOString(),
              changeRequestMessage: null,
              rejectionReason: null,
            }
          : p
      ),
      partnerHistory: [entry, ...s.partnerHistory],
    }));
    persistNow(get());
  },
  requestPartnerChanges: (id, message) => {
    const previous = get().partners.find((p) => p.id === id);
    const entry = buildHistoryEntry(
      id,
      "change_request",
      previous?.reviewStatus ?? "Pending Review",
      "Changes Requested",
      message
    );
    set((s) => ({
      partners: s.partners.map((p) =>
        p.id === id
          ? {
              ...p,
              reviewStatus: "Changes Requested",
              reviewedAt: new Date().toISOString(),
              changeRequestMessage: message,
              rejectionReason: null,
            }
          : p
      ),
      partnerHistory: [entry, ...s.partnerHistory],
    }));
    persistNow(get());
  },
  rejectPartnerReview: (id, reason) => {
    const previous = get().partners.find((p) => p.id === id);
    const entry = buildHistoryEntry(id, "partner_rejected", previous?.reviewStatus ?? "Pending Review", "Rejected", reason);
    set((s) => ({
      partners: s.partners.map((p) =>
        p.id === id
          ? {
              ...p,
              reviewStatus: "Rejected",
              status: "Inactive",
              reviewedAt: new Date().toISOString(),
              rejectionReason: reason,
              changeRequestMessage: null,
            }
          : p
      ),
      partnerHistory: [entry, ...s.partnerHistory],
    }));
    persistNow(get());
  },

  markComplianceDocumentViewed: (partnerId, type) => {
    set((s) => ({
      partners: s.partners.map((p) => {
        if (p.id !== partnerId) return p;
        const docs = p.complianceDocuments ?? [];
        const idx = docs.findIndex((d) => d.type === type);
        if (idx === -1) return p;
        return {
          ...p,
          complianceDocuments: docs.map((d, i) => (i === idx ? { ...d, viewedBySponsorAt: new Date().toISOString() } : d)),
        };
      }),
    }));
    persistNow(get());
  },
  markOtherComplianceDocumentViewed: (partnerId, fileId) => {
    set((s) => ({
      partners: s.partners.map((p) => {
        if (p.id !== partnerId) return p;
        const docs = p.complianceDocuments ?? [];
        const idx = docs.findIndex((d) => d.type === "Other" && d.fileId === fileId);
        if (idx === -1) return p;
        return {
          ...p,
          complianceDocuments: docs.map((d, i) => (i === idx ? { ...d, viewedBySponsorAt: new Date().toISOString() } : d)),
        };
      }),
    }));
    persistNow(get());
  },

  setCeiling: (amount) => set({ allocationCeiling: amount }),

  setProjectStates: (projectId, states) =>
    set((s) => ({ projectStates: { ...s.projectStates, [projectId]: states } })),
  setProjectPartners: (projectId, partners) =>
    set((s) => {
      // Defense in depth: silently drop any name that doesn't resolve to a
      // currently-eligible (Active + Approved, or pre-review-workflow
      // Active) partner, so an ineligible assignment can't be recorded even
      // via a direct call bypassing CreateProjectSlideOver's own dropdown
      // filter and submit-time check. See src/lib/partnerEligibility.ts.
      const eligibleNames = new Set(
        s.partners.filter(isPartnerEligibleForAssignment).map((p) => p.name)
      );
      const filtered = partners.filter((name) => eligibleNames.has(name));
      return { projectPartners: { ...s.projectPartners, [projectId]: filtered } };
    }),
  setProjectDistricts: (projectId, districts) =>
    set((s) => ({ projectDistricts: { ...s.projectDistricts, [projectId]: districts } })),

  createPartnerForm: (input) => {
    const id = uid("pform");
    let created = false;
    set((s) => {
      if (s.partnerForms.some((f) => f.partnerType === input.partnerType)) return s;
      created = true;
      const today = new Date().toISOString().slice(0, 10);
      return {
        partnerForms: [
          ...s.partnerForms,
          { id, partnerType: input.partnerType, name: input.name, selectedItemIds: input.selectedItemIds, status: input.status, version: 1, createdAt: today, updatedAt: today },
        ],
      };
    });
    return created ? id : null;
  },
  updatePartnerForm: (id, patch) =>
    set((s) => ({
      partnerForms: s.partnerForms.map((f) =>
        f.id === id ? { ...f, ...patch, version: f.version + 1, updatedAt: new Date().toISOString().slice(0, 10) } : f
      ),
    })),
}));

persistLocal("settings", useSettingsStore, (s) => ({
  teamMembers: s.teamMembers,
  partners: s.partners,
  allocationCeiling: s.allocationCeiling,
  projectStates: s.projectStates,
  projectPartners: s.projectPartners,
  projectDistricts: s.projectDistricts,
  partnerForms: s.partnerForms,
  partnerTeamMembers: s.partnerTeamMembers,
  partnerHistory: s.partnerHistory,
}));
