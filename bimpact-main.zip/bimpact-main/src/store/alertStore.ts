import { create } from "zustand";
import { Alert } from "@/types/alert";
import { persistLocal } from "@/lib/localPersist";
import { evaluateAlerts, AlertCandidate, DERIVED_ALERT_TYPES } from "@/lib/alertRules";
import { useProjectStore } from "@/store/projectStore";
import { useFinanceStore } from "@/store/financeStore";
import { useMeetingStore } from "@/store/meetingStore";
import { useSettingsStore } from "@/store/settingsStore";

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

type AlertState = {
  alerts: Alert[];
  hydrated: boolean;
  hydrate: (state: { alerts: Alert[] }) => void;

  markRead: (id: string) => void;
  // Marks every CURRENTLY VISIBLE unread alert as read — the caller (Alerts
  // page) passes the exact ids it's showing, since "visible" depends on the
  // current session's role/project access (alertVisibility.ts), which this
  // store has no concept of.
  markAllRead: (ids: string[]) => void;

  // Event-stamped path — pushed directly by the store action that causes the
  // alert (see alertRules.ts's header comment). Guards against pushing a
  // duplicate for the same dedup key while an unresolved one is already
  // active, same as the derived path's own dedup rule.
  pushEvent: (candidate: AlertCandidate) => void;
  // Same as pushEvent, but consolidates on "already has an UNREAD alert
  // with this key" rather than "unresolved" — for one-shot events with no
  // real resolved/active state of their own (e.g. a compliance document
  // upload), where the desired behavior is "pile onto the existing alert
  // while the Sponsor hasn't looked at it yet, but a fresh upload AFTER
  // they dismiss it should read as a new alert" — mirrors the pre-existing
  // PartnerComplianceNotification consolidation rule this replaces.
  pushIfNoUnread: (candidate: AlertCandidate) => void;
  // For discrete, repeatable events with no durable "active/resolved" state
  // of their own (e.g. "ownership changed" — every occurrence is a distinct
  // fact that must show up on its own, never collapsed into an earlier one).
  // Appends a store-generated unique suffix to the given `key` itself,
  // rather than asking the caller (always a React component for these) to
  // compute one — Date.now()/Math.random() are flagged as impure-during-
  // render by this app's react-hooks/purity lint rule when called from
  // component code, but this store file isn't a component and was already
  // exempt (see uid() above, used the same way by every other action here).
  pushHistoryEvent: (candidate: AlertCandidate) => void;

  // Derived/computed path — recomputes every threshold/state rule from
  // live store state (see alertRules.ts) and reconciles against the current
  // alerts list: a newly-true condition becomes a new unread alert; a
  // condition that's no longer true gets `resolvedAt` stamped (kept, not
  // deleted — spec 17.17); an already-active alert for a still-true
  // condition is left completely alone (read state, createdAt, etc. never
  // touched by re-evaluation).
  evaluate: () => void;
};

function applyCandidate(existing: Alert[], c: AlertCandidate): Alert[] {
  if (existing.some((a) => a.key === c.key && !a.resolvedAt)) return existing; // already active, don't duplicate
  const alert: Alert = { ...c, id: uid("alt"), isRead: false, createdAt: new Date().toISOString(), resolvedAt: null };
  return [alert, ...existing];
}

export const useAlertStore = create<AlertState>((set) => ({
  alerts: [],
  hydrated: false,
  hydrate: (state) => set({ alerts: state.alerts ?? [], hydrated: true }),

  markRead: (id) => set((s) => ({ alerts: s.alerts.map((a) => (a.id === id ? { ...a, isRead: true } : a)) })),
  markAllRead: (ids) => {
    const idSet = new Set(ids);
    set((s) => ({ alerts: s.alerts.map((a) => (idSet.has(a.id) ? { ...a, isRead: true } : a)) }));
  },

  pushEvent: (c) => set((s) => ({ alerts: applyCandidate(s.alerts, c) })),
  pushHistoryEvent: (c) =>
    set((s) => {
      const alert: Alert = {
        ...c,
        key: `${c.key}:${uid("evt")}`,
        id: uid("alt"),
        isRead: false,
        createdAt: new Date().toISOString(),
        resolvedAt: null,
      };
      return { alerts: [alert, ...s.alerts] };
    }),
  pushIfNoUnread: (c) =>
    set((s) => {
      if (s.alerts.some((a) => a.key === c.key && !a.isRead)) return s;
      const alert: Alert = { ...c, id: uid("alt"), isRead: false, createdAt: new Date().toISOString(), resolvedAt: null };
      return { alerts: [alert, ...s.alerts] };
    }),

  evaluate: () => {
    const { projects, wbs, indicatorForms, indicatorFormResponses, indicatorFormShareLinks } = useProjectStore.getState();

    // Finance data is normally lazy-seeded per project (ensureExpenses/
    // ensureDisbursements only run when a Finance page for that project
    // mounts — see financeStore.ts) — same gap the Reporting module hit and
    // fixed the same way (FundUtilizationReport.tsx). Alerts must reflect
    // every project regardless of which Finance pages the user has actually
    // opened, so force-seed all of them here before reading state.
    const finance = useFinanceStore.getState();
    projects.forEach((p, i) => {
      finance.ensureExpenses(p.id);
      finance.ensureDisbursements(p.id, i);
    });
    const { expenses, disbursements, periodBudgets } = useFinanceStore.getState();
    const { meetings } = useMeetingStore.getState();
    const { partners, teamMembers } = useSettingsStore.getState();

    const candidates = evaluateAlerts({
      projects,
      wbs,
      indicatorForms,
      indicatorFormResponses,
      indicatorFormShareLinks,
      expenses,
      disbursements,
      periodBudgets,
      meetings,
      partners,
      teamMembers,
    });
    const liveKeys = new Set(candidates.map((c) => c.key));

    set((s) => {
      // Resolve any currently-active DERIVED alert whose condition is no
      // longer true. Event-only alerts (not in DERIVED_ALERT_TYPES, e.g.
      // "compliance_document_uploaded") are never touched here — they have
      // no snapshot-computable condition to check against. Partner-targeted
      // alerts (targetPartnerOrgId set — first-login nudge, changes
      // requested, approved, micro-budget assigned) are also never
      // auto-resolved: once one of these appears in a Partner's own Alerts
      // list, it stays there — per explicit product decision, a Partner's
      // history of what's happened to their org/submission shouldn't
      // silently disappear just because the underlying condition later
      // changed (e.g. they finish uploading, or get re-reviewed). They can
      // still be marked read individually.
      let next = s.alerts.map((a) =>
        !a.resolvedAt && !a.targetPartnerOrgId && DERIVED_ALERT_TYPES.has(a.type) && !liveKeys.has(a.key)
          ? { ...a, resolvedAt: new Date().toISOString() }
          : a
      );
      // Add any newly-true condition that isn't already active.
      for (const c of candidates) next = applyCandidate(next, c);
      return { alerts: next };
    });
  },
}));

persistLocal("alerts", useAlertStore, (s) => ({ alerts: s.alerts }));
