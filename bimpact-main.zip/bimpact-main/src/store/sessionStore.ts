import { create } from "zustand";
import { persistLocal } from "@/lib/localPersist";
import { DEFAULT_DEMO_WORKSPACE_ID, useWorkspaceStore } from "@/store/workspaceStore";
import { useShellStore } from "@/store/shellStore";
import { useSettingsStore, persistNow as persistSettingsNow } from "@/store/settingsStore";
import { PartnerOrg } from "@/types/settings";

export type UserRole = "sponsor" | "partner";
// This product only supports email/password sign-up — no OAuth/social
// registration — so "email" is the only method an account can ever have.
export type AuthMethod = "email";
export type VerificationStatus = "none" | "pending" | "verified" | "expired";
export type RegisteredAccount = { email: string; method: AuthMethod };

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

function sameEmail(a: string, b: string): boolean {
  return a.toLowerCase() === b.toLowerCase();
}

type PersistedSessionState = {
  authenticated: boolean;
  role: UserRole | null;
  name: string | null;
  email: string | null;
  userId: string | null;
  authMethod: AuthMethod | null;
  emailVerified: boolean;
  onboardingComplete: boolean;
  workspaceId: string | null;
  verificationStatus: VerificationStatus;
  registeredAccounts: RegisteredAccount[];
  partnerOrgId: string | null;
};

type SessionState = PersistedSessionState & {
  hydrated: boolean;
  // Transient (never persisted) — lets AppShell's single redirect effect tell
  // "just logged out" apart from "never authenticated" without a second
  // navigator racing it (see AppShell.tsx).
  justLoggedOut: boolean;
  hydrate: (state: Partial<PersistedSessionState>) => void;
  login: (role: UserRole, email: string, name?: string) => void;
  loginAsPartner: (partner: PartnerOrg) => void;
  loginWithCredentials: (
    email: string,
    password: string
  ) => { ok: true; role: UserRole } | { ok: false; reason: "invalid" };
  logout: () => void;
  clearJustLoggedOut: () => void;
  findAccountByEmail: (email: string) => RegisteredAccount | undefined;
  registerWithEmail: (
    name: string,
    email: string,
    password: string
  ) => { ok: true; userId: string } | { ok: false; reason: "duplicate" };
  verifyEmail: () => void;
  markVerificationExpired: () => void;
  resendVerification: () => void;
  completeOnboarding: (input: {
    userType: "sponsor" | "partner" | "";
    jobRole: string;
    companyName: string;
    baseline: { teamMembers: number; partners: number; committeeMembers: number; projects: number };
  }) => string;
};

const DEFAULT_PERSISTED: PersistedSessionState = {
  authenticated: false,
  role: null,
  name: null,
  email: null,
  userId: null,
  authMethod: null,
  emailVerified: false,
  onboardingComplete: false,
  workspaceId: null,
  verificationStatus: "none",
  registeredAccounts: [],
  partnerOrgId: null,
};

// login/logout (and every other mutating action here) persist synchronously
// (not through the debounced subscriber below) because they're immediately
// followed by a hard `window.location` navigation at the call site — a
// debounced write could get cancelled by the page unloading before its
// timer fires.
function persistNow(state: PersistedSessionState) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem("bimpact:session", JSON.stringify(state));
  } catch {
    // best-effort — matches localPersist.ts's own swallow-and-log approach
  }
}

function persistedSlice(s: SessionState): PersistedSessionState {
  return {
    authenticated: s.authenticated,
    role: s.role,
    name: s.name,
    email: s.email,
    userId: s.userId,
    authMethod: s.authMethod,
    emailVerified: s.emailVerified,
    onboardingComplete: s.onboardingComplete,
    workspaceId: s.workspaceId,
    verificationStatus: s.verificationStatus,
    registeredAccounts: s.registeredAccounts,
    partnerOrgId: s.partnerOrgId,
  };
}

export const useSessionStore = create<SessionState>((set, get) => ({
  ...DEFAULT_PERSISTED,
  hydrated: false,
  justLoggedOut: false,
  hydrate: (state) => set({ ...DEFAULT_PERSISTED, ...state, hydrated: true }),

  login: (role, email, name) => {
    const s = get();
    const existing = s.findAccountByEmail(email);
    const registeredAccounts = existing
      ? s.registeredAccounts
      : [...s.registeredAccounts, { email, method: "email" as AuthMethod }];
    set({
      authenticated: true,
      role,
      email,
      name: name ?? null,
      justLoggedOut: false,
      userId: s.userId ?? uid("usr"),
      authMethod: "email",
      emailVerified: true,
      onboardingComplete: true,
      workspaceId: DEFAULT_DEMO_WORKSPACE_ID,
      verificationStatus: "verified",
      registeredAccounts,
    });
    persistNow(persistedSlice(get()));
  },

  loginAsPartner: (partner) => {
    set({
      authenticated: true,
      role: "partner",
      email: partner.contactEmail,
      name: partner.contactName,
      justLoggedOut: false,
      userId: uid("usr"),
      authMethod: "email",
      emailVerified: true,
      onboardingComplete: true,
      workspaceId: partner.workspaceId,
      partnerOrgId: partner.id,
      verificationStatus: "verified",
    });
    persistNow(persistedSlice(get()));
    // Stamped exactly once, on this partner's very first login ever (this
    // action fires on EVERY subsequent login too — see loginWithCredentials
    // below — so the guard matters). Powers the one-time "welcome, upload
    // your compliance documents" alert (alertRules.ts's partnerAlerts) —
    // derived off this timestamp rather than a separate event push, so it
    // stays consistent with every other permanent-state alert in this app.
    if (!partner.firstLoginAt) {
      useSettingsStore.getState().updatePartner(partner.id, { firstLoginAt: new Date().toISOString() });
      // Synchronous write, not the debounced subscriber — loginWithCredentials's
      // caller (LoginForm.tsx) does a hard `window.location` navigation right
      // after this returns, which would otherwise cancel settingsStore's
      // normal 400ms-debounced persist before it ever fires, silently
      // dropping the stamp (confirmed: the in-memory update took effect, but
      // never survived the immediate navigation without this).
      persistSettingsNow(useSettingsStore.getState());
    }
  },

  // Unified login entry point for the single Email + Password screen — auto-
  // detects role by matching the email against settingsStore's partner
  // directory (case-insensitively) instead of asking the user to pick
  // Sponsor vs. Partner. A match logs in via loginAsPartner (which owns the
  // partner-specific workspaceId/partnerOrgId wiring); anything else falls
  // back to the existing sponsor login. No real password check exists
  // anywhere in this mock app — password is required only to be non-empty.
  loginWithCredentials: (email, password) => {
    if (!email.trim() || !password) return { ok: false, reason: "invalid" };
    const partner = useSettingsStore
      .getState()
      .partners.find((p) => sameEmail(p.contactEmail, email));
    if (partner) {
      get().loginAsPartner(partner);
      return { ok: true, role: "partner" };
    }
    get().login("sponsor", email);
    return { ok: true, role: "sponsor" };
  },

  logout: () => {
    set({
      authenticated: false,
      role: null,
      name: null,
      email: null,
      justLoggedOut: true,
      userId: null,
      authMethod: null,
      emailVerified: false,
      onboardingComplete: false,
      workspaceId: null,
      verificationStatus: "none",
      partnerOrgId: null,
      // registeredAccounts is the persistent mock directory, not per-session
      // state — deliberately not cleared here.
    });
    persistNow(persistedSlice(get()));
  },

  clearJustLoggedOut: () => set({ justLoggedOut: false }),

  findAccountByEmail: (email) => get().registeredAccounts.find((a) => sameEmail(a.email, email)),

  // Password is accepted (matching the store's public signature/contract)
  // but this app has no backend to hash/store it against — every other mock
  // auth form here (the unified LoginForm, the register page) is equally
  // password-optional.
  registerWithEmail: (name, email) => {
    const s = get();
    if (s.findAccountByEmail(email)) return { ok: false, reason: "duplicate" };
    const userId = uid("usr");
    set({
      authenticated: true,
      userId,
      name,
      email,
      authMethod: "email",
      emailVerified: false,
      onboardingComplete: false,
      verificationStatus: "pending",
      role: "sponsor",
      registeredAccounts: [...s.registeredAccounts, { email, method: "email" }],
    });
    persistNow(persistedSlice(get()));
    return { ok: true, userId };
  },

  verifyEmail: () => {
    set({ emailVerified: true, verificationStatus: "verified" });
    persistNow(persistedSlice(get()));
  },

  markVerificationExpired: () => {
    set({ verificationStatus: "expired" });
    persistNow(persistedSlice(get()));
  },

  resendVerification: () => {
    set({ verificationStatus: "pending" });
    persistNow(persistedSlice(get()));
  },

  completeOnboarding: (input) => {
    const s = get();
    const workspaceId = useWorkspaceStore.getState().createWorkspace({
      name: input.companyName,
      ownerUserId: s.userId ?? uid("usr"),
      baseline: input.baseline,
    });
    if (input.jobRole) useShellStore.getState().setRole(input.jobRole);
    set({ workspaceId, onboardingComplete: true, role: "sponsor" });
    persistNow(persistedSlice(get()));
    return workspaceId;
  },
}));

persistLocal("session", useSessionStore, persistedSlice);
