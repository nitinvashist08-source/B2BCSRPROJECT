import { create } from "zustand";
import { persistLocal } from "@/lib/localPersist";

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

export const DEFAULT_DEMO_WORKSPACE_ID = "ws-demo";

export type ChecklistBaseline = {
  teamMembers: number;
  partners: number;
  committeeMembers: number;
  projects: number;
};

export type Workspace = {
  id: string;
  name: string;
  type: "corporate";
  ownerUserId: string;
  // Snapshot of team/partner/committee/project counts at creation time, so
  // the one-time "getting started" step (end of /onboarding) can tell
  // "done since signup" apart from "already existed in the shared demo
  // data" — see GettingStartedStep.tsx. Stored on the workspace record
  // (not component state) deliberately: /onboarding remounts with a fresh
  // component instance partway through the flow (AppShell swaps from a
  // standalone layout to the full Sidebar/Header shell the moment
  // onboardingComplete flips true, which changes enough of the surrounding
  // JSX structure that React can't preserve the page's local state across
  // it) — anything the getting-started step needs has to survive that,
  // so it lives here instead of in useState.
  checklistBaseline: ChecklistBaseline;
};

type WorkspaceState = {
  workspaces: Workspace[];
  hydrated: boolean;
  hydrate: (state: { workspaces: Workspace[] }) => void;
  createWorkspace: (input: { name: string; ownerUserId: string; baseline: ChecklistBaseline }) => string;
  getWorkspace: (id: string) => Workspace | undefined;
};

// createWorkspace persists synchronously (not through the debounced
// subscriber below) because sessionStore.completeOnboarding — its only
// caller — immediately follows it with a hard `window.location` navigation:
// a debounced write's timer can get cancelled by the page unloading first,
// silently dropping the new workspace (session.workspaceId would then point
// at a workspace that was never actually saved). Same reasoning/pattern as
// sessionStore's login/logout.
function persistNow(workspaces: Workspace[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem("bimpact:workspace", JSON.stringify({ workspaces }));
  } catch {
    // best-effort — matches localPersist.ts's own swallow-and-log approach
  }
}

export const useWorkspaceStore = create<WorkspaceState>((set, get) => ({
  workspaces: [],
  hydrated: false,
  hydrate: (state) => set({ ...state, hydrated: true }),

  // Do not create duplicate workspaces if the account already has one.
  createWorkspace: (input) => {
    const existing = get().workspaces.find((w) => w.ownerUserId === input.ownerUserId);
    if (existing) return existing.id;
    const id = uid("ws");
    const workspace: Workspace = {
      id,
      name: input.name,
      type: "corporate",
      ownerUserId: input.ownerUserId,
      checklistBaseline: input.baseline,
    };
    const workspaces = [...get().workspaces, workspace];
    set({ workspaces });
    persistNow(workspaces);
    return id;
  },

  getWorkspace: (id) => get().workspaces.find((w) => w.id === id),
}));

persistLocal("workspace", useWorkspaceStore, (s) => ({
  workspaces: s.workspaces,
}));
