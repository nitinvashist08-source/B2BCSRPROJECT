import { create } from "zustand";

// toggleMicro/expandAllMicro/collapseAllMicro, bImpact_MeetingSplit_v10.html:14526-14549.
// Deliberately NOT persisted — the original never remembers collapse state
// across a render either (see the MicroCategory type comment in
// types/finance.ts), it's pure ephemeral UI state.
type MicroUiState = {
  collapsedProjects: Set<string>;
  collapsedCategories: Set<string>;
  toggleProject: (id: string) => void;
  toggleCategory: (id: string) => void;
  expandAll: () => void;
  collapseAll: (categoryIds: string[], projectIds: string[]) => void;
};

export const useMicroUiStore = create<MicroUiState>((set) => ({
  collapsedProjects: new Set(),
  collapsedCategories: new Set(),
  toggleProject: (id) =>
    set((s) => {
      const next = new Set(s.collapsedProjects);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return { collapsedProjects: next };
    }),
  toggleCategory: (id) =>
    set((s) => {
      const next = new Set(s.collapsedCategories);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return { collapsedCategories: next };
    }),
  expandAll: () => set({ collapsedProjects: new Set(), collapsedCategories: new Set() }),
  collapseAll: (categoryIds, projectIds) => set({ collapsedProjects: new Set(projectIds), collapsedCategories: new Set(categoryIds) }),
}));
